# BUILD CHECKLIST | WAVE GUARD RC

## 빌드 정보
- 작성자: __________
- 작성 일시/시간대: __________
- Unity Editor 버전: 6000.3.x (실제 설치 버전 기입)
- Git Branch / SHA: __________ / __________
- Release candidate 버전: __________
- Windows Build Profile: __________
- Android Build Profile: __________
- Build Folder: __________

## 프로젝트/품질 사전 점검
- [ ] 변경 사항이 승인되었고 Git SHA가 기록됨
- [ ] Unity Console 컴파일 오류 0건
- [ ] Build Profiles의 Scene List (Title, Stage)가 정확함
- [ ] Title -> Stage -> Restart 경로 확인
- [ ] 92일차 회귀 테스트 결과 확보 (PASS / FAIL 수 기입)
- [ ] 93일차 성능 테스트 결과 확보 (기기/조건 포함)
- [ ] Product Name / Bundle Version / Icon 확인

## Windows Release
- [ ] Windows x64 프로파일 선택
- [ ] Development Build OFF 확인
- [ ] Build 성공 / 산출물 파일 확인
- [ ] EXE와 *_Data 및 기타 필요한 파일 동봉
- [ ] 에디터 없이 실행 성공
- [ ] Player.log 수집

## Android RC
- [ ] Android SDK / NDK / OpenJDK 설치 확인
- [ ] Package Name 및 버전 코드 확인
- [ ] IL2CPP / ARM64 설정 확인
- [ ] 키스토어·서명 준비 및 안전한 비밀 정보 관리
- [ ] Android APK 빌드 성공 / 파일 확인
- [ ] adb devices에 단말 'device'로 표시
- [ ] APK 실제 설치 및 실행 확인
- [ ] Logcat 수집
- [ ] 기기 모델 / OS / 해상도 기록

## 최종 승인
- [ ] 모든 필수 테스트 결과 표 작성
- [ ] 치명적/높음 우선순위의 미해결 결함 없음
- [ ] 빌드 산출물 SHA-256 해시 기록
- [ ] RELEASE_REPORT.md 작성
- 판정: **미결정 / GO / NO-GO**
- 승인자: __________
