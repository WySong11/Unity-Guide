# WAVE GUARD | RELEASE REPORT

## 1. 식별 정보
| 항목 | 값 |
|---|---|
| 후보 버전 | |
| Git SHA | |
| Unity 버전 | |
| Windows 프로파일 / 산출물 / SHA-256 | |
| Android 프로파일 / APK / SHA-256 | |
| 담당자 / 검증 일자 | |

## 2. 측정 및 실기기 환경
| Environment ID | 장치/OS | 빌드 유형 | 해상도 | 검증 시간 | 참고 사항 |
|---|---|---|---|---|---|
| WIN-01 | | | | | |
| AND-01 | | | | | |

## 3. 테스트 실행 요약
| 항목 | PASS | FAIL | BLOCKED | NOT_RUN |
|---|---:|---:|---:|---:|
| Windows | | | | |
| Android | | | | |

테스트 통과율 = PASS / (PASS + FAIL) × 100%; 실행률 = (PASS + FAIL + BLOCKED) / 전체 × 100% (수업 예시 정의). 시험 기준을 따로 선언하세요.

## 4. 성능 및 로그
- Windows FPS / Frame Time / 관측 조건:
- Android FPS / Frame Time / 발열 / 관측 조건:
- Windows Player.log 주요 경고/오류:
- Android Logcat 주요 경고/오류:
- Crash / ANR / 데이터 유실 여부:

## 5. 미해결 결함
| ID | Severity | 재현 방법 | 플랫폼 | 영향 | 후속 조치 |
|---|---|---|---|---|---|
| | | | | | |

## 6. Release Gate 판정
- [ ] G1 Windows 및 Android 필수 빌드 성공
- [ ] G2 필수 대상 기기 정상 시작
- [ ] G3 사용자 E2E 필수 흐름 전부 검증
- [ ] G4 미해결 치명적(P0/P1) 결함 없음
- [ ] G5 로그·파일 해시·시험 결과 증거 완비

**결론: 미결정 / GO / NO-GO**  
**결론 근거:**  
**승인자 / 시각:**

## 7. 증거 링크 및 제한 사항
- screenshots/:
- logs/:
- 테스트 미실행 사유:
- 테스트 범위 밖 항목:
