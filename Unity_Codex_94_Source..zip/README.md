# 94일차 | 최종 빌드 · 실행 검증 실습 자료

**과정:** UNITY × CODEX | AI GAME DEVELOPMENT  
**기준 환경:** Unity 6.3 LTS / WAVE GUARD / Windows x64 & Android  
**전제:** 85~93일차에 작성한 프로젝트가 있으며 빌드는 수강생 PC에서 직접 수행합니다.

## 권장 실습 순서
1. `templates/BUILD_CHECKLIST.md`에서 사전 점검을 수행합니다.
2. Unity `File > Build Profiles`에서 Windows Release 및 Android RC를 각각 빌드합니다.
3. `templates/DEVICE_MATRIX.csv`에 PC·Android 기기 정보를 적습니다.
4. `templates/TEST_RESULTS.csv`를 열고 실제 실행 결과를 `PASS/FAIL/BLOCKED/NOT_RUN`으로 기록합니다.
5. Windows `Player.log`와 Android Logcat을 수집합니다.
6. `templates/RELEASE_REPORT.md`를 작성하고 Go/No-Go를 결정합니다.

## 안내
- 자료의 체크 상태는 **모두 미확인**이며, 미실행 테스트를 PASS로 처리하지 마세요.
- 실제 앱의 Company/Product Name, Android Package Name, 버전은 프로젝트 설정에서 확인합니다.
- Keystore/비밀번호/Google API 비밀키 등은 ZIP·Git·보고서에 첨부하지 마세요.
- 로그 공유 전 개인정보·인증 토큰·민감 정보가 없는지 검사하세요.
- `Editor/ReleasePreflightAudit.cs`는 예시 Unity Editor 메뉴 도구입니다. 필요할 때 프로젝트의 `Assets/Editor` 아래로 복사한 후 사용하세요.
- Unity 프로젝트를 실제 빌드하거나 실행 검증한 결과물이 **아닙니다**.
