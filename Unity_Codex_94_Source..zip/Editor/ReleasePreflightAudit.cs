// Example Unity Editor-only audit. Copy to Assets/Editor/ in a Unity project.
// Reads project state and prints diagnostics; does not modify settings or build.
using UnityEditor;
using UnityEngine;

public static class ReleasePreflightAudit
{
    [MenuItem("Tools/WaveGuard/Release/Print Preflight")]
    public static void Print()
    {
        Debug.Log($"Unity: {Application.unityVersion}");
        Debug.Log($"Build Target: {EditorUserBuildSettings.activeBuildTarget}");
        Debug.Log($"Development Build: {EditorUserBuildSettings.development}");
        Debug.Log($"Product: {PlayerSettings.productName}");
        Debug.Log($"Company: {PlayerSettings.companyName}");
        Debug.Log($"Bundle Version: {PlayerSettings.bundleVersion}");

        foreach (var scene in EditorBuildSettings.scenes)
        {
            Debug.Log($"Scene: {scene.path} | Enabled: {scene.enabled}");
        }
        Debug.Log("Preflight inspection only. Build/run verification is not performed.");
    }
}
