# 94일차 Codex 프롬프트

## Prompt 1 — 읽기 전용 Release Readiness Audit
Unity 6.3 WAVE GUARD 프로젝트를 읽기 전용으로 점검해줘.
AGENTS.md를 우선 읽고, Build Profiles/Scene List/Player Settings/Android 서명 파일 노출 여부를 확인해줘.
Git SHA, Unity 버전, 미확인 설정, 92일차 테스트·93일차 성능 근거를 표로 정리해줘.
코드나 설정은 변경하지 말고, 실제 실행하지 않은 검증은 미실행이라고 명시해줘.

## Prompt 2 — 최소 수정으로 빌드 오류 대응
첨부한 Editor.log 또는 Android Gradle/IL2CPP 빌드 오류에서 최초 원인을 찾고, 연쇄 오류와 구분해줘.
증거가 있는 파일과 함수만 대상으로 최소 수정안을 제시해줘. 기존 SerializeField/Event/API 계약과 Git 상태를 보존해줘.
변경 후 Unity 컴파일·테스트·빌드·git diff --check를 점검하고 실행하지 못한 항목은 미실행으로 기록해줘.

## Prompt 3 — 독립 실행 결과 검토
첨부한 BUILD_CHECKLIST.md, TEST_RESULTS.csv, Player.log, Android Logcat, 93일차 성능 보고서를 검토해줘.
Windows·Android별 PASS/FAIL/BLOCKED/NOT_RUN을 분리하고, 크래시·ANR·저장·스킬·웨이브 회귀 위험을 판단해줘.
빌드 SHA/버전 불일치와 누락 증거를 지적하고 RELEASE_REPORT.md의 Go/No-Go 초안을 작성해줘.
검증되지 않은 상황을 PASS로 만들지 말고, 판단 근거와 추정을 구분해줘.
