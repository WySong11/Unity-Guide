using UnityEngine;

/// <summary>장면 시연 전용: 선택적 카메라 자동 공전. 기본적으로 비활성화.</summary>
public sealed class Day36CameraOrbit : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField, Range(0f, 30f)] private float degreesPerSecond = 8f;
    [SerializeField] private bool orbitEnabled;

    private void LateUpdate()
    {
        if (!orbitEnabled || target == null) return;
        transform.RotateAround(target.position, Vector3.up,
                               degreesPerSecond * Time.deltaTime);
        transform.LookAt(target.position);
    }
}
