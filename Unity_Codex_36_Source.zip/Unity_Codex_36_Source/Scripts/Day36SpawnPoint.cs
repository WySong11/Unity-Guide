using UnityEngine;

/// <summary>씬에서 시작 위치와 방향을 눈으로 확인하는 표시용 컴포넌트.</summary>
public sealed class Day36SpawnPoint : MonoBehaviour
{
    [SerializeField, Range(0.2f, 3f)] private float gizmoRadius = 0.65f;

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(transform.position, gizmoRadius);
        Gizmos.DrawLine(transform.position,
                        transform.position + transform.forward * 1.8f);
    }
}
