# 36일차 Codex 프롬프트 모음

## 프롬프트 A · 코드 작성 요청

Unity 6.3 URP 프로젝트에서 Editor 메뉴를 통해 3D 기본 씬을 생성하는 C# 도구를 작성해줘.
반드시 파일 변경 전 대상 경로 목록을 제시하고, 기존 씬이나 에셋을 덮어쓰지 마.
루트 이름 Day36_BasicLevel, 하위 01_Environment / 02_Obstacles / 03_Markers / 04_Systems.
18×18 바닥, 좌/우/후면 벽, 장애물 3개, PlayerSpawn, GoalMarker, Main Camera, Directional Light를 만든다.
Obstacle 프리팹 1개를 저장하고 3개의 인스턴스로 배치해줘.
UnityEditor API는 Editor 폴더에 한정하고, 실행 테스트는 수행 여부와 근거를 구분해 보고해줘.

## 프롬프트 B · 검증 요청

이 프로젝트에서 Day36_Basic3D 씬을 대상으로 다음을 검사해줘: 하위 루트 4개, Ground/Wall/Obstacle의 Collider, Camera MainCamera 태그, Directional Light, PlayerSpawn, Prefab 연결, 저장 경로, URP 활성 여부.
코드만 확인한 사실과 Unity Editor에서 실행 확인한 사실을 분리해서 PASS/FAIL/NOT TESTED로 보고해줘.
누락이나 경고 발견 시 변경 전 수정 계획과 영향을 받는 파일을 표시해줘.

## 프롬프트 C · 오류 분석

다음 Unity Console 로그와 Hierarchy 출력을 참고해서 오류 원인을 추정해줘.
내 로그에 없는 사실은 가정이라고 표시하고, 재현 방법 → 원인 후보 → 최소 수정안 → 재검증 순서로 보고해줘.
[여기에 Console 로그, Unity 버전, 관련 스크립트, Inspector 상태 첨부]
