# 36일차 학생 워크시트

1. 35일차 물리 실습장과 36일차 기본 씬의 설계 목적 차이를 2줄로 설명해 보세요.
2. Hierarchy에 `Environment`, `Obstacles`, `Markers`, `Systems` 그룹을 분리하는 이유는 무엇인가요?
3. Ground의 중심 Y=-0.25, Scale Y=0.5일 때 윗면 Y 좌표는 얼마인가요?
4. 같은 Prefab을 세 번 배치하면 어떤 점이 수월해지나요?
5. Inspector에서 MainCamera 태그가 누락되면 검증 코드가 무엇을 보고하나요?
6. Unity 프로젝트에서 `UnityEditor` 코드를 `Editor` 폴더에 둬야 하는 이유를 설명해 보세요.
7. `SceneManager`와 `EditorSceneManager`는 언제 사용하나요?
8. Codex가 씬을 수정하기 전 반드시 확인해야 할 사항 2개를 적으세요.
9. 검증 결과를 PASS/FAIL/NOT TESTED로 구분해야 하는 이유는 무엇인가요?
10. **확장 과제:** 오른쪽 벽을 이동시키되 기존 씬 파일을 안전하게 복제한 뒤 적용해 보세요.
