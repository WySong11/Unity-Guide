# Unity × Codex 36일차 실습: 기본 3D 씬 구성

기준: Unity 6.3 계열 / Universal 3D(URP) 프로젝트 / Editor 메뉴 기반 자동 생성 예제

## 오늘의 산출물

- `Assets/Unity_Codex/Day36/Scenes/Day36_Basic3D.unity`
- `Assets/Unity_Codex/Day36/Materials/` 내 머티리얼 3종
- `Assets/Unity_Codex/Day36/Prefabs/Obstacle.prefab`
- `Day36_BasicLevel` 루트 하위에 환경·장애물·마커·시스템 분리

## 순서

1. 기존 프로젝트를 Git으로 커밋하거나 파일 백업 후 Unity 6.3에서 엽니다.
2. Universal 3D(URP) 프로젝트인지 Graphics/Quality 설정을 확인합니다.
3. ZIP 내부 `Scripts`와 `Editor`의 .cs를 각각 `Assets/Scripts/Day36` 및 `Assets/Editor/Day36`에 복사합니다. Editor 스크립트를 반드시 Editor 폴더에 둡니다.
4. Unity Console의 컴파일 오류가 0건인지 확인합니다.
5. 메뉴 `Tools > Unity Codex > Day36 > Create Basic 3D Scene`을 실행합니다. **씬에 미저장 변경이 있으면 저장할지 묻습니다.**
6. 생성된 `Day36_Basic3D.unity` 씬을 열어 Hierarchy/Scene/Game 뷰를 확인합니다.
7. 메뉴 `Tools > Unity Codex > Day36 > Validate Open Scene`을 실행해 Console 결과를 기록합니다.
8. 메뉴 `Tools > Unity Codex > Day36 > Print Hierarchy Report`로 구성 정보를 출력합니다.

## 안전 규칙

- 기존 경로에 씬 파일이 있으면 덮어쓰지 않습니다. 먼저 복제·이름 변경하거나 백업합니다.
- 새 씬을 만들기 전 기존 씬의 미저장 변경 사항을 저장할지 확인합니다.
- Materials/Prefabs는 동일 경로가 존재하면 재사용합니다(기존 에셋을 변경하지 않음).
- 새 씬 저장 후 처음부터 실제 Play Mode 확인이 필요합니다. 코드는 대화에서 작성했으며 Unity Editor에서의 실제 실행 검증은 하지 않았습니다.
- Shader.Find가 URP/Lit를 찾지 못하면 Standard fallback을 시도합니다. URP 의도와 다르면 먼저 Render Pipeline 설정을 점검하세요.
- 물리 이동, 플레이어 제어, 인게임 UI는 본 차시 범위 밖입니다. 캐릭터 시작 위치를 위한 Marker만 제공합니다.

## 학생 제출

`Day36_Basic3D.unity`, Inspector 캡처 2장, Hierarchy 캡처 1장, 검증 로그 1장, 작성한 Codex 프롬프트 1개, 수정 내역 정리.
