# 공식 문서 참고 자료 (2026-10-26 확인)

- Unity 6.3 LTS 릴리스 및 지원: https://unity.com/releases/unity-6/support
- Unity 6.3 PrefabUtility: https://docs.unity.com/en-us/engine/6000.3/script-reference/unityeditor/prefabutility
- Unity EditorSceneManager: https://docs.unity.com/en-us/engine/6000.0/script-reference/unityeditor/scenemanagement/editorscenemanager
- Unity CreatePrimitive: https://docs.unity3d.com/ja/6000.0/ScriptReference/GameObject.CreatePrimitive.html
- GraphicsSettings.currentRenderPipeline: https://docs.unity.com/en-us/engine/6000.7/script-reference/unityengine/rendering/graphicssettings/currentrenderpipeline

버전 선택이 가능한 공식 API 문서에서 설치한 실제 Editor 버전(6000.3.x)에 맞춰 시그니처를 확인하세요.
