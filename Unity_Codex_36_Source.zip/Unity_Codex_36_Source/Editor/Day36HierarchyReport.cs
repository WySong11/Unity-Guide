#if UNITY_EDITOR
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Codex에 전달할 Hierarchy 텍스트를 Console에 출력합니다.</summary>
public static class Day36HierarchyReport
{
    [MenuItem("Tools/Unity Codex/Day36/Print Hierarchy Report")]
    public static void PrintReport()
    {
        var scene = SceneManager.GetActiveScene();
        var sb = new StringBuilder();
        sb.AppendLine($"Scene: {scene.name} | Path: {scene.path}");
        foreach (GameObject root in scene.GetRootGameObjects())
            AppendRecursive(sb, root.transform, 0);
        Debug.Log(sb.ToString());
    }

    private static void AppendRecursive(StringBuilder sb, Transform t, int depth)
    {
        sb.Append(' ', depth * 2).Append("- ").Append(t.name)
          .Append("  pos=").Append(t.position.ToString("F1")).AppendLine();
        foreach (Transform child in t) AppendRecursive(sb, child, depth + 1);
    }
}
#endif
