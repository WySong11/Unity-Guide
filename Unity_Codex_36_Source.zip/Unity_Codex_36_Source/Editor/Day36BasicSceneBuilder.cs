#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Unity 6.x: 씬과 에셋을 Day36 폴더에만 신규 생성합니다.</summary>
public static class Day36BasicSceneBuilder
{
    private const string Root = "Assets/Unity_Codex/Day36";
    private const string ScenePath = Root + "/Scenes/Day36_Basic3D.unity";
    private const string PrefabPath = Root + "/Prefabs/Obstacle.prefab";

    [MenuItem("Tools/Unity Codex/Day36/Create Basic 3D Scene")]
    public static void CreateScene()
    {
        if (File.Exists(ScenePath))
        {
            Debug.LogWarning("[Day36] 이미 씬이 존재합니다. 덮어쓰지 않습니다: " + ScenePath);
            EditorUtility.DisplayDialog("Day36", "기존 씬이 있습니다. 직접 백업/이름 변경 후 재시도하세요.", "확인");
            return;
        }

        // 이전 씬 변경사항을 버리지 않도록 저장 여부를 먼저 확인합니다.
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        EnsureFolder("Assets", "Unity_Codex");
        EnsureFolder("Assets/Unity_Codex", "Day36");
        EnsureFolder(Root, "Scenes");
        EnsureFolder(Root, "Materials");
        EnsureFolder(Root, "Prefabs");

        // URP Lit를 우선 사용하되, 다른 파이프라인에서는 지원 셰이더를 찾습니다.
        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (shader == null) shader = Shader.Find("Standard");
        if (shader == null)
        {
            Debug.LogError("[Day36] 호환 가능한 Lit 셰이더를 찾지 못했습니다.");
            return;
        }

        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene,
                                                 NewSceneMode.Single);
        Transform root = new GameObject("Day36_BasicLevel").transform;
        Transform env = AddGroup("01_Environment", root);
        Transform obstacles = AddGroup("02_Obstacles", root);
        Transform markers = AddGroup("03_Markers", root);
        Transform systems = AddGroup("04_Systems", root);

        Material floorMat = MakeMaterial("Floor_Green", shader,
                                         new Color(0.27f, 0.54f, 0.43f));
        Material wallMat = MakeMaterial("Wall_Blue", shader,
                                        new Color(0.24f, 0.42f, 0.64f));
        Material obstacleMat = MakeMaterial("Obstacle_Orange", shader,
                                            new Color(0.95f, 0.55f, 0.22f));

        CreatePrimitive(PrimitiveType.Cube, "Ground", env,
                        new Vector3(0f, -0.25f, 0f),
                        new Vector3(18f, 0.5f, 18f), floorMat);
        CreatePrimitive(PrimitiveType.Cube, "Wall_Back", env,
                        new Vector3(0f, 1f, 9f),
                        new Vector3(18f, 2f, 0.5f), wallMat);
        CreatePrimitive(PrimitiveType.Cube, "Wall_Left", env,
                        new Vector3(-9f, 1f, 0f),
                        new Vector3(0.5f, 2f, 18f), wallMat);
        CreatePrimitive(PrimitiveType.Cube, "Wall_Right", env,
                        new Vector3(9f, 1f, 0f),
                        new Vector3(0.5f, 2f, 18f), wallMat);

        // 한 번만 Prefab Asset으로 저장하고 씬에는 Prefab 인스턴스를 배치합니다.
        var proto = CreatePrimitive(PrimitiveType.Cube, "Obstacle", null,
                                    Vector3.zero, new Vector3(1.4f, 1.2f, 1.4f),
                                    obstacleMat);
        if (!File.Exists(PrefabPath))
            PrefabUtility.SaveAsPrefabAsset(proto, PrefabPath);
        Object.DestroyImmediate(proto);
        GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>(PrefabPath);
        Vector3[] points = { new Vector3(-3f, 0.6f, 1f),
                             new Vector3(0f, 0.6f, 3f),
                             new Vector3(3f, 0.6f, -1f) };
        for (int i = 0; i < points.Length; i++)
        {
            var obj = (GameObject)PrefabUtility.InstantiatePrefab(prefab, scene);
            obj.name = "Obstacle_" + (i + 1).ToString("00");
            obj.transform.SetParent(obstacles, false);
            obj.transform.position = points[i];
        }

        var spawn = new GameObject("PlayerSpawn");
        spawn.transform.SetParent(markers, false);
        spawn.transform.position = new Vector3(0f, 0.15f, -5f);
        spawn.AddComponent<Day36SpawnPoint>();
        var goal = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        goal.name = "GoalMarker";
        goal.transform.SetParent(markers, false);
        goal.transform.position = new Vector3(0f, 0.12f, 6.5f);
        goal.transform.localScale = new Vector3(1f, 0.12f, 1f);
        var goalCollider = goal.GetComponent<Collider>();
        if (goalCollider != null) Object.DestroyImmediate(goalCollider);

        var lightGO = new GameObject("Sun_DirectionalLight");
        lightGO.transform.SetParent(systems, false);
        var sun = lightGO.AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.intensity = 1.2f;
        lightGO.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

        var cameraGO = new GameObject("Main Camera");
        cameraGO.tag = "MainCamera";
        cameraGO.transform.SetParent(systems, false);
        Camera camera = cameraGO.AddComponent<Camera>();
        camera.fieldOfView = 60f;
        cameraGO.AddComponent<AudioListener>();
        cameraGO.transform.position = new Vector3(-10f, 12f, -16f);
        cameraGO.transform.LookAt(new Vector3(0f, 0f, 1f));
        cameraGO.AddComponent<Day36CameraOrbit>();

        EditorSceneManager.MarkSceneDirty(scene);
        bool saved = EditorSceneManager.SaveScene(scene, ScenePath);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        if (saved) Debug.Log("[Day36] 새 씬 생성 완료: " + ScenePath);
        else Debug.LogError("[Day36] 씬 저장 실패: " + ScenePath);
    }

    private static Transform AddGroup(string name, Transform parent)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        return go.transform;
    }

    private static GameObject CreatePrimitive(PrimitiveType type, string name,
        Transform parent, Vector3 pos, Vector3 scale, Material material)
    {
        var go = GameObject.CreatePrimitive(type);
        go.name = name;
        if (parent != null) go.transform.SetParent(parent, false);
        go.transform.position = pos;
        go.transform.localScale = scale;
        var renderer = go.GetComponent<Renderer>();
        if (renderer != null) renderer.sharedMaterial = material;
        return go;
    }

    private static Material MakeMaterial(string name, Shader shader, Color color)
    {
        string path = Root + "/Materials/" + name + ".mat";
        var existing = AssetDatabase.LoadAssetAtPath<Material>(path);
        if (existing != null) return existing;
        var material = new Material(shader) { name = name, color = color };
        AssetDatabase.CreateAsset(material, path);
        return material;
    }

    private static void EnsureFolder(string parent, string child)
    {
        string path = parent + "/" + child;
        if (!AssetDatabase.IsValidFolder(path)) AssetDatabase.CreateFolder(parent, child);
    }
}
#endif
