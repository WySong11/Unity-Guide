#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Rendering;

/// <summary>현재 열려 있는 Day36 씬의 최소 구성과 저장 상태를 점검합니다.</summary>
public static class Day36SceneValidator
{
    [MenuItem("Tools/Unity Codex/Day36/Validate Open Scene")]
    public static void Validate()
    {
        Scene scene = SceneManager.GetActiveScene();
        int errors = 0;
        int warnings = 0;
        var roots = new List<GameObject>();
        scene.GetRootGameObjects(roots);
        GameObject level = roots.Find(go => go.name == "Day36_BasicLevel");
        if (level == null) { Debug.LogError("[Day36] Day36_BasicLevel 루트가 없습니다."); errors++; }
        if (!scene.isLoaded) { Debug.LogError("[Day36] 열린 씬이 없습니다."); errors++; }
        if (string.IsNullOrEmpty(scene.path)) { Debug.LogWarning("[Day36] 씬을 저장하세요."); warnings++; }
        if (scene.isDirty) { Debug.LogWarning("[Day36] 저장되지 않은 변경 사항이 있습니다."); warnings++; }
        if (GraphicsSettings.currentRenderPipeline == null)
        { Debug.LogWarning("[Day36] 활성 렌더 파이프라인 에셋이 없습니다. URP 구성 여부를 확인하세요."); warnings++; }

        if (level != null)
        {
            string[] groups = { "01_Environment", "02_Obstacles", "03_Markers", "04_Systems" };
            foreach (string name in groups)
            {
                if (level.transform.Find(name) != null) continue;
                Debug.LogError("[Day36] 누락 그룹: " + name); errors++;
            }
            if (level.transform.Find("03_Markers/PlayerSpawn") == null)
            { Debug.LogError("[Day36] PlayerSpawn이 없습니다."); errors++; }
        }

        Camera main = Camera.main;
        if (main == null) { Debug.LogError("[Day36] MainCamera 태그의 활성 Camera가 없습니다."); errors++; }
        Light[] lights = Object.FindObjectsByType<Light>(FindObjectsSortMode.None);
        bool hasSun = false;
        foreach (Light light in lights)
            if (light.type == LightType.Directional) hasSun = true;
        if (!hasSun) { Debug.LogError("[Day36] Directional Light가 없습니다."); errors++; }

        Collider[] colliders = Object.FindObjectsByType<Collider>(FindObjectsSortMode.None);
        if (colliders.Length < 5) { Debug.LogWarning("[Day36] 예상보다 Collider가 적습니다: " + colliders.Length); warnings++; }
        Debug.Log($"[Day36] 씬 검증 완료: 오류 {errors}건, 경고 {warnings}건, Collider {colliders.Length}개. 저장 경로: {scene.path}");
    }
}
#endif
