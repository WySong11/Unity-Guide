# Unity × Codex · 64일차 통합 게임플레이 테스트

Unity 6.3 · New Input System · 3D URP 권장 · 120분 / 44슬라이드.

## 설치
1. `Assets/Day64_IntegrationLab` 폴더를 기존 Unity 6.3 프로젝트 Assets에 복사합니다.
2. New Input System 패키지가 설치되어 있는지 확인합니다.
3. Unity 상단 **Tools > Unity Codex > Day64 > Create Integration QA Lab** 실행. 매번 새 폴더에 Scene/Prefab을 만들며 기존 데이터는 덮어쓰지 않습니다.
4. 만들어진 `Day64_Integration_QA.unity`를 열고 Game View에서 **START / RESTART**.
5. `Tools > Unity Codex > Day64 > Validate Open Scene`으로 정적 검사.

## 조작
WASD 이동 · F/마우스 좌클릭 Raycast 공격 · Q Heal · H Potion · P Pause · HUD: Save/Load, QA Kill, Smoke.

## 중요 범위·제한
- 이 코드는 **독립 통합 QA 데모/교육용**이며 55~63일차 코드에 자동으로 연결되는 운영 게임 프레임워크가 아닙니다. 기존 프로젝트에 적용할 때 `Day64GameSignals` 이벤트를 실제 시스템에 연결하고, 단계별 테스트 증거를 수집합니다.
- 초기 생성되는 독립 데모 몬스터에는 NavMeshAgent가 **없습니다**. 직선 추적은 **NavMesh 경로 검증 PASS가 아닙니다**. 실제 AI 경로 항목은 52일차 NavMeshAgent/AI Navigation 씬에서 베이크 후 검증하세요. 필요 시 생성된 Enemy Prefab에 NavMeshAgent를 추가하고 경로 상태를 별도 시험합니다.
- HUD의 `RUN SMOKE`는 현재 데모를 초기화하고 **Spawn→Kill→Count만 점검**합니다. 실제 이동·카메라·Raycast·Save·씬 전환·성능 테스트를 대신하지 않습니다.
- 예제 씬은 한 씬입니다. 실제 **Title→Game→Result** 전환은 62일차 프로젝트에서 별도 테스트해야 합니다.
- `Day64CombatFeedback`은 독립 데모용 일회성 ParticleSystem을 생성합니다. **Object Pool 성능 검사는 기존 54/63일차 풀 구현**을 대상으로 수행해야 합니다.
- Unity Editor에서 컴파일/실행을 이 환경에서 수행하지 않았습니다.

## 배포·저장 주의
저장 파일: `Application.persistentDataPath/day64-save.json`. 이 예제는 일반 게임 상태 데이터만 저장하며 인증 정보·개인정보는 저장하지 않습니다. Load는 JSON 전체 값 검사 후 반영합니다. 본 예제는 원자적 저장/다중 슬롯/Cloud Save의 대체가 아닙니다.

## 검증 순서
1. Editor 정적 검사 → 2. Smoke → 3. T01~T12 수동 시연 → 4. Console/Profiler/스크린샷 수집 → 5. 실패 재현·수정·전체 회귀 재검사.

## 배점
이동·전투·AI 25 / Wave·Pool 25 / 스킬·아이템·Save 20 / Pause·Restart·성능 15 / Codex·증빙 15 = 100점.
