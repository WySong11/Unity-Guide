# Codex 테스트 프롬프트

## 1. 연결·정적 검사
Unity 6.3 프로젝트에서 55~63일차 시스템 연결을 정적 리뷰해줘. Player·Combat·Enemy AI·Wave·Pool·Skill·Item·Save·Scene 경계, 이벤트 구독과 해제, 순환 의존성을 조사해. 기존 파일을 임의 변경하지 말고 실패 가능성/근거/검증 절차를 알려줘.

## 2. 실행 검증
Unity Editor 연결 도구가 실제 사용 가능하다면 Play Mode에서 T01~T12를 가능한 만큼 실행하고 로그·스크린샷·Profiler 증거를 수집해줘. 실행하지 못한 항목은 NOT RUN/BLOCKED로 남겨. 정적 추정만으로 PASS를 쓰지 마.

## 3. 디버깅·회귀
재현 단계 → 첫 실패 경계 → 수정 전 Snapshot → 최소 수정 diff → 테스트 재실행 → 의도하지 않은 수정 파일 목록 순서로 보고해줘. 특히 Kill 중복, Pool 상태 초기화, Pause 종료 후 timeScale, 잘못된 JSON 적용, 씬 재진입 이벤트 중복을 확인해.
