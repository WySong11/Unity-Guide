# 이전 강의 구성과의 통합 경계
- Day55 WaveSpawner: `Kill` 이벤트를 정확히 한 번 통지하고 ActiveCount를 반환된 Monster 수와 동기화
- Day56 Integration Observer: 이벤트 발생 횟수와 기대값 비교, 실행 증거 확보
- Day58 SkillController: 실패 시 Mana와 Cooldown이 변하지 않는지 확인
- Day59 Inventory: Potion 사용 실패에서 Slot count 보존, UI 통지
- Day60 EffectEngine: 아이템·스킬 효과 성공 여부와 사용 비용 분리
- Day61 SaveService: DTO 검증 후 적용; 실패할 때 현재 상태 유지
- Day62 GameFlowManager: 씬 전환·Pause·매니저 인스턴스 중복 검사
- Day63 CombatPresenter: Attack/Hit/Dead 중복 연출과 VFX 풀 반환 확인

`Day64_IntegrationLab`은 독립적 개념 확인용 샘플입니다. 실제 수강생 프로젝트는 위 계약을 기준으로 이질적인 DayNN 구현을 연결해야 합니다.
