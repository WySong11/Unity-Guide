using UnityEngine;
public sealed class Day64FollowCamera : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private Vector3 offset=new Vector3(0f,6f,-9f);
    public void Configure(Transform t) { target=t; }
    private void LateUpdate()
    {
        if(target == null) return;
        transform.position=Vector3.Lerp(transform.position,target.position+offset,10f*Time.deltaTime);
        transform.LookAt(target.position+new Vector3(0f,0.7f,9f));
    }
}
