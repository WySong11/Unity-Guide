using System.Collections;
using UnityEngine;

public sealed class Day64IntegrationSmokeRunner : MonoBehaviour
{
    [SerializeField] private Day64GameSession session;
    [SerializeField] private Day64WaveController wave;
    [SerializeField] private Day64IntegrationObserver observer;
    private bool running;
    public string LastResult { get; private set; } = "Not run";
    public void Configure(Day64GameSession s,Day64WaveController w,Day64IntegrationObserver o)
    { session=s;wave=w;observer=o; }
    public void RunSmoke()
    {
        if(running) return;
        StartCoroutine(Run());
    }
    private IEnumerator Run()
    {
        running=true;
        LastResult="RUNNING (resets current demo!)";
        if(session==null || wave==null || observer==null)
        { LastResult="FAIL: missing references"; running=false;yield break; }
        if(!wave.RestartAtWave(0,true))
        { LastResult="FAIL: cannot restart"; running=false;yield break; }
        yield return new WaitForSeconds(0.15f);
        if(wave.ActiveCount<1 || !observer.IsConsistent())
        { LastResult="FAIL: spawn/consistency";running=false;yield break; }
        int before=session.Kills;
        if(!wave.ForceDefeatOne())
        { LastResult="FAIL: force defeat";running=false;yield break; }
        yield return null;
        if(session.Kills!=before+1 || !observer.IsConsistent())
        { LastResult="FAIL: kill count";running=false;yield break; }
        LastResult="PASS: smoke spawn→kill→counter only";
        running=false;
    }
}
