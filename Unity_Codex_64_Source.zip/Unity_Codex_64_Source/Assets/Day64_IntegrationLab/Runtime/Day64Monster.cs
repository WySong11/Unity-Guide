using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(Collider))]
public sealed class Day64Monster : MonoBehaviour
{
    [SerializeField, Min(1)] private int baseHP = 50;
    private Day64WaveController owner;
    private Day64GameSession target;
    private Day64GameSignals signals;
    private NavMeshAgent agent;
    private float nextAttackAt;
    private float speed;
    public int HP { get; private set; }
    public int MaxHP => baseHP;
    public bool IsAlive => HP > 0;

    private void Awake() { agent = GetComponent<NavMeshAgent>(); }
    public void Initialize(Day64WaveController poolOwner, Day64GameSession player,
        Day64GameSignals gameSignals, float movementSpeed)
    {
        owner = poolOwner; target = player; signals = gameSignals;
        speed = movementSpeed;
        HP = baseHP; nextAttackAt = Time.time + 1f;
        if (agent != null)
        {
            agent.speed = speed;
            if (agent.isOnNavMesh)
            {
                agent.isStopped = false;
                agent.ResetPath();
            }
        }
    }
    private void Update()
    {
        if (!IsAlive || target == null || !target.CanPlay) return;
        var player = owner != null ? owner.PlayerTarget : null;
        if (player == null) return;
        Vector3 delta = player.position - transform.position;
        delta.y = 0f;
        float distance = delta.magnitude;
        if (distance > 1.8f)
        {
            if (agent != null && agent.isOnNavMesh)
                agent.SetDestination(player.position);
            else if (distance > 0.01f)
                transform.position += delta.normalized * (speed * Time.deltaTime);
        }
        else if (Time.time >= nextAttackAt)
        {
            nextAttackAt = Time.time + 2f;
            target.TakeDamage(5);
        }
    }
    public bool TakeDamage(int amount)
    {
        if (!IsAlive || amount <= 0 || target == null || !target.CanPlay) return false;
        int applied = Mathf.Min(HP, amount);
        HP -= applied;
        signals?.RaiseHit(this, applied);
        if (HP == 0) owner?.HandleMonsterDied(this);
        return true;
    }
    public void PrepareReturn()
    {
        HP = 0;
        if (agent != null && agent.isOnNavMesh)
        {
            agent.isStopped = true;
            agent.ResetPath();
        }
        owner = null;target = null;signals = null;
    }
}
