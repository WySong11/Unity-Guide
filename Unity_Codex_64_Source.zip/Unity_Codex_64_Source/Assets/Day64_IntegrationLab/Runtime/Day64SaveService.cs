using System;
using System.IO;
using UnityEngine;

[Serializable]
public sealed class Day64SaveDto
{
    public int version=1;
    public int hp;
    public int mana;
    public int potions;
    public int kills;
    public int score;
    public int waveIndex;
}

public sealed class Day64SaveService : MonoBehaviour
{
    [SerializeField] private Day64GameSession session;
    [SerializeField] private Day64WaveController wave;
    public string SavePath => Path.Combine(Application.persistentDataPath, "day64-save.json");
    public string LastMessage { get; private set; } = "Not saved";
    public void Configure(Day64GameSession s, Day64WaveController w) { session=s;wave=w; }
    public bool Save()
    {
        if(session == null || wave == null) { LastMessage="Missing references";return false; }
        if(!session.CanPlay || session.HP <= 0) { LastMessage="Save only while playing";return false; }
        var dto=new Day64SaveDto {
            hp=session.HP, mana=session.Mana, potions=session.Potions,
            kills=session.Kills,score=session.Score,waveIndex=wave.WaveIndex
        };
        string temp=SavePath+".tmp";
        try
        {
            Directory.CreateDirectory(Application.persistentDataPath);
            File.WriteAllText(temp,JsonUtility.ToJson(dto,true));
            if(File.Exists(SavePath)) File.Copy(SavePath,SavePath+".bak",true);
            File.Copy(temp,SavePath,true);
            File.Delete(temp);
            LastMessage="Saved";return true;
        }
        catch(Exception e) { LastMessage="Save failed: "+e.Message;return false; }
    }
    public bool TryLoad(out Day64SaveDto dto)
    {
        dto=null;
        if(!File.Exists(SavePath)) { LastMessage="No save";return false; }
        try
        {
            Day64SaveDto d=JsonUtility.FromJson<Day64SaveDto>(File.ReadAllText(SavePath));
            if(!Validate(d)) { LastMessage="Invalid version or values";return false; }
            dto=d;LastMessage="Validated";return true;
        }
        catch(Exception e) { LastMessage="Load failed: "+e.GetType().Name;return false; }
    }
    public bool LoadAndApply()
    {
        if(session==null || wave==null || !TryLoad(out Day64SaveDto data)) return false;
        // Validate before any mutation. Wave can be restored before player values.
        session.ResetDemo();
        if(!wave.RestartAtWave(data.waveIndex)) { LastMessage="Wave restore failed"; return false; }
        session.ApplySave(data);
        LastMessage="Loaded";return true;
    }
    public bool Validate(Day64SaveDto d)
    {
        return d!=null && d.version==1 && session!=null &&
            d.hp>=1 && d.hp<=session.MaxHP &&
            d.mana>=0 && d.mana<=session.MaxMana &&
            d.potions>=0 && d.potions<=99 &&
            d.kills>=0 && d.kills<=1000000 &&
            d.score>=0 && d.score<=10000000 &&
            d.waveIndex>=0 && d.waveIndex<3;
    }
}
