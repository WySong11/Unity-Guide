using UnityEngine;
public sealed class Day64IntegrationHUD : MonoBehaviour
{
    [SerializeField] private Day64GameSession session;
    [SerializeField] private Day64WaveController wave;
    [SerializeField] private Day64SkillController skill;
    [SerializeField] private Day64SaveService save;
    [SerializeField] private Day64IntegrationObserver observer;
    [SerializeField] private Day64IntegrationSmokeRunner smoke;
    public void Configure(Day64GameSession s,Day64WaveController w,Day64SkillController k,
        Day64SaveService v,Day64IntegrationObserver o,Day64IntegrationSmokeRunner t)
    {session=s;wave=w;skill=k;save=v;observer=o;smoke=t;}
    private void OnGUI()
    {
        GUILayout.BeginArea(new Rect(14,14,400,490),GUI.skin.box);
        GUILayout.Label("DAY64 · INTEGRATED GAMEPLAY TEST");
        if(session!=null)
        {
            GUILayout.Label($"{session.State} | HP {session.HP}/{session.MaxHP} | MP {session.Mana}/{session.MaxMana}");
            GUILayout.Label($"Potions {session.Potions} | Kills {session.Kills} | Score {session.Score}");
        }
        if(wave!=null) GUILayout.Label($"Wave {wave.WaveIndex+1} | Alive {wave.ActiveCount}/{wave.MaxAlive} | Pool idle {wave.PoolInactive}");
        if(observer!=null)
        {
            GUILayout.Label($"Spawn/Hit/Kill/Wave: {observer.Spawned}/{observer.Hits}/{observer.Killed}/{observer.WavesCompleted}");
            GUILayout.Label("Invariant: "+(observer.IsConsistent()?"OK":"CHECK"));
        }
        if(skill!=null) GUILayout.Label($"Heal cooldown: {skill.Remaining:0.0}s");
        GUILayout.Label("WASD Move | F/Click Attack | Q Heal | H Potion | P Pause");
        if(GUILayout.Button("START / RESTART")) wave?.StartCycle();
        if(GUILayout.Button("DEFEAT ONE (K)")) wave?.ForceDefeatOne();
        if(GUILayout.Button("COMPLETE WAVE (QA)")) wave?.ForceCompleteCurrentWaveForTesting();
        if(GUILayout.Button("TAKE 20 DAMAGE")) session?.TakeDamage(20);
        if(GUILayout.Button("ADD POTION")) session?.AddPotion(1);
        if(GUILayout.Button("HEAL (Q)")) skill?.TryHeal();
        if(GUILayout.Button("USE POTION (H)")) session?.UsePotion();
        if(GUILayout.Button("PAUSE / RESUME (P)")) session?.TogglePause();
        GUILayout.BeginHorizontal();
        if(GUILayout.Button("SAVE")) save?.Save();
        if(GUILayout.Button("LOAD")) save?.LoadAndApply();
        GUILayout.EndHorizontal();
        if(save!=null) GUILayout.Label("Save: "+save.LastMessage);
        if(GUILayout.Button("RUN SMOKE (RESETS DEMO)")) smoke?.RunSmoke();
        if(smoke!=null) GUILayout.Label("Smoke: "+smoke.LastResult);
        GUILayout.EndArea();
    }
}
