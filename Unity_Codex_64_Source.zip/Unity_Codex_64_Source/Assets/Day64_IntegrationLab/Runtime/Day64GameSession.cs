using System;
using UnityEngine;

public enum Day64PlayState { Ready, Playing, Paused, GameOver }

public sealed class Day64GameSession : MonoBehaviour
{
    [SerializeField, Min(1)] private int maxHP = 100;
    [SerializeField, Min(1)] private int maxMana = 60;
    [SerializeField, Min(0)] private int initialPotions = 2;
    public Day64PlayState State { get; private set; } = Day64PlayState.Ready;
    public int HP { get; private set; }
    public int MaxHP => maxHP;
    public int Mana { get; private set; }
    public int MaxMana => maxMana;
    public int Potions { get; private set; }
    public int Kills { get; private set; }
    public int Score { get; private set; }
    public bool CanPlay => State == Day64PlayState.Playing;
    public bool CanHeal => HP > 0 && HP < MaxHP;
    public event Action OnChanged;
    private void Awake() { ResetDemo(); }
    public void ResetDemo()
    {
        Time.timeScale = 1f;
        HP = maxHP; Mana = maxMana; Potions = initialPotions;
        Score = 0; Kills = 0;
        State = Day64PlayState.Ready;
        OnChanged?.Invoke();
    }
    public void StartDemo()
    {
        if (State != Day64PlayState.Ready) return;
        Time.timeScale = 1f;
        State = Day64PlayState.Playing;
        OnChanged?.Invoke();
    }
    public void Pause()
    {
        if (!CanPlay) return;
        State = Day64PlayState.Paused;
        Time.timeScale = 0f;
        OnChanged?.Invoke();
    }
    public void Resume()
    {
        if (State != Day64PlayState.Paused) return;
        Time.timeScale = 1f;
        State = Day64PlayState.Playing;
        OnChanged?.Invoke();
    }
    public void TogglePause() { if (CanPlay) Pause(); else if (State == Day64PlayState.Paused) Resume(); }
    public void FinishDemo()
    {
        if (State != Day64PlayState.Playing) return;
        State = Day64PlayState.GameOver;
        Time.timeScale = 1f;
        OnChanged?.Invoke();
    }
    public bool TakeDamage(int amount)
    {
        if (!CanPlay || amount <= 0 || HP <= 0) return false;
        HP = Mathf.Max(0, HP - amount);
        if (HP == 0) { State = Day64PlayState.GameOver; Time.timeScale = 1f; }
        OnChanged?.Invoke();
        return true;
    }
    public int Heal(int amount)
    {
        if (!CanPlay || !CanHeal || amount <= 0) return 0;
        int restored = Mathf.Min(amount, MaxHP - HP);
        HP += restored; OnChanged?.Invoke();
        return restored;
    }
    public bool SpendMana(int amount)
    {
        if (!CanPlay || amount < 0 || Mana < amount) return false;
        Mana -= amount; OnChanged?.Invoke(); return true;
    }
    public void AddPotion(int amount)
    {
        if (!CanPlay || amount <= 0) return;
        Potions = Mathf.Min(99, Potions + amount);
        OnChanged?.Invoke();
    }
    public bool UsePotion()
    {
        if (!CanPlay || Potions <= 0 || !CanHeal) return false;
        if (Heal(30) <= 0) return false;
        Potions--; OnChanged?.Invoke(); return true;
    }
    public void GainKill()
    {
        if (!CanPlay) return;
        Kills++; Score += 10;
        OnChanged?.Invoke();
    }
    public void ApplySave(Day64SaveDto d)
    {
        if (d == null) return;
        Time.timeScale = 1f;
        State = Day64PlayState.Playing;
        HP = d.hp; Mana = d.mana; Potions = d.potions;
        Score = d.score; Kills = d.kills;
        OnChanged?.Invoke();
    }
    private void OnDisable() { Time.timeScale = 1f; }
}
