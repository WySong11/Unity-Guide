using UnityEngine;
using UnityEngine.InputSystem;
public sealed class Day64RaycastAttack : MonoBehaviour
{
    [SerializeField] private Day64GameSession session;
    [SerializeField] private Camera aimCamera;
    [SerializeField] private LayerMask hitMask=~0;
    [SerializeField] private float range=30f;
    [SerializeField] private float attackCooldown=0.4f;
    private float nextAttackAt;
    public int SuccessfulHits { get; private set; }
    public void Configure(Day64GameSession s, Camera cam) { session=s;aimCamera=cam; }
    private void Update()
    {
        if(Keyboard.current != null && Keyboard.current.fKey.wasPressedThisFrame) TryAttack();
        if(Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame)
        {
            Vector2 pointer = Mouse.current.position.ReadValue();
            float yFromTop = Screen.height - pointer.y;
            // Ignore mouse clicks on the teaching HUD so buttons don't fire a weapon.
            if(pointer.x < 14f || pointer.x > 414f || yFromTop < 14f || yFromTop > 504f)
                TryAttack();
        }
    }
    public bool TryAttack()
    {
        if(session == null || !session.CanPlay || aimCamera == null || Time.time < nextAttackAt) return false;
        nextAttackAt=Time.time+attackCooldown;
        // Aim is camera-centered; the capsule's collider is on the enemy root.
        Ray ray=aimCamera.ViewportPointToRay(new Vector3(0.5f,0.5f,0));
        if(!Physics.Raycast(ray,out RaycastHit hit,range,hitMask,QueryTriggerInteraction.Ignore)) return false;
        Day64Monster monster=hit.collider.GetComponentInParent<Day64Monster>();
        if(monster==null || !monster.TakeDamage(20)) return false;
        SuccessfulHits++;return true;
    }
}
