using UnityEngine;
public sealed class Day64IntegrationObserver : MonoBehaviour
{
    [SerializeField] private Day64GameSignals signals;
    [SerializeField] private Day64WaveController wave;
    [SerializeField] private Day64GameSession session;
    public int Spawned { get; private set; }
    public int Killed { get; private set; }
    public int Hits { get; private set; }
    public int WavesCompleted { get; private set; }
    public void Configure(Day64GameSignals bus,Day64WaveController w,Day64GameSession s)
    { signals=bus;wave=w;session=s; }
    private void OnEnable()
    {
        if(signals == null) return;
        signals.OnSpawn+=HandleSpawn;
        signals.OnKill+=HandleKill;
        signals.OnHit+=HandleHit;
        signals.OnWaveCompleted+=HandleWave;
    }
    private void OnDisable()
    {
        if(signals == null) return;
        signals.OnSpawn-=HandleSpawn;
        signals.OnKill-=HandleKill;
        signals.OnHit-=HandleHit;
        signals.OnWaveCompleted-=HandleWave;
    }
    private void HandleSpawn(Day64Monster m) { Spawned++; }
    private void HandleKill(Vector3 at) { Killed++; }
    private void HandleHit(Day64Monster m,int damage) { Hits++; }
    private void HandleWave(int index) { WavesCompleted++; }
    public bool IsConsistent()
    {
        if(wave==null || session==null) return false;
        return wave.ActiveCount>=0 && wave.ActiveCount<=wave.MaxAlive &&
            session.HP>=0 && session.HP<=session.MaxHP &&
            session.Potions>=0;
    }
    public string Snapshot()
    {
        if(session==null || wave==null) return "Missing references";
        return $"State={session.State} HP={session.HP} MP={session.Mana} " +
            $"Wave={wave.WaveIndex+1} Alive={wave.ActiveCount} " +
            $"Kills={session.Kills} Potions={session.Potions}";
    }
}
