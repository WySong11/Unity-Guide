using UnityEngine;
public sealed class Day64CombatFeedback : MonoBehaviour
{
    [SerializeField] private Day64GameSignals signals;
    private AudioSource sfx;
    private AudioClip hitSound;
    public void Configure(Day64GameSignals bus) { signals=bus; }
    private void Awake()
    {
        sfx=gameObject.AddComponent<AudioSource>();
        sfx.playOnAwake=false;sfx.spatialBlend=0f;
        const int rate=22050;
        var samples=new float[rate/12];
        for(int i=0;i<samples.Length;i++)
            samples[i]=Mathf.Sin(2f*Mathf.PI*450f*i/rate)*(1f-(float)i/samples.Length)*0.09f;
        hitSound=AudioClip.Create("Day64 hit",samples.Length,1,rate,false);
        hitSound.SetData(samples,0);
    }
    private void OnEnable()
    {
        if(signals==null)return;
        signals.OnHit+=OnHit;
        signals.OnKill+=OnKill;
    }
    private void OnDisable()
    {
        if(signals==null)return;
        signals.OnHit-=OnHit;
        signals.OnKill-=OnKill;
    }
    private void OnHit(Day64Monster monster,int damage)
    {
        if(sfx!=null && hitSound!=null) sfx.PlayOneShot(hitSound);
        if(monster!=null) MakeBurst(monster.transform.position+Vector3.up,Color.yellow);
    }
    private void OnKill(Vector3 position) { MakeBurst(position+Vector3.up,Color.red); }
    private static void MakeBurst(Vector3 position,Color color)
    {
        // Tiny independent QA effect, not production pooled VFX. Verify production pool separately.
        var o=new GameObject("Day64_QA_Burst");o.transform.position=position;
        var ps=o.AddComponent<ParticleSystem>();
        var main=ps.main; main.startLifetime=0.28f;main.startSpeed=3f;
        main.startSize=0.12f;main.startColor=color; main.duration=0.15f;
        main.loop=false;main.stopAction=ParticleSystemStopAction.Destroy;
        var emission=ps.emission;emission.rateOverTime=0f;
        emission.SetBursts(new []{new ParticleSystem.Burst(0f,9)});
        ps.Play();
    }
}
