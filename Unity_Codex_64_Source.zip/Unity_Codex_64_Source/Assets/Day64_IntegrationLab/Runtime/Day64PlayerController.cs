using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(CharacterController))]
public sealed class Day64PlayerController : MonoBehaviour
{
    [SerializeField] private Day64GameSession session;
    [SerializeField, Min(0.1f)] private float moveSpeed = 4f;
    private CharacterController controller;
    private float verticalSpeed;
    private void Awake() { controller=GetComponent<CharacterController>(); }
    public void Configure(Day64GameSession targetSession) { session=targetSession; }
    private void Update()
    {
        if (session == null || !session.CanPlay || Keyboard.current == null) return;
        Vector3 input=Vector3.zero;
        if(Keyboard.current.wKey.isPressed) input+=Vector3.forward;
        if(Keyboard.current.sKey.isPressed) input+=Vector3.back;
        if(Keyboard.current.aKey.isPressed) input+=Vector3.left;
        if(Keyboard.current.dKey.isPressed) input+=Vector3.right;
        if(controller.isGrounded && verticalSpeed < 0f) verticalSpeed=-1f;
        verticalSpeed += Physics.gravity.y * Time.deltaTime;
        Vector3 move = input.normalized * moveSpeed;
        move.y=verticalSpeed;
        controller.Move(move*Time.deltaTime);
        if (input.sqrMagnitude>0.01f) transform.rotation=Quaternion.LookRotation(input);
    }
}
