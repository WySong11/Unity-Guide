using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Pool;

public sealed class Day64WaveController : MonoBehaviour
{
    [SerializeField] private Day64Monster monsterPrefab;
    [SerializeField] private Day64GameSession session;
    [SerializeField] private Day64GameSignals signals;
    [SerializeField] private Transform playerTarget;
    [SerializeField] private Transform[] spawnPoints;
    [SerializeField, Min(1)] private int maxAlive = 3;
    [SerializeField, Min(0.1f)] private float spawnInterval = 1f;
    [SerializeField, Min(0.1f)] private float restSeconds = 1.5f;
    private ObjectPool<Day64Monster> pool;
    private readonly HashSet<Day64Monster> alive = new HashSet<Day64Monster>();
    private Coroutine waveRoutine;
    private int remainingToSpawn;
    private bool pendingNextWave;
    public int WaveIndex { get; private set; } = 0; // 0 means first wave; 0..2
    public int ActiveCount => alive.Count;
    public int MaxAlive => maxAlive;
    public int PoolInactive => pool != null ? pool.CountInactive : 0;
    public Transform PlayerTarget => playerTarget;
    public Day64GameSession Session => session;
    public int SpawnAttempts { get; private set; }

    public void Configure(Day64Monster prefab, Transform target, Day64GameSession state,
        Day64GameSignals bus, Transform[] spots)
    {
        monsterPrefab = prefab;playerTarget = target;session = state;
        signals = bus;spawnPoints = spots;
    }
    private void Awake()
    {
        if (monsterPrefab == null) { Debug.LogError("Day64 monster prefab missing", this); return; }
        pool = new ObjectPool<Day64Monster>(CreateMonster,
            m => m.gameObject.SetActive(true),
            m => m.gameObject.SetActive(false),
            m => { if (m != null) Destroy(m.gameObject); },
            collectionCheck: true, defaultCapacity: 4, maxSize: 24);
        var created = new List<Day64Monster>();
        for (int i=0;i<3;i++) created.Add(pool.Get());
        foreach (var monster in created) pool.Release(monster);
    }
    private Day64Monster CreateMonster()
    {
        var m = Instantiate(monsterPrefab, transform);
        m.gameObject.SetActive(false);
        return m;
    }
    public void StartCycle() { RestartAtWave(0, true); }
    public bool RestartAtWave(int index, bool resetSession = false)
    {
        if (pool == null || index < 0 || index >= 3 || session == null) return false;
        StopRunningAndClear();
        if (resetSession) session.ResetDemo();
        if (session.State == Day64PlayState.Ready) session.StartDemo();
        else if (session.State == Day64PlayState.Paused) session.Resume();
        if (!session.CanPlay) return false;
        WaveIndex = index;
        pendingNextWave = false;
        remainingToSpawn = 3 + WaveIndex * 2;
        waveRoutine = StartCoroutine(SpawnWave());
        return true;
    }
    private IEnumerator SpawnWave()
    {
        while (remainingToSpawn > 0 && session != null && session.CanPlay)
        {
            if (alive.Count >= maxAlive) { yield return null; continue; }
            if (!TrySpawnOne()) { yield return new WaitForSeconds(0.5f); continue; }
            remainingToSpawn--;
            yield return new WaitForSeconds(spawnInterval);
        }
        waveRoutine = null;
        if (remainingToSpawn == 0 && alive.Count == 0) FinishWave();
    }
    private bool TrySpawnOne()
    {
        SpawnAttempts++;
        if (pool == null || playerTarget == null || spawnPoints == null || spawnPoints.Length == 0) return false;
        Transform point = spawnPoints[Random.Range(0,spawnPoints.Length)];
        if (point == null) return false;
        Vector3 position = point.position;
        if (NavMesh.SamplePosition(position, out NavMeshHit hit, 1.5f, NavMesh.AllAreas))
            position = hit.position;
        // Standalone lab also runs before NavMesh baking; fallback is test-only straight chase.
        Day64Monster monster = pool.Get();
        monster.transform.position = position;
        monster.Initialize(this, session, signals, 2.0f + WaveIndex * 0.3f);
        alive.Add(monster);
        signals?.RaiseSpawn(monster);
        return true;
    }
    public void HandleMonsterDied(Day64Monster monster)
    {
        if (monster == null || !alive.Remove(monster)) return;
        monster.PrepareReturn();
        session?.GainKill();
        signals?.RaiseKill(monster.transform.position);
        pool.Release(monster);
        if (remainingToSpawn == 0 && alive.Count == 0 && waveRoutine == null) FinishWave();
    }
    private void FinishWave()
    {
        if (pendingNextWave) return;
        pendingNextWave = true;
        signals?.RaiseWaveCompleted(WaveIndex + 1);
        if (WaveIndex >= 2) { session?.FinishDemo(); return; }
        StartCoroutine(BeginNextWave());
    }
    private IEnumerator BeginNextWave()
    {
        yield return new WaitForSeconds(restSeconds);
        if (session == null || !session.CanPlay) yield break;
        WaveIndex++; remainingToSpawn = 3 + WaveIndex * 2;
        pendingNextWave = false;
        waveRoutine = StartCoroutine(SpawnWave());
    }
    public bool ForceDefeatOne()
    {
        if (session == null || !session.CanPlay) return false;
        Day64Monster victim=null;
        foreach(var monster in alive) { victim=monster; break; }
        return victim != null && victim.TakeDamage(victim.HP);
    }
    public void ForceCompleteCurrentWaveForTesting()
    {
        if (session == null || !session.CanPlay) return;
        if (waveRoutine != null) StopCoroutine(waveRoutine);
        waveRoutine = null;remainingToSpawn = 0;
        var snapshot = new List<Day64Monster>(alive);
        foreach(var monster in snapshot) monster.TakeDamage(monster.HP);
        if (alive.Count == 0) FinishWave();
    }
    private void StopRunningAndClear()
    {
        StopAllCoroutines();waveRoutine=null;pendingNextWave=false;
        if(pool != null)
        {
            foreach(var monster in alive)
            {
                if(monster == null) continue;
                monster.PrepareReturn();pool.Release(monster);
            }
        }
        alive.Clear();remainingToSpawn=0;
    }
    private void OnDestroy() { StopRunningAndClear();pool?.Clear(); }
}
