using UnityEngine;
using UnityEngine.InputSystem;
public sealed class Day64SkillController : MonoBehaviour
{
    [SerializeField] private Day64GameSession session;
    [SerializeField, Min(1)] private int manaCost=15;
    [SerializeField, Min(1)] private int healAmount=30;
    [SerializeField, Min(0.1f)] private float cooldown=5f;
    private float nextHealAt;
    public float Remaining => Mathf.Max(0f,nextHealAt-Time.time);
    public void Configure(Day64GameSession s) { session=s; }
    private void Update()
    {
        if(Keyboard.current!=null && Keyboard.current.qKey.wasPressedThisFrame) TryHeal();
        if(Keyboard.current!=null && Keyboard.current.hKey.wasPressedThisFrame) session?.UsePotion();
        if(Keyboard.current!=null && Keyboard.current.pKey.wasPressedThisFrame) session?.TogglePause();
    }
    public bool TryHeal()
    {
        if(session == null || !session.CanPlay || Time.time < nextHealAt) return false;
        if(!session.CanHeal || session.Mana < manaCost) return false;
        if(!session.SpendMana(manaCost)) return false;
        session.Heal(healAmount);
        nextHealAt=Time.time+cooldown;
        return true;
    }
}
