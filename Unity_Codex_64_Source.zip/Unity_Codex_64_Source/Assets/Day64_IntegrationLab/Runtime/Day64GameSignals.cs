using System;
using UnityEngine;

public sealed class Day64GameSignals : MonoBehaviour
{
    public event Action<Day64Monster> OnSpawn;
    public event Action<Day64Monster, int> OnHit;
    public event Action<Vector3> OnKill;
    public event Action<int> OnWaveCompleted;

    public void RaiseSpawn(Day64Monster monster) => OnSpawn?.Invoke(monster);
    public void RaiseHit(Day64Monster monster, int damage) => OnHit?.Invoke(monster, damage);
    public void RaiseKill(Vector3 position) => OnKill?.Invoke(position);
    public void RaiseWaveCompleted(int wave) => OnWaveCompleted?.Invoke(wave);
}
