#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.AI;

public static class Day64SceneLabBuilderEditor
{
    [MenuItem("Tools/Unity Codex/Day64/Create Integration QA Lab")]
    public static void Build()
    {
        string basePath=AssetDatabase.GenerateUniqueAssetPath("Assets/Day64_Integration_Lab");
        string name=basePath.Substring("Assets/".Length);
        AssetDatabase.CreateFolder("Assets",name);
        string scenes=Dir(basePath,"Scenes");
        string prefabs=Dir(basePath,"Prefabs");
        var scene=EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects,NewSceneMode.Single);
        GameObject ground=GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.name="QA Ground";
        ground.transform.position=new Vector3(0,-0.25f,0);
        ground.transform.localScale=new Vector3(25f,0.5f,25f);
        GameObject prefabRoot=new GameObject("Day64_Enemy_Prefab");
        var enemyCollider=prefabRoot.AddComponent<CapsuleCollider>();
        enemyCollider.center=Vector3.up;
        enemyCollider.height=2f;enemyCollider.radius=0.5f;
        GameObject enemyVisual=GameObject.CreatePrimitive(PrimitiveType.Capsule);
        enemyVisual.name="Body";enemyVisual.transform.SetParent(prefabRoot.transform,false);
        enemyVisual.transform.localPosition=Vector3.up;
        Object.DestroyImmediate(enemyVisual.GetComponent<Collider>());
        // Keep the standalone demo playable before NavMesh is baked.
        // Add a NavMeshAgent to this prefab only when validating the real NavMesh build.
        prefabRoot.AddComponent<Day64Monster>();
        string prefabPath=prefabs+"/Day64_Enemy.prefab";
        GameObject saved=PrefabUtility.SaveAsPrefabAsset(prefabRoot,prefabPath);
        Object.DestroyImmediate(prefabRoot);
        var monster=saved.GetComponent<Day64Monster>();

        var player=GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name="Day64 Player";player.transform.position=new Vector3(0f,1f,-4f);
        Object.DestroyImmediate(player.GetComponent<CapsuleCollider>());
        CharacterController cc=player.AddComponent<CharacterController>();cc.height=2f;cc.radius=.48f;
        var mover=player.AddComponent<Day64PlayerController>();
        var shooter=player.AddComponent<Day64RaycastAttack>();
        Camera camera=Camera.main;
        if(camera==null) { var camObj=new GameObject("Main Camera");camObj.tag="MainCamera";camera=camObj.AddComponent<Camera>(); }
        var follow=camera.gameObject.AddComponent<Day64FollowCamera>();
        follow.Configure(player.transform);
        camera.transform.position=player.transform.position+new Vector3(0f,6f,-9f);
        camera.transform.LookAt(player.transform.position+Vector3.up);

        var root=new GameObject("Day64 QA Game Root");
        var bus=root.AddComponent<Day64GameSignals>();
        var session=root.AddComponent<Day64GameSession>();
        var wave=root.AddComponent<Day64WaveController>();
        var skill=root.AddComponent<Day64SkillController>();
        var save=root.AddComponent<Day64SaveService>();
        var observe=root.AddComponent<Day64IntegrationObserver>();
        var smoke=root.AddComponent<Day64IntegrationSmokeRunner>();
        var hud=root.AddComponent<Day64IntegrationHUD>();
        var feedback=root.AddComponent<Day64CombatFeedback>();
        Transform[] spots=new Transform[3];
        Vector3[] positions={new Vector3(-3f,0f,5f),new Vector3(0f,0f,7f),new Vector3(3f,0f,5f)};
        for(int i=0;i<spots.Length;i++)
        {
            var point=new GameObject("SpawnPoint_"+(i+1));point.transform.position=positions[i];
            point.transform.parent=root.transform;spots[i]=point.transform;
        }
        // Configure component references BEFORE the scene is first enabled in Play Mode.
        wave.Configure(monster,player.transform,session,bus,spots);
        skill.Configure(session);save.Configure(session,wave);
        mover.Configure(session);shooter.Configure(session,camera);
        observe.Configure(bus,wave,session);smoke.Configure(session,wave,observe);
        hud.Configure(session,wave,skill,save,observe,smoke);
        feedback.Configure(bus);
        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene,scenes+"/Day64_Integration_QA.unity");
        AssetDatabase.SaveAssets();AssetDatabase.Refresh();
        Selection.activeGameObject=root;
        Debug.Log("Day64 QA Lab created: "+basePath+". Bake NavMesh for navigation tests; fallback chase is ONLY for demo.");
    }
    private static string Dir(string parent,string name)
    {
        AssetDatabase.CreateFolder(parent,name);
        return parent+"/"+name;
    }
}
#endif
