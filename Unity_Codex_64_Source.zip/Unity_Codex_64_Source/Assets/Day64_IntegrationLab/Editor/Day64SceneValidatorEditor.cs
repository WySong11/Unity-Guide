#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
public static class Day64SceneValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day64/Validate Open Scene")]
    public static void Validate()
    {
        int failed=0;
        if(Object.FindFirstObjectByType<Day64GameSession>()==null) {Debug.LogError("Day64 missing GameSession");failed++;}
        if(Object.FindFirstObjectByType<Day64WaveController>()==null) {Debug.LogError("Day64 missing WaveController");failed++;}
        if(Object.FindFirstObjectByType<Day64GameSignals>()==null) {Debug.LogError("Day64 missing Signals");failed++;}
        if(Object.FindFirstObjectByType<Day64IntegrationObserver>()==null) {Debug.LogError("Day64 missing Observer");failed++;}
        if(Object.FindFirstObjectByType<Day64SaveService>()==null) {Debug.LogError("Day64 missing SaveService");failed++;}
        if(Object.FindFirstObjectByType<Day64PlayerController>()==null) {Debug.LogError("Day64 missing PlayerController");failed++;}
        if(Camera.main==null) {Debug.LogError("Day64 missing MainCamera");failed++;}
        if(failed==0) Debug.Log("Day64 static scene check passed. NOT a Play Mode or NavMesh test.");
        else Debug.LogError($"Day64 static scene check failed: {failed} missing elements");
    }
}
#endif
