#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

/// <summary>열린 씬의 기본 물리 구성 오류를 탐지(수정하지 않음).</summary>
public static class Day35PhysicsValidator
{
    [MenuItem("Tools/Unity Codex/Day35/Validate Open Scene")]
    public static void ValidateOpenScene()
    {
        int issues = 0, bodies = 0, triggers = 0;
        foreach (Rigidbody body in Object.FindObjectsByType<Rigidbody>(FindObjectsSortMode.None))
        {
            bodies++;
            if (body.GetComponent<Collider>() == null && body.GetComponentInChildren<Collider>() == null)
            {
                Debug.LogWarning($"[Day35 Validator] Rigidbody에 Collider 없음: {body.name}", body);
                issues++;
            }
        }
        foreach (Collider collider in Object.FindObjectsByType<Collider>(FindObjectsSortMode.None))
        {
            if (collider.isTrigger) triggers++;
            if (collider is MeshCollider mesh && !mesh.convex && mesh.attachedRigidbody != null && !mesh.attachedRigidbody.isKinematic)
            {
                Debug.LogWarning($"[Day35 Validator] 동적 Rigidbody + 비볼록 MeshCollider: {collider.name}", collider);
                issues++;
            }
        }
        Debug.Log($"[Day35 Validator] Bodies={bodies}, Triggers={triggers}, Issues={issues} " +
                  "(이 도구는 씬 설정을 자동 수정하지 않습니다.)");
    }
}
#endif
