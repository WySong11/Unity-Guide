#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Tools/Unity Codex/Day35 아래 메뉴에서 새 실습 씬 생성.</summary>
public static class Day35PhysicsSceneBuilder
{
    private const string ScenePath = "Assets/Day35_PhysicsLab/Day35_PhysicsLab.unity";

    [MenuItem("Tools/Unity Codex/Day35/Create 3D Physics Lab")]
    public static void CreateLab()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        if (File.Exists(ScenePath) &&
            !EditorUtility.DisplayDialog("씬이 이미 존재합니다", "기존 실습 씬을 덮어쓸까요?", "덮어쓰기", "취소"))
            return;

        if (!AssetDatabase.IsValidFolder("Assets/Day35_PhysicsLab"))
            AssetDatabase.CreateFolder("Assets", "Day35_PhysicsLab");
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        GameObject ground = CreateCube("Ground_Static", new Vector3(0f, -0.25f, 0f),
            new Vector3(16f, 0.5f, 16f), new Color(0.18f, 0.34f, 0.43f));
        ground.AddComponent<Day35CollisionReporter3D>();

        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Player"; player.tag = "Player";
        player.transform.position = new Vector3(-4f, 2.2f, -1f);
        SetMaterial(player, new Color(0.16f, 0.66f, 0.90f));
        Rigidbody playerRb = player.AddComponent<Rigidbody>();
        playerRb.mass = 1f; playerRb.interpolation = RigidbodyInterpolation.Interpolate;
        player.AddComponent<Day35GroundSensor3D>();
        player.AddComponent<Day35PhysicsPlayer3D>();
        player.AddComponent<Day35CollisionReporter3D>();

        for (int i = 0; i < 3; i++)
        {
            GameObject cube = CreateCube("DynamicCube_" + (i + 1),
                new Vector3(-0.8f + i * 1.35f, 2.2f + i * 1.1f, 0f),
                Vector3.one, new Color(0.98f, 0.68f, 0.25f));
            Rigidbody rb = cube.AddComponent<Rigidbody>();
            rb.mass = 1f + i * 2f;
            cube.AddComponent<Day35CollisionReporter3D>();
        }

        GameObject pickup = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        pickup.name = "Pickup_Trigger";
        pickup.transform.position = new Vector3(2f, 1.1f, -2f);
        pickup.transform.localScale = Vector3.one * 0.8f;
        pickup.GetComponent<Collider>().isTrigger = true;
        pickup.AddComponent<Day35TriggerPickup3D>();
        SetMaterial(pickup, new Color(0.25f, 0.88f, 0.52f));

        GameObject pad = CreateCube("ImpulsePad_Trigger", new Vector3(4f, 0.12f, 2f),
            new Vector3(2f, 0.25f, 2f), new Color(0.89f, 0.32f, 0.43f));
        pad.GetComponent<Collider>().isTrigger = true;
        pad.AddComponent<Day35ImpulsePad3D>();

        GameObject ball = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        ball.name = "LaunchBall_L_key";
        ball.transform.position = new Vector3(-1f, 1.5f, 3f);
        Rigidbody ballBody = ball.AddComponent<Rigidbody>();
        ballBody.mass = 0.8f;
        ball.AddComponent<Day35BallLauncher3D>();
        ball.AddComponent<Day35CollisionReporter3D>();
        SetMaterial(ball, new Color(0.53f, 0.45f, 0.94f));

        GameObject cam = new GameObject("Main Camera", typeof(Camera), typeof(AudioListener));
        cam.tag = "MainCamera";
        cam.transform.position = new Vector3(1f, 10f, -15f);
        cam.transform.LookAt(new Vector3(0f, 1f, 0f));
        cam.GetComponent<Camera>().fieldOfView = 56f;

        GameObject lightObj = new GameObject("Directional Light", typeof(Light));
        Light light = lightObj.GetComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.2f;
        lightObj.transform.rotation = Quaternion.Euler(48f, -32f, 0f);

        EditorSceneManager.SaveScene(scene, ScenePath);
        AssetDatabase.SaveAssets();
        Selection.activeGameObject = player;
        EditorGUIUtility.PingObject(player);
        Debug.Log($"[Day35] 실습 씬 생성 완료: {ScenePath} (WASD/방향키 이동, Space 점프, L 공 발사)");
    }

    private static GameObject CreateCube(string objName, Vector3 pos, Vector3 scale, Color tint)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = objName;
        go.transform.position = pos;
        go.transform.localScale = scale;
        SetMaterial(go, tint);
        return go;
    }

    private static void SetMaterial(GameObject go, Color tint)
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (shader == null) shader = Shader.Find("Standard");
        if (shader == null) return;
        Material mat = new Material(shader) { name = $"D35_{go.name}_Material" };
        if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", tint);
        if (mat.HasProperty("_Color")) mat.SetColor("_Color", tint);
        string path = $"Assets/Day35_PhysicsLab/{go.name}_Material.mat";
        AssetDatabase.CreateAsset(mat, AssetDatabase.GenerateUniqueAssetPath(path));
        go.GetComponent<Renderer>().sharedMaterial = mat;
    }
}
#endif
