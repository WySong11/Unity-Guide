using UnityEngine;

/// <summary>물리적 충돌 시 물체 이름, 상대속도, 첫 접점을 Console에 기록.</summary>
public sealed class Day35CollisionReporter3D : MonoBehaviour
{
    [SerializeField] private bool logStay = false;

    private void OnCollisionEnter(Collision collision) => Report("Enter", collision);
    private void OnCollisionExit(Collision collision) => Debug.Log(
        $"[Day35 Collision Exit] {name} / {collision.gameObject.name}", this);

    private void OnCollisionStay(Collision collision)
    {
        if (logStay) Report("Stay", collision);
    }

    private void Report(string phase, Collision collision)
    {
        string details = collision.contactCount > 0
            ? $"first contact: {collision.GetContact(0).point:F2}" : "no contact";
        Debug.Log($"[Day35 Collision {phase}] {name} ↔ {collision.gameObject.name} / " +
                  $"relativeSpeed={collision.relativeVelocity.magnitude:F2} / {details}", this);
        if (collision.contactCount > 0)
        {
            ContactPoint contact = collision.GetContact(0); // contacts 배열 생성 방지
            Debug.DrawRay(contact.point, contact.normal, Color.cyan, 1f);
        }
    }
}
