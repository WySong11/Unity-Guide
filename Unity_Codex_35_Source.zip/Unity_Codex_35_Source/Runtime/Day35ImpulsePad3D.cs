using UnityEngine;

/// <summary>Trigger에 진입하는 동적 Rigidbody에 순간적인 힘 적용.</summary>
[RequireComponent(typeof(Collider))]
public sealed class Day35ImpulsePad3D : MonoBehaviour
{
    [SerializeField] private Vector3 impulse = new Vector3(0f, 7f, 3f);

    private void OnTriggerEnter(Collider other)
    {
        Rigidbody body = other.attachedRigidbody;
        if (body == null || body.isKinematic) return;
        body.AddForce(impulse, ForceMode.Impulse);
        Debug.Log($"[Day35 Impulse Pad] {body.name} : {impulse}", this);
    }
}
