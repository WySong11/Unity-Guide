using UnityEngine;

/// <summary>Capsule 발밑에서 바닥으로 Raycast를 수행하는 3D 접지 센서.</summary>
[RequireComponent(typeof(CapsuleCollider))]
public sealed class Day35GroundSensor3D : MonoBehaviour
{
    [SerializeField] private LayerMask groundLayers = ~0;
    [SerializeField, Min(0.01f)] private float probeDistance = 0.35f;
    [SerializeField, Min(0f)] private float startHeight = 0.15f;

    private CapsuleCollider capsule;
    public bool IsGrounded { get; private set; }

    private void Awake() => capsule = GetComponent<CapsuleCollider>();

    private void FixedUpdate()
    {
        // 시작점은 Capsule의 바닥보다 조금 위쪽에 배치합니다.
        Vector3 origin = new Vector3(capsule.bounds.center.x,
            capsule.bounds.min.y + startHeight, capsule.bounds.center.z);
        IsGrounded = Physics.Raycast(origin, Vector3.down, out RaycastHit hit,
            probeDistance, groundLayers, QueryTriggerInteraction.Ignore)
            && !hit.collider.transform.IsChildOf(transform);
        Debug.DrawRay(origin, Vector3.down * probeDistance,
            IsGrounded ? Color.green : Color.red);
    }

    private void OnDrawGizmosSelected()
    {
        CapsuleCollider current = capsule != null ? capsule : GetComponent<CapsuleCollider>();
        if (current == null) return;
        Vector3 origin = new Vector3(current.bounds.center.x,
            current.bounds.min.y + startHeight, current.bounds.center.z);
        Gizmos.color = Color.yellow;
        Gizmos.DrawLine(origin, origin + Vector3.down * probeDistance);
    }
}
