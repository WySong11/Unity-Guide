using UnityEngine;
using UnityEngine.Events;

/// <summary>Is Trigger가 활성화된 Collider를 통과하면 수집 이벤트를 실행.</summary>
[RequireComponent(typeof(Collider))]
public sealed class Day35TriggerPickup3D : MonoBehaviour
{
    [SerializeField] private string targetTag = "Player";
    [SerializeField] private UnityEvent onCollected = new UnityEvent();
    [SerializeField] private bool hideAfterCollection = true;
    private bool collected;

    private void OnTriggerEnter(Collider other)
    {
        if (collected || !other.CompareTag(targetTag)) return;
        collected = true;
        Debug.Log($"[Day35 Pickup] {other.name} collected {name}", this);
        onCollected.Invoke();
        if (hideAfterCollection) gameObject.SetActive(false);
    }
}
