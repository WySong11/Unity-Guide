using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>L 키 입력 시 공에 충격량을 적용. Input System/Legacy 입력 모두 지원.</summary>
[RequireComponent(typeof(Rigidbody))]
public sealed class Day35BallLauncher3D : MonoBehaviour
{
    [SerializeField] private Vector3 launchDirection = new Vector3(0f, 0.5f, 1f);
    [SerializeField, Min(0f)] private float impulse = 6f;
    private Rigidbody rb;

    private void Awake() => rb = GetComponent<Rigidbody>();

    private void Update()
    {
        bool pressed = false;
#if ENABLE_INPUT_SYSTEM
        pressed = Keyboard.current != null && Keyboard.current.lKey.wasPressedThisFrame;
#elif ENABLE_LEGACY_INPUT_MANAGER
        pressed = Input.GetKeyDown(KeyCode.L);
#endif
        if (!pressed || rb.isKinematic || launchDirection.sqrMagnitude < 0.0001f) return;
        rb.AddForce(launchDirection.normalized * impulse, ForceMode.Impulse);
    }
}
