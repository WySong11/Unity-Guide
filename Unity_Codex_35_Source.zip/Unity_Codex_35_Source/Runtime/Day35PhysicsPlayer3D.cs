using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>입력은 Update, Rigidbody 제어는 FixedUpdate에서 수행합니다.</summary>
[RequireComponent(typeof(Rigidbody), typeof(CapsuleCollider))]
public sealed class Day35PhysicsPlayer3D : MonoBehaviour
{
    [SerializeField, Min(0f)] private float moveSpeed = 5f;
    [SerializeField, Min(0f)] private float jumpImpulse = 5f;
    [SerializeField] private Day35GroundSensor3D groundSensor;

    private Rigidbody rb;
    private Vector2 movement;
    private bool jumpRequested;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
        if (groundSensor == null) groundSensor = GetComponent<Day35GroundSensor3D>();
        rb.constraints |= RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
    }

    private void Update()
    {
#if ENABLE_INPUT_SYSTEM
        Keyboard k = Keyboard.current;
        if (k == null) { movement = Vector2.zero; return; }
        movement = new Vector2(
            (k.dKey.isPressed || k.rightArrowKey.isPressed ? 1 : 0) -
            (k.aKey.isPressed || k.leftArrowKey.isPressed ? 1 : 0),
            (k.wKey.isPressed || k.upArrowKey.isPressed ? 1 : 0) -
            (k.sKey.isPressed || k.downArrowKey.isPressed ? 1 : 0));
        if (k.spaceKey.wasPressedThisFrame) jumpRequested = true;
#elif ENABLE_LEGACY_INPUT_MANAGER
        movement = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        if (Input.GetKeyDown(KeyCode.Space)) jumpRequested = true;
#else
        movement = Vector2.zero;
#endif
    }

    private void FixedUpdate()
    {
        Vector2 axes = Vector2.ClampMagnitude(movement, 1f);
        Vector3 oldVelocity = rb.linearVelocity;
        rb.linearVelocity = new Vector3(axes.x * moveSpeed, oldVelocity.y, axes.y * moveSpeed);

        if (jumpRequested && groundSensor != null && groundSensor.IsGrounded)
        {
            rb.AddForce(Vector3.up * jumpImpulse, ForceMode.Impulse);
        }
        jumpRequested = false;
    }
}
