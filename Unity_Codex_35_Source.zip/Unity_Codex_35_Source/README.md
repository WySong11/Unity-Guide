# Unity Codex 35일차 · 3D 물리 및 충돌

- 권장 환경: Unity 6.3 (6000.3), Universal 3D / URP 프로젝트
- Runtime 6개 + Editor 2개 C# 스크립트, 평가/실습 양식 포함
- `Runtime/*.cs` → `Assets/Day35/Runtime/`, `Editor/*.cs` → `Assets/Day35/Editor/`에 복사
- `Editor` 폴더는 반드시 Editor 전용 폴더에 배치하여 빌드에 포함되지 않게 합니다.

## 빠른 실행
1. Console 컴파일 오류가 없는지 확인합니다.
2. **Tools > Unity Codex > Day35 > Create 3D Physics Lab**을 실행합니다.
3. 이전 씬이 수정됐다면 저장 여부를 선택합니다. 기존 Day35 씬이 있으면 덮어쓰기 여부를 확인합니다.
4. `Assets/Day35_PhysicsLab/Day35_PhysicsLab.unity`가 저장됐는지 확인합니다.
5. Play Mode: **WASD/방향키 이동**, **Space 점프**, **L 공에 힘 적용**.
6. 초록 Sphere는 통과하며 수집되고, 빨간 Pad를 통과하면 위로 튀어 오릅니다.
7. **Tools > Unity Codex > Day35 > Validate Open Scene**에서 기본 구성 검사를 실행합니다.

## 중요한 확인 사항
- 입력은 새 Input System이 활성화돼 있으면 Keyboard.current를 사용하며, Legacy만 활성화돼 있으면 Input.GetAxisRaw를 사용합니다.
- Ground Sensor는 Capsule 바닥 가까운 곳에서 아래로 Raycast합니다. 콜라이더 크기·스케일을 크게 바꾸면 startHeight/probeDistance를 조정하세요.
- Unity 6 Rigidbody는 `linearVelocity`, `linearDamping` 속성을 사용합니다. `Rigidbody2D`와 3D Rigidbody를 혼용하지 않습니다.
- OnCollisionEnter: 양쪽 Collider가 Trigger가 아니어야 하며, 적어도 하나는 동적 Rigidbody여야 합니다.
- OnTriggerEnter: 하나 이상 Trigger Collider, 적어도 하나는 Rigidbody 등의 Physics Body가 필요합니다.
- 물리 설정은 `FixedUpdate()`에서 변경하고, 키 입력은 `Update()`에서 읽습니다.
- 실습 씬 생성 메뉴는 새 실습 Scene을 생성합니다. 기존 URP 34일차 씬을 직접 변경하지 않습니다.
- Editor 유틸리티는 오브젝트 수집/오류 유무를 확인하는 진단 도구이며 플레이 테스트를 대체하지 않습니다.

## 추천 수업 시간(120분)
- 개념/비교 20분 · Collider/Rigidbody 설정 25분 · 충돌/Trigger 25분
- 힘·접지·레이캐스트 25분 · Codex/오류 수정 15분 · 테스트 10분

## 공식 문서
- https://docs.unity3d.com/6000.0/Documentation/ScriptReference/Rigidbody.html
- https://docs.unity3d.com/Manual/collider-interactions.html
- https://docs.unity3d.com/6000.0/Documentation/ScriptReference/Physics.Raycast.html
