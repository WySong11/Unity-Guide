# 35일차 학생 워크시트: 3D 물리 및 충돌

이름: __________________  날짜: _______________  팀: _______________

## A. Inspector 구성(기초)
1. Floor: Cube + BoxCollider, Rigidbody 없음. 중력 영향을 받는가? 왜?
2. FallingCube: Rigidbody + BoxCollider. Mass를 1에서 5로 바꾸고 낙하 결과를 비교하세요.
3. MovingCube: Rigidbody의 Is Kinematic을 켜고 다시 실행하세요. 무엇이 달라지는가?

## B. 충돌과 Trigger(기본)
1. 두 Collider의 Is Trigger를 모두 끄고 충돌 결과를 확인하세요.
2. 한쪽만 Is Trigger를 켜고, `OnCollisionEnter`와 `OnTriggerEnter` 로그를 비교하세요.
3. Rigidbody를 모두 제거하면 왜 콜백이 발생하지 않을 수 있는지 설명하세요.

## C. AddForce·접지(응용)
1. L키 발사 공에 `ForceMode.Impulse`를 적용하고 Mass를 바꾸어 관찰하세요.
2. Capsule 플레이어의 점프가 지면에서만 되는지 확인하세요.
3. Raycast에서 `QueryTriggerInteraction.Ignore`를 빼면 어떤 오검출 위험이 있나요?

## D. 회귀 테스트
| 테스트 | 예상 결과 | 실제 결과(통과/실패) |
|---|---|---|
| Play 누르면 Cube가 낙하한다 | 바닥에서 멈춤 | |
| 장애물 접촉 | OnCollisionEnter 출력 | |
| 초록 Pickup 통과 | OnTriggerEnter 후 비활성화 | |
| 빨간 Pad 진입 | Rigidbody에 Impulse 적용 | |
| Space 점프 | 접지할 때만 점프 | |
| 벽/바닥 통과 여부 | 관통 없이 정상 반응 | |

## E. Codex 질문
- Console의 오류 전문과 발생 단계를 첨부하고, 재현 방법을 적으세요.
- 수정 전/후 git diff를 첨부하고, 영향받는 다른 기능을 나열하세요.
- 최종 제출: Scene 파일, C# 소스, Inspector 캡처 3장 이상, 결과표.
