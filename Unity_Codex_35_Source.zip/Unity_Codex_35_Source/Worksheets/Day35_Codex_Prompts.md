# Codex 프롬프트 예제

## 1. 현재 상태 진단
Unity 6.3 URP 3D 프로젝트입니다. 현재 씬의 Rigidbody, 3D Collider, Is Trigger, Collision Detection, Layer 충돌 매트릭스를 **읽기 전용으로** 분석해 주세요. OnCollision/OnTrigger 호출 조건이 맞는지 확인하고, 컴파일 오류·Inspector 미연결·Physics 설정 문제를 분리하여 근거와 함께 보고하세요. 승인 없이 파일을 수정하지 마세요.

## 2. 최소 수정
다음 재현 단계에서 [오류 메시지]가 발생합니다. [재현 단계/기대 결과/실제 결과/관련 코드/Console Stack Trace]를 보고 우선 원인을 분석해 주세요. 최소 범위의 수정안을 파일별 diff로 제시하고, 승인 후 적용하세요. 기존 2D 시스템과 Day34 URP 씬은 변경하지 마세요.

## 3. 테스트
변경 후 Unity 컴파일 가능 여부를 확인하고, Rigidbody·Collision·Trigger·Grounded·Raycast의 회귀 테스트 목록을 작성해 주세요. Unity Editor/MCP 실행이 불가능하면 실행했다고 주장하지 말고 수동 검증 절차를 제공하세요. 결과를 통과/실패/미검증으로 나눠 보고하세요.
