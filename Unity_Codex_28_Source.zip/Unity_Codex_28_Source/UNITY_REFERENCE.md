# Unity 6 공식 API 참고 자료

- `Time.timeScale`: https://docs.unity.com/en-us/engine/6000.3/script-reference/unityengine/time/timescale
- `Time.unscaledDeltaTime`: https://docs.unity.com/ko-kr/engine/6000.0/script-reference/unityengine/time/unscaleddeltatime
- `WaitForSecondsRealtime`: https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/waitforsecondsrealtime
- `SceneManager.LoadSceneAsync`: https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/scenemanagement/scenemanager/loadsceneasync
- `Application.CanStreamedLevelBeLoaded`: https://docs.unity.com/ko-kr/engine/6000.3/script-reference/unityengine/application/canstreamedlevelbeloaded
