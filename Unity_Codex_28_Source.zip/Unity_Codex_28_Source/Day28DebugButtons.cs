using UnityEngine;

// OnClick()에 아래 public void 메서드들을 연결하여 기능을 확인합니다.
public sealed class Day28DebugButtons : MonoBehaviour
{
    [SerializeField] private GameFlowControllerV2 gameFlow;

    public void Add100Points() { if (gameFlow != null) gameFlow.AddScore(100); }
    public void Win()          { if (gameFlow != null) gameFlow.ShowVictory(); }
    public void Lose()         { if (gameFlow != null) gameFlow.ShowDefeat(); }
    public void Pause()        { if (gameFlow != null) gameFlow.PauseGame(); }
    public void Resume()       { if (gameFlow != null) gameFlow.ResumeGame(); }
    public void Restart()      { if (gameFlow != null) gameFlow.RestartGame(); }
    public void Title()        { if (gameFlow != null) gameFlow.ReturnToTitle(); }
}
