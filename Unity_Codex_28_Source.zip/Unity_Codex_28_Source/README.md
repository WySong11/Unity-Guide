# Unity × Codex — 28일차 실습 소스

수업: **일시정지, 재시작, 게임 흐름** (Unity 6.3 / UGUI + TextMeshPro)

## 파일 구성
- `GameFlowControllerV2.cs`: 상태, 일시정지·재개, 결과, 점수, 재시작/타이틀 로딩
- `PauseHotkeyInput.cs`: Escape / Android Back 키 입력. Input System 또는 Legacy Input Manager 컴파일 분기
- `PauseAwareTimer.cs`: Playing 상태에서만 감소하는 타이머
- `Day28DebugButtons.cs`: Inspector Button OnClick() 테스트 메서드

## 씬 설정
1. `TitleScene`, `GameScene`을 저장하고 **File > Build Profiles > Scene List**에 등록합니다. (Unity 6)
2. `GameScene`에 `Canvas`를 추가합니다. `PausePanel`, `ResultPanel`은 **시작할 때 숨김** 상태로 두어도 `Awake()`가 상태에 맞게 자동 설정합니다.
3. `GameFlow` 빈 오브젝트에 `GameFlowControllerV2`를 붙이고 PausePanel, ResultPanel, TMP 텍스트를 연결합니다.
4. `PauseHotkeyInput`을 별도 오브젝트에 붙여 `GameFlow`를 지정합니다. 일시정지 키 입력은 이 한 컴포넌트에서만 처리하세요.
5. Resume / Restart / Title 버튼의 `On Click()`에 `GameFlowControllerV2.ResumeGame / RestartGame / ReturnToTitle`을 각각 연결합니다.
6. 테스트용 DebugButtons 오브젝트에 `Day28DebugButtons`를 붙이고 Add100Points / Win / Lose 버튼을 연결합니다.
7. 선택: `PauseAwareTimer`를 `GameScene`에 붙이고 TMP 텍스트와 `GameFlow`를 연결합니다.

## 27일차 코드와 함께 사용할 때
- 기존 `GameFlowController`는 27일차 수업의 결과물이고 이번 `GameFlowControllerV2`는 **교체/확장 실습용 별도 클래스**입니다.
- 기존 GameFlowController에 연결했던 버튼은 **V2의 메서드로 다시 연결**합니다.
- 기존 Day26ResultBridge가 GameFlowController 타입을 직접 참조한다면 V2에 맞춰 연결 코드를 수정해야 합니다. 기존 Controller와 V2를 동시에 게임 상태의 소유자로 사용하지 마세요.
- 26일차 `GameScore` 점수는 해당 이벤트를 받아 `GameFlowControllerV2.AddScore(증가량)`로 전달하거나, 본 예제의 `Score`를 사용하세요. **한 프로젝트에 점수의 원천은 하나만** 유지하는 것을 권장합니다. 기존 점수를 동기화하려면 별도의 `SetScore` 인터페이스를 추가해 이벤트가 전달하는 `총점`을 지정하세요. `AddScore`는 **증가량**을 받습니다.

## 동작 검증
- Pause → `Time.timeScale=0` / PausePanel 표시 / Physics 멈춤
- Resume → `Time.timeScale=1` / PausePanel 숨김
- Paused에서 Resume/Restart/Title 버튼 클릭 가능 (EventSystem 필요)
- Result 중 Pause/Escape 추가 입력은 무시
- Restart/Title 연타는 `isLoading`으로 중복 요청 방지
- 재시작/복귀 후 `Time.timeScale=1`
- `PauseAwareTimer`는 Paused/Result/Loading에서 감소하지 않음
- Unity Editor뿐 아니라 Windows/Android 실제 빌드에서 재검증

## 주의사항
- `Time.timeScale=0`은 모든 `Update()`를 멈추지 않습니다. `Time.unscaledDeltaTime`, 애니메이터 Unscaled Time, UI 이벤트는 계속 동작할 수 있습니다. 게임플레이 입력은 `gameFlow.IsPlaying`으로 보호하세요.
- `WaitForSeconds`는 timeScale 영향을 받고, `WaitForSecondsRealtime`은 받지 않습니다.
- `AudioListener.pause`는 전역 오디오에 영향을 줍니다. 일시정지 메뉴 효과음이 필요하면 AudioSource.ignoreListenerPause를 적절히 설정하세요.
- `Time.timeScale`은 전역 상태이므로 다른 일시정지 관리자와 중복 적용하지 마세요.
- 입력이 `Input System Package (New)`이든 `Both`이든 컴파일 심볼로 처리합니다. Legacy 선택 환경도 지원합니다.
- `GameFlowControllerV2` 코드는 입문 수업용 예제로, 실제 프로젝트에서는 씬 전환 서비스·사운드 관리·입력 매니저를 분리할 수 있습니다.
