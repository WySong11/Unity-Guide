using TMPro;
using UnityEngine;

// Time.deltaTime은 Time.timeScale = 0에서 증가하지 않습니다.
public sealed class PauseAwareTimer : MonoBehaviour
{
    [SerializeField] private GameFlowControllerV2 gameFlow;
    [SerializeField] private TMP_Text timerText;
    [SerializeField, Min(1f)] private float durationSeconds = 60f;

    private float remainingSeconds;
    private bool finished;

    private void Awake()
    {
        remainingSeconds = durationSeconds;
        RefreshLabel();
    }

    private void Update()
    {
        if (finished || gameFlow == null || !gameFlow.IsPlaying) return;

        remainingSeconds = Mathf.Max(0f, remainingSeconds - Time.deltaTime);
        RefreshLabel();

        if (remainingSeconds <= 0f)
        {
            finished = true;
            gameFlow.ShowDefeat();
        }
    }

    private void RefreshLabel()
    {
        if (timerText != null)
            timerText.text = $"TIME  {Mathf.CeilToInt(remainingSeconds)}";
    }
}
