using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

// 28일차: TitleScene → GameScene 구조에서 GameScene 내부의 상태를 관리합니다.
public enum Day28FlowState
{
    Playing,
    Paused,
    Result,
    Loading
}

public sealed class GameFlowControllerV2 : MonoBehaviour
{
    [Header("Panels (GameScene)")]
    [SerializeField] private GameObject pausePanel;
    [SerializeField] private GameObject resultPanel;
    [SerializeField] private TMP_Text resultTitleText;
    [SerializeField] private TMP_Text resultScoreText;

    [Header("Scene Transition")]
    [SerializeField] private string titleSceneName = "TitleScene";

    [Header("Pause Settings")]
    [SerializeField] private bool pauseGameplayAudio = true;
    [SerializeField, Min(0)] private int initialScore;

    private bool isLoading;

    public Day28FlowState State { get; private set; } = Day28FlowState.Playing;
    public int Score { get; private set; }
    public bool IsPlaying => State == Day28FlowState.Playing;
    public event Action<Day28FlowState> StateChanged;
    public event Action<int> ScoreChanged;

    private void Awake()
    {
        RestoreTimeAndAudio();
        Score = Mathf.Max(0, initialScore);
        State = Day28FlowState.Playing;
        RefreshPanels();
    }

    private void Start()
    {
        ScoreChanged?.Invoke(Score);
        StateChanged?.Invoke(State);
    }

    public void TogglePause()
    {
        if (State == Day28FlowState.Playing) PauseGame();
        else if (State == Day28FlowState.Paused) ResumeGame();
    }

    public void PauseGame()
    {
        if (State != Day28FlowState.Playing) return;
        SetState(Day28FlowState.Paused);
        Time.timeScale = 0f;
        if (pauseGameplayAudio) AudioListener.pause = true;
    }

    public void ResumeGame()
    {
        if (State != Day28FlowState.Paused) return;
        RestoreTimeAndAudio();
        SetState(Day28FlowState.Playing);
    }

    public void AddScore(int amount)
    {
        if (!IsPlaying || amount <= 0) return;
        Score += amount;
        ScoreChanged?.Invoke(Score);
    }

    public void ShowVictory() => ShowResult("승리!");
    public void ShowDefeat() => ShowResult("패배!");

    private void ShowResult(string message)
    {
        if (State != Day28FlowState.Playing) return;
        RestoreTimeAndAudio();   // 결과 화면의 UI 효과·사운드를 막지 않습니다.
        SetState(Day28FlowState.Result);
        Time.timeScale = 0f;     // 게임 물리와 scaled time을 중지합니다.

        if (resultTitleText != null) resultTitleText.text = message;
        if (resultScoreText != null) resultScoreText.text = $"SCORE  {Score:N0}";
    }

    public void RestartGame()
    {
        if (isLoading) return;
        StartCoroutine(LoadSceneOnce(SceneManager.GetActiveScene().name));
    }

    public void ReturnToTitle()
    {
        if (isLoading) return;
        StartCoroutine(LoadSceneOnce(titleSceneName));
    }

    private IEnumerator LoadSceneOnce(string sceneName)
    {
        if (string.IsNullOrWhiteSpace(sceneName) ||
            !Application.CanStreamedLevelBeLoaded(sceneName))
        {
            Debug.LogError($"[Day28] Scene List에서 '{sceneName}' 씬을 확인하세요.");
            yield break;
        }

        isLoading = true;
        SetState(Day28FlowState.Loading);
        RestoreTimeAndAudio(); // 재시작/복귀 전에 반드시 1로 복원합니다.

        AsyncOperation operation = SceneManager.LoadSceneAsync(sceneName);
        if (operation == null)
        {
            isLoading = false;
            SetState(Day28FlowState.Playing);
            Debug.LogError($"[Day28] Scene 로딩 실패: {sceneName}");
            yield break;
        }

        while (!operation.isDone)
            yield return null;
    }

    private void SetState(Day28FlowState next)
    {
        State = next;
        RefreshPanels();
        StateChanged?.Invoke(State);
    }

    private void RefreshPanels()
    {
        if (pausePanel != null)
            pausePanel.SetActive(State == Day28FlowState.Paused);
        if (resultPanel != null)
            resultPanel.SetActive(State == Day28FlowState.Result);
    }

    private static void RestoreTimeAndAudio()
    {
        Time.timeScale = 1f;
        AudioListener.pause = false;
    }

    private void OnDestroy()
    {
        RestoreTimeAndAudio();
    }
}
