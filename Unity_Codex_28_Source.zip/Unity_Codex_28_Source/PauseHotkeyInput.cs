using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

// 게임플레이 상태에서 Escape / Android Back을 '토글 입력 한 곳'에서 처리합니다.
public sealed class PauseHotkeyInput : MonoBehaviour
{
    [SerializeField] private GameFlowControllerV2 gameFlow;

    private void Update()
    {
        if (gameFlow == null) return;
        bool pausePressed = false;

#if ENABLE_INPUT_SYSTEM
        pausePressed = Keyboard.current != null &&
                       Keyboard.current.escapeKey.wasPressedThisFrame;
#elif ENABLE_LEGACY_INPUT_MANAGER
        pausePressed = Input.GetKeyDown(KeyCode.Escape);
#endif

        if (pausePressed)
            gameFlow.TogglePause();
    }
}
