using TMPro;
using UnityEngine;

public class SkillCooldownHUD : MonoBehaviour
{
    [SerializeField] private PlayerShockwaveSkill skill;
    [SerializeField] private TMP_Text cooldownText;
    private float nextRefresh;

    private void Update()
    {
        if (skill == null || cooldownText == null ||
            Time.unscaledTime < nextRefresh)
            return;

        nextRefresh = Time.unscaledTime + 0.1f;
        float left = skill.Remaining;
        cooldownText.text = left <= 0f ? "Q  READY" : $"Q  {left:0.0}s";
    }
}
