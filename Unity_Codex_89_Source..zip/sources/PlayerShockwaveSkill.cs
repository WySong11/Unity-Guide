using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// Requires the earlier lessons' PlayerHealth, EnemyHealth and StageWaveController.
/// Wire PlayerInput's Skill action (Invoke Unity Events) to OnSkill.
/// </summary>
public class PlayerShockwaveSkill : MonoBehaviour
{
    [SerializeField] private SkillDefinitionSO skill;
    [SerializeField] private PlayerHealth player;
    [SerializeField] private StageWaveController stage;
    [SerializeField] private Transform hitOrigin;
    [SerializeField] private LayerMask enemyLayers;

    private readonly SkillCooldown cooldown = new();
    // Fixed-size buffer: increase capacity if encounters can exceed 32 colliders.
    private readonly Collider2D[] hits = new Collider2D[32];
    private readonly HashSet<EnemyHealth> unique = new();

    public float Remaining => cooldown.Remaining(Time.time);

    public void OnSkill(InputAction.CallbackContext context)
    {
        if (context.performed) TryCast();
    }

    public bool TryCast()
    {
        if (skill == null || player == null || !player.IsAlive ||
            hitOrigin == null || Time.timeScale == 0f)
            return false;

        if (stage != null && stage.State != StageRunState.Spawning &&
            stage.State != StageRunState.Fighting)
            return false;

        if (!cooldown.TryStart(Time.time, skill.cooldown)) return false;
        ApplyShockwave();
        return true;
    }

    private void ApplyShockwave()
    {
        var filter = new ContactFilter2D
        {
            useLayerMask = true,
            layerMask = enemyLayers
        };

        int count = Physics2D.OverlapCircle(
            (Vector2)hitOrigin.position, skill.radius, filter, hits);

        unique.Clear();
        for (int i = 0; i < count; i++)
        {
            var hp = hits[i].GetComponentInParent<EnemyHealth>();
            if (hp != null && hp.IsAlive && unique.Add(hp))
                hp.TakeDamage(skill.damage);
        }

        // VFX / SFX are added to a dedicated view in the optional extension.
    }

    private void OnDrawGizmosSelected()
    {
        if (hitOrigin == null || skill == null) return;
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(hitOrigin.position, skill.radius);
    }
}
