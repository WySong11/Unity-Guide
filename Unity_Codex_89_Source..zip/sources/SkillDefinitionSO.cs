using UnityEngine;

[CreateAssetMenu(menuName = "WaveGuard/Skill", fileName = "Skill_Shockwave")]
public class SkillDefinitionSO : ScriptableObject
{
    public string id = "shockwave";
    public string displayName = "충격파";
    public Sprite icon;
    [Min(0f)] public float cooldown = 5f;
    [Min(0)] public int damage = 2;
    [Min(0.1f)] public float radius = 2f;
}
