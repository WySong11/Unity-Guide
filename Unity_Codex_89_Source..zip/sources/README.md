# 89일차 — WAVE GUARD 스킬 / 아이템 실습 코드

**기준**: Unity 6.3 LTS (6000.3), URP 2D, New Input System, TextMeshPro.

## 필수 선행 코드
- 85일차: `PlayerHealth` (`IsAlive`, `CurrentHealth`, `HealthChanged`, `maxHealth` 사용)
- 86일차: `EnemyHealth` (`IsAlive`, `TakeDamage(int)` 사용)
- 87일차: `StageWaveController` / `StageRunState` (`Spawning`, `Fighting`)
- 88일차: PlayerInput 이벤트·Stage UI·Pause/Restart 흐름

프로젝트 코드와 이름이 다르면 **기존 공개 API를 먼저 확인하여 연결을 수정**하세요. 이 ZIP만 빈 Unity 프로젝트에 복사한다고 완성되는 독립 프로젝트는 아닙니다.

## 적용
1. `SkillDefinitionSO`, `SkillCooldown`, `PlayerShockwaveSkill`을 `Assets/_Game/Scripts/Skills`에 배치합니다.
2. `ItemDefinitionSO`, `HealthItemPickup2D`를 `Assets/_Game/Scripts/Items`에 배치합니다.
3. `SkillCooldownHUD`를 `Assets/_Game/Scripts/UI`에 배치합니다.
4. `PlayerHealth_Heal_PATCH.txt`의 **메서드만 기존 PlayerHealth 클래스 내부에 추가**합니다. 해당 .txt는 C# 소스 파일로 컴파일되는 대상이 아닙니다.
5. Assets > Create > WaveGuard > Skill 에서 `Skill_Shockwave` 생성: Cooldown 5 / Damage 2 / Radius 2.
6. Assets > Create > WaveGuard > Item 에서 `Item_PotionSmall` 생성: Effect Heal / Amount 2.
7. Player에 `PlayerShockwaveSkill`을 추가하고 Skill, PlayerHealth, StageWaveController, HitOrigin, Enemy LayerMask를 Inspector에 연결합니다.
8. 기존 Input Actions의 **Player** Map에 Button 타입 Skill 액션을 만들고 `<Keyboard>/q` 바인딩합니다. PlayerInput Behavior를 `Invoke Unity Events`로 쓰는 경우 Skill 이벤트에 `PlayerShockwaveSkill.OnSkill`을 지정합니다.
9. Item Prefab에 SpriteRenderer + CircleCollider2D(`isTrigger=true`) + `HealthItemPickup2D`를 추가하고 Item 에셋을 할당합니다. Player/Item Trigger에 필요한 Rigidbody2D 및 Layer Collision Matrix를 확인합니다.
10. Canvas에 TMP_Text와 SkillCooldownHUD를 추가하고 Player Skill 참조를 연결합니다.
11. EditMode Tests를 별도 Test Assembly에 배치하고 Runtime Assembly에 대한 참조를 설정한 다음 실행합니다.

## 테스트 / 주의
- Skill은 `Time.time`을 사용하므로 `Time.timeScale=0`일 때 재사용 대기시간도 멈춥니다. HUD 표시 타이밍은 `Time.unscaledTime`을 사용합니다.
- `Physics2D.OverlapCircle`은 미리 할당한 Collider2D[32] 버퍼를 사용합니다. 32개 초과의 Collider가 동시에 겹치면 추가 적이 누락될 수 있습니다. 예상 최대 콜라이더 수에 맞게 버퍼를 조정하세요.
- 한 적에 여러 자식 Collider가 있는 경우 HashSet으로 중복 피해를 방지합니다.
- 회복량이 0이면 (예: 체력 최대 상태) 아이템을 소비하지 않는 정책입니다.
- 플레이어가 죽거나 결과 화면이 나타난 경우 스킬 입력을 차단합니다. 입력 액션 연결과 UI 상태 처리는 PlayMode에서 별도로 확인해야 합니다.
- ScriptableObject의 정적 데이터는 Play 중 변경하지 말고, Cooldown·Pickup 소모 상태는 런타임 컴포넌트에서 관리합니다.
- 이 자료는 교육용 예제입니다. 사용 중인 Unity 버전 및 선행 강의의 실제 클래스 정의에 따라 컴파일 확인이 필요합니다.
