using NUnit.Framework;

public class SkillCooldownTests
{
    [Test]
    public void BlocksUntilExactReadyTime()
    {
        var cooldown = new SkillCooldown();
        Assert.IsTrue(cooldown.TryStart(10f, 5f));
        Assert.IsFalse(cooldown.TryStart(14.99f, 5f));
        Assert.AreEqual(0.01f, cooldown.Remaining(14.99f), 0.001f);
        Assert.IsTrue(cooldown.TryStart(15f, 5f));
    }

    [Test]
    public void StartsReadyButRejectsNegativeDuration()
    {
        var cooldown = new SkillCooldown();
        Assert.IsTrue(cooldown.IsReady(0f));
        Assert.IsFalse(cooldown.TryStart(0f, -1f));
        Assert.IsTrue(cooldown.TryStart(0f, 0f));
    }
}
