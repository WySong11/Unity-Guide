using UnityEngine;

public enum ItemEffectType { Heal }

[CreateAssetMenu(menuName = "WaveGuard/Item", fileName = "Item_PotionSmall")]
public class ItemDefinitionSO : ScriptableObject
{
    public string id = "potion_small";
    public string displayName = "작은 회복약";
    public Sprite icon;
    public ItemEffectType effect = ItemEffectType.Heal;
    [Min(1)] public int amount = 2;
}
