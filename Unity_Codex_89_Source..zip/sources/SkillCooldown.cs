using System;

// Game-logic time is passed in from the caller. Can run in EditMode tests.
public sealed class SkillCooldown
{
    private float nextReadyAt = float.NegativeInfinity;

    public bool IsReady(float now) => now >= nextReadyAt;
    public float Remaining(float now) => Math.Max(0f, nextReadyAt - now);

    public bool TryStart(float now, float duration)
    {
        if (duration < 0f || !IsReady(now)) return false;
        nextReadyAt = now + duration;
        return true;
    }
}
