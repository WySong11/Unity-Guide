using UnityEngine;

/// <summary>
/// Requires PlayerHealth.Heal(int) from the included health patch.
/// </summary>
public class HealthItemPickup2D : MonoBehaviour
{
    [SerializeField] private ItemDefinitionSO item;
    private bool consumed;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (consumed || item == null || item.effect != ItemEffectType.Heal)
            return;

        var health = other.GetComponentInParent<PlayerHealth>();
        if (health == null || !health.IsAlive) return;

        // By design, do not consume when already at full HP.
        if (health.Heal(item.amount) <= 0) return;
        consumed = true;
        Destroy(gameObject);
    }
}
