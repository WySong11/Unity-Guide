using TMPro;
using UnityEngine;

public class StageHUD : MonoBehaviour
{
    [SerializeField] StageWaveController controller;
    [SerializeField] TMP_Text waveText;
    [SerializeField] TMP_Text aliveText;
    [SerializeField] TMP_Text statusText;

    void OnEnable()
    {
        if (controller == null) return;
        controller.WaveStarted += OnWave;
        controller.AliveChanged += OnAlive;
        controller.StateChanged += OnState;
    }

    void OnDisable()
    {
        if (controller == null) return;
        controller.WaveStarted -= OnWave;
        controller.AliveChanged -= OnAlive;
        controller.StateChanged -= OnState;
    }

    void OnWave(int current, int total)
    {
        if (waveText != null) waveText.text = $"WAVE {current}/{total}";
    }

    void OnAlive(int count)
    {
        if (aliveText != null) aliveText.text = $"ENEMY {count}";
    }

    void OnState(StageRunState state)
    {
        if (statusText != null) statusText.text = state switch
        {
            StageRunState.Clear => "STAGE CLEAR!",
            StageRunState.GameOver => "GAME OVER",
            StageRunState.Spawning => "INCOMING WAVE",
            StageRunState.Fighting => "FIGHT!",
            _ => "READY"
        };
    }
}
