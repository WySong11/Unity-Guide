# 87일차 WAVE GUARD - 스테이지/웨이브 샘플 코드

## 기준
- Unity 6.3 LTS (6000.3), 2D, C#; UI는 TextMeshPro 사용
- 85일차 `PlayerHealth` (`Died` 이벤트) 및 86일차 `EnemyHealth` (`Died`, `TakeDamage`, `ResetHealth`)가 프로젝트에 존재해야 합니다.

## 구성
- `WaveDefinitionSO.cs`, `StageDefinitionSO.cs`: 에셋으로 관리할 스테이지/웨이브 데이터
- `WaveRules.cs`: 데이터 검증 및 총 생성 수 계산
- `StageWaveController.cs`: 웨이브 실행, 적 사망 집계, 클리어/게임오버
- `StageHUD.cs`: 상태 이벤트를 HUD에 표시
- `Tests/EditMode/WaveRulesTests.cs`: NUnit EditMode 테스트

## 적용 순서
1. 소스를 Assets/_Game/Scripts/Wave 폴더로 복사합니다. 테스트는 Test Assembly의 EditMode 폴더에 배치합니다.
2. Assets > Create > WaveGuard > Wave Definition 메뉴로 Wave_01 ~ Wave_03을 생성합니다.
3. 각 Wave 에셋의 Groups에 86일차 Enemy Prefab의 EnemyHealth 컴포넌트를 드래그하고 count, interval을 설정합니다.
4. Assets > Create > WaveGuard > Stage Definition에서 Stage_01을 생성하고 waves 배열에 순서대로 등록합니다.
5. Stage Scene에 `StageSystem` GameObject를 만들고 `StageWaveController` 컴포넌트를 추가합니다.
6. Stage, SpawnPoints 배열(비어 있거나 null이면 시작 안 됨), PlayerHealth 참조를 Inspector에서 지정합니다.
7. Canvas에 TextMeshPro 텍스트 3개를 배치하고 StageHUD의 필드에 연결합니다.
8. 실행 시 모든 웨이브의 적을 처치하면 Clear, PlayerHealth가 사망하면 GameOver가 됩니다.

## 주의
- 이 예제는 `Instantiate`를 사용합니다. ObjectPool 통합은 확장 과제이며, 풀로 되돌릴 때도 반드시 한 번만 적 사망 집계를 해야 합니다.
- `EnemyHealth.Died`는 적이 사망하면 단 한 번 발생해야 합니다. `Destroy`/강제 제거만 수행하면 AliveCount가 남아 진행이 멈출 수 있습니다.
- 게임오버 후 재시작은 씬 재로드 방식으로 구현하세요. 같은 씬에서 `Begin`만 다시 호출하는 구조가 아닙니다.
- 실행 도중 코드에서 ScriptableObject 에셋 값을 바꾸지 마세요. 런타임 진행 상태는 `StageWaveController`가 담당합니다.
- 플레이어/적 오브젝트와 씬 참조, 공격 판정은 전일차 프로젝트 설정에 따라 직접 연결해야 합니다.
- `StageHUD`는 초기 이벤트가 구독 전에 발생하는 문제가 없도록 StageWaveController.Start()가 실행되기 전에 OnEnable에서 구독합니다.
