using NUnit.Framework;
using UnityEngine;

public class WaveRulesTests
{
    [Test]
    public void CountEnemies_AddsGroups_AndIgnoresNegative()
    {
        var wave = ScriptableObject.CreateInstance<WaveDefinitionSO>();
        try
        {
            wave.groups = new[]
            {
                new EnemySpawnGroup { count = 3 },
                new EnemySpawnGroup { count = 2 },
                new EnemySpawnGroup { count = -1 }
            };
            Assert.AreEqual(5, WaveRules.CountEnemies(wave));
        }
        finally { Object.DestroyImmediate(wave); }
    }
}
