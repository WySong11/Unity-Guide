using UnityEngine;

public static class WaveRules
{
    public static int CountEnemies(WaveDefinitionSO wave)
    {
        if (wave == null || wave.groups == null) return 0;
        int total = 0;
        foreach (var group in wave.groups)
        {
            if (group != null) total += Mathf.Max(0, group.count);
        }
        return total;
    }

    public static bool IsValid(StageDefinitionSO stage, Transform[] spawnPoints,
                               PlayerHealth player)
    {
        if (stage == null || player == null ||
            spawnPoints == null || spawnPoints.Length == 0 ||
            stage.waves == null || stage.waves.Length == 0)
            return false;

        foreach (var point in spawnPoints)
            if (point == null) return false;

        foreach (var wave in stage.waves)
        {
            if (wave == null || wave.groups == null || wave.groups.Length == 0)
                return false;
            foreach (var group in wave.groups)
                if (group == null || group.enemyPrefab == null ||
                    group.count < 1 || group.interval < 0f)
                    return false;
        }
        return true;
    }
}
