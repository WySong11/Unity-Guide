using System;
using UnityEngine;

[Serializable]
public class EnemySpawnGroup
{
    public EnemyHealth enemyPrefab;
    [Min(1)] public int count = 3;
    [Min(0f)] public float interval = 0.6f;
}

[CreateAssetMenu(fileName = "Wave_01", menuName = "WaveGuard/Wave Definition")]
public class WaveDefinitionSO : ScriptableObject
{
    [Min(0f)] public float startDelay = 1f;
    public EnemySpawnGroup[] groups;
}
