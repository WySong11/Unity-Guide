using UnityEngine;

[CreateAssetMenu(fileName = "Stage_01", menuName = "WaveGuard/Stage Definition")]
public class StageDefinitionSO : ScriptableObject
{
    public string stageId = "Stage_01";
    public WaveDefinitionSO[] waves;
}
