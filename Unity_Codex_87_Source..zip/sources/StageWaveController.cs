using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum StageRunState { Idle, Spawning, Fighting, Clear, GameOver }

public class StageWaveController : MonoBehaviour
{
    [SerializeField] StageDefinitionSO stage;
    [SerializeField] Transform[] spawnPoints;
    [SerializeField] PlayerHealth player;

    public StageRunState State { get; private set; } = StageRunState.Idle;
    public int WaveIndex { get; private set; } = -1;
    public int AliveCount { get; private set; }
    public event Action<int, int> WaveStarted;
    public event Action<int> AliveChanged;
    public event Action<StageRunState> StateChanged;

    readonly Dictionary<EnemyHealth, Action> deathHandlers = new();
    Coroutine run;

    void Start() => Begin();

    public void Begin()
    {
        if (run != null || State != StageRunState.Idle) return;
        if (!WaveRules.IsValid(stage, spawnPoints, player))
        {
            Debug.LogError("[Stage] Invalid stage, spawns or player", this);
            return;
        }
        player.Died += OnPlayerDied;
        run = StartCoroutine(RunStage());
    }

    IEnumerator RunStage()
    {
        for (int wi = 0; wi < stage.waves.Length; wi++)
        {
            if (State == StageRunState.GameOver) yield break;
            WaveIndex = wi;
            var wave = stage.waves[wi];
            SetState(StageRunState.Spawning);
            WaveStarted?.Invoke(wi + 1, stage.waves.Length);

            if (wave.startDelay > 0f)
                yield return new WaitForSeconds(wave.startDelay);
            if (State == StageRunState.GameOver) yield break;

            foreach (var group in wave.groups)
            {
                for (int i = 0; i < group.count; i++)
                {
                    if (State == StageRunState.GameOver) yield break;
                    SpawnOne(group.enemyPrefab);
                    if (group.interval > 0f)
                        yield return new WaitForSeconds(group.interval);
                    else
                        yield return null; // spread zero-delay spawns over frames
                }
            }

            SetState(StageRunState.Fighting);
            while (AliveCount > 0 && State != StageRunState.GameOver)
                yield return null;
        }
        if (State != StageRunState.GameOver)
            SetState(StageRunState.Clear);
        run = null;
    }

    void SpawnOne(EnemyHealth prefab)
    {
        var point = spawnPoints[UnityEngine.Random.Range(0, spawnPoints.Length)];
        var enemy = Instantiate(prefab, point.position, point.rotation);
        // The previous day's EnemyHealth exposes a parameterless Died event.
        Action handler = () => OnEnemyDied(enemy);
        enemy.Died += handler;
        deathHandlers.Add(enemy, handler);
        AliveCount++;
        AliveChanged?.Invoke(AliveCount);
    }

    void OnEnemyDied(EnemyHealth enemy)
    {
        if (!deathHandlers.TryGetValue(enemy, out var handler)) return;
        enemy.Died -= handler;
        deathHandlers.Remove(enemy);
        AliveCount = Mathf.Max(0, AliveCount - 1);
        AliveChanged?.Invoke(AliveCount);
    }

    void OnPlayerDied()
    {
        SetState(StageRunState.GameOver);
        if (run != null) StopCoroutine(run);
        run = null;
    }

    void SetState(StageRunState next)
    {
        if (State == next) return;
        State = next;
        StateChanged?.Invoke(next);
    }

    void OnDisable()
    {
        if (run != null) StopCoroutine(run);
        run = null;
        if (player != null) player.Died -= OnPlayerDied;
        foreach (var entry in deathHandlers)
            if (entry.Key != null) entry.Key.Died -= entry.Value;
        deathHandlers.Clear();
    }
}
