using UnityEngine;

public interface IDay44Damageable
{
    void TakeDamage(float amount, GameObject source);
}
