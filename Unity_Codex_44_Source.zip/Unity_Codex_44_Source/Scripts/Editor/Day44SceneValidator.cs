#if UNITY_EDITOR
using System.Linq;
using UnityEditor;
using UnityEngine;

public static class Day44SceneValidator
{
    [MenuItem("Tools/Unity Codex/Day44/Validate Current Scene")]
    public static void Validate()
    {
        var combat = UnityEngine.Object.FindFirstObjectByType<Day44CombatCoordinator>();
        var relay = UnityEngine.Object.FindFirstObjectByType<Day44AnimationEventRelay>();
        var targets = UnityEngine.Object.FindObjectsByType<Day44TargetHealth>(FindObjectsSortMode.None);
        if (!combat) Debug.LogError("[Day44] CombatCoordinator 누락");
        else Debug.Log("[Day44] CombatCoordinator OK");
        if (!relay) Debug.LogWarning("[Day44] AnimationEventRelay 누락");
        if (combat && relay && combat.gameObject != relay.gameObject)
            Debug.LogWarning("[Day44] Animator와 Relay의 GameObject 일치 여부를 확인하세요.");
        if (targets.Length == 0) Debug.LogWarning("[Day44] Health 타깃 없음");
        else Debug.Log("[Day44] 타깃 " + targets.Length + "개");
        if (!Camera.main) Debug.LogWarning("[Day44] MainCamera 태그가 있는 카메라 없음");
        if (combat)
        {
            var animator = combat.GetComponent<Animator>();
            if (!animator || !animator.runtimeAnimatorController)
                Debug.LogWarning("[Day44] Animator Controller 미연결");
            else
            {
                foreach (string p in new[] { "Melee", "Ranged" })
                    if (!animator.parameters.Any(x => x.name == p && x.type == AnimatorControllerParameterType.Trigger))
                        Debug.LogWarning("[Day44] Animator Trigger 없음: " + p);
            }
        }
        Debug.Log("[Day44] 검증 완료 — 실제 Attack Event와 Play Mode 테스트는 별도 실행 필요");
    }
}
#endif
