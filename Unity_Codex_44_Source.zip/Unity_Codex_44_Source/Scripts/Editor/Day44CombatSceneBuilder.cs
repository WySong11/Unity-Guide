#if UNITY_EDITOR
using System;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

public static class Day44CombatSceneBuilder
{
    private const string Folder = "Assets/Unity_Codex_Day44";

    [MenuItem("Tools/Unity Codex/Day44/Create Combat Practice Scene")]
    public static void CreatePracticeScene()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        if (!AssetDatabase.IsValidFolder(Folder)) AssetDatabase.CreateFolder("Assets", "Unity_Codex_Day44");
        string scenePath = AssetDatabase.GenerateUniqueAssetPath(Folder + "/Day44CombatPractice.unity");
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        var ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.name = "Ground";
        ground.transform.position = new Vector3(0, -0.4f, 2);
        ground.transform.localScale = new Vector3(16, 0.5f, 18);

        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Day44Player";
        player.transform.position = new Vector3(0, 1f, 0);
        player.transform.rotation = Quaternion.identity;

        GameObject visual = GameObject.CreatePrimitive(PrimitiveType.Cube);
        visual.name = "Visual";
        visual.transform.SetParent(player.transform, false);
        visual.transform.localPosition = new Vector3(0, 0.25f, 0);
        visual.transform.localScale = new Vector3(0.65f, 0.65f, 0.65f);
        var visualCollider = visual.GetComponent<Collider>();
        if (visualCollider) UnityEngine.Object.DestroyImmediate(visualCollider);

        var animator = player.AddComponent<Animator>();
        animator.runtimeAnimatorController = CreateAnimator();
        player.AddComponent<Day44MeleeHitbox>();
        var ranged = player.AddComponent<Day44HitscanGun>();
        var coordinator = player.AddComponent<Day44CombatCoordinator>();
        player.AddComponent<Day44AnimationEventRelay>();
        player.AddComponent<Day44CombatInput>();
        player.AddComponent<AudioSource>();
        player.AddComponent<Day44CombatFeedback>();

        GameObject muzzle = new GameObject("Muzzle");
        muzzle.transform.SetParent(player.transform, false);
        muzzle.transform.localPosition = new Vector3(0, 0.35f, 0.75f);
        Assign(ranged, "muzzle", muzzle.transform);
        Assign(ranged, "aimCamera", CreateCamera());

        var targetA = GameObject.CreatePrimitive(PrimitiveType.Cube);
        targetA.name = "Target_A";
        targetA.transform.position = new Vector3(0, 1f, 2.0f);
        targetA.transform.localScale = new Vector3(1.1f, 2f, 1f);
        targetA.AddComponent<Day44TargetHealth>();
        var targetB = GameObject.CreatePrimitive(PrimitiveType.Cube);
        targetB.name = "Target_B";
        targetB.transform.position = new Vector3(2.5f, 1f, 5.5f);
        targetB.transform.localScale = new Vector3(1.1f, 2f, 1f);
        targetB.AddComponent<Day44TargetHealth>();
        var targetC = GameObject.CreatePrimitive(PrimitiveType.Cube);
        targetC.name = "Target_C";
        targetC.transform.position = new Vector3(-2.5f, 1f, 5.5f);
        targetC.transform.localScale = new Vector3(1.1f, 2f, 1f);
        targetC.AddComponent<Day44TargetHealth>();

        var lightGo = new GameObject("Directional Light");
        var sun = lightGo.AddComponent<Light>();
        sun.type = LightType.Directional;
        lightGo.transform.rotation = Quaternion.Euler(50, -35, 0);

        var canvas = new GameObject("CombatCanvas", typeof(RectTransform), typeof(Canvas),
            typeof(CanvasScaler), typeof(GraphicRaycaster));
        var c = canvas.GetComponent<Canvas>();
        c.renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvas.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        var hud = canvas.AddComponent<Day44CombatHUD>();
        Assign(hud, "combat", coordinator);
        Assign(hud, "target", targetA.GetComponent<Day44TargetHealth>());
        var meleeImage = CreateFillImage(canvas.transform, "MeleeCooldown", new Vector2(0.06f, 0.15f), Color.cyan);
        var rangedImage = CreateFillImage(canvas.transform, "RangedCooldown", new Vector2(0.15f, 0.15f), Color.yellow);
        Assign(hud, "meleeCooldownFill", meleeImage);
        Assign(hud, "rangedCooldownFill", rangedImage);
        var status = CreateText(canvas.transform, "AttackStatus", "J 근접 / K 원거리", new Vector2(0.08f, 0.23f));
        var hp = CreateText(canvas.transform, "TargetHealth", "HP 100 / 100", new Vector2(0.08f, 0.29f));
        Assign(hud, "statusText", status);
        Assign(hud, "targetHealthText", hp);

        EditorSceneManager.SaveScene(scene, scenePath);
        AssetDatabase.SaveAssets();
        Selection.activeGameObject = player;
        Debug.Log("[Day44] 새 실습 씬 생성: " + scenePath + " | J=근접, K=원거리");
    }

    private static Camera CreateCamera()
    {
        var go = new GameObject("Main Camera");
        go.tag = "MainCamera";
        var camera = go.AddComponent<Camera>();
        go.AddComponent<AudioListener>();
        go.transform.position = new Vector3(0, 3.8f, -7.6f);
        go.transform.LookAt(new Vector3(0, 1.1f, 4.5f));
        return camera;
    }

    private static AnimatorController CreateAnimator()
    {
        string ctrlPath = AssetDatabase.GenerateUniqueAssetPath(Folder + "/Day44Combat.controller");
        AnimatorController controller = AnimatorController.CreateAnimatorControllerAtPath(ctrlPath);
        controller.AddParameter("Melee", AnimatorControllerParameterType.Trigger);
        controller.AddParameter("Ranged", AnimatorControllerParameterType.Trigger);
        var sm = controller.layers[0].stateMachine;
        var idle = sm.AddState("Idle");
        var melee = sm.AddState("MeleeAttack");
        var ranged = sm.AddState("RangedAttack");
        idle.motion = CreateClip("Idle", 0.6f, 1f, null);
        melee.motion = CreateClip("MeleeAttack", 0.65f, 1.22f,
            new[] { new AnimationEvent { time=0.22f, functionName="AE_MeleeOpen" },
                    new AnimationEvent { time=0.39f, functionName="AE_MeleeClose" },
                    new AnimationEvent { time=0.60f, functionName="AE_AttackEnd" } });
        ranged.motion = CreateClip("RangedAttack", 0.65f, 1.12f,
            new[] { new AnimationEvent { time=0.30f, functionName="AE_Fire" },
                    new AnimationEvent { time=0.60f, functionName="AE_AttackEnd" } });
        sm.defaultState = idle;
        AddAttackTransition(sm, melee, "Melee");
        AddAttackTransition(sm, ranged, "Ranged");
        AddReturn(melee, idle);
        AddReturn(ranged, idle);
        return controller;
    }
    private static AnimationClip CreateClip(string name, float duration, float peak, AnimationEvent[] events)
    {
        var clip = new AnimationClip { name = "Day44_" + name, frameRate = 30f };
        var x = new AnimationCurve(new Keyframe(0f, 0.65f), new Keyframe(duration*0.45f, 0.65f*peak), new Keyframe(duration, 0.65f));
        var y = new AnimationCurve(new Keyframe(0f, 0.65f), new Keyframe(duration*0.45f, 0.65f/peak), new Keyframe(duration, 0.65f));
        AnimationUtility.SetEditorCurve(clip, EditorCurveBinding.FloatCurve("Visual", typeof(Transform), "m_LocalScale.x"), x);
        AnimationUtility.SetEditorCurve(clip, EditorCurveBinding.FloatCurve("Visual", typeof(Transform), "m_LocalScale.y"), y);
        AnimationUtility.SetEditorCurve(clip, EditorCurveBinding.FloatCurve("Visual", typeof(Transform), "m_LocalScale.z"), x);
        clip.events = events ?? Array.Empty<AnimationEvent>();
        string path = AssetDatabase.GenerateUniqueAssetPath(Folder + "/" + clip.name + ".anim");
        AssetDatabase.CreateAsset(clip, path);
        return clip;
    }
    private static void AddAttackTransition(AnimatorStateMachine sm, AnimatorState dst, string trigger)
    {
        var t = sm.AddAnyStateTransition(dst);
        t.hasExitTime = false;
        t.duration = 0.05f;
        t.canTransitionToSelf = false;
        t.AddCondition(AnimatorConditionMode.If, 0f, trigger);
    }
    private static void AddReturn(AnimatorState from, AnimatorState to)
    {
        var t = from.AddTransition(to);
        t.hasExitTime = true;
        t.exitTime = 1f;
        t.duration = 0.03f;
    }
    private static Image CreateFillImage(Transform parent, string name, Vector2 anchor, Color color)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        var rt = go.GetComponent<RectTransform>();
        rt.anchorMin = rt.anchorMax = anchor;
        rt.sizeDelta = new Vector2(100, 34);
        var image = go.GetComponent<Image>();
        image.color = color;
        image.type = Image.Type.Filled;
        image.fillMethod = Image.FillMethod.Horizontal;
        image.fillAmount = 0f;
        return image;
    }
    private static TextMeshProUGUI CreateText(Transform parent, string name, string content, Vector2 anchor)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(TextMeshProUGUI));
        go.transform.SetParent(parent, false);
        var rect = go.GetComponent<RectTransform>();
        rect.anchorMin = rect.anchorMax = anchor;
        rect.sizeDelta = new Vector2(380, 48);
        var text = go.GetComponent<TextMeshProUGUI>();
        text.text = content;
        text.fontSize = 26f;
        text.color = Color.white;
        return text;
    }
    private static void Assign(UnityEngine.Object obj, string property, UnityEngine.Object value)
    {
        var so = new SerializedObject(obj);
        so.FindProperty(property).objectReferenceValue = value;
        so.ApplyModifiedPropertiesWithoutUndo();
    }
}
#endif
