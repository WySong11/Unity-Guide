using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Day44CombatHUD : MonoBehaviour
{
    [SerializeField] private Day44CombatCoordinator combat;
    [SerializeField] private Day44TargetHealth target;
    [SerializeField] private Image meleeCooldownFill;
    [SerializeField] private Image rangedCooldownFill;
    [SerializeField] private Slider targetHealthSlider;
    [SerializeField] private TMP_Text statusText;
    [SerializeField] private TMP_Text targetHealthText;

    private void OnEnable()
    {
        if (combat)
        {
            combat.AttackStarted += OnAttackStarted;
            combat.AttackFinished += OnAttackFinished;
        }
        if (target) target.HealthChanged += OnHealthChanged;
        if (target) OnHealthChanged(target.CurrentHealth, target.MaxHealth);
        UpdateAttackStatus();
    }
    private void OnDisable()
    {
        if (combat)
        {
            combat.AttackStarted -= OnAttackStarted;
            combat.AttackFinished -= OnAttackFinished;
        }
        if (target) target.HealthChanged -= OnHealthChanged;
    }
    private void Update()
    {
        if (!combat) return;
        if (meleeCooldownFill) meleeCooldownFill.fillAmount = combat.GetCooldown01(Day44AttackKind.Melee);
        if (rangedCooldownFill) rangedCooldownFill.fillAmount = combat.GetCooldown01(Day44AttackKind.Ranged);
    }
    private void OnAttackStarted(Day44AttackKind kind) => UpdateAttackStatus();
    private void OnAttackFinished(Day44AttackKind kind) => UpdateAttackStatus();
    private void UpdateAttackStatus()
    {
        if (statusText) statusText.text = combat ? $"공격 상태: {combat.ActiveAttack}" : "공격 연결 없음";
    }
    private void OnHealthChanged(float current, float max)
    {
        if (targetHealthSlider)
        {
            targetHealthSlider.minValue = 0f;
            targetHealthSlider.maxValue = Mathf.Max(1f, max);
            targetHealthSlider.SetValueWithoutNotify(current);
        }
        if (targetHealthText) targetHealthText.text = $"HP {current:0} / {max:0}";
    }
}
