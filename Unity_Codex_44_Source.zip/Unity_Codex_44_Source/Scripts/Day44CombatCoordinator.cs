using System;
using UnityEngine;

public enum Day44AttackKind { None, Melee, Ranged }

public class Day44CombatCoordinator : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Animator animator;
    [SerializeField] private Day44MeleeHitbox meleeHitbox;
    [SerializeField] private Day44HitscanGun rangedWeapon;
    [Header("Timing")]
    [SerializeField, Min(0.05f)] private float meleeCooldown = 0.8f;
    [SerializeField, Min(0.05f)] private float rangedCooldown = 0.6f;
    [SerializeField, Min(0.2f)] private float safetyTimeout = 1.5f;

    private static readonly int MeleeHash = Animator.StringToHash("Melee");
    private static readonly int RangedHash = Animator.StringToHash("Ranged");
    private float nextMeleeReady;
    private float nextRangedReady;
    private float forceFinishAt;

    public Day44AttackKind ActiveAttack { get; private set; }
    public bool IsAttacking => ActiveAttack != Day44AttackKind.None;
    public event Action<Day44AttackKind> AttackStarted;
    public event Action<Day44AttackKind> AttackFinished;

    private void Awake()
    {
        if (!animator) animator = GetComponent<Animator>();
        if (!meleeHitbox) meleeHitbox = GetComponent<Day44MeleeHitbox>();
        if (!rangedWeapon) rangedWeapon = GetComponent<Day44HitscanGun>();
    }

    private void Update()
    {
        // Animation Event가 누락되어도 입력 잠금이 영구화되지 않도록 보호합니다.
        if (IsAttacking && Time.time >= forceFinishAt) FinishAttack();
    }

    public bool TryMelee() => TryStart(Day44AttackKind.Melee);
    public bool TryRanged() => TryStart(Day44AttackKind.Ranged);

    private bool TryStart(Day44AttackKind kind)
    {
        if (!isActiveAndEnabled || Time.timeScale <= 0f || IsAttacking || !animator)
            return false;
        if (kind == Day44AttackKind.Melee && Time.time < nextMeleeReady) return false;
        if (kind == Day44AttackKind.Ranged && Time.time < nextRangedReady) return false;
        if (kind == Day44AttackKind.Melee && !meleeHitbox) return false;
        if (kind == Day44AttackKind.Ranged && !rangedWeapon) return false;

        ActiveAttack = kind;
        forceFinishAt = Time.time + safetyTimeout;
        if (kind == Day44AttackKind.Melee) nextMeleeReady = Time.time + meleeCooldown;
        else nextRangedReady = Time.time + rangedCooldown;

        animator.ResetTrigger(MeleeHash);
        animator.ResetTrigger(RangedHash);
        animator.SetTrigger(kind == Day44AttackKind.Melee ? MeleeHash : RangedHash);
        AttackStarted?.Invoke(kind);
        return true;
    }

    public void AnimationMeleeOpen()
    {
        if (ActiveAttack == Day44AttackKind.Melee) meleeHitbox?.OpenWindow();
    }
    public void AnimationMeleeClose() => meleeHitbox?.CloseWindow();
    public void AnimationFire()
    {
        if (ActiveAttack == Day44AttackKind.Ranged) rangedWeapon?.Fire();
    }
    public void AnimationFinished() => FinishAttack();

    private void FinishAttack()
    {
        if (!IsAttacking) return;
        var ended = ActiveAttack;
        meleeHitbox?.CloseWindow();
        ActiveAttack = Day44AttackKind.None;
        AttackFinished?.Invoke(ended);
    }

    public float GetCooldown01(Day44AttackKind kind)
    {
        float duration = kind == Day44AttackKind.Melee ? meleeCooldown : rangedCooldown;
        float until = kind == Day44AttackKind.Melee ? nextMeleeReady : nextRangedReady;
        return Mathf.Clamp01((until - Time.time) / duration);
    }

    private void OnDisable()
    {
        meleeHitbox?.CloseWindow();
        ActiveAttack = Day44AttackKind.None;
    }
}
