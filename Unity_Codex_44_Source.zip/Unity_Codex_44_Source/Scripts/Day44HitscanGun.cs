using UnityEngine;

public class Day44HitscanGun : MonoBehaviour
{
    [SerializeField] private Camera aimCamera;
    [SerializeField] private Transform muzzle;
    [SerializeField, Min(1f)] private float range = 45f;
    [SerializeField, Min(1f)] private float damage = 15f;
    [SerializeField] private LayerMask hitMask = ~0;
    [SerializeField] private ParticleSystem muzzleFlash;

    private void Awake()
    {
        if (!aimCamera) aimCamera = Camera.main;
        if (!muzzle) muzzle = transform;
    }

    public void Fire()
    {
        if (!muzzle) return;
        if (muzzleFlash) muzzleFlash.Play();
        Ray aimRay = aimCamera
            ? aimCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0f))
            : new Ray(muzzle.position, muzzle.forward);
        Vector3 aimPoint = aimRay.origin + aimRay.direction * range;
        if (Physics.Raycast(aimRay, out RaycastHit cameraHit, range, hitMask,
                QueryTriggerInteraction.Ignore))
            aimPoint = cameraHit.point;

        Vector3 direction = (aimPoint - muzzle.position).normalized;
        if (direction.sqrMagnitude < 0.0001f) direction = muzzle.forward;
        float distance = range;
        if (!Physics.Raycast(muzzle.position, direction, out RaycastHit muzzleHit, distance,
                hitMask, QueryTriggerInteraction.Ignore)) return;
        if (muzzleHit.transform.root == transform.root) return;
        foreach (MonoBehaviour component in muzzleHit.collider.GetComponentsInParent<MonoBehaviour>())
        {
            if (component is IDay44Damageable receiver)
            {
                receiver.TakeDamage(damage, transform.root.gameObject);
                break;
            }
        }
        Debug.DrawLine(muzzle.position, muzzleHit.point, Color.cyan, 0.7f);
    }
}
