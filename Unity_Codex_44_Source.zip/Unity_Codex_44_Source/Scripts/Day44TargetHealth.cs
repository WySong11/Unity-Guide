using System;
using UnityEngine;

public class Day44TargetHealth : MonoBehaviour, IDay44Damageable
{
    [SerializeField, Min(1f)] private float maxHealth = 100f;
    [SerializeField] private bool disableOnDeath = false;

    public float CurrentHealth { get; private set; }
    public float MaxHealth => maxHealth;
    public bool IsDead => CurrentHealth <= 0f;

    public event Action<float, float> HealthChanged;
    public event Action<float> Damaged;
    public event Action Died;

    private void Awake() => CurrentHealth = maxHealth;

    public void TakeDamage(float amount, GameObject source)
    {
        if (IsDead || amount <= 0f) return;
        float before = CurrentHealth;
        CurrentHealth = Mathf.Max(0f, before - amount);
        if (Mathf.Approximately(CurrentHealth, before)) return;
        Damaged?.Invoke(amount);
        HealthChanged?.Invoke(CurrentHealth, maxHealth);
        if (IsDead)
        {
            Died?.Invoke();
            if (disableOnDeath) gameObject.SetActive(false);
        }
    }

    public void ResetHealth()
    {
        CurrentHealth = maxHealth;
        HealthChanged?.Invoke(CurrentHealth, maxHealth);
    }
}
