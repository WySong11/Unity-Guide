using UnityEngine;

public class Day44CombatFeedback : MonoBehaviour
{
    [SerializeField] private Day44CombatCoordinator combat;
    [SerializeField] private AudioSource audioSource;
    [SerializeField] private AudioClip meleeClip;
    [SerializeField] private AudioClip rangedClip;

    private void Awake()
    {
        if (!combat) combat = GetComponent<Day44CombatCoordinator>();
        if (!audioSource) audioSource = GetComponent<AudioSource>();
    }
    private void OnEnable() { if (combat) combat.AttackStarted += Play; }
    private void OnDisable() { if (combat) combat.AttackStarted -= Play; }
    private void Play(Day44AttackKind kind)
    {
        AudioClip clip = kind == Day44AttackKind.Melee ? meleeClip : rangedClip;
        if (audioSource && clip) audioSource.PlayOneShot(clip);
    }
}
