using UnityEngine;

// Animator가 있는 GameObject에 추가하고 Animation Event에서 아래 메서드를 지정합니다.
public class Day44AnimationEventRelay : MonoBehaviour
{
    [SerializeField] private Day44CombatCoordinator combat;
    private void Awake()
    {
        if (!combat) combat = GetComponentInParent<Day44CombatCoordinator>();
    }

    public void AE_MeleeOpen() => combat?.AnimationMeleeOpen();
    public void AE_MeleeClose() => combat?.AnimationMeleeClose();
    public void AE_Fire() => combat?.AnimationFire();
    public void AE_AttackEnd() => combat?.AnimationFinished();
}
