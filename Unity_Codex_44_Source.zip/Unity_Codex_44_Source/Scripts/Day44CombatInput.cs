using UnityEngine;
using UnityEngine.InputSystem;

public class Day44CombatInput : MonoBehaviour
{
    [SerializeField] private Day44CombatCoordinator combat;
    [SerializeField] private InputActionReference meleeAction;
    [SerializeField] private InputActionReference rangedAction;
    [SerializeField] private bool keyboardFallback = true;

    private void Awake()
    {
        if (!combat) combat = GetComponent<Day44CombatCoordinator>();
    }

    private void OnEnable()
    {
        // PlayerInput이 같은 Action을 관리한다면 별도 Enable 호출을 제거하세요.
        meleeAction?.action?.Enable();
        rangedAction?.action?.Enable();
    }
    private void OnDisable()
    {
        meleeAction?.action?.Disable();
        rangedAction?.action?.Disable();
    }

    private void Update()
    {
        if (!combat || Time.timeScale <= 0f) return;
        bool melee = meleeAction?.action?.WasPressedThisFrame() ?? false;
        bool ranged = rangedAction?.action?.WasPressedThisFrame() ?? false;
        if (keyboardFallback && Keyboard.current != null)
        {
            melee |= Keyboard.current.jKey.wasPressedThisFrame;
            ranged |= Keyboard.current.kKey.wasPressedThisFrame;
        }
        if (melee) combat.TryMelee();
        else if (ranged) combat.TryRanged();
    }
}
