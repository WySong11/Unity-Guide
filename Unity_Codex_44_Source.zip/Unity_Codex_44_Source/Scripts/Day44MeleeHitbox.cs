using System.Collections.Generic;
using UnityEngine;

public class Day44MeleeHitbox : MonoBehaviour
{
    [SerializeField] private Transform origin;
    [SerializeField, Min(0.1f)] private float radius = 1.7f;
    [SerializeField, Range(1f, 180f)] private float halfAngle = 55f;
    [SerializeField, Min(1f)] private float damage = 25f;
    [SerializeField] private LayerMask targetLayers = ~0;

    private readonly Collider[] overlaps = new Collider[32];
    private readonly HashSet<MonoBehaviour> damaged = new HashSet<MonoBehaviour>();
    private bool activeWindow;

    private void Awake() { if (!origin) origin = transform; }

    public void OpenWindow()
    {
        damaged.Clear();
        activeWindow = true;
        CheckHits();
    }

    private void FixedUpdate() { if (activeWindow) CheckHits(); }

    public void CloseWindow() { activeWindow = false; }

    private void CheckHits()
    {
        Vector3 center = origin.position + origin.forward * 0.65f;
        int count = Physics.OverlapSphereNonAlloc(center, radius, overlaps, targetLayers,
            QueryTriggerInteraction.Ignore);
        for (int i = 0; i < count; i++)
        {
            Collider hit = overlaps[i];
            if (!hit || hit.transform.root == transform.root) continue;
            Vector3 toTarget = hit.bounds.center - origin.position;
            toTarget.y = 0f;
            if (toTarget.sqrMagnitude > 0.001f &&
                Vector3.Angle(origin.forward, toTarget.normalized) > halfAngle) continue;

            foreach (MonoBehaviour component in hit.GetComponentsInParent<MonoBehaviour>())
            {
                if (component is IDay44Damageable receiver && damaged.Add(component))
                {
                    receiver.TakeDamage(damage, transform.root.gameObject);
                    break;
                }
            }
        }
    }

    private void OnDisable() { activeWindow = false; damaged.Clear(); }

    private void OnDrawGizmosSelected()
    {
        Transform t = origin ? origin : transform;
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(t.position + t.forward * 0.65f, radius);
    }
}
