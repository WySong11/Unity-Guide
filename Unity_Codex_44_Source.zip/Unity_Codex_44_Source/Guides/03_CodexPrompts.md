# Codex 수업 프롬프트

## A. 분석 전용
```
Unity 6.3 URP 프로젝트의 37~43일차 플레이어 이동, 공격, 체력, UI 코드를 먼저 읽어줘.
게임 코드와 씬/Prefab 참조를 변경하지 말고,
1) 현재 Input → Combat → Damage → Health → UI 데이터 흐름,
2) Animator / Animation Event 통합 지점,
3) 클래스 이름 충돌과 PlayerInput 중복 위험,
4) 최소 수정 대상 파일과 Inspector 수동 연결사항을 표로 보고해줘.
실제 실행하지 않은 검증은 수행한 것처럼 쓰지 마.
```

## B. 구현
```
검토한 구조를 기준으로 공격 애니메이션과 전투 UI를 연결해줘.
Melee/Ranged Animator Trigger, Animation Event 기반 타격 창/사격, 종료 보호,
대상 HealthChanged 구독, 공격 쿨다운 UI를 구현하되
37~43일차 코드를 불필요하게 중복 생성하거나 파괴하지 마.
작업 전에 수정 파일 목록을 제시하고, 완료 후 git diff와 Inspector 변경사항을 요약해줘.
```

## C. 검증
```
변경된 C#과 Animator Event 연결을 먼저 정적으로 점검해줘.
가능하면 Unity Editor Play Mode 테스트를 수행하고,
J/K 1회 공격, 빠른 연타, Animation Event 누락, 타깃 다중 Collider,
Pause, 재시작, UI 활성화·비활성화의 8가지 테스트를 정리해줘.
각 결과를 Pass / Fail / Not Run으로 구분하고, Not Run은 이유를 밝혀줘.
동작하지 않은 경우 Console/Stack Trace와 재현 단계를 반드시 포함해줘.
```
