# 설치 및 실습 절차

## Step 0. 준비
- 프로젝트는 Unity 6.3 Universal 3D로 생성 또는 URP 구성 확인.
- Package Manager: Input System, TextMeshPro, Unity UI 설치 여부 확인.
- Input Handling은 Input System Package(New) 또는 Both이며 필요시 Editor 재시작.
- 42~43일차 소스는 독립 실행 모드에서 필수가 아닙니다.

## Step 1. Animator 체계
- Animator Controller에서 `Idle`, `MeleeAttack`, `RangedAttack` 상태 구성.
- Trigger 파라미터를 **대소문자까지 정확하게** `Melee`, `Ranged`로 지정.
- Melee 클립에 `AE_MeleeOpen` → `AE_MeleeClose` → `AE_AttackEnd` 순서로 이벤트 추가.
- Ranged 클립에 `AE_Fire` → `AE_AttackEnd` 순서로 이벤트 추가.
- `Day44AnimationEventRelay`는 **Animator가 달린 GameObject**에 추가.
- 3D 이동 시스템과 충돌하지 않게 기본 수업에서는 Apply Root Motion을 꺼 둡니다.

## Step 2. 공격 시스템
- 플레이어: CombatCoordinator, MeleeHitbox, HitscanGun, CombatInput.
- 총구 Muzzle Transform과 MainCamera 참조 연결.
- 타깃 Collider + Day44TargetHealth; Damageable 중복 연결 금지.
- J=근접, K=원거리 입력 테스트. Projectile을 쓰려면 `Day44HitscanGun.Fire()` 호출 지점을 기존 발사체 무기로 연결.

## Step 3. Canvas
- Canvas: Screen Space - Overlay, Canvas Scaler Scale With Screen Size, Reference Resolution 1920×1080.
- 쿨다운 Image 2개: Image Type `Filled`, Fill Method `Horizontal`, Fill Amount 0부터 갱신.
- 타깃 HP Slider와 TMP 텍스트 배치.
- Day44CombatHUD 컴포넌트에 Combat, Target, UI 참조 연결.
- HP는 OnEnable 초기 동기화 + HealthChanged 구독/해제.

## Step 4. 검증
- 씬 실행: J 1회 = 근접 트리거 및 HP가 접촉 시 1회 감소.
- K 1회 = Ranged 이벤트 시점에 한 번 발사.
- 빠른 연타, 타깃 복수 Collider, 무기 없는 상황에서 오류 확인.
- 일시정지 중 공격 차단과 쿨다운 정지 확인.
- 씬 재시작 및 UI 활성화/비활성화 후 이벤트 중복 여부 검사.

## 120분 운영
| 시간 | 학습 활동 |
|---|---|
| 10분 | 지난 41~43일차 공격/피격 구조 확인 |
| 20분 | Animator / Animation Event 개념 |
| 35분 | 근접/원거리 이벤트 구현 |
| 25분 | 공격 쿨다운·Target HP UI 연동 |
| 20분 | 디버깅·회귀 검증 |
| 10분 | 발표·정리 |
