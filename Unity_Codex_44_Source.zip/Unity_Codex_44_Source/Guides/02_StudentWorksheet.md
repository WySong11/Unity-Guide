# Day44 학생 워크시트

학번: __________  이름: __________  실습 날짜: __________

## 1. 시스템 이해
1. `Animator.SetTrigger("Melee")` 호출과 실제 HP 감소가 다른 이유를 설명하세요.
2. `AnimationEventRelay`를 Animator가 있는 GameObject에 부착해야 하는 이유는 무엇인가요?
3. `OnEnable`에서 이벤트를 구독할 때 `OnDisable`에 필요한 코드는 무엇인가요?
4. Melee 공격 한 번에 Target Collider가 2개 겹친 경우 HP는 몇 번 감소해야 하나요?

## 2. 구현 체크
- [ ] Melee/Ranged Trigger 생성
- [ ] 이벤트 메서드 4개 연결
- [ ] Hitbox 한 번 공격당 중복 피격 방지
- [ ] 쿨다운 UI Fill 표시
- [ ] 타깃 HP Slider와 Text 표시
- [ ] Play Mode 컴파일/로그 문제 해결

## 3. 캡처 제출
1. Animator State 전이 화면
2. Melee 공격과 Target HP 변화 화면
3. Ranged 공격과 쿨다운 UI 화면
4. Unity Console 전체 오류 유무

## 4. 오류 보고
- 재현 방법:
- Console 메시지/Stack Trace:
- 원인 가설:
- 변경 파일 및 수정 요지:
- 재검증 결과:

## 5. 심화 과제
- 공격 모션 클립을 바꾼 뒤 Animation Event 시점 재설정
- 캐릭터가 이동하면서 상체만 공격하도록 Avatar Mask 조사
- HUD에 Cooldown Ready 강조 표시 추가
