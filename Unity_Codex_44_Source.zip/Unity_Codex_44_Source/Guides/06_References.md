# 공식 참조 문서

- Unity 6 Animator API: https://docs.unity3d.com/ScriptReference/Animator.html
- Animator.SetTrigger: https://docs.unity3d.com/ScriptReference/Animator.SetTrigger.html
- Animation Events: https://docs.unity3d.com/Manual/script-AnimationWindowEvent.html
- Animation Clip: https://docs.unity3d.com/ScriptReference/AnimationClip.html
- Unity UI Image.fillAmount: https://docs.unity3d.com/Packages/com.unity.ugui@2.0/api/UnityEngine.UI.Image.html
- Unity UI Slider: https://docs.unity3d.com/Packages/com.unity.ugui@2.0/api/UnityEngine.UI.Slider.html
- Unity Input System: https://docs.unity3d.com/Packages/com.unity.inputsystem@1.17/manual/Actions.html

패키지 버전과 문서 URL 경로는 설치 시점에 따라 변경될 수 있습니다.
