# 자주 발생하는 오류

| 현상 | 우선 확인 |
|---|---|
| 애니메이션만 나옴 | Attack Clip의 Animation Event 메서드 이름 및 Relay 위치 |
| Melee 타깃 HP 2번 감소 | 같은 공격의 Active 구간 중복 판정/Collider 중복 |
| UI가 갱신되지 않음 | HealthChanged 연결 / Initial Sync / Target 참조 |
| 공격 후 움직일 수 없음 | AE_AttackEnd, Animator 전이, safetyTimeout 확인 |
| Ranged 사격이 캐릭터를 맞춤 | 카메라 중심 Ray와 Muzzle 위치, owner 제외 확인 |
| 일시정지 중 애니메이션만 움직임 | Animator Update Mode 및 Unscaled Time 사용 여부 확인 |
| TMP 글씨가 보이지 않음 | TextMeshPro Essential Resources 및 폰트 에셋 확인 |
| PlayerInput과 액션이 꼬임 | Day44CombatInput에서 중복 Action Enable/Disable 호출 여부 확인 |
| 메서드가 Inspector에서 안 보임 | public 메서드/호출 가능한 파라미터인지 확인 |

## 43일차 Health 연동
`Day44TargetHealth`는 독립 실습용입니다. 기존 `Day43Health`의 공개 API, 이벤트 타입을 직접 확인한 후 한쪽만 사용해야 합니다. 기존 스크립트에서 `IDay44Damageable`을 구현하거나 어댑터 컴포넌트로 기존 TakeDamage를 연결할 수 있습니다. 타입/인자 이름을 임의로 가정해서 예제 코드를 그대로 붙여넣지 마세요.
