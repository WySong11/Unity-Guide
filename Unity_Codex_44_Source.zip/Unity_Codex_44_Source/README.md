# Unity Codex 44일차 — 공격 애니메이션, UI 연동

- 대상: Unity 6.3 / Universal 3D (URP) / C# / uGUI + TextMeshPro / Input System
- 수업: 120분, 강의 PPT 44장
- 개념: 입력 → Animator Trigger → Animation Event → 근접·원거리 판정 → HP 이벤트 → HUD
- 소스: `Scripts` 아래 C# 11개 (Editor 전용 2개는 반드시 `Editor` 폴더 안에 두세요.)

## 사용 방법

1. Unity 6.3 Universal 3D 프로젝트를 엽니다.
2. Package Manager에서 **Input System**, **TextMeshPro**, **Unity UI** 패키지를 확인합니다.
3. TextMeshPro를 처음 사용한다면 TMP Essential Resources를 프로젝트에 가져옵니다.
4. 이 폴더의 `Scripts`를 프로젝트의 `Assets/` 하위로 복사합니다. `Scripts/Editor`는 Editor 폴더 위치를 반드시 유지합니다.
5. 컴파일 오류가 없는지 Unity Console에서 확인합니다.
6. **Tools → Unity Codex → Day44 → Create Combat Practice Scene** 메뉴를 실행합니다.
7. 새로 저장된 `Assets/Unity_Codex_Day44/Day44CombatPractice*.unity` 씬을 열고 Play를 실행합니다.
8. **J** 키로 근접, **K** 키로 원거리 공격을 실행합니다.
9. **Tools → Unity Codex → Day44 → Validate Current Scene** 메뉴로 참조를 점검합니다.
10. 검사 결과는 `Guides/04_TestMatrix.csv`에 기록합니다.

## 중요 제한

- 이 패키지는 **독립적인 Day44 예제**입니다. **41~43일차와 자동으로 병합하거나 기존 스크립트를 자동 변경하지 않습니다.**
- 기본 예제 `Day44TargetHealth`와 기존 `Day43Health`가 동일 타깃에 동시에 피해를 처리하지 않도록 하세요.
- 기존 프로젝트와 병합할 경우 `IDay44Damageable.TakeDamage()`를 기존 Health 공개 메서드에 전달하는 **어댑터** 또는 기존 데미지 인터페이스로 교체하세요.
- `Day44CombatInput`과 기존 `PlayerInput`이 동일한 InputAction을 모두 활성화하지 않도록 관리하세요.
- 자동 생성된 캐릭터의 Animator는 **학습용 간단한 스케일 애니메이션**입니다. 실제 캐릭터 공격 클립은 별도로 준비해야 합니다.
- Animator / Animation Event의 누락을 방어하는 안전 종료 로직은 실제 클립의 오류 자체를 해결하는 것이 아닙니다.
- Unity Editor에서의 **실제 컴파일·Play Mode 검증을 수행한 파일은 아닙니다.** 각 환경에서 실행 점검이 필요합니다.
