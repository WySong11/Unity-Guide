using UnityEngine;

/// <summary>
/// 디버깅 전용: 수평/수직 속도와 접지 검사 결과를 일정 주기로 출력.
/// 진단 완료 후 비활성화/제거하여 Console 로그를 줄이세요.
/// </summary>
[RequireComponent(typeof(Rigidbody2D))]
public class MovementDebugProbe2D : MonoBehaviour
{
    [SerializeField] private Transform groundCheck;
    [SerializeField] private LayerMask groundLayer;
    [SerializeField, Min(0.01f)] private float groundRadius = 0.12f;
    [SerializeField, Min(0.1f)] private float logInterval = 0.5f;
    private Rigidbody2D rb;
    private float nextLogTime;

    private void Awake() => rb = GetComponent<Rigidbody2D>();

    private void Update()
    {
        if (Time.unscaledTime < nextLogTime) return;
        nextLogTime = Time.unscaledTime + logInterval;

        bool grounded = groundCheck != null &&
            Physics2D.OverlapCircle(groundCheck.position, groundRadius, groundLayer) != null;
        Vector2 v = rb.linearVelocity;
        Debug.Log($"[MoveProbe] grounded={grounded}, vx={v.x:F2}, vy={v.y:F2}", this);
    }
}
