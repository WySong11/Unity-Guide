using UnityEngine;

/// <summary>
/// 15일차 PlayerHealth2D와 함께 사용하는 간단한 단일 플레이어 위험물 예시.
/// CollisionStay2D에만 반응하므로 Hazard의 Collider는 Is Trigger=Off.
/// </summary>
public class HazardDamageCooldown2D : MonoBehaviour
{
    [SerializeField, Min(1)] private int damage = 1;
    [SerializeField, Min(0.01f)] private float damageInterval = 0.5f;
    private float nextDamageTime;

    private void OnCollisionStay2D(Collision2D collision)
    {
        if (!collision.gameObject.CompareTag("Player")) return;
        if (Time.time < nextDamageTime) return;
        if (!collision.gameObject.TryGetComponent(out PlayerHealth2D playerHealth)) return;

        playerHealth.TakeDamage(damage);
        nextDamageTime = Time.time + damageInterval;
    }
}
