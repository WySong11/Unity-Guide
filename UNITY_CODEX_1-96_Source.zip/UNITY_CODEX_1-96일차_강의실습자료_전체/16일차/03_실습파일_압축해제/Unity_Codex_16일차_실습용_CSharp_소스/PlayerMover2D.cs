using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// 16일차 실습: Input System 기반 2D 플레이어 이동/점프.
/// PlayerInput이 동일 InputAction을 관리하는 경우 이 스크립트의 Enable/Disable 방식과 혼용하지 마세요.
/// </summary>
[RequireComponent(typeof(Rigidbody2D))]
public class PlayerMover2D : MonoBehaviour
{
    [Header("Input Actions")]
    [SerializeField] private InputActionReference moveAction;
    [SerializeField] private InputActionReference jumpAction;

    [Header("Movement")]
    [SerializeField, Min(0f)] private float moveSpeed = 5f;
    [SerializeField, Min(0f)] private float jumpSpeed = 8f;
    [SerializeField] private SpriteRenderer sprite;

    [Header("Ground Check")]
    [SerializeField] private Transform groundCheck;
    [SerializeField] private LayerMask groundLayer;
    [SerializeField, Min(0.01f)] private float radius = 0.12f;

    private Rigidbody2D rb;
    private float moveX;
    private bool jumpRequested;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    private void OnEnable()
    {
        if (moveAction != null)
            moveAction.action?.Enable();

        if (jumpAction != null && jumpAction.action != null)
        {
            jumpAction.action.performed += OnJump;
            jumpAction.action.Enable();
        }
    }

    private void OnDisable()
    {
        if (jumpAction != null && jumpAction.action != null)
        {
            jumpAction.action.performed -= OnJump;
            jumpAction.action.Disable();
        }
        if (moveAction != null)
            moveAction.action?.Disable();

        jumpRequested = false;
        moveX = 0f;
    }

    private void Update()
    {
        moveX = moveAction?.action != null
            ? moveAction.action.ReadValue<Vector2>().x : 0f;

        if (sprite != null && Mathf.Abs(moveX) > 0.01f)
            sprite.flipX = moveX < 0f;
    }

    private void FixedUpdate()
    {
        Vector2 v = rb.linearVelocity;
        v.x = moveX * moveSpeed;

        if (jumpRequested && IsGrounded())
            v.y = jumpSpeed;

        jumpRequested = false;
        rb.linearVelocity = v;
    }

    private void OnJump(InputAction.CallbackContext ctx)
    {
        jumpRequested = true;
    }

    private bool IsGrounded()
    {
        if (groundCheck == null)
            return false;

        return Physics2D.OverlapCircle(
            groundCheck.position, radius, groundLayer) != null;
    }

    private void OnDrawGizmosSelected()
    {
        if (groundCheck == null)
            return;

        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(groundCheck.position, radius);
    }
}
