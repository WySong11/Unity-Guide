# 16일차 Codex 실습 프롬프트

## 1. 분석만 요청
```text
현재 Unity 6.3 2D 프로젝트에서 PlayerMover2D.cs를 분석해줘.
증상은 Space 키 입력 시 점프가 가끔 무시되는 것이야.
기존 기능 유지, 관련 없는 파일 변경 금지, 지금은 파일 수정 금지.
입력 -> Update -> FixedUpdate -> Rigidbody2D 흐름을 설명하고,
원인을 증거 중심으로 우선순위 정리한 다음 확인 절차와 최소 수정안을 제안해줘.
실제 Unity Play Mode에서 실행하지 못한 테스트는 미실행이라고 표시해줘.
```

## 2. 범위가 명확해진 뒤 수정 요청
```text
진단에서 확인한 점프 누락 원인만 수정해줘.
PlayerMover2D.cs만 수정하고, Move/Jump Action 설정과 기존 조작은 유지해줘.
수정 전후 Diff를 정리하고 예상 부작용과 수동 테스트 목록을 알려줘.
파일 변경 후 승인 없이 git reset --hard, git clean 또는 강제 checkout을 사용하지 마.
```

## 3. 검증 요청
```text
현재 PlayerMover2D.cs의 수정 내용을 리뷰해줘.
Update에서 입력을 읽고 FixedUpdate에서 물리 속도를 적용하는지,
Y 속도를 보존하는지, Ground Layer를 정확히 사용하는지,
OnEnable/OnDisable 구독을 대칭 처리하는지 확인해줘.
실제 실행한 검사와 코드 분석만 한 검사를 분리해서 보고해줘.
```
