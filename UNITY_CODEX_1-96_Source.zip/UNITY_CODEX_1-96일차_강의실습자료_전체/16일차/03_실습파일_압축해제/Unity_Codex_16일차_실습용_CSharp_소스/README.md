# 16일차 — Codex 디버깅 · 2D 이동 시스템 완성

대상: **Unity 6.3 + Input System**, 15일차 PlayerMover2D 기반 2D URP 프로젝트.
강의 슬라이드의 코드 예제와 함께 사용합니다. 이 패키지는 Unity Editor에서 컴파일 및 Play Mode를 직접 검증한 산출물이 아니라 **강의 실습용 소스**입니다.

## 구성
- `PlayerMover2D.cs` — 이동/점프 및 접지 판정의 정리 버전
- `MovementDebugProbe2D.cs` — 속도·접지 결과를 일정 시간마다 Console에 출력하는 진단 스크립트
- `HazardDamageCooldown2D.cs` — 일정 간격으로 위험물 접촉 피해 처리 (15일차 `PlayerHealth2D.cs` 필요)
- `ManualTestMatrix.csv` — 학생 수동 테스트 기록지
- `BugReportTemplate.md` — 오류 재현과 수정 기록 양식
- `CodexPrompts.md` — Codex 분석/수정/회귀 테스트 프롬프트

## 1. 시작 전
1. 15일차 프로젝트의 Git 상태와 Diff를 점검하고 정상 동작 시점을 커밋합니다.
2. `Day15_PlayerMovement` Scene을 복제해 `Day16_DebugAndPolish`로 저장합니다.
3. 기존 `PlayerMover2D.cs`를 **백업 및 Diff 확인 후** 새 예제로 교체합니다.
4. 기존 이동 스크립트와 다른 이동 제어 스크립트를 동시에 활성화하지 않습니다.

## 2. Unity Inspector 설정
- Player: `Rigidbody2D` Dynamic, `CapsuleCollider2D`, `SpriteRenderer`, `PlayerMover2D`.
- Rigidbody2D: Gravity Scale 시작 예시 `2.5`, Freeze Rotation Z 체크.
- Player 아래 `GroundCheck`를 발 아래에 둡니다. Ground는 별도 레이어에 포함합니다.
- PlayerMover2D: Move Speed `5`, Jump Speed `8`, Radius `0.12`, Ground Layer 지정.
- Input Actions: `Player/Move` = Value/Vector2, WASD 2D Composite, `Player/Jump` = Button, Space.
- `moveAction`, `jumpAction`, `sprite`, `groundCheck` 필드를 연결합니다.

> **입력 관리 주의:** 본 예제는 스크립트에서 Action을 Enable/Disable합니다. 같은 Action을 `PlayerInput`이나 다른 매니저가 제어하는 경우 반드시 소유권을 하나로 통일하세요.

## 3. 디버깅 순서
1. 이동이 안 되는 경우: Action Reference, Action Type, Enabled 상태, Console을 확인합니다.
2. 점프가 안 되는 경우: Ground Layer, `GroundCheck` 위치·반경, Rigidbody2D 설정을 확인합니다.
3. 점프 중 멈추는 경우: `rb.linearVelocity.y`가 매 물리 프레임 0으로 초기화되는지 확인합니다.
4. 벽 관통/떨림: Transform 직접 이동과 Rigidbody2D 물리 이동을 혼용하는지 확인합니다.
5. 피격 중복: 기존 15일차 `HazardCollision2D`와 이 예제의 `HazardDamageCooldown2D` 중 **한 가지만** 사용하세요.
6. 실습 후 `ManualTestMatrix.csv`에 통과/실패/미실행을 기록합니다.

## 4. 결과물
Scene, C# 소스, 오류 보고서 1개, 테스트표, Unity Console/Inspector 화면, 변경 Diff, Git 커밋.

## 5. 한계와 확장
- 기본 점프는 키 입력을 다음 FixedUpdate까지 저장하고 **그 FixedUpdate에서 접지하지 않았다면 버립니다.** 코요테 타임/점프 버퍼는 추가 기능입니다.
- `HazardDamageCooldown2D`는 단일 플레이어 기준입니다. 여러 플레이어가 있다면 플레이어별 쿨다운으로 확장해야 합니다.
- 특정 Unity 버전에서 변경된 API는 프로젝트의 설치된 버전 문서를 기준으로 확인하세요.

공식 문서:
- https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/rigidbody2d/linearvelocity
- https://learn.unity.com/course/input-system-video-series
- https://learn.chatgpt.com/docs/codex/ide
