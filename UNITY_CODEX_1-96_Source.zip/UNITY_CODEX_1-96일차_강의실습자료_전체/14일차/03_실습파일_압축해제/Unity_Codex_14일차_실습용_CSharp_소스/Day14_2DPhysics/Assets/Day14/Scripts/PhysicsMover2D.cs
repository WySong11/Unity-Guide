using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// Unity 6.3 LTS 예제. Input System으로 좌우 이동과 점프를 처리합니다.
/// Player에는 Rigidbody2D와 Collider2D가 있어야 합니다.
/// </summary>
[RequireComponent(typeof(Rigidbody2D))]
public class PhysicsMover2D : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] private float moveSpeed = 5f;
    [SerializeField] private float jumpImpulse = 7f;

    [Header("Ground Check")]
    [SerializeField] private Transform groundCheck;
    [SerializeField] private float groundRadius = 0.12f;
    [SerializeField] private LayerMask groundLayer;

    private Rigidbody2D rb;
    private float moveX;
    private bool jumpQueued;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null)
        {
            moveX = 0f;
            return;
        }

        moveX = (keyboard.dKey.isPressed ? 1f : 0f)
              - (keyboard.aKey.isPressed ? 1f : 0f);

        if (keyboard.spaceKey.wasPressedThisFrame && IsGrounded())
            jumpQueued = true;
    }

    private void FixedUpdate()
    {
        rb.linearVelocity = new Vector2(moveX * moveSpeed, rb.linearVelocity.y);

        if (!jumpQueued)
            return;

        jumpQueued = false;
        rb.AddForce(Vector2.up * jumpImpulse, ForceMode2D.Impulse);
    }

    private bool IsGrounded()
    {
        return groundCheck != null &&
               Physics2D.OverlapCircle(groundCheck.position, groundRadius, groundLayer) != null;
    }

    private void OnDrawGizmosSelected()
    {
        if (groundCheck == null) return;
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(groundCheck.position, groundRadius);
    }
}
