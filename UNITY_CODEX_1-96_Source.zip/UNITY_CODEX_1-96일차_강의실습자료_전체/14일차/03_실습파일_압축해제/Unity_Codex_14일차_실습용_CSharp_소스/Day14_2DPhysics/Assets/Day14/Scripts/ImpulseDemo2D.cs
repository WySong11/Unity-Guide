using UnityEngine;

/// <summary>
/// Inspector에서 초기 발사 방향을 설정하고 Space로 발사하는 보조 실습입니다.
/// </summary>
[RequireComponent(typeof(Rigidbody2D))]
public class ImpulseDemo2D : MonoBehaviour
{
    [SerializeField] private Vector2 impulseDirection = new Vector2(1f, 1f);
    [SerializeField] private float impulseStrength = 5f;
    private Rigidbody2D rb;

    private void Awake() => rb = GetComponent<Rigidbody2D>();

    public void Launch()
    {
        rb.AddForce(impulseDirection.normalized * impulseStrength, ForceMode2D.Impulse);
    }
}
