using UnityEngine;

/// <summary>
/// 일반 충돌로 위험물 접촉을 감지합니다.
/// Hazard의 Collider2D는 Is Trigger를 끕니다.
/// </summary>
[RequireComponent(typeof(Collider2D))]
public class HazardCollision2D : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D hit)
    {
        if (hit.collider.CompareTag("Player"))
            Debug.LogWarning("위험물에 닿았습니다!");
    }
}
