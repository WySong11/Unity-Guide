using UnityEngine;

/// <summary>
/// 코인의 CircleCollider2D에서 Is Trigger를 체크합니다.
/// Player에는 Rigidbody2D 및 Player 태그가 필요합니다.
/// </summary>
[RequireComponent(typeof(Collider2D))]
public class CoinPickup2D : MonoBehaviour
{
    private bool collected;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (collected || !other.CompareTag("Player")) return;
        collected = true;
        Debug.Log("코인 획득!");
        Destroy(gameObject);
    }
}
