using UnityEngine;

/// <summary>
/// 충돌이 시작되거나 종료되는 시점을 확인합니다.
/// </summary>
public class CollisionLogger2D : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D hit)
    {
        Debug.Log($"Collision Enter: {hit.collider.name}");
    }

    private void OnCollisionExit2D(Collision2D hit)
    {
        Debug.Log($"Collision Exit: {hit.collider.name}");
    }
}
