# 14일차: Rigidbody2D와 Collider2D 실습

대상: Unity 6.3 LTS (6000.3 계열), Input System 패키지 사용.

## A. 씬 준비

1. **Player**: SpriteRenderer, Rigidbody2D(Dynamic), CapsuleCollider2D, PhysicsMover2D 추가.
2. Rigidbody2D의 **Gravity Scale=1**, **Constraints > Freeze Rotation Z** 체크.
3. Player의 Tag를 **Player**로 지정.
4. Player 아래 빈 GameObject **GroundCheck**를 생성하여 발 아래 배치.
5. **Ground**: SpriteRenderer, BoxCollider2D 추가. `Ground`라는 새 Layer를 만들고 지정.
6. PhysicsMover2D의 `groundCheck`에 자식 오브젝트를, `groundLayer`에 Ground 레이어를 연결.
7. **Coin**: SpriteRenderer, CircleCollider2D(**Is Trigger = ON**), CoinPickup2D. Prefab으로 저장 후 여러 개 배치.
8. **Hazard**: SpriteRenderer, BoxCollider2D(**Is Trigger = OFF**), HazardCollision2D 추가.
9. `File > Save`로 씬 저장.

## B. 실행 확인

- A/D: 좌우 이동
- Space: 지면에 닿았을 때 점프
- 코인 겹침: Console에 '코인 획득!' 출력 후 코인 제거
- 장애물 접촉: Console에 위험물 접촉 로그

## C. 주의 사항

- `Rigidbody` / `BoxCollider`는 3D이며 **Rigidbody2D / BoxCollider2D**와 다른 시스템입니다.
- 입력 이벤트 읽기는 Update, 속도 및 AddForce 같은 물리 처리는 FixedUpdate에서 수행합니다.
- Unity 6은 `Rigidbody2D.linearVelocity`를 사용합니다. 이전 버전의 `velocity` 예제와 혼동하지 마세요.
- 콜라이더 이벤트가 안 오면 Body Type, Is Trigger, Layer Collision Matrix, Tag, 비활성 여부를 확인하세요.
- 예제 `PhysicsMover2D`는 기본 학습용입니다. 경사·벽 점프·이동 플랫폼·고급 접지 시스템은 별도 구현해야 합니다.

## D. 제출

- Unity 씬 1개, 스크립트 3개 이상, 이동/점프/코인/위험물 기능 시연 영상 또는 스크린샷 4장
- Git commit 또는 변경 기록과 Codex 프롬프트·테스트 내역
