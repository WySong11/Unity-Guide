# 확인 퀴즈 정답
1. Rigidbody2D
2. Collider2D의 Is Trigger
3. FixedUpdate() (단, 입력 읽기는 Update에서)
4. CircleCollider2D
5. Physics2D.OverlapCircle() (다른 접지 검사 방법도 가능)
