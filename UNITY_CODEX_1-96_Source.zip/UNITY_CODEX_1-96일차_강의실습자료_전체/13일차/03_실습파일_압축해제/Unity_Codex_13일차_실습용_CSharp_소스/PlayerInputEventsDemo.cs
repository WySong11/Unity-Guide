using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// 별도 실습: PlayerInput / Behavior = Invoke Unity Events.
/// Move 이벤트는 OnMove, Jump 이벤트는 OnJump에 연결하세요.
/// PlayerInput이 Actions 활성화를 관리하므로 직접 Enable()하지 않습니다.
/// </summary>
[RequireComponent(typeof(PlayerInput))]
public class PlayerInputEventsDemo : MonoBehaviour
{
    [SerializeField, Min(0f)] private float moveSpeed = 4f;
    private Vector2 moveInput;

    public void OnMove(InputAction.CallbackContext context)
    {
        moveInput = context.ReadValue<Vector2>();
    }

    public void OnJump(InputAction.CallbackContext context)
    {
        if (context.performed)
            Debug.Log("PlayerInput Jump performed!");
    }

    private void Update()
    {
        Vector2 input = Vector2.ClampMagnitude(moveInput, 1f);
        transform.position +=
            new Vector3(input.x, 0f, input.y) * moveSpeed * Time.deltaTime;
    }
}
