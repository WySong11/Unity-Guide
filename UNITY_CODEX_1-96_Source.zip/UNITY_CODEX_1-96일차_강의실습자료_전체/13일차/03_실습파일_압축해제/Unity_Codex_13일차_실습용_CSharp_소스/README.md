# 13일차 — Unity Input System 및 키 입력 실습

기준: Unity 6.3 LTS 계열 + 설치된 Input System 패키지. 실제 패키지 버전은 Package Manager에서 확인하세요.

## 사전 설정
1. Window > Package Manager > Unity Registry > Input System이 설치되어 있는지 확인합니다.
2. 필요하다면 Edit > Project Settings > Player > Other Settings > Active Input Handling을 Input System Package (New) 또는 Both로 설정하고 Editor를 재시작합니다.
3. 씬에 3D Cube를 만들고 바닥 Plane을 배치합니다. Game 뷰에서 입력 테스트합니다.

## 1단계: KeyboardPollingDemo.cs
- Cube에 컴포넌트로 붙여 WASD 이동, Space 로그를 확인합니다.
- 이 방식은 특정 키보드 키와 코드가 직접 연결되어 있으며 빠른 프로토타입에 적합합니다.

## 2단계: Input Actions 에셋 만들기
1. Assets > Create > Input Actions에서 `Lesson13Controls.inputactions`를 만듭니다.
2. Action Map `Player`를 만들고 다음 Actions를 추가합니다.
   - `Move`: Action Type=Value, Control Type=Vector2.
   - Move에 `2D Vector` Composite 추가: Up=<Keyboard>/w, Down=s, Left=a, Right=d.
   - 추가 Composite로 Arrow Keys(상하좌우)를 연결해도 됩니다.
   - `Jump`: Action Type=Button, Binding=<Keyboard>/space.
3. 에셋 저장 후 Cube에 `ActionReferenceMover.cs`를 붙입니다.
4. Inspector에서 Move Action Reference와 Jump Action Reference를 연결합니다.
5. **동일 Cube에서는 KeyboardPollingDemo를 비활성화해 중복 이동을 피합니다.**

## 3단계: PlayerInput 이벤트 워크플로 (선택 실습)
- ActionReferenceMover를 끄고, 같은 Cube에 PlayerInput과 PlayerInputEventsDemo를 붙입니다.
- PlayerInput의 Actions에 위 에셋을 연결하고 Default Map을 Player로 설정합니다.
- Behavior = Invoke Unity Events로 설정합니다.
- Events에서 Move → PlayerInputEventsDemo.OnMove, Jump → OnJump를 연결합니다.
- PlayerInput이 Actions를 관리하므로, ActionReferenceMover와 동시에 쓰지 마세요.

## 확인 체크리스트
- [ ] WASD로 XZ 평면에서 이동한다.
- [ ] 대각선 이동 속도가 직선 이동보다 빠르지 않다.
- [ ] Space를 한 번 누르면 로그가 한 번 출력된다.
- [ ] Game 뷰 포커스가 필요한 환경인지 확인한다.
- [ ] Action Map, Binding, Active Input Handling을 설명할 수 있다.
- [ ] Codex가 수정한 내용의 Diff를 읽고 검증한다.

## 참고
- Unity 6.3 Input System 공식 학습: https://learn.unity.com/course/input-system-video-series/unity-version?version=6.3
- 설치/활성화: https://github.com/Unity-Technologies/InputSystem/blob/develop/Packages/com.unity.inputsystem/Documentation~/Installation.md
- PlayerInput 이벤트: https://docs.unity.cn/Packages/com.unity.inputsystem@1.13/manual/PlayerInput.html

코드는 교육용 예시이며 실제 Unity Editor 컴파일/Play Mode 실행은 수강생 환경에서 검증해야 합니다.
