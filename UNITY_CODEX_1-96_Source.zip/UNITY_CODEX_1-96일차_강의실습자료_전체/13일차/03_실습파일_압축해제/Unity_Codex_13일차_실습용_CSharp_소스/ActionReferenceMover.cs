using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// Input Actions 에셋의 Move(Vector2)와 Jump(Button)를 참조합니다.
/// 주의: PlayerInput 컴포넌트와 같은 Actions를 동시에 제어하지 않는 독립 실습입니다.
/// </summary>
public class ActionReferenceMover : MonoBehaviour
{
    [Header("Actions")]
    [SerializeField] private InputActionReference moveAction;
    [SerializeField] private InputActionReference jumpAction;

    [Header("Movement")]
    [SerializeField, Min(0f)] private float moveSpeed = 4f;

    private void OnEnable()
    {
        if (moveAction != null && moveAction.action != null)
            moveAction.action.Enable();

        if (jumpAction != null && jumpAction.action != null)
            jumpAction.action.Enable();
    }

    private void OnDisable()
    {
        if (moveAction != null && moveAction.action != null)
            moveAction.action.Disable();

        if (jumpAction != null && jumpAction.action != null)
            jumpAction.action.Disable();
    }

    private void Update()
    {
        if (moveAction == null || moveAction.action == null)
            return;

        Vector2 input = moveAction.action.ReadValue<Vector2>();
        input = Vector2.ClampMagnitude(input, 1f);

        // 3D 평면(XZ) 이동: WASD와 화살표 키 공통 동작
        Vector3 direction = new Vector3(input.x, 0f, input.y);
        transform.position += direction * moveSpeed * Time.deltaTime;

        if (jumpAction != null && jumpAction.action != null &&
            jumpAction.action.WasPressedThisFrame())
        {
            Debug.Log("Jump 입력 감지: Space!");
        }
    }
}
