using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>Input System의 Keyboard 장치 상태를 직접 읽는 연습용 코드입니다.</summary>
public class KeyboardPollingDemo : MonoBehaviour
{
    [SerializeField, Min(0f)] private float moveSpeed = 4f;

    private void Update()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null)
            return;

        Vector3 direction = Vector3.zero;
        if (keyboard.wKey.isPressed) direction += Vector3.forward;
        if (keyboard.sKey.isPressed) direction += Vector3.back;
        if (keyboard.aKey.isPressed) direction += Vector3.left;
        if (keyboard.dKey.isPressed) direction += Vector3.right;

        transform.position += direction.normalized * moveSpeed * Time.deltaTime;

        if (keyboard.spaceKey.wasPressedThisFrame)
            Debug.Log("Space 키를 눌렀습니다! (점프 동작은 다음 수업에서 구현)");
    }
}
