# 57일차 학생 실습 워크시트 (120분)

이름: ____________  날짜: ____________  Unity 버전: ____________

### A. ScriptableObject 이해 (25분)
1. MonoBehaviour, ScriptableObject, Prefab의 차이를 한 문장씩 정의하시오.
2. 실행 중 MonsterData의 MaxHealth를 직접 감소시키면 위험한 이유를 설명하시오.
3. SO 에셋이 사용자의 저장 게임을 대체하지 못하는 이유를 적으시오.

### B. 데이터 작성 (30분)
- MonsterData 에셋 3개(Goblin/Orc/Golem)를 생성하고 HP, Speed 값을 기록하시오.
- WaveData 3개에 SpawnEntry, Count, Interval, MaxAlive를 입력하시오.
- DifficultyData 에셋을 하나 만들고 Wave 1과 Wave 3의 HP 배율을 비교하시오.

### C. 실습 (45분)
- Tools > Day57 > Create ScriptableObject Lab 메뉴로 독립 실습 씬 생성.
- MonsterData에서 Goblin Speed를 변경한 뒤 플레이 움직임이 변하는지 확인.
- 동시에 활성화된 Goblin 2개 중 한 개만 피해를 주고, 나머지 HP가 그대로인지 확인.
- `Defeat all` 버튼으로 Wave 1~3 완료하고 Pool Count를 기록.
- `Restart` 후 이전 Wave·HP가 정상 초기화되는지 확인.

### D. Codex + 검증 (20분)
- 데이터/인스턴스 소유권 관점으로 코드 분석을 요청하고 위험 코드 2개를 적으시오.
- Editor 메뉴 Validator로 데이터 에셋 오류를 검사하시오.
- `Day57_Test_Checklist.csv` T01~T12의 Pass/Fail/Skipped와 로그를 작성하시오.

### 제출물
- ScriptableObject 에셋 3종 이상 / Scene / 테스트 시나리오 기록 / Console 스크린샷 / Codex diff.
- 주의: 다른 Day55·Day56 컴포넌트를 함께 배치했다면 실행 중복 여부를 점검하세요.
