# 강사용 운영 가이드

## 강의 시간표
- 0~25분: SO, MonoBehaviour, Prefab, SaveData 비교 및 공유 에셋 특성.
- 25~55분: `CreateAssetMenu`, `[Serializable]`, `[SerializeField]`, 참조형 필드 실습.
- 55~100분: MonsterData 3종 + WaveData 3종 + DifficultyData + Pool 실습.
- 100~120분: 공유 원본 오염·Pool 초기화·실패 케이스 + Codex 리뷰.

## 질문 포인트
1. 두 Goblin이 같은 SO 에셋을 참조해도 HP가 다른 이유는?
2. Prewarm 10회 `Get`/`Release` 한 개씩 교대하면 몇 개 생성되는가? (대개 한 개 재사용)
3. `maxSize`와 `maxAlive`는 왜 다른가? (유휴 저장 상한 / 게임 동시 생존 상한)
4. SO 필드를 `public set`으로 노출하는 것이 왜 위험한가?
5. SaveData와 SO를 혼동하면 빌드에서 어떤 문제가 생기는가?

## 정확성 유의
- ScriptableObject는 빌드에서 원본 에셋을 영구적으로 갱신하는 데이터 저장 수단이 아니다.
- 런타임에 SO 복사본을 만들 수는 있으나 그것 자체가 영구 저장을 뜻하지 않는다.
- 수업용 추적은 Transform 기반; NavMesh AI 통합은 후속 확장 과제로 구분한다.
- 학생 코드가 실제로 Unity Editor에서 컴파일·Play Mode 통과했는지는 별도 확인한다.

## 참조 공식 문서
- https://docs.unity3d.com/kr/current/Manual/class-ScriptableObject.html
- https://docs.unity3d.com/6000.1/Documentation/Manual/class-ScriptableObject.html
- https://docs.unity3d.com/6000.0/Documentation/ScriptReference/Pool.ObjectPool_1.html
