# Day57 Codex 실습 프롬프트

## 1. 구현 전 구조 리뷰
Unity 6.3 실습 프로젝트에서 ScriptableObject 데이터 분리 구조를 분석해줘.
읽기 전용으로 다룰 MonsterData/WaveData/DifficultyData와 개별 Unit의 CurrentHP/IsDead/Target 소유권을 구분하고, 현재 클래스 의존성 다이어그램을 제시해줘. 원본 Scene·Prefab·Asset을 덮어쓰지 말아줘. 코드 변경 전에 계획을 먼저 보여줘.

## 2. SO 원본 오염 검증
`Day57MonsterData.MaxHealth`가 TakeDamage, Spawn, Pool.Get, Restart 중에 수정되는 경로가 있는지 모든 호출 지점을 조사해줘. SO 값을 런타임 저장 용도로 쓰지 않았는지 확인하고, 같은 SO를 참조하는 Unit A/B의 HP 독립성을 검증하는 테스트를 제안해줘.

## 3. WaveConfig 검사
WaveData의 null Entry, count=0, interval<0, maxAlive=0, DifficultyData=null 시 실제 동작과 예상 결과를 비교해줘. Invalid 설정을 조용히 성공 처리하지 말고 로그와 회복 가능한 제어 흐름을 작성해줘.

## 4. Pool 재사용 검증
ObjectPool Prewarm, Get/Release, 중복 반환, 이벤트 구독 해제, Restart 후 Unit.CurrentHealth 복원을 점검해줘. `maxSize`는 inactive 저장 한도임을 확인하고 대규모 구조 변경 없이 최소 수정만 제안해줘.

## 5. 최종 회귀 검증
T01~T12 테스트를 수행할 수 있는 방법을 작성하고, 직접 Unity Editor 도구를 사용했다면 정확한 로그·스크린샷·실행 여부를 보고해줘. 실행 불가 시 '미실행'으로 기록해줘. 변경 파일 목록, diff, 예상 영향, 잔여 위험도 작성해줘.
