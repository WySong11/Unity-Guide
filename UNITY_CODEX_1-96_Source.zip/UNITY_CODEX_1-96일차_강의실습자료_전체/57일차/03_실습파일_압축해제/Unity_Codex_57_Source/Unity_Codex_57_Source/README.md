# UNITY × CODEX | 57일차 ScriptableObject 데이터

Unity 6.3 / URP 또는 3D 템플릿 / 120분 / Day57 접두사 독립 실습

## 오늘의 목표
- `ScriptableObject`로 몬스터·웨이브·난이도 설정을 프로젝트 Asset으로 저장한다.
- 공유 설정(SO)과 몬스터마다 달라지는 실행 상태(HP·타깃)를 분리한다.
- Monster Pool·Wave Spawner에서 SO 에셋을 읽어 웨이브를 진행한다.
- 데이터 오염·Prefab 연결 누락·재사용 초기화 오류를 검증한다.

## 설치 및 자동 실습 씬 생성
1. 새로운 Unity 6.3 3D URP 프로젝트 또는 기존 프로젝트의 **사본**을 준비합니다.
2. 이 ZIP의 `Runtime/`과 `Editor/` C# 파일을 Unity 프로젝트 `Assets/Day57/Scripts/Runtime`, `Assets/Day57/Scripts/Editor` 폴더에 각각 복사합니다.
3. 스크립트 컴파일 오류가 없는지 Console에서 확인합니다.
4. 메뉴 **Tools > Day57 > Create ScriptableObject Lab**을 선택합니다. 현재 열린 변경 씬의 저장 여부를 묻습니다.
5. 새 폴더 `Assets/Day57_SO_Lab[_N]/` 아래 `Data`, `Prefabs`, `Scenes`가 생성됩니다. **기존 폴더·에셋을 덮어쓰지 않습니다.**
6. 새로 생성된 `Scenes/Day57_ScriptableObjectLab.unity`을 열고 Play를 누른 다음 HUD의 **Start**를 누릅니다.
7. `Hit one (-20)` / `Defeat all` / `Restart`를 사용해 3개 Wave, SO 공유 참조, HP 독립성, Pool 재사용을 검증합니다.
8. 메뉴 **Tools > Day57 > Validate ScriptableObject Assets**로 누락/중복·잘못된 데이터 확인을 시작합니다.

## 기본 데이터
- Monster_Goblin: HP 40 / Speed 3.2 / Damage 7
- Monster_Orc: HP 80 / Speed 2.2 / Damage 12
- Monster_Golem: HP 160 / Speed 1.2 / Damage 18
- Wave01: Goblin ×4 / MaxAlive 3
- Wave02: Goblin ×3 + Orc ×3 / MaxAlive 4
- Wave03: Goblin ×3 + Orc ×3 + Golem ×2 / MaxAlive 4
- Difficulty_Default: Wave마다 HP·속도 배율 적용, **에셋 원본 불변**

## 아키텍처
```
MonsterData (.asset) ─┐
WaveData (.asset) ────┼─> WaveSpawner ─> Pool.Get ─> MonsterUnit.Initialize
DifficultyData (.asset)┘                          │
                                         Unit.CurrentHP (독립)
                                            ↓ Died
                                      Pool.TryReturn
```

`Day57MonsterUnit`의 Update는 별도 NavMesh 없이 Transform 기반 추적을 구현하여 새 프로젝트에서도 쉽게 실습하도록 했습니다. **52일차 NavMesh Enemy AI와 자동 통합되지 않습니다.** 실제 프로젝트에는 기존 AI Brain을 유지하고 `Initialize` 때 SO 설정값만 적용하도록 어댑터를 작성하세요. 55~56일차 타입을 이 프로젝트에 복사하지 않아도 본 실습은 독립적으로 돌아가도록 설계했습니다.

## 중요한 주의사항
- **SO 에셋은 Read-only 설정처럼 취급**합니다. `CurrentHP`, `IsDead`, `Target`, `Cooldown` 등을 SO에 보관하지 않습니다.
- Unity Editor에서 런타임에 SO 에셋을 수정하면 값이 남는 경우가 있습니다. 배포 빌드에서 SO를 사용자 세이브로 사용할 수 없습니다. 사용자 진행 데이터는 JSON/파일/DB 등 별도 저장 방식으로 구현합니다.
- `defaultCapacity`는 사전 생성 수가 아닙니다. 예제는 `Get N개 → Release N개` 방식의 Prewarm을 사용합니다. `maxSize`는 **유휴 풀에 보관할 최대 개수**이며 동시 활성 개체 수 제한이 아닙니다.
- `MonsterData`가 비어 있거나 `WaveData`에 유효 Entry가 없으면 Spawner는 Failed로 전환합니다. 잘못된 엔트리의 경우 경고 후 건너뜁니다.
- 실습용 `OnGUI`는 간편 테스트 UI입니다. 실제 게임 UI는 Canvas/TMP 등으로 대체할 수 있습니다.
- `Day57MonsterUnit`은 NavMeshAgent·Rigidbody 제어 코드와 자동 호환되지 않습니다. 실게임에 적용할 때 이동 루틴을 하나만 남기세요.

## 제출
`Docs/Day57_Test_Checklist.csv`의 12개 항목 결과와 SO Inspector 캡처 3장, MonsterUnit 2개 비교 캡처, Wave 완료 화면, Codex 분석 요약·diff를 제출합니다.

**검증 범위:** ZIP 내부 파일·PPT 문서 및 정적 구문 검토까지만 완료. Unity Editor 컴파일과 실제 Play Mode는 수강생 프로젝트에서 별도로 확인해야 합니다.
