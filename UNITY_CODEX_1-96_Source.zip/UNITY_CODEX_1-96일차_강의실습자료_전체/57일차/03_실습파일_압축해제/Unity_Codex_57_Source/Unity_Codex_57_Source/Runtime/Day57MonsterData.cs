using UnityEngine;

// Shared, authoring-time monster configuration. Never store current HP here.
[CreateAssetMenu(fileName = "Monster_New", menuName = "Day57/Monster Data")]
public sealed class Day57MonsterData : ScriptableObject
{
    [SerializeField] private string monsterId = "goblin";
    [SerializeField] private string displayName = "Goblin";
    [SerializeField, Min(1f)] private float maxHealth = 40f;
    [SerializeField, Min(0f)] private float moveSpeed = 3f;
    [SerializeField, Min(0f)] private float attackDamage = 8f;
    [SerializeField, Min(0)] private int rewardScore = 10;
    [SerializeField] private Color displayColor = Color.green;

    public string MonsterId => monsterId;
    public string DisplayName => displayName;
    public float MaxHealth => maxHealth;
    public float MoveSpeed => moveSpeed;
    public float AttackDamage => attackDamage;
    public int RewardScore => rewardScore;
    public Color DisplayColor => displayColor;

    private void OnValidate()
    {
        maxHealth = Mathf.Max(1f, maxHealth);
        moveSpeed = Mathf.Max(0f, moveSpeed);
        attackDamage = Mathf.Max(0f, attackDamage);
        rewardScore = Mathf.Max(0, rewardScore);
    }
}
