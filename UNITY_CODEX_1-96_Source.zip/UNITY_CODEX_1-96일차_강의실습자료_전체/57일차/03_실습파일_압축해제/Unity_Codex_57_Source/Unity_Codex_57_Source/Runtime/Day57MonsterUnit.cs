using System;
using UnityEngine;

// Runtime state belongs to this component, not the ScriptableObject asset.
public sealed class Day57MonsterUnit : MonoBehaviour
{
    private Day57MonsterData configuration;
    private Transform target;
    private float currentHealth;
    private float maxHealth;
    private float currentSpeed;
    private bool isDead = true;
    private Renderer[] renderers;
    private MaterialPropertyBlock propertyBlock;
    private static readonly int BaseColorId = Shader.PropertyToID("_BaseColor");
    private static readonly int ColorId = Shader.PropertyToID("_Color");

    public event Action<Day57MonsterUnit> Died;
    public Day57MonsterData Data => configuration;
    public float CurrentHealth => currentHealth;
    public float MaxHealth => maxHealth;
    public float CurrentSpeed => currentSpeed;
    public bool IsDead => isDead;

    private void Awake()
    {
        renderers = GetComponentsInChildren<Renderer>();
        propertyBlock = new MaterialPropertyBlock();
    }

    public void Initialize(Day57MonsterData data, float healthScale,
                           float speedScale, Transform followTarget)
    {
        configuration = data;
        target = followTarget;
        maxHealth = data != null ? Mathf.Max(1f, data.MaxHealth * Mathf.Max(0.01f, healthScale)) : 1f;
        currentHealth = maxHealth;
        currentSpeed = data != null ? Mathf.Max(0f, data.MoveSpeed * speedScale) : 0f;
        isDead = data == null;

        if (data != null && renderers != null)
        {
            foreach (Renderer r in renderers)
            {
                r.GetPropertyBlock(propertyBlock);
                propertyBlock.SetColor(BaseColorId, data.DisplayColor);
                propertyBlock.SetColor(ColorId, data.DisplayColor);
                r.SetPropertyBlock(propertyBlock);
            }
        }
    }

    private void Update()
    {
        if (isDead || target == null || currentSpeed <= 0f) return;
        Vector3 to = target.position - transform.position;
        to.y = 0f;
        if (to.sqrMagnitude < 2.25f) return;
        Vector3 delta = to.normalized * (currentSpeed * Time.deltaTime);
        transform.position += delta;
        if (to.sqrMagnitude > 0.001f)
            transform.rotation = Quaternion.LookRotation(to);
    }

    public void TakeDamage(float amount)
    {
        if (isDead || amount <= 0f) return;
        currentHealth = Mathf.Max(0f, currentHealth - amount);
        if (currentHealth > 0f) return;
        isDead = true;
        Died?.Invoke(this);
    }

    public void ResetForPool()
    {
        target = null;
        configuration = null;
        currentHealth = 0f;
        currentSpeed = 0f;
        isDead = true;
    }
}
