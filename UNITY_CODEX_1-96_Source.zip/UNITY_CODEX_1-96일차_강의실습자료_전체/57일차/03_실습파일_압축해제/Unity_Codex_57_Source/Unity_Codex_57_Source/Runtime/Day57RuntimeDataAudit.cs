using UnityEngine;

// Optional runtime invariant checks; never modifies SO assets.
public sealed class Day57RuntimeDataAudit : MonoBehaviour
{
    [SerializeField] private Day57WaveSpawner spawner;
    [SerializeField, Min(0.2f)] private float interval = 2f;
    private float nextCheck;

    private void Update()
    {
        if (spawner == null || Time.unscaledTime < nextCheck) return;
        nextCheck = Time.unscaledTime + interval;
        foreach (Day57MonsterUnit unit in spawner.GetActiveSnapshot())
        {
            if (unit == null || unit.Data == null)
            {
                Debug.LogError("[Day57] Active monster has no data", this);
                continue;
            }
            if (unit.CurrentHealth < 0f || unit.CurrentHealth > unit.MaxHealth + 0.001f)
                Debug.LogError("[Day57] Runtime HP invariant failed", unit);
        }
        if (spawner.Pool != null && spawner.Alive != spawner.Pool.CountActive)
            Debug.LogWarning("[Day57] Active counts differ; inspect spawn/return callbacks", this);
    }
}
