using UnityEngine;

[CreateAssetMenu(fileName = "Difficulty_New", menuName = "Day57/Difficulty Data")]
public sealed class Day57DifficultyData : ScriptableObject
{
    [SerializeField, Min(0f)] private float healthGrowthPerWave = 0.15f;
    [SerializeField, Min(0f)] private float speedGrowthPerWave = 0.05f;

    // Wave index is zero based. These calculations DO NOT mutate the asset.
    public float HealthScale(int waveIndex) =>
        1f + Mathf.Max(0, waveIndex) * healthGrowthPerWave;

    public float SpeedScale(int waveIndex) =>
        1f + Mathf.Max(0, waveIndex) * speedGrowthPerWave;

    private void OnValidate()
    {
        healthGrowthPerWave = Mathf.Max(0f, healthGrowthPerWave);
        speedGrowthPerWave = Mathf.Max(0f, speedGrowthPerWave);
    }
}
