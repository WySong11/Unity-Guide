using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class Day57SpawnEntry
{
    public Day57MonsterData monster;
    [Min(1)] public int count = 3;
    [Min(0f)] public float interval = 0.8f;
}

[CreateAssetMenu(fileName = "Wave_New", menuName = "Day57/Wave Data")]
public sealed class Day57WaveData : ScriptableObject
{
    [SerializeField] private List<Day57SpawnEntry> entries = new List<Day57SpawnEntry>();
    [SerializeField, Min(1)] private int maxAlive = 3;
    [SerializeField, Min(0f)] private float breakSeconds = 2f;

    public IReadOnlyList<Day57SpawnEntry> Entries => entries;
    public int MaxAlive => maxAlive;
    public float BreakSeconds => breakSeconds;

    public bool HasValidEntry()
    {
        if (entries == null) return false;
        foreach (Day57SpawnEntry entry in entries)
            if (entry != null && entry.monster != null && entry.count > 0)
                return true;
        return false;
    }

    private void OnValidate()
    {
        maxAlive = Mathf.Max(1, maxAlive);
        breakSeconds = Mathf.Max(0f, breakSeconds);
    }
}
