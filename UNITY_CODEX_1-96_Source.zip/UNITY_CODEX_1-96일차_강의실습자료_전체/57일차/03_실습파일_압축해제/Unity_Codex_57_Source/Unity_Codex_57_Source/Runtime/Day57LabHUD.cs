using System.Collections.Generic;
using UnityEngine;

// Independent lab: OnGUI requires no TextMeshPro, UI assets or Input System setup.
public sealed class Day57LabHUD : MonoBehaviour
{
    [SerializeField] private Day57WaveSpawner spawner;
    private Vector2 scroll;
    private void OnGUI()
    {
        if (spawner == null) return;
        GUILayout.BeginArea(new Rect(12, 12, 375, 445), GUI.skin.box);
        GUILayout.Label("DAY 57 | SCRIPTABLEOBJECT DATA LAB");
        GUILayout.Label("Wave: " + spawner.WaveNumber + "/" + spawner.WaveCount +
                       "  State: " + spawner.State);
        GUILayout.Label("Spawned: " + spawner.Spawned + "  Killed: " + spawner.Killed +
                       "  Alive: " + spawner.Alive);
        if (spawner.Pool != null)
            GUILayout.Label("Pool - active: " + spawner.Pool.CountActive +
                           "  inactive: " + spawner.Pool.CountInactive);
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Start")) spawner.StartRun();
        if (GUILayout.Button("Restart")) spawner.RestartRun();
        if (GUILayout.Button("Stop")) spawner.StopRun();
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Hit one (-20)")) spawner.DamageOne(20f);
        if (GUILayout.Button("Defeat all")) spawner.DamageAll(100000f);
        GUILayout.EndHorizontal();
        scroll = GUILayout.BeginScrollView(scroll, GUILayout.Height(245));
        List<Day57MonsterUnit> units = spawner.GetActiveSnapshot();
        foreach (Day57MonsterUnit unit in units)
        {
            if (unit == null) continue;
            Day57MonsterData data = unit.Data;
            GUILayout.Label((data != null ? data.DisplayName : "No data") +
                " | Unit HP " + unit.CurrentHealth.ToString("F0") +
                "/" + unit.MaxHealth.ToString("F0") +
                " | SO HP " + (data != null ? data.MaxHealth.ToString("F0") : "?") +
                " | Asset ID " + (data != null ? data.GetInstanceID().ToString() : "null"));
        }
        GUILayout.EndScrollView();
        GUILayout.EndArea();
    }
}
