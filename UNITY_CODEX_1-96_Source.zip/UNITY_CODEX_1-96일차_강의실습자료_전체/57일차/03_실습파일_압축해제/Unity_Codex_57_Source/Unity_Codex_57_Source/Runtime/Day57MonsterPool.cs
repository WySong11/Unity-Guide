using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

public sealed class Day57MonsterPool : MonoBehaviour
{
    [SerializeField] private Day57MonsterUnit prefab;
    [SerializeField, Min(0)] private int prewarmCount = 8;
    [SerializeField, Min(1)] private int maxInactive = 64;
    private ObjectPool<Day57MonsterUnit> pool;
    private readonly HashSet<Day57MonsterUnit> leased = new HashSet<Day57MonsterUnit>();

    public int CountActive => leased.Count;
    public int CountInactive => pool != null ? pool.CountInactive : 0;
    public int CountAll => pool != null ? pool.CountAll : 0;
    public bool IsConfigured => prefab != null && pool != null;

    private void Awake()
    {
        if (prefab == null)
        {
            Debug.LogError("[Day57] Monster Pool prefab is missing", this);
            return;
        }
        pool = new ObjectPool<Day57MonsterUnit>(Create, OnGet, OnRelease, OnDestroyUnit,
            true, Mathf.Max(1, prewarmCount), Mathf.Max(1, maxInactive));

        // Acquire ALL then release ALL. Get/Release in the same loop only warms one.
        var initial = new List<Day57MonsterUnit>();
        for (int i = 0; i < prewarmCount; i++) initial.Add(Get());
        foreach (Day57MonsterUnit unit in initial) TryReturn(unit);
    }

    private Day57MonsterUnit Create()
    {
        Day57MonsterUnit unit = Instantiate(prefab, transform);
        unit.gameObject.SetActive(false);
        return unit;
    }

    private void OnGet(Day57MonsterUnit unit) => unit.gameObject.SetActive(true);

    private void OnRelease(Day57MonsterUnit unit)
    {
        unit.ResetForPool();
        unit.gameObject.SetActive(false);
        unit.transform.SetParent(transform, true);
    }

    private void OnDestroyUnit(Day57MonsterUnit unit)
    {
        if (unit != null) Destroy(unit.gameObject);
    }

    public Day57MonsterUnit Get()
    {
        if (pool == null) return null;
        Day57MonsterUnit unit = pool.Get();
        leased.Add(unit);
        return unit;
    }

    public bool TryReturn(Day57MonsterUnit unit)
    {
        if (pool == null || unit == null || !leased.Remove(unit)) return false;
        pool.Release(unit);
        return true;
    }

    public void ReturnAll()
    {
        var snapshot = new List<Day57MonsterUnit>(leased);
        foreach (Day57MonsterUnit unit in snapshot) TryReturn(unit);
    }

    private void OnDestroy()
    {
        pool?.Clear();
        pool = null;
        leased.Clear();
    }
}
