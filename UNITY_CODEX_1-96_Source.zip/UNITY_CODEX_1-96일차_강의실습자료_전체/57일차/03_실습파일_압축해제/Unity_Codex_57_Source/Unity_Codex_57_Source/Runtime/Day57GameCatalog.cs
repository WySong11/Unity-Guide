using System;
using UnityEngine;

[CreateAssetMenu(fileName = "GameCatalog", menuName = "Day57/Game Catalog")]
public sealed class Day57GameCatalog : ScriptableObject
{
    [SerializeField] private Day57MonsterData[] monsters;
    [SerializeField] private Day57WaveData[] waves;

    public Day57WaveData[] Waves => waves;
    public Day57MonsterData FindMonster(string id)
    {
        if (monsters == null || string.IsNullOrWhiteSpace(id)) return null;
        foreach (Day57MonsterData entry in monsters)
        {
            if (entry != null && string.Equals(entry.MonsterId, id,
                                               StringComparison.Ordinal))
                return entry;
        }
        return null;
    }
}
