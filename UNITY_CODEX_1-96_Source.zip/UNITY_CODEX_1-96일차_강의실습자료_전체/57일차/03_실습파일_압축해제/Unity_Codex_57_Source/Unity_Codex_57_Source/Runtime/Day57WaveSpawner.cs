using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Day57WaveState { Ready, Spawning, Clearing, Break, Completed, Failed }

public sealed class Day57WaveSpawner : MonoBehaviour
{
    [SerializeField] private Day57WaveData[] waves;
    [SerializeField] private Day57DifficultyData difficulty;
    [SerializeField] private Day57MonsterPool monsterPool;
    [SerializeField] private Transform[] spawnPoints;
    [SerializeField] private Transform playerTarget;
    [SerializeField] private bool autoStart;

    private readonly HashSet<Day57MonsterUnit> active = new HashSet<Day57MonsterUnit>();
    private Coroutine routine;
    private int waveIndex;
    private int spawned;
    private int killed;
    private Day57WaveState state = Day57WaveState.Ready;

    public Day57WaveState State => state;
    public int WaveNumber => waveIndex + 1;
    public int WaveCount => waves != null ? waves.Length : 0;
    public int Spawned => spawned;
    public int Killed => killed;
    public int Alive => active.Count;
    public Day57MonsterPool Pool => monsterPool;
    public Day57WaveData[] Waves => waves;
    public Day57DifficultyData Difficulty => difficulty;

    private void Start()
    {
        if (autoStart) StartRun();
    }

    public void StartRun()
    {
        if (routine != null) return;
        if (waves == null || waves.Length == 0 || monsterPool == null ||
            !monsterPool.IsConfigured || spawnPoints == null || spawnPoints.Length == 0)
        {
            state = Day57WaveState.Failed;
            Debug.LogError("[Day57] WaveSpawner references are incomplete", this);
            return;
        }
        ResetRunState();
        routine = StartCoroutine(Run());
    }

    public void RestartRun()
    {
        StopRun();
        StartRun();
    }

    public void StopRun()
    {
        if (routine != null) StopCoroutine(routine);
        routine = null;
        var snapshot = new List<Day57MonsterUnit>(active);
        foreach (Day57MonsterUnit unit in snapshot)
        {
            if (unit == null) continue;
            unit.Died -= OnUnitDied;
            if (monsterPool != null) monsterPool.TryReturn(unit);
        }
        active.Clear();
        ResetRunState();
    }

    private void OnDisable() => StopRun();

    private void ResetRunState()
    {
        waveIndex = 0;
        spawned = 0;
        killed = 0;
        state = Day57WaveState.Ready;
    }

    private IEnumerator Run()
    {
        for (waveIndex = 0; waveIndex < waves.Length; waveIndex++)
        {
            Day57WaveData config = waves[waveIndex];
            spawned = 0;
            killed = 0;
            if (config == null || !config.HasValidEntry())
            {
                Debug.LogError("[Day57] Invalid WaveData: wave " + (waveIndex + 1), this);
                state = Day57WaveState.Failed;
                routine = null;
                yield break;
            }
            state = Day57WaveState.Spawning;
            foreach (Day57SpawnEntry entry in config.Entries)
            {
                if (entry == null || entry.monster == null || entry.count <= 0)
                {
                    Debug.LogWarning("[Day57] Skipping invalid spawn entry", this);
                    continue;
                }
                for (int i = 0; i < entry.count; i++)
                {
                    while (active.Count >= config.MaxAlive) yield return null;
                    Day57MonsterUnit unit = monsterPool.Get();
                    if (unit == null)
                    {
                        state = Day57WaveState.Failed;
                        routine = null;
                        yield break;
                    }
                    Transform point = NextPoint(spawned);
                    if (point == null)
                    {
                        monsterPool.TryReturn(unit);
                        state = Day57WaveState.Failed;
                        routine = null;
                        yield break;
                    }
                    unit.transform.SetPositionAndRotation(point.position, point.rotation);
                    float hpScale = difficulty != null ? difficulty.HealthScale(waveIndex) : 1f;
                    float speedScale = difficulty != null ? difficulty.SpeedScale(waveIndex) : 1f;
                    unit.Initialize(entry.monster, hpScale, speedScale, playerTarget);
                    unit.Died -= OnUnitDied;
                    unit.Died += OnUnitDied;
                    active.Add(unit);
                    spawned++;
                    if (entry.interval > 0f) yield return new WaitForSeconds(entry.interval);
                    else yield return null;
                }
            }
            state = Day57WaveState.Clearing;
            while (active.Count > 0) yield return null;
            if (waveIndex < waves.Length - 1)
            {
                state = Day57WaveState.Break;
                if (config.BreakSeconds > 0f)
                    yield return new WaitForSeconds(config.BreakSeconds);
            }
        }
        state = Day57WaveState.Completed;
        routine = null;
    }

    private Transform NextPoint(int index)
    {
        if (spawnPoints == null || spawnPoints.Length == 0) return null;
        for (int i = 0; i < spawnPoints.Length; i++)
        {
            Transform point = spawnPoints[(index + i) % spawnPoints.Length];
            if (point != null) return point;
        }
        return null;
    }

    private void OnUnitDied(Day57MonsterUnit unit)
    {
        if (unit == null || !active.Remove(unit)) return;
        unit.Died -= OnUnitDied;
        monsterPool.TryReturn(unit);
        killed++;
    }

    public void DamageOne(float amount)
    {
        var snapshot = new List<Day57MonsterUnit>(active);
        if (snapshot.Count > 0 && snapshot[0] != null)
            snapshot[0].TakeDamage(amount);
    }

    public void DamageAll(float amount)
    {
        var snapshot = new List<Day57MonsterUnit>(active);
        foreach (Day57MonsterUnit unit in snapshot)
            if (unit != null) unit.TakeDamage(amount);
    }

    public List<Day57MonsterUnit> GetActiveSnapshot() => new List<Day57MonsterUnit>(active);
}
