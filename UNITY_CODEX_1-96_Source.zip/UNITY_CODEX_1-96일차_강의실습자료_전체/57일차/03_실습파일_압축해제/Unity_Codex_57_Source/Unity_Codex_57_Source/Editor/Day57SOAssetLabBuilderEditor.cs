#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class Day57SOAssetLabBuilderEditor
{
    [MenuItem("Tools/Day57/Create ScriptableObject Lab")]
    public static void Build()
    {
        // Never overwrite other lectures or existing user assets.
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
            return;

        string root = "Assets/Day57_SO_Lab";
        int suffix = 2;
        while (AssetDatabase.IsValidFolder(root))
            root = "Assets/Day57_SO_Lab_" + suffix++;
        AssetDatabase.CreateFolder("Assets", root.Substring("Assets/".Length));
        AssetDatabase.CreateFolder(root, "Data");
        AssetDatabase.CreateFolder(root, "Prefabs");
        AssetDatabase.CreateFolder(root, "Scenes");
        string dataPath = root + "/Data/";
        var goblin = MakeMonster(dataPath, "Monster_Goblin", "goblin", "Goblin", 40f, 3.2f, 7f, Color.green);
        var orc = MakeMonster(dataPath, "Monster_Orc", "orc", "Orc", 80f, 2.2f, 12f, new Color(0.85f, 0.42f, 0.1f));
        var golem = MakeMonster(dataPath, "Monster_Golem", "golem", "Golem", 160f, 1.2f, 18f, new Color(0.25f, 0.5f, 0.95f));
        var difficulty = ScriptableObject.CreateInstance<Day57DifficultyData>();
        AssetDatabase.CreateAsset(difficulty, dataPath + "Difficulty_Default.asset");
        Day57WaveData wave1 = MakeWave(dataPath, "Wave_01", 3, 2f,
            (goblin, 4, 0.7f));
        Day57WaveData wave2 = MakeWave(dataPath, "Wave_02", 4, 2f,
            (goblin, 3, 0.55f), (orc, 3, 0.9f));
        Day57WaveData wave3 = MakeWave(dataPath, "Wave_03", 4, 0f,
            (goblin, 3, 0.45f), (orc, 3, 0.7f), (golem, 2, 1.1f));
        Day57WaveData[] waves = { wave1, wave2, wave3 };
        var catalog = ScriptableObject.CreateInstance<Day57GameCatalog>();
        AssetDatabase.CreateAsset(catalog, dataPath + "GameCatalog.asset");
        var catSO = new SerializedObject(catalog);
        WriteArray(catSO.FindProperty("monsters"), new Object[] { goblin, orc, golem });
        WriteArray(catSO.FindProperty("waves"), new Object[] { wave1, wave2, wave3 });
        catSO.ApplyModifiedPropertiesWithoutUndo();

        GameObject proto = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        proto.name = "Day57_MonsterPrototype";
        proto.AddComponent<Day57MonsterUnit>();
        proto.transform.position = Vector3.zero;
        GameObject prefabGO = PrefabUtility.SaveAsPrefabAsset(proto, root + "/Prefabs/Day57_Monster.prefab");
        Object.DestroyImmediate(proto);
        Day57MonsterUnit prefab = prefabGO.GetComponent<Day57MonsterUnit>();

        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
        floor.name = "Ground";
        floor.transform.position = new Vector3(0, -0.5f, 0);
        floor.transform.localScale = new Vector3(24, 1, 24);
        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "PlayerTarget";
        player.transform.position = new Vector3(0, 1f, 0);

        var spots = new List<Transform>();
        Vector3[] positions = { new Vector3(-8, 1, 7), new Vector3(8, 1, 7),
                                new Vector3(-8, 1, -7), new Vector3(8, 1, -7) };
        for (int i = 0; i < positions.Length; i++)
        {
            GameObject go = new GameObject("SpawnPoint_" + (i + 1));
            go.transform.position = positions[i];
            spots.Add(go.transform);
        }
        GameObject cam = new GameObject("Main Camera");
        cam.tag = "MainCamera";
        Camera camera = cam.AddComponent<Camera>();
        cam.AddComponent<AudioListener>();
        camera.transform.position = new Vector3(0, 19, -20);
        camera.transform.LookAt(new Vector3(0, 0, 0));
        GameObject light = new GameObject("Directional Light");
        Light sunlight = light.AddComponent<Light>();
        sunlight.type = LightType.Directional;
        light.transform.rotation = Quaternion.Euler(55, -35, 0);

        GameObject poolGO = new GameObject("MonsterPool");
        Day57MonsterPool pool = poolGO.AddComponent<Day57MonsterPool>();
        var poolSO = new SerializedObject(pool);
        poolSO.FindProperty("prefab").objectReferenceValue = prefab;
        poolSO.FindProperty("prewarmCount").intValue = 8;
        poolSO.FindProperty("maxInactive").intValue = 64;
        poolSO.ApplyModifiedPropertiesWithoutUndo();

        GameObject spawnGO = new GameObject("WaveSpawner");
        Day57WaveSpawner spawner = spawnGO.AddComponent<Day57WaveSpawner>();
        var spawnerSO = new SerializedObject(spawner);
        WriteArray(spawnerSO.FindProperty("waves"), waves);
        spawnerSO.FindProperty("difficulty").objectReferenceValue = difficulty;
        spawnerSO.FindProperty("monsterPool").objectReferenceValue = pool;
        WriteArray(spawnerSO.FindProperty("spawnPoints"), spots.ToArray());
        spawnerSO.FindProperty("playerTarget").objectReferenceValue = player.transform;
        spawnerSO.FindProperty("autoStart").boolValue = false;
        spawnerSO.ApplyModifiedPropertiesWithoutUndo();

        GameObject toolsGO = new GameObject("LabHUD_And_Audit");
        var hud = toolsGO.AddComponent<Day57LabHUD>();
        var audit = toolsGO.AddComponent<Day57RuntimeDataAudit>();
        var hudSO = new SerializedObject(hud);
        hudSO.FindProperty("spawner").objectReferenceValue = spawner;
        hudSO.ApplyModifiedPropertiesWithoutUndo();
        var auditSO = new SerializedObject(audit);
        auditSO.FindProperty("spawner").objectReferenceValue = spawner;
        auditSO.ApplyModifiedPropertiesWithoutUndo();

        string scenePath = root + "/Scenes/Day57_ScriptableObjectLab.unity";
        EditorSceneManager.SaveScene(scene, scenePath);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Selection.activeObject = AssetDatabase.LoadAssetAtPath<SceneAsset>(scenePath);
        EditorGUIUtility.PingObject(Selection.activeObject);
        Debug.Log("[Day57] Lab created (no overwrites): " + root);
        EditorUtility.DisplayDialog("Day57 SO Lab", "Generated: " + root +
            "\nOpen the scene, enter Play Mode, and press Start in the HUD.", "OK");
    }

    private static Day57MonsterData MakeMonster(string folder, string file,
        string id, string label, float hp, float speed, float damage, Color color)
    {
        Day57MonsterData asset = ScriptableObject.CreateInstance<Day57MonsterData>();
        AssetDatabase.CreateAsset(asset, folder + file + ".asset");
        var so = new SerializedObject(asset);
        so.FindProperty("monsterId").stringValue = id;
        so.FindProperty("displayName").stringValue = label;
        so.FindProperty("maxHealth").floatValue = hp;
        so.FindProperty("moveSpeed").floatValue = speed;
        so.FindProperty("attackDamage").floatValue = damage;
        so.FindProperty("displayColor").colorValue = color;
        so.ApplyModifiedPropertiesWithoutUndo();
        return asset;
    }

    private static Day57WaveData MakeWave(string folder, string file, int maxAlive,
        float breakSeconds, params (Day57MonsterData monster, int count, float interval)[] entries)
    {
        Day57WaveData asset = ScriptableObject.CreateInstance<Day57WaveData>();
        AssetDatabase.CreateAsset(asset, folder + file + ".asset");
        var so = new SerializedObject(asset);
        so.FindProperty("maxAlive").intValue = maxAlive;
        so.FindProperty("breakSeconds").floatValue = breakSeconds;
        SerializedProperty list = so.FindProperty("entries");
        list.arraySize = entries.Length;
        for (int i = 0; i < entries.Length; i++)
        {
            var element = list.GetArrayElementAtIndex(i);
            element.FindPropertyRelative("monster").objectReferenceValue = entries[i].monster;
            element.FindPropertyRelative("count").intValue = entries[i].count;
            element.FindPropertyRelative("interval").floatValue = entries[i].interval;
        }
        so.ApplyModifiedPropertiesWithoutUndo();
        return asset;
    }

    private static void WriteArray(SerializedProperty list, Object[] values)
    {
        list.arraySize = values.Length;
        for (int i = 0; i < values.Length; i++)
            list.GetArrayElementAtIndex(i).objectReferenceValue = values[i];
    }
}
#endif
