#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public static class Day57SOAssetValidatorEditor
{
    [MenuItem("Tools/Day57/Validate ScriptableObject Assets")]
    public static void Validate()
    {
        int errors = 0;
        int checkedMonsters = 0;
        int checkedWaves = 0;
        var ids = new HashSet<string>();
        foreach (string guid in AssetDatabase.FindAssets("t:Day57MonsterData"))
        {
            Day57MonsterData data = AssetDatabase.LoadAssetAtPath<Day57MonsterData>(
                AssetDatabase.GUIDToAssetPath(guid));
            if (data == null) continue;
            checkedMonsters++;
            if (string.IsNullOrWhiteSpace(data.MonsterId) || !ids.Add(data.MonsterId))
            {
                Debug.LogError("[Day57] Empty or duplicate MonsterId: " + data.name, data);
                errors++;
            }
            if (data.MaxHealth <= 0 || data.MoveSpeed < 0)
            {
                Debug.LogError("[Day57] Invalid monster stats: " + data.name, data);
                errors++;
            }
        }
        foreach (string guid in AssetDatabase.FindAssets("t:Day57WaveData"))
        {
            Day57WaveData wave = AssetDatabase.LoadAssetAtPath<Day57WaveData>(
                AssetDatabase.GUIDToAssetPath(guid));
            if (wave == null) continue;
            checkedWaves++;
            if (wave.MaxAlive < 1 || !wave.HasValidEntry())
            {
                Debug.LogError("[Day57] Invalid WaveData: " + wave.name, wave);
                errors++;
            }
            foreach (Day57SpawnEntry entry in wave.Entries)
            {
                if (entry == null || entry.monster == null || entry.count < 1 || entry.interval < 0)
                {
                    Debug.LogError("[Day57] Invalid entry in: " + wave.name, wave);
                    errors++;
                }
            }
        }
        Debug.Log("[Day57] Asset Validator - Monsters: " + checkedMonsters +
            ", Waves: " + checkedWaves + ", Errors: " + errors);
        if (checkedMonsters == 0 || checkedWaves == 0)
            Debug.LogWarning("[Day57] No monster or wave data found - create a lab first");
        EditorUtility.DisplayDialog("Day57 Validation", "Monsters: " + checkedMonsters +
            "\nWaves: " + checkedWaves + "\nErrors: " + errors, "OK");
    }
}
#endif
