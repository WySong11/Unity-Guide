#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using UnityEngine.AI;
using Unity.AI.Navigation;

public static class Day50SceneValidator
{
    [MenuItem("Tools/Unity Codex/Day50/Validate Scene")]
    public static void Validate()
    {
        int errors = 0;
        NavMeshSurface surface = Object.FindFirstObjectByType<NavMeshSurface>();
        Day50EnemyBrain brain = Object.FindFirstObjectByType<Day50EnemyBrain>();
        Day50PatrolRoute route = Object.FindFirstObjectByType<Day50PatrolRoute>();
        Day50EnemyPerception sensor = Object.FindFirstObjectByType<Day50EnemyPerception>();
        Day50EnemyNavigation navigation = Object.FindFirstObjectByType<Day50EnemyNavigation>();
        if (surface == null) { Debug.LogError("[Day50] NavMeshSurface 없음"); errors++; }
        if (brain == null) { Debug.LogError("[Day50] EnemyBrain 없음"); errors++; }
        if (route == null || !route.HasPoints) { Debug.LogError("[Day50] Waypoint 배열 없음"); errors++; }
        if (sensor == null || sensor.Target == null) { Debug.LogError("[Day50] Target 연결 없음"); errors++; }
        if (navigation == null || navigation.Agent == null) { Debug.LogError("[Day50] NavMeshAgent 없음"); errors++; }
        NavMeshTriangulation triangulation = NavMesh.CalculateTriangulation();
        if (triangulation.vertices.Length == 0) { Debug.LogError("[Day50] NavMesh Bake 데이터 없음"); errors++; }
        if (navigation != null && !navigation.Agent.isOnNavMesh && Application.isPlaying)
            Debug.LogWarning("[Day50] Enemy가 NavMesh 위에 없습니다.");
        if (errors == 0) Debug.Log("[Day50] 씬 기본 구성 정상. Play Mode 시 Chase/Return 테스트도 수행하세요.");
        else Debug.LogWarning($"[Day50] {errors}개 문제를 수정하세요.");
    }
}
#endif
