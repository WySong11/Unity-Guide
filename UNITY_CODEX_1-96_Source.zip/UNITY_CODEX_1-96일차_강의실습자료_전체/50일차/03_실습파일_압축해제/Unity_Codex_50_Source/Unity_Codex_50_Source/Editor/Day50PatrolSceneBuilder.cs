#if UNITY_EDITOR
using System;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.SceneManagement;
using Unity.AI.Navigation;

public static class Day50PatrolSceneBuilder
{
    private const string RootPath = "Assets/UnityCodexDay50";
    [MenuItem("Tools/Unity Codex/Day50/Create Patrol Chase Lab")]
    public static void Build()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        EnsureFolders();
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        GameObject root = new GameObject("Day50_PatrolChase_Lab");
        GameObject geometry = new GameObject("NavigationGeometry");
        geometry.transform.SetParent(root.transform);
        CreateCube("Ground", new Vector3(0f, -0.25f, 0f), new Vector3(28f, 0.5f, 28f),
            new Color(0.30f, 0.47f, 0.46f), geometry.transform);
        CreateCube("Wall_A", new Vector3(0f, 1f, 0f), new Vector3(2f, 2f, 7f),
            new Color(0.29f, 0.35f, 0.5f), geometry.transform);
        CreateCube("Wall_B", new Vector3(5f, 1f, 6f), new Vector3(5f, 2f, 1f),
            new Color(0.29f, 0.35f, 0.5f), geometry.transform);
        GameObject routeObject = new GameObject("PatrolPoints");
        routeObject.transform.SetParent(root.transform);
        Vector3[] positions = {
            new Vector3(-8f, 0f, -6f), new Vector3(-8f, 0f, 6f),
            new Vector3(8f, 0f, 6f), new Vector3(8f, 0f, -6f)
        };
        Transform[] points = new Transform[positions.Length];
        for (int i = 0; i < positions.Length; i++)
        {
            GameObject point = new GameObject($"WP_{i:00}");
            point.transform.SetParent(routeObject.transform);
            point.transform.position = positions[i];
            points[i] = point.transform;
        }
        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Player_TestTarget";
        player.transform.SetParent(root.transform);
        player.transform.position = new Vector3(0f, 1f, 10f);
        UnityEngine.Object.DestroyImmediate(player.GetComponent<CapsuleCollider>());
        player.AddComponent<CharacterController>();
        player.AddComponent<Day50PlayerMover>();
        Paint(player, new Color(0.29f, 0.68f, 0.98f));

        GameObject enemy = new GameObject("Enemy_Patrol_Chase");
        enemy.transform.SetParent(root.transform);
        enemy.transform.position = positions[0]; // Agent 루트는 NavMesh 높이(y=0)
        enemy.transform.rotation = Quaternion.LookRotation(Vector3.forward);
        GameObject enemyVisual = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        enemyVisual.name = "Visual";
        enemyVisual.transform.SetParent(enemy.transform, false);
        enemyVisual.transform.localPosition = Vector3.up; // 캡슐 중심만 y=1
        UnityEngine.Object.DestroyImmediate(enemyVisual.GetComponent<CapsuleCollider>());
        Paint(enemyVisual, new Color(0.96f, 0.48f, 0.32f));
        NavMeshAgent agent = enemy.AddComponent<NavMeshAgent>();
        agent.radius = 0.45f; agent.height = 2f; agent.speed = 2f;
        agent.acceleration = 12f; agent.angularSpeed = 560f;
        enemy.AddComponent<Day50EnemyNavigation>();
        Day50EnemyPerception sensor = enemy.AddComponent<Day50EnemyPerception>();
        sensor.Configure(player.transform);
        Day50PatrolRoute route = enemy.AddComponent<Day50PatrolRoute>();
        route.Configure(points);
        Day50EnemyBrain brain = enemy.AddComponent<Day50EnemyBrain>();
        Day50AIDiagnostics debug = enemy.AddComponent<Day50AIDiagnostics>();
        SerializedObject diagnostic = new SerializedObject(debug);
        diagnostic.FindProperty("brain").objectReferenceValue = brain;
        diagnostic.ApplyModifiedPropertiesWithoutUndo();

        GameObject cameraObject = new GameObject("Main Camera");
        cameraObject.tag = "MainCamera";
        Camera camera = cameraObject.AddComponent<Camera>();
        camera.fieldOfView = 60f;
        cameraObject.AddComponent<AudioListener>();
        Day50FollowCamera follow = cameraObject.AddComponent<Day50FollowCamera>();
        follow.Configure(player.transform);
        cameraObject.transform.position = player.transform.position + new Vector3(0f, 12f, -13f);

        GameObject lightObject = new GameObject("Directional Light");
        Light light = lightObject.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.0f;
        lightObject.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

        // 외부 장애물은 Geometry의 하위 오브젝트이므로 Children 모드를 사용합니다.
        NavMeshSurface surface = geometry.AddComponent<NavMeshSurface>();
        surface.collectObjects = CollectObjects.Children;
        surface.useGeometry = NavMeshCollectGeometry.PhysicsColliders;
        string unique = DateTime.Now.ToString("yyyyMMdd_HHmmss");
        string scenePath = AssetDatabase.GenerateUniqueAssetPath(
            $"{RootPath}/Scenes/Day50_PatrolChase_{unique}.unity");
        EditorSceneManager.SaveScene(scene, scenePath);
        surface.BuildNavMesh();
        EditorSceneManager.SaveScene(scene, scenePath);
        AssetDatabase.SaveAssets();
        Selection.activeGameObject = enemy;
        EditorGUIUtility.PingObject(enemy);
        Debug.Log($"[Day50] Scene 생성: {scenePath} / Bake 후 플레이어를 WASD로 이동하세요.");
    }

    private static void EnsureFolders()
    {
        if (!AssetDatabase.IsValidFolder(RootPath)) AssetDatabase.CreateFolder("Assets", "UnityCodexDay50");
        if (!AssetDatabase.IsValidFolder(RootPath + "/Scenes")) AssetDatabase.CreateFolder(RootPath, "Scenes");
        if (!AssetDatabase.IsValidFolder(RootPath + "/Materials")) AssetDatabase.CreateFolder(RootPath, "Materials");
    }
    private static GameObject CreateCube(string name, Vector3 pos, Vector3 scale, Color color, Transform parent)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = name; go.transform.SetParent(parent);
        go.transform.position = pos; go.transform.localScale = scale;
        Paint(go, color); return go;
    }
    private static void Paint(GameObject go, Color color)
    {
        Renderer renderer = go.GetComponent<Renderer>();
        if (renderer == null) return;
        Shader shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
        if (shader == null) return;
        Material material = new Material(shader) { color = color, name = "Day50_" + go.name };
        string path = AssetDatabase.GenerateUniqueAssetPath(
            RootPath + "/Materials/" + material.name + ".mat");
        AssetDatabase.CreateAsset(material, path);
        renderer.sharedMaterial = material;
    }
}
#endif
