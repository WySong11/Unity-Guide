# Unity × Codex · 50일차 Patrol / Chase 구현

- 대상: Unity 6.3 프로젝트(예: 6000.3 계열), **3D URP** 프로젝트 권장
- 학습 시간: 120분
- 전제: 49일차 Enemy AI/FSM 개념, NavMeshAgent 기초
- 독립 데모: `Day50` 접두사로 기존 49일차 클래스와 이름 충돌 방지

## 1. 설치 및 프로젝트 설정

1. **Window → Package Manager**에서 `AI Navigation` (`com.unity.ai.navigation`) 설치.
2. `Input System` (`com.unity.inputsystem`) 설치. 데모의 `Day50PlayerMover`가 Keyboard.current를 사용합니다.
3. **Edit → Project Settings → Player → Active Input Handling**에 `Input System Package` 또는 `Both` 지정(필요할 경우 Editor 재시작).
4. Source의 `Runtime` 폴더 내 `.cs` 파일을 프로젝트의 `Assets/UnityCodexDay50/Runtime/`으로 복사.
5. Source의 `Editor` 폴더 내 `.cs` 파일을 **반드시** `Assets/UnityCodexDay50/Editor/`로 복사. Editor 전용 코드가 런타임 어셈블리에 들어가면 빌드 오류가 발생합니다.
6. Unity 컴파일 완료 후 **Tools → Unity Codex → Day50 → Create Patrol Chase Lab** 선택.
7. 작업 중인 Scene이 수정되었다면 저장 확인창이 뜹니다. 도구는 새 Scene 파일을 생성하며 기존 Scene을 덮어쓰지 않습니다.
8. 자동 생성된 씬에서 Ground·Wall을 모아 둔 `NavigationGeometry`에 `NavMeshSurface`가 연결되고 Bake됩니다. Scene 뷰에서 NavMesh가 생성되었는지 확인합니다.
9. **Tools → Unity Codex → Day50 → Validate Scene** 실행하여 씬 구성을 점검합니다.
10. Play Mode → `WASD`로 플레이어 이동, `F1`로 AI 디버그 HUD 켜기/끄기.

## 2. 예상 씬 구조

```
Day50_PatrolChase_Lab
  NavigationGeometry
    Ground
    Wall_A
    Wall_B
  PatrolPoints
    WP_00
    WP_01
    WP_02
    WP_03
  Player_TestTarget
    CharacterController
    Day50PlayerMover
  Enemy_Patrol_Chase
    NavMeshAgent
    Day50EnemyNavigation
    Day50EnemyPerception
    Day50PatrolRoute
    Day50EnemyBrain
    Day50AIDiagnostics
    Visual
Main Camera
Directional Light
```

## 3. 상태 흐름

```
Patrol --(거리+시야각+LOS 만족)--> Chase
Chase --(지속적 시야 상실)-------> Return
Return --(웨이포인트 도착)-------> Patrol
Return --(타깃 재탐지)---------> Chase
생존 상태 --(추후 체력 시스템)----> Dead
```

현재 50일차 소스는 **Attack 상태를 구현하지 않습니다.** 타깃 가까이 도착하면 멈추고 이후 레슨에서 공격을 연결합니다.

## 4. 주요 Inspector 수치(교육용 예시)

| 항목 | 예시 |
|---|---:|
| Detection Radius | 7m |
| Lose Radius | 11m |
| View Angle | 120° |
| Patrol Speed | 2m/s |
| Chase Speed | 4.5m/s |
| Chase Stop Distance | 1.7m |
| Lost Target Delay | 1.5초 |
| Repath Interval | 0.25초 |
| Waypoint Wait | 0.75초 |

## 5. 주의 사항

- 49일차 `EnemyBrain`과 50일차 `Day50EnemyBrain`을 **같은 Enemy에 동시에 붙이지 마세요**. 두 시스템이 동일한 NavMeshAgent를 제어하면 경로 충돌이 발생합니다.
- `NavMeshSurface`가 Bake되지 않았거나 Enemy가 NavMesh 밖에 있으면 이동을 시작하지 않습니다. HUD의 `NavMesh:false`를 확인하세요.
- 벽 가림은 **Collider**와 `obstacleMask` 설정에 의존합니다. 데모에서는 자기 Collider와 Target Collider를 Raycast 필터링으로 무시합니다.
- 실습은 3D NavMesh 이동입니다. Rigidbody와 NavMeshAgent가 동시에 위치를 제어하도록 구성하지 마세요.
- 씬 자동 생성 도구는 실습용 Material 에셋을 `Assets/UnityCodexDay50/Materials`에 별도로 저장합니다.
- NavMesh 베이크와 이동, 실제 플레이 테스트는 Unity Editor에서 확인해야 합니다. 패키지와 프로젝트 설정에 따라 경고가 다를 수 있습니다.

## 6. 제출물

Scene(.unity), Runtime·Editor C# 소스, Inspector 설정 화면 캡처, Play Mode 테스트표(CSV), 오류 수정 로그 및 Codex 프롬프트/결과.

## 7. 참고 문서

- AI Navigation: https://docs.unity3d.com/kr/6000.0/Manual/com.unity.ai.navigation.html
- NavMeshAgent.SetDestination: https://docs.unity3d.com/ja/current/ScriptReference/AI.NavMeshAgent.SetDestination.html
- NavMeshAgent.stoppingDistance: https://docs.unity3d.com/kr/current/ScriptReference/AI.NavMeshAgent-stoppingDistance.html
