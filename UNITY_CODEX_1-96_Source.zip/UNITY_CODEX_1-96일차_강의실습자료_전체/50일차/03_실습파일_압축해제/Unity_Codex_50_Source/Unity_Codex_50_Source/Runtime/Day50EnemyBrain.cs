using System;
using UnityEngine;

/// <summary>Patrol → Chase → Return 반복. Attack은 51일차 확장 지점입니다.</summary>
[RequireComponent(typeof(Day50EnemyNavigation), typeof(Day50EnemyPerception), typeof(Day50PatrolRoute))]
public sealed class Day50EnemyBrain : MonoBehaviour
{
    [SerializeField] private Day50EnemyNavigation navigation;
    [SerializeField] private Day50EnemyPerception perception;
    [SerializeField] private Day50PatrolRoute route;
    [SerializeField, Min(0.05f)] private float repathInterval = 0.25f;
    [SerializeField, Min(0.1f)] private float lostTargetDelay = 1.5f;
    [SerializeField, Min(0.1f)] private float chaseStopDistance = 1.7f;
    [SerializeField, Min(0.2f)] private float recoveryTimeout = 3f;

    public event Action<Day50EnemyState> StateChanged;
    public Day50EnemyState State { get; private set; } = Day50EnemyState.Patrol;
    public float LostTimer => lostTimer;
    public Day50EnemyNavigation Navigation => navigation;
    public Day50EnemyPerception Perception => perception;

    private float lostTimer;
    private float repathTimer;
    private float patrolWait;
    private float failureTimer;
    private bool waitingAtPatrolPoint;
    private Vector3 lastSeenPosition;
    private Vector3 returnPosition;

    private void Awake()
    {
        if (!navigation) navigation = GetComponent<Day50EnemyNavigation>();
        if (!perception) perception = GetComponent<Day50EnemyPerception>();
        if (!route) route = GetComponent<Day50PatrolRoute>();
    }
    private void Start() => BeginPatrol();
    private void Update()
    {
        if (State == Day50EnemyState.Dead || navigation == null || !navigation.Ready) return;
        if (State != Day50EnemyState.Chase && perception.CanAcquire()) BeginChase();
        switch (State)
        {
            case Day50EnemyState.Patrol: UpdatePatrol(); break;
            case Day50EnemyState.Chase: UpdateChase(); break;
            case Day50EnemyState.Return: UpdateReturn(); break;
        }
    }

    private void ChangeState(Day50EnemyState next)
    {
        if (State == next) return;
        State = next;
        StateChanged?.Invoke(next);
        Debug.Log($"[Day50] AI 상태: {next}", this);
    }

    private void BeginPatrol()
    {
        if (!route || !route.HasPoints) { Debug.LogWarning("Day50: Patrol Waypoint 연결 필요", this); return; }
        navigation.SetPatrolMode();
        ChangeState(Day50EnemyState.Patrol);
        waitingAtPatrolPoint = false;
        patrolWait = 0f;
        failureTimer = 0f;
        navigation.TryGo(route.CurrentPoint);
    }
    private void UpdatePatrol()
    {
        if (!route || !route.HasPoints) return;
        if (!waitingAtPatrolPoint)
        {
            if (navigation.HasArrived() ||
                (!navigation.Agent.pathPending &&
                 Vector3.Distance(transform.position, route.CurrentPoint) <= 0.35f))
            {
                waitingAtPatrolPoint = true;
                patrolWait = route.WaitAtPoint;
                navigation.Stop();
            }
            else if (!navigation.Agent.hasPath && !navigation.Agent.pathPending)
                RetryOrSkipPatrolPoint();
            else if (navigation.PathFailed()) RetryOrSkipPatrolPoint();
        }
        else
        {
            patrolWait -= Time.deltaTime;
            if (patrolWait <= 0f)
            {
                route.Advance();
                navigation.SetPatrolMode();
                if (!navigation.TryGo(route.CurrentPoint)) RetryOrSkipPatrolPoint();
                waitingAtPatrolPoint = false;
                failureTimer = 0f;
            }
        }
    }
    private void RetryOrSkipPatrolPoint()
    {
        failureTimer += Time.deltaTime;
        if (failureTimer < recoveryTimeout) return;
        route.Advance();
        navigation.TryGo(route.CurrentPoint);
        failureTimer = 0f;
        Debug.LogWarning("[Day50] 경로가 없어 다음 Waypoint로 이동합니다.", this);
    }

    private void BeginChase()
    {
        Transform target = perception.Target;
        if (target == null) return;
        if (route && route.HasPoints) returnPosition = route.CurrentPoint;
        else returnPosition = transform.position;
        lostTimer = 0f;
        repathTimer = 0f;
        lastSeenPosition = target.position;
        navigation.SetChaseMode(chaseStopDistance);
        ChangeState(Day50EnemyState.Chase);
    }
    private void UpdateChase()
    {
        Transform target = perception.Target;
        if (target == null) { BeginReturn(); return; }
        if (perception.CanKeepSight())
        {
            lostTimer = 0f;
            lastSeenPosition = target.position;
        }
        else
        {
            lostTimer += Time.deltaTime;
            if (lostTimer >= lostTargetDelay) { BeginReturn(); return; }
        }
        if (perception.DistanceToTarget <= chaseStopDistance && perception.CanKeepSight())
        {
            navigation.Stop();
            return;
        }
        repathTimer -= Time.deltaTime;
        if (repathTimer <= 0f)
        {
            navigation.SetChaseMode(chaseStopDistance);
            navigation.TryGo(lastSeenPosition);
            repathTimer = repathInterval;
        }
    }

    private void BeginReturn()
    {
        route.SelectClosest(transform.position);
        returnPosition = route.HasPoints ? route.CurrentPoint : returnPosition;
        navigation.SetPatrolMode();
        ChangeState(Day50EnemyState.Return);
        repathTimer = 0f;
        navigation.TryGo(returnPosition);
    }
    private void UpdateReturn()
    {
        if (navigation.HasArrived() ||
            Vector3.Distance(transform.position, returnPosition) <= 0.45f)
        {
            BeginPatrol();
            return;
        }
        repathTimer -= Time.deltaTime;
        if (repathTimer <= 0f && (navigation.PathFailed() ||
            (!navigation.Agent.hasPath && !navigation.Agent.pathPending)))
        {
            navigation.TryGo(returnPosition);
            repathTimer = 0.5f;
        }
    }
    public void Die()
    {
        if (State == Day50EnemyState.Dead) return;
        navigation.Stop();
        ChangeState(Day50EnemyState.Dead);
    }
    private void OnDisable() { if (navigation != null && navigation.Ready) navigation.Stop(); }
}
