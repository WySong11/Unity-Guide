using UnityEngine;
using UnityEngine.AI;

/// <summary>F1 키로 런타임 디버그 HUD를 켜고 끕니다.</summary>
public sealed class Day50AIDiagnostics : MonoBehaviour
{
    [SerializeField] private Day50EnemyBrain brain;
    [SerializeField] private bool visible = true;
    private void Update()
    {
        if (UnityEngine.InputSystem.Keyboard.current?.f1Key.wasPressedThisFrame == true)
            visible = !visible;
    }
    private void OnGUI()
    {
        if (!visible || brain == null) return;
        Day50EnemyNavigation navigation = brain.Navigation;
        Day50EnemyPerception perception = brain.Perception;
        NavMeshAgent agent = navigation != null ? navigation.Agent : null;
        GUI.Box(new Rect(15, 15, 380, 185), "DAY 50  |  PATROL / CHASE");
        string info = $"State: {brain.State}\n" +
                      $"Target distance: {(perception != null ? perception.DistanceToTarget : -1f):F1}\n" +
                      $"Lost timer: {brain.LostTimer:F1}s\n" +
                      $"NavMesh: {(navigation != null && navigation.Ready)}\n" +
                      $"pathPending: {(agent != null && agent.pathPending)}\n" +
                      $"pathStatus: {(agent != null ? agent.pathStatus.ToString() : "None")}\n" +
                      $"remainingDistance: {(agent != null && agent.isOnNavMesh ? agent.remainingDistance : -1f):F1}";
        GUI.Label(new Rect(30, 42, 350, 155), info);
    }
}
