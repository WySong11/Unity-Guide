public enum Day50EnemyState
{
    Patrol,
    Chase,
    Return,
    Dead
}
