# 50일차 학생 워크시트: Patrol / Chase 구현

## 실습 A — NavMesh 기반 Patrol

1. Ground와 Wall의 Collider를 확인한 뒤 NavMeshSurface를 Bake하세요.
2. WP_00~WP_03의 좌표를 Scene 창에 표시하세요.
3. 적이 모든 Waypoint를 순서대로 순회하는지 확인하세요.
4. Waypoint 도착 후 약 0.75초 기다리게 변경하세요.
5. `autoBraking`을 Patrol에서 켰을 때/껐을 때의 차이를 설명하세요.

## 실습 B — Player 탐지와 Chase

1. `detectionRadius`를 7m, `viewAngle`을 120°로 설정하세요.
2. 적의 앞쪽/뒤쪽에 접근한 플레이어의 탐지 결과를 비교하세요.
3. 적과 플레이어 사이에 벽을 두어 LOS 차단을 확인하세요.
4. 추적 중 Player를 좌우로 이동해 경로가 갱신되는지 확인하세요.
5. 타깃으로부터 1.7m 이내에서는 이동을 정지하도록 하세요.

## 실습 C — 타깃 상실과 Return

1. Player가 벽 뒤로 숨은 순간부터 `lostTimer` 변화를 기록하세요.
2. 1.5초 이상 보이지 않으면 Return하도록 하세요.
3. Return 상태에서 다시 탐지되면 Chase로 전환되게 하세요.
4. Waypoint가 비어 있거나 Bake가 빠진 경우 Console 경고를 확인하세요.

## Codex 활용

- 수정 전 재현 절차, Console 로그, 관련 컴포넌트 설정을 먼저 전달하세요.
- 수정 파일 목록·diff·테스트 결과를 요청하세요.
- 실패한 테스트 항목만 재수정한 후 전체 테스트 16개를 다시 수행하세요.
