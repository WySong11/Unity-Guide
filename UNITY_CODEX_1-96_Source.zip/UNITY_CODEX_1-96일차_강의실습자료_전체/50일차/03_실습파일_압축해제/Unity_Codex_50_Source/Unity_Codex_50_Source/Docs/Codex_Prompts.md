# 50일차 Codex 프롬프트

## 1. 분석

> Unity 6.3 프로젝트의 49일차 Enemy AI 코드와 현재 씬의 NavMesh 구성부터 분석해줘. Patrol, Chase, Return 전이와 이동 컴포넌트의 책임을 정리하고, 기존 스크립트와 중복되는 제어가 있는지 확인해줘. 수정하지 말고 위험 사항과 변경 계획만 제시해줘.

## 2. 구현

> 50일차 Patrol·Chase를 구현해줘. 순서형 Waypoint 순찰 및 대기, 거리·시야각·LOS 탐지, 0.25초 간격 추적 재요청, 타깃을 1.5초 상실하면 가장 가까운 Waypoint로 복귀하도록 해줘. NavMesh가 없어도 NullReferenceException이 발생하지 않게 방어해줘. 기존 프로젝트의 클래스명·Inspector 설정·공개 API 변경은 최소화하고 먼저 diff를 검토하게 해줘.

## 3. 오류 분석

> 다음 Play Mode 증상과 Console 로그를 보고 원인을 가설별로 분류해줘: [증상/로그 붙여 넣기]. isOnNavMesh, pathPending, remainingDistance, isStopped, pathStatus, Waypoint 참조, LOS LayerMask를 확인하고 가장 가능성 높은 원인부터 최소 수정해줘. 실제 Unity 실행 없이 성공을 단정하지 마.

## 4. 검증

> Patrol/Chase/Return의 정상·경계·실패 시나리오를 포함한 테스트표를 작성해줘. 특히 탐지 각도 밖, 벽 뒤, 시야 짧게 상실, 오래 상실, Return 중 재탐지, Bake 누락, 누락된 Inspector 참조를 검증해줘. 확인 결과는 Pass/Fail/Not Run으로 구분하고 미실행 항목을 성공으로 표시하지 마.
