# 50일차 강사용 확인 사항

- Patrol: `HasArrived()`는 `pathPending`이 false이고, 경로가 있고, `remainingDistance`가 유한해야 도착 후보입니다.
- 다음 Waypoint로 이동하기 전에 `isStopped=false`가 되도록 `SetPatrolMode()`를 적용합니다.
- 탐지: Range, View Angle(Enemy의 forward), Line of Sight가 모두 통과해야 Chase에 진입합니다.
- 이미 Chase 중이면 유지 거리(`loseRadius`)를 탐지 거리보다 크게 두어 상태 진동을 줄입니다.
- LOS: Enemy/Target 자체 Collider는 장애물로 오인하지 않도록 필터링합니다.
- Repath: SetDestination은 재탐색 간격으로 호출합니다. 실제 이동 목표가 바뀌면 마지막으로 본 위치를 갱신합니다.
- Return: Target을 일정 시간 잃었을 때 가장 가까운 Waypoint로 복귀하여 다시 Patrol합니다.
- NavMesh 실패: 단순히 코드를 반복 실행하는 것이 아니라 Bake 여부, Enemy 위치, Agent 상태, 도달 가능한 지점을 확인합니다.
- 49일차의 기존 EnemyController를 붙인 상태로 Day50EnemyBrain을 추가하면 안 됩니다.
- 50일차는 Attack 미구현 상태가 정상이며, 가까이 도착한 뒤 멈춥니다.
