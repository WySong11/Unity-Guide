using UnityEngine;

/// <summary>OnGUI teaching-only diagnostic overlay; replace with uGUI/TMP in a production game.</summary>
public sealed class Day40MovementDebugOverlay : MonoBehaviour
{
    [SerializeField] private Day40PlayerMotor3D motor;
    [SerializeField] private Day40MovementInput input;
    [SerializeField] private bool showOverlay = true;

    private void Awake()
    {
        if (motor == null) motor = GetComponent<Day40PlayerMotor3D>();
        if (input == null) input = GetComponent<Day40MovementInput>();
    }

    private void OnGUI()
    {
        if (!showOverlay || motor == null) return;
        Vector2 axis = input != null ? input.Move : Vector2.zero;
        GUI.Box(new Rect(12, 12, 288, 164), "Day 40 - Movement Debug");
        GUI.Label(new Rect(24, 41, 266, 23), $"State: {motor.State}   Grounded: {motor.IsGrounded}");
        GUI.Label(new Rect(24, 65, 266, 23), $"Move Axis: {axis.x:F2}, {axis.y:F2}");
        GUI.Label(new Rect(24, 89, 266, 23), $"Planar Speed: {motor.PlanarSpeed:F2} m/s");
        GUI.Label(new Rect(24, 113, 266, 23), $"Vertical Speed: {motor.VerticalSpeed:F2} m/s");
        GUI.Label(new Rect(24, 137, 266, 23), $"Dash: {motor.DashRemaining:F2}s   Cooldown: {motor.DashCooldownRemaining:F2}s");
    }
}
