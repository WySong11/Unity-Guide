using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// Unity 6.x + Input System. Assign individual actions from Day40Gameplay.inputactions.
/// This sample owns action enable/disable; do not also enable the same actions from PlayerInput.
/// </summary>
public sealed class Day40MovementInput : MonoBehaviour
{
    [Header("Input Actions")]
    [SerializeField] private InputActionReference move;
    [SerializeField] private InputActionReference jump;
    [SerializeField] private InputActionReference sprint;
    [SerializeField] private InputActionReference dash;

    public bool Ready => move != null && move.action != null &&
                         jump != null && jump.action != null &&
                         sprint != null && sprint.action != null &&
                         dash != null && dash.action != null;

    public Vector2 Move => move != null && move.action != null
        ? Vector2.ClampMagnitude(move.action.ReadValue<Vector2>(), 1f)
        : Vector2.zero;

    public bool JumpPressed => jump != null && jump.action != null && jump.action.WasPressedThisFrame();
    public bool SprintHeld => sprint != null && sprint.action != null && sprint.action.IsPressed();
    public bool DashPressed => dash != null && dash.action != null && dash.action.WasPressedThisFrame();

    private void OnEnable()
    {
        SetEnabled(true);
        if (!Ready) Debug.LogWarning("[Day40] Move / Jump / Sprint / Dash references are incomplete.", this);
    }

    private void OnDisable() => SetEnabled(false);

    private void SetEnabled(bool enabled)
    {
        SetAction(move, enabled);
        SetAction(jump, enabled);
        SetAction(sprint, enabled);
        SetAction(dash, enabled);
    }

    private static void SetAction(InputActionReference reference, bool enabled)
    {
        if (reference == null || reference.action == null) return;
        if (enabled && !reference.action.enabled) reference.action.Enable();
        else if (!enabled && reference.action.enabled) reference.action.Disable();
    }
}
