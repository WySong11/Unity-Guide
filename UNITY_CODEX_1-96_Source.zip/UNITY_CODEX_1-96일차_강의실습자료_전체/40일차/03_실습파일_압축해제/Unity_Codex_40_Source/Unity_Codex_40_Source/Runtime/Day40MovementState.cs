public enum Day40MovementState
{
    Idle = 0,
    Walk = 1,
    Sprint = 2,
    Jump = 3,
    Fall = 4,
    Dash = 5,
    Paused = 6
}
