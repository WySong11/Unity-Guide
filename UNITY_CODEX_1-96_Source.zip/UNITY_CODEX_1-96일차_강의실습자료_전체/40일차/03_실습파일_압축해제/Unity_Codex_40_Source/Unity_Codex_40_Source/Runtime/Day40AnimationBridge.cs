using UnityEngine;

/// <summary>Optional Animator bridge. Create Speed(float), Grounded(bool), Dash(bool), MoveState(int).</summary>
public sealed class Day40AnimationBridge : MonoBehaviour
{
    [SerializeField] private Day40PlayerMotor3D motor;
    [SerializeField] private Animator animator;

    private static readonly int SpeedHash = Animator.StringToHash("Speed");
    private static readonly int GroundedHash = Animator.StringToHash("Grounded");
    private static readonly int DashHash = Animator.StringToHash("Dash");
    private static readonly int StateHash = Animator.StringToHash("MoveState");

    private void Awake()
    {
        if (motor == null) motor = GetComponent<Day40PlayerMotor3D>();
        if (animator == null) animator = GetComponentInChildren<Animator>();
    }

    private void Update()
    {
        if (motor == null || animator == null) return;
        animator.SetFloat(SpeedHash, motor.PlanarSpeed);
        animator.SetBool(GroundedHash, motor.IsGrounded);
        animator.SetBool(DashHash, motor.IsDashing);
        animator.SetInteger(StateHash, (int)motor.State);
    }
}
