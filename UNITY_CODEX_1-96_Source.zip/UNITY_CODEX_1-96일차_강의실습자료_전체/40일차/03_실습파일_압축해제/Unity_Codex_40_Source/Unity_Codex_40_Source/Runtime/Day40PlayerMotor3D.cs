using System;
using UnityEngine;

/// <summary>
/// CharacterController-based movement. This is the sole mover for this Player GameObject.
/// Replace/disable Day37 and Day39 motors rather than stacking multiple movers.
/// </summary>
[RequireComponent(typeof(CharacterController))]
public sealed class Day40PlayerMotor3D : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Day40MovementInput movementInput;
    [SerializeField] private Transform cameraTransform;

    [Header("Planar Movement (m/s; m/s²)")]
    [Min(0f)] [SerializeField] private float walkSpeed = 4f;
    [Min(0f)] [SerializeField] private float sprintSpeed = 7f;
    [Min(0.1f)] [SerializeField] private float acceleration = 12f;
    [Min(0.1f)] [SerializeField] private float deceleration = 16f;
    [Min(1f)] [SerializeField] private float turnSpeedDegrees = 720f;

    [Header("Jump and Gravity")]
    [Min(0.01f)] [SerializeField] private float jumpHeight = 1.5f;
    [SerializeField] private float gravity = -20f;
    [Min(0f)] [SerializeField] private float jumpBufferTime = 0.12f;
    [Min(0f)] [SerializeField] private float coyoteTime = 0.10f;
    [SerializeField] private float groundStickVelocity = -2f;

    [Header("Dash")]
    [Min(0.1f)] [SerializeField] private float dashSpeed = 10f;
    [Min(0.01f)] [SerializeField] private float dashDuration = 0.18f;
    [Min(0f)] [SerializeField] private float dashCooldown = 1f;
    [SerializeField] private bool allowAirDash = false;

    private CharacterController controller;
    private Vector3 planarVelocity;
    private Vector3 dashDirection;
    private float verticalSpeed;
    private float jumpBufferLeft;
    private float coyoteLeft;
    private float dashTimeLeft;
    private float dashCooldownLeft;
    private bool grounded;
    private Day40MovementState state = Day40MovementState.Idle;

    public Vector3 PlanarVelocity => planarVelocity;
    public float PlanarSpeed => planarVelocity.magnitude;
    public float VerticalSpeed => verticalSpeed;
    public bool IsGrounded => grounded;
    public bool IsDashing => dashTimeLeft > 0f;
    public float DashCooldownRemaining => dashCooldownLeft;
    public float DashRemaining => dashTimeLeft;
    public Day40MovementState State => state;
    public event Action<Day40MovementState> StateChanged;

    private void Awake()
    {
        controller = GetComponent<CharacterController>();
        if (movementInput == null) movementInput = GetComponent<Day40MovementInput>();
        if (cameraTransform == null && Camera.main != null) cameraTransform = Camera.main.transform;
        grounded = controller.isGrounded;
    }

    private void OnEnable()
    {
        planarVelocity = Vector3.zero;
        verticalSpeed = 0f;
        jumpBufferLeft = coyoteLeft = dashTimeLeft = dashCooldownLeft = 0f;
        state = Day40MovementState.Idle;
    }

    private void Update()
    {
        if (controller == null || !controller.enabled) return;

        // Time.timeScale pauses gameplay delta time, but UI / Update callbacks may still run.
        if (Time.timeScale <= 0.0001f)
        {
            SetState(Day40MovementState.Paused);
            return;
        }

        float dt = Time.deltaTime;
        if (dt <= 0f) return;

        bool wasGrounded = controller.isGrounded; // Result of the PREVIOUS Move.
        grounded = wasGrounded;
        dashCooldownLeft = Mathf.Max(0f, dashCooldownLeft - dt);
        jumpBufferLeft = Mathf.Max(0f, jumpBufferLeft - dt);
        coyoteLeft = wasGrounded ? coyoteTime : Mathf.Max(0f, coyoteLeft - dt);

        Vector2 raw = movementInput != null ? movementInput.Move : Vector2.zero;
        bool jumpPressed = movementInput != null && movementInput.JumpPressed;
        bool dashPressed = movementInput != null && movementInput.DashPressed;
        bool sprintHeld = movementInput != null && movementInput.SprintHeld;
        if (jumpPressed) jumpBufferLeft = jumpBufferTime;
        Vector3 wantedDirection = GetCameraRelativeMove(raw);

        // Store dash direction once; subsequent input cannot steer the dash.
        if (dashPressed && dashTimeLeft <= 0f && dashCooldownLeft <= 0f &&
            (wasGrounded || allowAirDash))
        {
            dashDirection = wantedDirection.sqrMagnitude > 0.001f
                ? wantedDirection.normalized : transform.forward;
            dashDirection.y = 0f;
            dashDirection.Normalize();
            dashTimeLeft = dashDuration;
            dashCooldownLeft = dashCooldown;
        }

        bool dashActiveThisFrame = dashTimeLeft > 0f;
        if (dashActiveThisFrame)
        {
            planarVelocity = dashDirection * dashSpeed;
        }
        else
        {
            float speed = sprintHeld ? sprintSpeed : walkSpeed;
            Vector3 desired = wantedDirection * speed;
            float rate = wantedDirection.sqrMagnitude > 0.0001f ? acceleration : deceleration;
            planarVelocity = Vector3.MoveTowards(planarVelocity, desired, rate * dt);
        }

        if ((jumpPressed || jumpBufferLeft > 0f) &&
            (wasGrounded || coyoteLeft > 0f) && !dashActiveThisFrame)
        {
            verticalSpeed = Mathf.Sqrt(jumpHeight * -2f * gravity);
            jumpBufferLeft = 0f;
            coyoteLeft = 0f;
            wasGrounded = false; // Do not ground-stick during the launch frame.
        }
        else if (wasGrounded && verticalSpeed < 0f)
        {
            verticalSpeed = groundStickVelocity;
        }
        verticalSpeed += gravity * dt;

        if (!dashActiveThisFrame && wantedDirection.sqrMagnitude > 0.001f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(wantedDirection);
            transform.rotation = Quaternion.RotateTowards(
                transform.rotation, targetRotation, turnSpeedDegrees * dt);
        }

        CollisionFlags flags = controller.Move((planarVelocity + Vector3.up * verticalSpeed) * dt);
        grounded = (flags & CollisionFlags.Below) != 0;
        if ((flags & CollisionFlags.Above) != 0 && verticalSpeed > 0f)
            verticalSpeed = 0f;
        if (grounded && verticalSpeed < 0f) verticalSpeed = groundStickVelocity;

        if (dashActiveThisFrame)
        {
            dashTimeLeft = Mathf.Max(0f, dashTimeLeft - dt);
            if (dashTimeLeft <= 0f)
            {
                // Avoid lingering at dash speed after the dash ends.
                float postDashMax = sprintHeld ? sprintSpeed : walkSpeed;
                planarVelocity = Vector3.ClampMagnitude(planarVelocity, postDashMax);
            }
        }
        SelectState(sprintHeld);
    }

    private Vector3 GetCameraRelativeMove(Vector2 axis)
    {
        Vector3 forward = cameraTransform != null ? cameraTransform.forward : Vector3.forward;
        Vector3 right = cameraTransform != null ? cameraTransform.right : Vector3.right;
        forward.y = 0f;
        right.y = 0f;
        forward = forward.sqrMagnitude > 0.0001f ? forward.normalized : Vector3.forward;
        right = right.sqrMagnitude > 0.0001f ? right.normalized : Vector3.right;
        return Vector3.ClampMagnitude(forward * axis.y + right * axis.x, 1f);
    }

    private void SelectState(bool sprintHeld)
    {
        if (IsDashing) SetState(Day40MovementState.Dash);
        else if (!grounded) SetState(verticalSpeed > 0f ? Day40MovementState.Jump : Day40MovementState.Fall);
        else if (PlanarSpeed < 0.12f) SetState(Day40MovementState.Idle);
        else SetState(sprintHeld ? Day40MovementState.Sprint : Day40MovementState.Walk);
    }

    private void SetState(Day40MovementState next)
    {
        if (state == next) return;
        state = next;
        StateChanged?.Invoke(next);
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawLine(transform.position + Vector3.up, transform.position + Vector3.up + planarVelocity * 0.4f);
        Gizmos.color = Color.yellow;
        Gizmos.DrawLine(transform.position + Vector3.up * 1.4f,
            transform.position + Vector3.up * 1.4f + dashDirection * 1.5f);
    }

    private void OnValidate()
    {
        gravity = Mathf.Min(-0.1f, gravity);
        groundStickVelocity = Mathf.Min(-0.01f, groundStickVelocity);
        sprintSpeed = Mathf.Max(sprintSpeed, walkSpeed);
    }
}
