using UnityEngine;

/// <summary>Standalone follow-camera fallback. Use the Day38 orbit camera instead when integrating older lessons.</summary>
public sealed class Day40FollowCamera3D : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private Vector3 offset = new Vector3(0f, 3.4f, -6.5f);
    [Min(0.01f)] [SerializeField] private float followSmoothTime = 0.12f;
    [SerializeField] private Vector3 lookOffset = new Vector3(0f, 1.2f, 0f);
    private Vector3 followVelocity;

    public void SetTarget(Transform value) => target = value;

    private void LateUpdate()
    {
        if (target == null) return;
        Vector3 expected = target.position + offset;
        transform.position = Vector3.SmoothDamp(transform.position, expected,
            ref followVelocity, followSmoothTime);
        transform.LookAt(target.position + lookOffset);
    }
}
