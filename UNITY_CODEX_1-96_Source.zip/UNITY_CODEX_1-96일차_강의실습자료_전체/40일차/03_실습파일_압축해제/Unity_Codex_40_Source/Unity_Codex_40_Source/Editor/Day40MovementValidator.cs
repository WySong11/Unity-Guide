#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

/// <summary>Static setup validator. A passing check does not replace Play Mode testing.</summary>
public static class Day40MovementValidator
{
    [MenuItem("Tools/Unity Codex/Day40/Validate Movement Scene")]
    public static void Validate()
    {
        var motors = Object.FindObjectsByType<Day40PlayerMotor3D>(FindObjectsSortMode.None);
        if (motors.Length == 0)
        {
            Debug.LogError("[Day40] No Day40PlayerMotor3D was found.");
            return;
        }
        if (motors.Length > 1)
            Debug.LogWarning("[Day40] More than one Day40PlayerMotor3D exists. Review intentional ownership.");

        foreach (var motor in motors)
        {
            var player = motor.gameObject;
            if (player.GetComponent<CharacterController>() == null)
                Debug.LogError("[Day40] CharacterController missing.", player);
            var input = player.GetComponent<Day40MovementInput>();
            if (input == null || !input.Ready)
                Debug.LogError("[Day40] InputActionReferences not connected. Assign Move/Jump/Sprint/Dash.", player);
            if (player.GetComponent<Rigidbody>() != null)
                Debug.LogWarning("[Day40] Rigidbody on a CharacterController player requires special design.", player);
            var oldMovers = player.GetComponents<MonoBehaviour>();
            foreach (var behaviour in oldMovers)
            {
                if (behaviour != null && behaviour.enabled && behaviour != motor &&
                    (behaviour.GetType().Name.Contains("Day37CharacterMotor") ||
                     behaviour.GetType().Name.Contains("Day39PlayerMotor")))
                    Debug.LogError("[Day40] Older player motor is enabled alongside Day40PlayerMotor3D.", player);
            }
        }

        if (Camera.main == null)
            Debug.LogWarning("[Day40] No active MainCamera tagged camera found.");
        Debug.Log($"[Day40] Completed static scene validation for {motors.Length} motor(s). " +
                  "Run the manual regression matrix in Play Mode.");
    }
}
#endif
