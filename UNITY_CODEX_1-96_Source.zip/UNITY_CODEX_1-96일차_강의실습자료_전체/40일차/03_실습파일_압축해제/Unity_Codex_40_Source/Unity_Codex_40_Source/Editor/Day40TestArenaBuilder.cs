#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Creates a NEW test scene; the active scene is not overwritten.</summary>
public static class Day40TestArenaBuilder
{
    private const string Root = "Assets/Day40";

    [MenuItem("Tools/Unity Codex/Day40/Create Movement Test Arena")]
    public static void Create()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        EnsureFolder("Assets", "Day40");
        EnsureFolder(Root, "Scenes");
        EnsureFolder(Root, "Materials");
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        MakeCube("Ground", new Vector3(0f, -0.5f, 0f), new Vector3(30f, 1f, 30f), new Color(0.22f, 0.43f, 0.40f));
        MakeCube("Wall_A", new Vector3(0f, 1.0f, 7f), new Vector3(7f, 2f, .8f), new Color(0.61f, 0.65f, 0.72f));
        MakeCube("Wall_B", new Vector3(5f, 1.0f, 3f), new Vector3(.8f, 2f, 8f), new Color(0.61f, 0.65f, 0.72f));
        MakeCube("Step_01", new Vector3(-4f, .15f, 4f), new Vector3(2f, .30f, 2f), new Color(0.80f, 0.67f, 0.37f));
        MakeCube("Step_02", new Vector3(-4f, .32f, 6.1f), new Vector3(2f, .64f, 2f), new Color(0.80f, 0.67f, 0.37f));
        GameObject slope = MakeCube("Slope_20deg", new Vector3(-7.2f, .35f, 2.5f),
            new Vector3(3f, .4f, 4f), new Color(0.4f, 0.55f, 0.70f));
        slope.transform.rotation = Quaternion.Euler(20f, 0f, 0f);

        var player = new GameObject("Day40_Player");
        player.transform.position = new Vector3(0f, .06f, 0f);
        var cc = player.AddComponent<CharacterController>();
        cc.height = 2f;
        cc.radius = .38f;
        cc.center = new Vector3(0f, 1f, 0f);
        cc.slopeLimit = 45f;
        cc.stepOffset = .3f;
        player.AddComponent<Day40MovementInput>();
        player.AddComponent<Day40PlayerMotor3D>();
        player.AddComponent<Day40MovementDebugOverlay>();
        // InputActionReference fields are intentionally not assigned: see README.

        var visual = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        visual.name = "Visual_Only";
        visual.transform.SetParent(player.transform, false);
        visual.transform.localPosition = new Vector3(0f, 1f, 0f);
        Object.DestroyImmediate(visual.GetComponent<Collider>()); // CharacterController owns collision.
        ApplyMaterial(visual, new Color(0.22f, .55f, .92f));

        var cameraGO = new GameObject("Main Camera");
        cameraGO.tag = "MainCamera";
        var camera = cameraGO.AddComponent<Camera>();
        cameraGO.AddComponent<AudioListener>();
        cameraGO.transform.position = new Vector3(0f, 3.4f, -6.5f);
        var follow = cameraGO.AddComponent<Day40FollowCamera3D>();
        follow.SetTarget(player.transform);
        cameraGO.transform.LookAt(player.transform.position + Vector3.up * 1.2f);

        var sun = new GameObject("Directional Light");
        sun.transform.rotation = Quaternion.Euler(48f, -32f, 0f);
        var sunLight = sun.AddComponent<Light>();
        sunLight.type = LightType.Directional;
        sunLight.intensity = 1.2f;

        string scenePath = AssetDatabase.GenerateUniqueAssetPath(Root + "/Scenes/Day40_MovementTest.unity");
        EditorSceneManager.SaveScene(scene, scenePath);
        AssetDatabase.SaveAssets();
        Debug.Log($"[Day40] Created {scenePath}. Assign 4 InputActionReferences before Play Mode. " +
                  "Disable old Day37/Day39 motors before integrating in an existing scene.");
    }

    private static GameObject MakeCube(string label, Vector3 position, Vector3 scale, Color tint)
    {
        var obj = GameObject.CreatePrimitive(PrimitiveType.Cube);
        obj.name = label;
        obj.transform.position = position;
        obj.transform.localScale = scale;
        ApplyMaterial(obj, tint);
        return obj;
    }

    private static void ApplyMaterial(GameObject gameObject, Color tint)
    {
        var shader = Shader.Find("Universal Render Pipeline/Lit");
        if (shader == null) shader = Shader.Find("Standard");
        if (shader == null) return;
        var mat = new Material(shader) { color = tint };
        string matPath = AssetDatabase.GenerateUniqueAssetPath(
            Root + "/Materials/" + gameObject.name + ".mat");
        AssetDatabase.CreateAsset(mat, matPath);
        gameObject.GetComponent<Renderer>().sharedMaterial = mat;
    }

    private static void EnsureFolder(string parent, string name)
    {
        if (!AssetDatabase.IsValidFolder(parent + "/" + name))
            AssetDatabase.CreateFolder(parent, name);
    }
}
#endif
