# Unity Codex 40일차 — 이동 시스템 개선 및 검증

대상: **Unity 6.3 (6000.3), URP, Input System**. 이 자료는 실제 Unity 프로젝트 내 컴파일/실행 검증 전의 **교육용 소스**입니다.

## 설치 순서

1. Unity 프로젝트를 복사하거나 Git 브랜치를 먼저 분리합니다. (39일차 원본 유지)
2. Input System 패키지를 설치하고 Project Settings > Player > Active Input Handling에서 Input System을 활성화합니다.
3. `Runtime` C# 6개와 `Day40Gameplay.inputactions`를 `Assets/Day40/` 하위로 복사합니다.
4. `Editor` C# 2개를 반드시 `Assets/Day40/Editor/` 폴더에 복사합니다. **Editor 폴더 밖에서는 빌드가 실패할 수 있습니다.**
5. 새 실습 씬이 필요하면 **Tools > Unity Codex > Day40 > Create Movement Test Arena** 메뉴를 클릭합니다. (현재 수정된 씬은 저장 여부를 먼저 묻고, 새 씬을 별도 이름으로 저장합니다.)
6. Player의 `Day40MovementInput`에 `Day40Gameplay`의 개별 **Move, Jump, Sprint, Dash** 액션 참조를 Inspector에서 연결합니다. 각 액션 옆의 object picker에서 액션을 선택합니다.
7. Player의 `Day40PlayerMotor3D`에서 `movementInput`과 `cameraTransform`을 확인합니다. 카메라가 비어 있으면 시작 시 `Camera.main`을 사용합니다.
8. **Day37/Day39의 다른 이동 컨트롤러는 끕니다.** 같은 CharacterController를 두 스크립트가 동시에 움직이면 결과를 예측할 수 없습니다.
9. 카메라는 예제 `Day40FollowCamera3D` 또는 기존 38일차 Orbit 카메라 중 하나만 사용합니다. 하나의 카메라를 두 시스템이 움직이지 않게 합니다.
10. **Tools > Unity Codex > Day40 > Validate Movement Scene**을 실행하고 Console을 검토합니다. `Valid` 출력은 **컴파일·PlayMode 통과를 의미하지 않습니다.**
11. Play Mode에서 `Docs/테스트_체크리스트.csv`의 테스트를 실제 수행합니다.

## 조작

| 입력 | 동작 |
|---|---|
| W/A/S/D | 카메라 기준 이동 |
| Shift | Sprint |
| Space | Jump |
| LeftCtrl | Dash |

* UI 일시정지 버튼은 28일차 `Time.timeScale` 시스템이 있을 때 사용합니다. 본 패키지에는 별도의 Pause UI가 없습니다.
* 39일차 `.inputactions` 복제본을 사용하되 이름만 `Day40Gameplay`로 바꾸었습니다. Action 내부 ID는 동일해도 별도의 에셋이면 정상입니다. 같은 자원 여러 개를 동시에 enable/disable하지 않게 주의합니다.
* Animator는 선택이며 `Speed`(float), `Grounded`(bool), `Dash`(bool), `MoveState`(int) 파라미터가 있는 경우에만 `Day40AnimationBridge`를 활성화합니다.
* `Day40MovementDebugOverlay`의 `OnGUI`는 교육용 진단 패널입니다. 정식 UI는 uGUI/TMP로 별도 구현합니다.
* GameObject의 재시작 이전 반드시 28일차 flow에서 `Time.timeScale=1`을 복원합니다.
* 테스트 아레나에서 눈으로 보이는 캡슐은 **Collider가 없는 시각화 자식**이며 충돌은 CharacterController만 처리합니다.

## 학습 목표

- 입력/상태/이동/애니메이션의 역할 구분
- `Vector3.ClampMagnitude`를 사용한 대각선 속력 제한
- 가속·감속, 점프·중력, 대시 타이머·쿨다운 처리
- `CollisionFlags`, `isGrounded`로 낙하·벽·천장 문제 분석
- Console/HUD/Profiler/Git diff/Codex로 오류 재현과 회귀 검증

## 참고

- https://docs.unity3d.com/ScriptReference/CharacterController.Move.html
- https://docs.unity3d.com/ScriptReference/CharacterController-isGrounded.html
- https://docs.unity3d.com/Manual/ProfilerPhysics.html
