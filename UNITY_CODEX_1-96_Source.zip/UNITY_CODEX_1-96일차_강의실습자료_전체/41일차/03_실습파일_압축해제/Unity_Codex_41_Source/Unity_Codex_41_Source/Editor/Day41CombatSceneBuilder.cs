#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class Day41CombatSceneBuilder
{
    private const string Folder = "Assets/Day41CombatLab";
    [MenuItem("Tools/Unity Codex/Day41/Build Combat Lab")]
    public static void Build()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        if (!AssetDatabase.IsValidFolder(Folder)) AssetDatabase.CreateFolder("Assets", "Day41CombatLab");
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);

        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.name = "Ground";
        ground.transform.localScale = new Vector3(22, 0.5f, 24);
        ground.transform.position = new Vector3(0, -0.25f, 5);
        Material groundMat = MakeMaterial(new Color(0.20f, 0.27f, 0.32f));
        ground.GetComponent<Renderer>().sharedMaterial = groundMat;
        for (int i = 0; i < 5; i++)
        {
            GameObject target = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            target.name = "Target_" + (i + 1);
            target.transform.position = new Vector3((i - 2) * 2.4f, 1f, i == 2 ? 2.0f : 6f);
            target.GetComponent<Renderer>().sharedMaterial = MakeMaterial(Color.Lerp(Color.yellow, Color.red, i / 5f));
            target.AddComponent<Day41TargetHealth3D>();
        }

        GameObject player = new GameObject("Player_Combat_Root");
        player.transform.position = Vector3.zero;
        player.layer = 2; // Ignore Raycast: 자기 몸을 카메라 조준 Ray가 먼저 맞히지 않도록
        CharacterController cc = player.AddComponent<CharacterController>();
        cc.height = 2;
        cc.center = Vector3.up;
        GameObject attackAnchor = new GameObject("MeleeOrigin");
        attackAnchor.transform.SetParent(player.transform);
        attackAnchor.transform.localPosition = new Vector3(0, 1.1f, 0.4f);
        GameObject muzzle = new GameObject("Muzzle");
        muzzle.transform.SetParent(player.transform);
        muzzle.transform.localPosition = new Vector3(0.30f, 1.35f, 0.7f);
        var melee = player.AddComponent<Day41MeleeAttack3D>();
        var hitscan = player.AddComponent<Day41HitscanGun3D>();
        var pool = player.AddComponent<Day41ProjectilePool3D>();
        var input = player.AddComponent<Day41CombatInput3D>();
        player.AddComponent<Day41CombatDebugHUD>();

        // 새 프리팹 파일명 자동 생성: 기존 자료는 덮어쓰지 않음.
        GameObject sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        sphere.name = "Day41Projectile";
        sphere.transform.localScale = Vector3.one * 0.3f;
        Rigidbody rb = sphere.AddComponent<Rigidbody>();
        rb.useGravity = false;
        sphere.AddComponent<Day41Projectile3D>();
        string prefabPath = AssetDatabase.GenerateUniqueAssetPath(Folder + "/Projectile.prefab");
        GameObject prefab = PrefabUtility.SaveAsPrefabAsset(sphere, prefabPath);
        Object.DestroyImmediate(sphere);

        Camera cam = Camera.main;
        if (cam == null)
        {
            GameObject camGo = new GameObject("Main Camera");
            cam = camGo.AddComponent<Camera>();
            camGo.tag = "MainCamera";
        }
        cam.transform.position = new Vector3(0f, 2.1f, -4.5f);
        cam.transform.LookAt(new Vector3(0f, 1f, 5f));
        Transform camMuzzle = muzzle.transform;
        Assign(melee, "attackOrigin", attackAnchor.transform);
        Assign(hitscan, "aimCamera", cam);
        Assign(hitscan, "muzzle", camMuzzle);
        // DefaultRaycastLayers는 Ignore Raycast 레이어를 제외합니다.
        SerializedObject hitConfig = new SerializedObject(hitscan);
        hitConfig.FindProperty("hitMask").intValue = Physics.DefaultRaycastLayers;
        hitConfig.ApplyModifiedPropertiesWithoutUndo();
        Assign(pool, "projectilePrefab", prefab.GetComponent<Day41Projectile3D>());
        Assign(pool, "muzzle", camMuzzle);
        Assign(pool, "ownerCollider", cc);
        Assign(input, "melee", melee);
        Assign(input, "hitscan", hitscan);
        Assign(input, "projectile", pool);
        // 데모 카메라가 고정되어 있으므로 J/K/L을 눌러 원거리 공격을 확인할 수 있습니다.
        // 기존 Day40 PlayerMotor와 Day38 카메라를 붙일 때 중복 Motor는 제거하세요.
        string scenePath = AssetDatabase.GenerateUniqueAssetPath(Folder + "/Day41_CombatLab.unity");
        EditorSceneManager.SaveScene(scene, scenePath);
        AssetDatabase.SaveAssets();
        Selection.activeGameObject = player;
        Debug.Log($"Day41 scene created: {scenePath}. Inspector 연결과 LayerMask를 확인하세요.");
    }

    private static Material MakeMaterial(Color color)
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (shader == null) shader = Shader.Find("Standard");
        Material material = new Material(shader);
        material.color = color;
        string path = AssetDatabase.GenerateUniqueAssetPath(Folder + "/Day41Material.mat");
        AssetDatabase.CreateAsset(material, path);
        return material;
    }
    private static void Assign(Object component, string field, Object value)
    {
        SerializedObject serialized = new SerializedObject(component);
        serialized.FindProperty(field).objectReferenceValue = value;
        serialized.ApplyModifiedPropertiesWithoutUndo();
    }
}
#endif
