#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

public static class Day41CombatValidator
{
    [MenuItem("Tools/Unity Codex/Day41/Validate Combat Scene")]
    public static void Validate()
    {
        var melee = Object.FindFirstObjectByType<Day41MeleeAttack3D>();
        var hitscan = Object.FindFirstObjectByType<Day41HitscanGun3D>();
        var pool = Object.FindFirstObjectByType<Day41ProjectilePool3D>();
        var input = Object.FindFirstObjectByType<Day41CombatInput3D>();
        var targets = Object.FindObjectsByType<Day41TargetHealth3D>(FindObjectsSortMode.None);
        Debug.Log($"[Day41 validate] Melee={(melee != null)}, Hitscan={(hitscan != null)}, " +
                  $"ProjectilePool={(pool != null)}, Input={(input != null)}, Targets={targets.Length}");
        if (melee == null || hitscan == null || pool == null || input == null || targets.Length == 0)
            Debug.LogWarning("Day41: 일부 필수 컴포넌트가 없습니다. README의 Inspector 구성표를 확인하세요.");
        else Debug.Log("Day41: 구성 요소 존재 확인 완료. 실제 충돌/피격 테스트는 Play Mode에서 수행하세요.");
    }
}
#endif
