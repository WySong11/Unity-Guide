# 41일차 | 근접·원거리 공격 실습 안내

**기준:** Unity 6.3 (6000.3), Universal 3D(URP), Input System 패키지 활성화.

## 빠른 시작 (새 독립 실습 씬)
1. `Runtime`을 `Assets/Day41/Runtime`, `Editor`를 `Assets/Day41/Editor`에 복사합니다. C# 파일명과 공개 클래스명은 일치합니다.
2. `Day41Combat.inputactions`를 프로젝트에 복사한 다음 에셋을 더블클릭해 바인딩을 확인합니다.
3. 메뉴 `Tools > Unity Codex > Day41 > Build Combat Lab` 실행. 기존 씬은 저장 여부를 묻고 새 씬 파일을 **중복 없는 이름**으로 생성합니다.
4. `Player_Combat_Root`의 Input 컴포넌트에 Melee / Hitscan / Projectile 참조를 연결합니다. (연결하지 않아도 키보드 J/K/L 폴백 사용 가능)
5. Play Mode에서 **J 근접, K Raycast, L 물리 발사체**를 실행해 Console HP 감소를 확인합니다.
6. `Tools > Unity Codex > Day41 > Validate Combat Scene`는 **구성 요소 존재**만 검사합니다. 실제 테스트를 대신하지 않습니다.

## 실습장 주의
- 생성된 Camera는 고정된 예제이며, 38일차 Orbit Camera를 연동하면 기존 Main Camera 중복 사용을 피합니다.
- 독립 실습장에 이동 Motor를 추가하지 않았습니다. 40일차 `Day40PlayerMotor3D`를 가져올 때는 **이동 담당 Motor 1개만** 활성화합니다.
- 초보자용 Raycast와 발사체는 `hitMask` / 물리 충돌 행렬에서 자기 플레이어 Layer를 제외해야 합니다. Player Root가 CharacterController를 갖고 있다면 발사체와의 자기 충돌은 `ownerCollider`로 차단합니다.
- `Day41Projectile3D`를 사용하는 Prefab은 Rigidbody + Collider가 필요합니다. Rigidbody는 Unity 6의 `linearVelocity`를 사용합니다.
- 공격 범위에 적이 많으면 `OverlapSphereNonAlloc` 결과 배열(32)이 가득 찰 수 있습니다. 실제 게임은 크기를 조정하세요.
- 공격 충돌 판정은 레이어/Collider/방향/거리 조건을 모두 만족해야 합니다. Target은 Enemy 레이어로 배치하고 targetMask에 Enemy를 포함하세요.

## 40일차 기존 씬 연결
1. 기존 Player의 Combat 전용 자식에 `MeleeOrigin`(전방)과 `Muzzle`을 생성합니다.
2. 공격 컴포넌트를 기존 Player에 추가해 `CombatInput`만 입력을 처리하도록 연결합니다.
3. 기존 Input Actions와 Day41 Combat Actions의 컨트롤 충돌을 확인합니다.
4. 플레이어 근처, 벽 뒤, 장애물 앞에 `Day41TargetHealth3D`를 배치합니다.
5. Animator와 연결 시 근접 판정 시점(애니메이션 이벤트)은 다음 심화 단계에서 다루며, 이 예제는 입력 순간 판정합니다.

## 추천 Inspector 시작 값
- Melee: Radius=1.8, Angle=100°, Damage=25, Cooldown=0.65
- Hitscan: Damage=15, Range=60, FireInterval=0.15
- Projectile: Speed=18, FireInterval=0.30, PrewarmCount=12, Lifetime=3
- Target: MaxHealth=100, ResetOnDefeat=true

## 필수 최종 검증
- [ ] 한 공격에 같은 대상 중복 피해 없음
- [ ] 범위 밖·시야각 밖 대상 미피격
- [ ] Raycast는 벽에서 중단
- [ ] Muzzle가 벽 뒤일 때 벽 관통 없음
- [ ] 발사체는 수명 종료·충돌 시 풀 반환
- [ ] 빠른 반복 사격 뒤 Console 오류 없음
- [ ] Time.timeScale=0에서 공격 입력 차단, 재개 정상
- [ ] 37~40일차 이동·카메라·대시 회귀 테스트 통과

## 한계
Editor 툴은 실습용 씬 구성에 도움을 주는 예제입니다. 프로젝트 패키지 버전과 씬 상황에 따라 Inspector 조정이 필요하며 자동 Unity 컴파일·Play Mode 검증 결과는 아닙니다.
