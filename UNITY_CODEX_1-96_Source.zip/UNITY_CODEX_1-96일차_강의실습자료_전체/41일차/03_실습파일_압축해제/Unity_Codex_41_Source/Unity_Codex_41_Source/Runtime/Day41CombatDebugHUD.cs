using UnityEngine;

public sealed class Day41CombatDebugHUD : MonoBehaviour
{
    private GUIStyle style;
    private void OnGUI()
    {
        if (style == null) style = new GUIStyle(GUI.skin.box) { fontSize = 16, alignment = TextAnchor.UpperLeft };
        GUI.Box(new Rect(12, 12, 395, 103),
            "DAY 41 COMBAT LAB\nJ: Melee   K: Hitscan   L: Projectile\nCheck target HP in Console (pause disables attacks)", style);
    }
}
