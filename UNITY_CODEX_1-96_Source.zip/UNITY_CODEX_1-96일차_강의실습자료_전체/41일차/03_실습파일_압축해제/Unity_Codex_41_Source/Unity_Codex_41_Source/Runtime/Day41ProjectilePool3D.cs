using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

/// <summary>발사체를 미리 생성하고 재사용. Pool은 씬 생명주기 안에서 관리.</summary>
public sealed class Day41ProjectilePool3D : MonoBehaviour
{
    [SerializeField] private Day41Projectile3D projectilePrefab;
    [SerializeField] private Transform muzzle;
    [SerializeField] private GameObject attacker;
    [SerializeField] private Collider ownerCollider;
    [SerializeField, Min(1)] private int prewarmCount = 12;
    [SerializeField, Min(1f)] private float projectileSpeed = 18f;
    [SerializeField, Min(0f)] private float fireInterval = 0.3f;
    private ObjectPool<Day41Projectile3D> pool;
    private float nextFireTime;

    private void Awake()
    {
        if (projectilePrefab == null) return;
        pool = new ObjectPool<Day41Projectile3D>(
            () => {
                Day41Projectile3D item = Instantiate(projectilePrefab, transform);
                item.SetPool(this);
                item.gameObject.SetActive(false);
                return item;
            },
            item => item.gameObject.SetActive(true),
            item => item.gameObject.SetActive(false),
            item => { if (item != null) Destroy(item.gameObject); },
            collectionCheck: true, defaultCapacity: Mathf.Max(1, prewarmCount), maxSize: 128);
    }
    private void Start()
    {
        if (pool == null) return;
        var warm = new List<Day41Projectile3D>(prewarmCount);
        for (int i = 0; i < prewarmCount; i++) warm.Add(pool.Get());
        foreach (Day41Projectile3D item in warm) pool.Release(item);
    }
    public bool TryFire()
    {
        if (Time.timeScale <= 0f || Time.time < nextFireTime || pool == null || muzzle == null)
            return false;
        nextFireTime = Time.time + fireInterval;
        Day41Projectile3D projectile = pool.Get();
        projectile.Launch(muzzle.position, muzzle.forward, projectileSpeed,
            attacker != null ? attacker : gameObject, ownerCollider);
        return true;
    }
    public void Return(Day41Projectile3D projectile)
    {
        if (projectile != null && pool != null) pool.Release(projectile);
    }
}
