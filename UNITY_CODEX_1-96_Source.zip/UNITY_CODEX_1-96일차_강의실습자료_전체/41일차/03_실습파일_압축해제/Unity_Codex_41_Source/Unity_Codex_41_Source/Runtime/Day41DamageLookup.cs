using UnityEngine;

/// <summary>Collider가 자식에 있고 체력 컴포넌트가 부모에 있을 때도 검색.</summary>
public static class Day41DamageLookup
{
    public static bool TryFind(Collider collider, out IDay41Damageable receiver, out Component owner)
    {
        receiver = null;
        owner = null;
        if (collider == null) return false;
        for (Transform t = collider.transform; t != null; t = t.parent)
        {
            MonoBehaviour[] behaviours = t.GetComponents<MonoBehaviour>();
            foreach (MonoBehaviour behaviour in behaviours)
            {
                if (behaviour is IDay41Damageable damageable && behaviour.isActiveAndEnabled)
                {
                    receiver = damageable;
                    owner = behaviour;
                    return true;
                }
            }
        }
        return false;
    }
}
