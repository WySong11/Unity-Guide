using UnityEngine;

[RequireComponent(typeof(Rigidbody), typeof(Collider))]
public sealed class Day41Projectile3D : MonoBehaviour
{
    [SerializeField, Min(0.1f)] private float lifetime = 3f;
    [SerializeField, Min(1)] private int damage = 20;
    private Day41ProjectilePool3D pool;
    private Rigidbody body;
    private Collider ownCollider;
    private Collider ownerCollider;
    private GameObject attacker;
    private bool returning;
    private float remaining;

    private void Awake()
    {
        body = GetComponent<Rigidbody>();
        ownCollider = GetComponent<Collider>();
        body.useGravity = false;
        body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
    }
    public void SetPool(Day41ProjectilePool3D value) => pool = value;

    public void Launch(Vector3 position, Vector3 direction, float speed,
        GameObject source, Collider shooterCollider)
    {
        if (body == null) body = GetComponent<Rigidbody>();
        if (ownCollider == null) ownCollider = GetComponent<Collider>();
        returning = false;
        remaining = lifetime;
        attacker = source;
        ownerCollider = shooterCollider;
        transform.position = position;
        transform.rotation = Quaternion.LookRotation(direction.normalized);
        body.linearVelocity = Vector3.zero;
        body.angularVelocity = Vector3.zero;
        if (ownerCollider != null) Physics.IgnoreCollision(ownCollider, ownerCollider, true);
        body.linearVelocity = direction.normalized * speed; // Unity 6
    }
    private void Update()
    {
        if (returning || Time.timeScale <= 0f) return;
        remaining -= Time.deltaTime;
        if (remaining <= 0f) ReturnToPool();
    }
    private void OnCollisionEnter(Collision collision)
    {
        if (returning) return;
        if (Day41DamageLookup.TryFind(collision.collider, out IDay41Damageable receiver, out _))
            receiver.TakeDamage(damage, attacker, collision.GetContact(0).point);
        ReturnToPool();
    }
    private void ReturnToPool()
    {
        if (returning) return;
        returning = true;
        body.linearVelocity = Vector3.zero;
        body.angularVelocity = Vector3.zero;
        if (ownerCollider != null && ownCollider != null)
            Physics.IgnoreCollision(ownCollider, ownerCollider, false);
        ownerCollider = null;
        attacker = null;
        if (pool != null) pool.Return(this);
        else gameObject.SetActive(false);
    }
}
