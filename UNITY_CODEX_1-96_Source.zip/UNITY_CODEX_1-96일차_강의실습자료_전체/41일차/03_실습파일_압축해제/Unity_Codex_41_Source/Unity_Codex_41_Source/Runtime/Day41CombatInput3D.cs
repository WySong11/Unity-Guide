using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>37~40일차 Motor를 건드리지 않는 공격 입력 연결 스크립트.</summary>
public sealed class Day41CombatInput3D : MonoBehaviour
{
    [SerializeField] private InputActionReference meleeAction;
    [SerializeField] private InputActionReference hitscanAction;
    [SerializeField] private InputActionReference projectileAction;
    [SerializeField] private Day41MeleeAttack3D melee;
    [SerializeField] private Day41HitscanGun3D hitscan;
    [SerializeField] private Day41ProjectilePool3D projectile;
    private bool ownMelee, ownHitscan, ownProjectile;

    private static bool EnableIfNeeded(InputActionReference reference)
    {
        if (reference == null || reference.action == null || reference.action.enabled) return false;
        reference.action.Enable();
        return true;
    }
    private void OnEnable()
    {
        ownMelee = EnableIfNeeded(meleeAction);
        ownHitscan = EnableIfNeeded(hitscanAction);
        ownProjectile = EnableIfNeeded(projectileAction);
    }
    private void OnDisable()
    {
        if (ownMelee) meleeAction?.action?.Disable();
        if (ownHitscan) hitscanAction?.action?.Disable();
        if (ownProjectile) projectileAction?.action?.Disable();
    }
    private void Update()
    {
        if (Time.timeScale <= 0f) return;
        // Input Actions가 연결되면 해당 바인딩만 사용; 없으면 J/K/L 임시 테스트
        bool meleePressed = meleeAction?.action != null ? meleeAction.action.WasPressedThisFrame()
            : Keyboard.current?.jKey.wasPressedThisFrame == true;
        bool hitscanPressed = hitscanAction?.action != null ? hitscanAction.action.WasPressedThisFrame()
            : Keyboard.current?.kKey.wasPressedThisFrame == true;
        bool projectilePressed = projectileAction?.action != null ? projectileAction.action.WasPressedThisFrame()
            : Keyboard.current?.lKey.wasPressedThisFrame == true;
        if (meleePressed) melee?.TryAttack();
        if (hitscanPressed) hitscan?.TryFire();
        if (projectilePressed) projectile?.TryFire();
    }
}
