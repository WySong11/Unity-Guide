using UnityEngine;

/// <summary>카메라 중앙으로 조준하되 발사점에서 다시 Raycast하여 벽 통과를 방지.</summary>
public sealed class Day41HitscanGun3D : MonoBehaviour
{
    [SerializeField] private Camera aimCamera;
    [SerializeField] private Transform muzzle;
    [SerializeField, Min(1)] private int damage = 15;
    [SerializeField, Min(1f)] private float maxDistance = 60f;
    [SerializeField, Min(0f)] private float fireInterval = 0.15f;
    [SerializeField] private LayerMask hitMask = ~0; // 벽 + 타깃 포함, 플레이어 Layer 제외
    private float nextFireTime;

    public bool TryFire()
    {
        if (Time.timeScale <= 0f || Time.time < nextFireTime) return false;
        if (aimCamera == null || muzzle == null)
        { Debug.LogWarning("Day41 hitscan: assign Camera and Muzzle", this); return false; }
        nextFireTime = Time.time + fireInterval;

        Ray cameraRay = aimCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0f));
        Vector3 targetPoint = cameraRay.GetPoint(maxDistance);
        if (Physics.Raycast(cameraRay, out RaycastHit lookHit, maxDistance,
            hitMask, QueryTriggerInteraction.Ignore)) targetPoint = lookHit.point;

        Vector3 delta = targetPoint - muzzle.position;
        Vector3 direction = delta.sqrMagnitude > 0.0001f ? delta.normalized : muzzle.forward;
        if (Physics.Raycast(muzzle.position, direction, out RaycastHit hit,
            maxDistance, hitMask, QueryTriggerInteraction.Ignore))
        {
            if (Day41DamageLookup.TryFind(hit.collider, out IDay41Damageable receiver, out _))
                receiver.TakeDamage(damage, gameObject, hit.point);
            Debug.DrawLine(muzzle.position, hit.point, Color.red, 0.45f);
        }
        else Debug.DrawRay(muzzle.position, direction * maxDistance, Color.cyan, 0.45f);
        return true;
    }
}
