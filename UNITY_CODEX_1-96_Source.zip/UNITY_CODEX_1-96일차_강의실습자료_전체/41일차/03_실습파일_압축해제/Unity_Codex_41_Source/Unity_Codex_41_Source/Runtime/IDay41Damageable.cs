using UnityEngine;

/// <summary>피격 가능한 오브젝트가 구현할 공통 계약.</summary>
public interface IDay41Damageable
{
    void TakeDamage(int amount, GameObject attacker, Vector3 hitPoint);
}
