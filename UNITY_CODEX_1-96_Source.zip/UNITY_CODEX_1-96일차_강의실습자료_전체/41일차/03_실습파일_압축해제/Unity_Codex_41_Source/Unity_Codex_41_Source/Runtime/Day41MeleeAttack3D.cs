using System.Collections.Generic;
using UnityEngine;

/// <summary>전방 반경 + 각도 기반 근접 공격. 다중 Collider 중복 피격 방지.</summary>
public sealed class Day41MeleeAttack3D : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Transform attackOrigin;
    [SerializeField] private GameObject attacker;
    [Header("Attack")]
    [SerializeField, Min(0.1f)] private float radius = 1.8f;
    [SerializeField, Range(1f, 180f)] private float attackAngle = 100f;
    [SerializeField, Min(1)] private int damage = 25;
    [SerializeField, Min(0f)] private float cooldown = 0.65f;
    [SerializeField] private LayerMask targetMask = ~0;
    [SerializeField] private LayerMask obstructionMask = 0; // 환경 레이어만 지정; 0이면 시야 검사 생략

    private readonly Collider[] hitBuffer = new Collider[32];
    private readonly HashSet<Component> hitThisAttack = new HashSet<Component>();
    private float nextAttackTime;

    public bool TryAttack()
    {
        if (Time.timeScale <= 0f || Time.time < nextAttackTime) return false;
        if (attackOrigin == null) { Debug.LogWarning("Day41 melee: attackOrigin is missing", this); return false; }
        nextAttackTime = Time.time + cooldown;
        hitThisAttack.Clear();
        int count = Physics.OverlapSphereNonAlloc(attackOrigin.position, radius, hitBuffer,
            targetMask, QueryTriggerInteraction.Ignore);
        for (int i = 0; i < count; i++)
        {
            Collider col = hitBuffer[i];
            if (col == null || col.transform.IsChildOf(transform.root)) continue;
            if (!Day41DamageLookup.TryFind(col, out IDay41Damageable target, out Component owner)) continue;
            if (hitThisAttack.Contains(owner)) continue;
            Vector3 point = col.ClosestPoint(attackOrigin.position);
            Vector3 towards = point - attackOrigin.position;
            if (towards.sqrMagnitude < 0.001f) towards = col.bounds.center - attackOrigin.position;
            if (towards.sqrMagnitude > 0.001f && Vector3.Angle(attackOrigin.forward, towards) > attackAngle * 0.5f)
                continue;
            if (obstructionMask.value != 0 && towards.sqrMagnitude > 0.001f &&
                Physics.Raycast(attackOrigin.position, towards.normalized, towards.magnitude,
                    obstructionMask, QueryTriggerInteraction.Ignore)) continue;
            hitThisAttack.Add(owner);
            target.TakeDamage(damage, attacker != null ? attacker : gameObject, point);
        }
        if (count == hitBuffer.Length) Debug.LogWarning("Day41 melee: hit buffer full; enlarge array", this);
        return true;
    }

    private void OnDrawGizmosSelected()
    {
        if (attackOrigin == null) return;
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(attackOrigin.position, radius);
        Vector3 left = Quaternion.AngleAxis(-attackAngle * 0.5f, Vector3.up) * attackOrigin.forward;
        Vector3 right = Quaternion.AngleAxis(attackAngle * 0.5f, Vector3.up) * attackOrigin.forward;
        Gizmos.DrawLine(attackOrigin.position, attackOrigin.position + left * radius);
        Gizmos.DrawLine(attackOrigin.position, attackOrigin.position + right * radius);
    }
}
