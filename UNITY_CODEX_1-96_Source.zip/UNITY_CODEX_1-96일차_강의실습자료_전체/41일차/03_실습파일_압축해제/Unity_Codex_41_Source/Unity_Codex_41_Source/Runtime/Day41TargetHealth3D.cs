using UnityEngine;
using UnityEngine.Events;

/// <summary>근접, Raycast, 발사체 공격이 함께 사용하는 훈련용 체력.</summary>
public sealed class Day41TargetHealth3D : MonoBehaviour, IDay41Damageable
{
    [SerializeField, Min(1)] private int maxHealth = 100;
    [SerializeField] private bool resetOnDefeat = true;
    [SerializeField, Min(0.1f)] private float resetDelay = 2f;
    [SerializeField] private UnityEvent onDefeated;

    private int currentHealth;
    public int CurrentHealth => currentHealth;
    public int MaxHealth => maxHealth;
    private void Awake() => currentHealth = maxHealth;

    public void TakeDamage(int amount, GameObject attacker, Vector3 hitPoint)
    {
        if (amount <= 0 || currentHealth <= 0) return;
        currentHealth = Mathf.Max(0, currentHealth - amount);
        Debug.Log($"[Day41] {name}: -{amount}, HP {currentHealth}/{maxHealth}, hit {hitPoint}", this);
        if (currentHealth > 0) return;
        onDefeated?.Invoke();
        if (resetOnDefeat) Invoke(nameof(ResetHealth), resetDelay);
    }

    public void ResetHealth()
    {
        CancelInvoke(nameof(ResetHealth));
        currentHealth = maxHealth;
    }
}
