using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// 테스트용 시작 씬의 GameObject에 붙여서 Player.log와 Scene 흐름을 확인합니다.
/// 릴리스 배포 전에는 컴포넌트를 제거하거나 비활성화하는 것을 권장합니다.
/// </summary>
public sealed class Day31RuntimeSmokeProbe : MonoBehaviour
{
    [SerializeField] private bool persistAcrossScenes = true;
    private static Day31RuntimeSmokeProbe instance;

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(gameObject);
            return;
        }
        instance = this;
        if (persistAcrossScenes) DontDestroyOnLoad(gameObject);
        Debug.Log($"[Day31] Boot | Unity={Application.unityVersion} | Platform={Application.platform}");
    }

    private void OnEnable() => SceneManager.sceneLoaded += OnSceneLoaded;
    private void OnDisable() => SceneManager.sceneLoaded -= OnSceneLoaded;

    private void Start()
    {
        Debug.Log($"[Day31] Start | Scene={SceneManager.GetActiveScene().name} | " +
                  $"Resolution={Screen.width}x{Screen.height} | TimeScale={Time.timeScale}");
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        Debug.Log($"[Day31] SceneLoaded | {scene.name} | Mode={mode} | TimeScale={Time.timeScale}");
        if (Mathf.Approximately(Time.timeScale, 0f))
            Debug.LogWarning("[Day31] 씬 이동 후 timeScale=0: 일시정지 해제 누락 가능성 확인");
    }
}
