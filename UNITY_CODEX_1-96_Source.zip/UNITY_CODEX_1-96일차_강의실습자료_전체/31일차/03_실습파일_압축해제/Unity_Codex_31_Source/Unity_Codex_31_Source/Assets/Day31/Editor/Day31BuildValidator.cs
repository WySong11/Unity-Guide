using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

/// <summary>
/// Day 31: Windows 빌드 직전에 Scene List를 확인하는 에디터 전용 도구.
/// 반드시 Assets/.../Editor 폴더에 배치하세요.
/// </summary>
public static class Day31BuildValidator
{
    [MenuItem("Tools/Day31/1. Check Build Readiness")]
    public static void CheckFromMenu()
    {
        bool ready = Validate(out List<string> messages);
        foreach (string message in messages)
        {
            if (message.StartsWith("ERROR")) Debug.LogError("[Day31] " + message);
            else Debug.LogWarning("[Day31] " + message);
        }
        if (ready) Debug.Log("[Day31] Scene List 검사 통과. Play 테스트는 별도로 진행하세요.");
    }

    public static bool Validate(out List<string> messages)
    {
        messages = new List<string>();
        var enabled = new List<EditorBuildSettingsScene>();
        foreach (var scene in EditorBuildSettings.scenes)
            if (scene.enabled) enabled.Add(scene);

        if (enabled.Count == 0)
        {
            messages.Add("ERROR: Build Profiles의 Scene List에 활성화된 씬이 없습니다.");
            return false;
        }

        bool valid = true;
        for (int i = 0; i < enabled.Count; i++)
        {
            string path = enabled[i].path;
            if (string.IsNullOrWhiteSpace(path) || AssetDatabase.LoadAssetAtPath<SceneAsset>(path) == null)
            {
                valid = false;
                messages.Add($"ERROR: Scene[{i}] 파일을 찾을 수 없음: {path}");
            }
        }
        var first = Path.GetFileNameWithoutExtension(enabled[0].path);
        if (!string.Equals(first, "TitleScene", System.StringComparison.OrdinalIgnoreCase))
            messages.Add($"WARNING: 첫 씬은 '{first}' 입니다. 시작 씬이 맞는지 확인하세요.");

        if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.StandaloneWindows64)
        {
            messages.Add("ERROR: 활성 빌드 타깃이 Windows x86_64가 아닙니다. Build Profiles에서 전환하세요.");
            valid = false;
        }
        if (string.IsNullOrWhiteSpace(PlayerSettings.productName))
            messages.Add("WARNING: Player Settings의 Product Name을 확인하세요.");
        return valid;
    }
}
