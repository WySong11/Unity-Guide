using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

/// <summary>Day31: 빌드 프로파일 UI 실습 후 선택적으로 사용하는 빌드 자동화 예제.</summary>
public static class Day31WindowsBuilder
{
    [MenuItem("Tools/Day31/2. Build Windows (Development)")]
    public static void BuildDevelopment() => Build(BuildOptions.Development, "Development");

    [MenuItem("Tools/Day31/3. Build Windows (Release)")]
    public static void BuildRelease() => Build(BuildOptions.None, "Release");

    private static void Build(BuildOptions options, string flavor)
    {
        if (!Day31BuildValidator.Validate(out var messages))
        {
            foreach (var message in messages) Debug.LogError("[Day31] " + message);
            Debug.LogError("[Day31] 사전 검증 실패: 빌드를 중단합니다.");
            return;
        }

        // 에디터에 현재 저장된 활성 Scene List만 사용합니다.
        string[] scenes = EditorBuildSettings.scenes
            .Where(scene => scene.enabled)
            .Select(scene => scene.path)
            .ToArray();
        string projectRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
        string outputDir = Path.Combine(projectRoot, "Builds", "Windows", flavor);
        Directory.CreateDirectory(outputDir);
        string exePath = Path.Combine(outputDir, "Day31Game.exe");

        var buildOptions = new BuildPlayerOptions
        {
            scenes = scenes,
            locationPathName = exePath,
            target = BuildTarget.StandaloneWindows64,
            options = options
        };

        Debug.Log($"[Day31] {flavor} 빌드 시작: {exePath}");
        BuildReport report = BuildPipeline.BuildPlayer(buildOptions);
        bool success = report.summary.result == BuildResult.Succeeded;
        if (success)
            Debug.Log($"[Day31] 빌드 성공 | 크기: {report.summary.totalSize:N0} bytes | 결과: {exePath}");
        else
            Debug.LogError($"[Day31] 빌드 실패 ({report.summary.result}). Console/Editor.log 확인 필요.");
    }
}
