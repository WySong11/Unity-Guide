# 31일차 Codex 실습 프롬프트

## 1) 읽기 전용 진단
현재 Unity 프로젝트에서 변경 없이 빌드 준비 상태를 확인해줘.
- Unity Editor/버전, 활성 플랫폼, Build Profiles 씬 목록 및 첫 씬 확인
- 컴파일 오류, 플레이 중 Console 오류, Scene 참조 누락 가능성 점검
- git status와 git diff --stat 확인. 사용자 기존 변경은 보존
- 확인된 사실/추정/추가 검증 필요 사항을 구분해 표로 정리
- 빌드 또는 파일 수정을 실행하기 전에 계획과 위험을 알려줘

## 2) 플레이 테스트 계획
수업의 TitleScene → GameScene → Pause/Resume → Restart → Result → Title
전체 흐름에 대한 Play 테스트 시나리오를 만들어줘.
정상/예외 경로, 재현 방법, 기대 결과, 수집할 로그/스크린샷을 명시해줘.
특히 Time.timeScale, ObjectPool 재사용, HUD 초기값, NullReferenceException을 검사해줘.

## 3) 빌드 실패 원인 분석
다음 빌드 오류와 Player.log, Editor.log를 분석해줘.
[오류 로그 붙여넣기]
- 가장 가능성 큰 근본 원인 1~3개를 증거와 함께 설명
- 불필요한 리팩터링 없이 최소 수정 방안을 제안
- 변경 파일 목록 및 테스트 방법을 먼저 제시
- Unity 실행, 재빌드 완료를 직접 확인하지 못했다면 성공이라고 말하지 마

## 4) 수정 후 회귀 테스트
수정된 파일만 git diff로 점검하고 테스트 매트릭스 PT-01~PT-14에 따라
수동/자동 검증을 구분해 보고해줘. 각 항목에 Pass/Fail/Not Run을 표시해줘.
스크립트 컴파일, Editor Play, Windows 실행 파일, Player.log 결과를 각각 구분해.
