# Unity × Codex — 31일차 플레이 테스트 및 빌드

- 대상: Unity 6.3 (6000.3 계열), Windows x86_64 (실습 기본 플랫폼)
- 본 ZIP은 **기존 Unity 프로젝트에 복사하는 스크립트 예제**입니다. 완성 Unity 프로젝트 전체가 아닙니다.
- 빌드 결과 `.exe`는 포함하지 않았고, 실제 Unity Editor에서 빌드해야 생성됩니다.

## 구성 및 설치

1. `Assets/Day31/Editor/`의 두 `.cs`는 프로젝트의 `Assets` 내 `Editor` 폴더 구조를 유지합니다.
2. `Assets/Day31/Runtime/Day31RuntimeSmokeProbe.cs`는 `TitleScene`의 빈 GameObject에 추가하여 Play/빌드 로그를 봅니다.
3. `Optional_PlayMode_Tests/Day31PlayModeSmokeTests.cs`는 **Unity Test Framework의 PlayMode Test Assembly를 생성한 뒤** 그 어셈블리 폴더에 복사합니다. 예: Test Runner → Create PlayMode Test Assembly. 테스트 프레임워크 참조가 없는 일반 런타임 Assembly 안에 그대로 둬서는 안 됩니다.
4. 기존 `TitleScene`과 `GameScene`이 있을 경우 `File > Build Profiles > Scene List`에 이 순서로 활성화합니다. 프로젝트 씬 이름이 다르면 이 설정과 validator의 시작 씬 점검 기준을 프로젝트에 맞게 수정합니다.
5. Build Profiles의 플랫폼을 Windows로 전환하고, `Tools > Day31 > 1. Check Build Readiness`를 실행합니다.
6. 에디터에서 직접 `Build` 또는 `Build and Run`을 먼저 경험한 뒤 `Tools > Day31 > 2/3` 자동 빌드를 선택적으로 사용합니다.
7. `Builds/Windows/Development`와 `Builds/Windows/Release`에 각각 `.exe`, `_Data` 폴더 등이 생성됩니다. 배포할 때는 관련 파일을 함께 포함해야 합니다.

## 핵심 주의사항

- Validator가 검증하는 것은 **씬 목록, 파일 존재, 플랫폼 상태** 일부입니다. 자동으로 게임의 모든 오류를 확인하지는 않습니다.
- 에디터 Play 성공은 Standalone 빌드 성공/정상 동작과 다릅니다. 반드시 `.exe`를 실행하여 확인합니다.
- 테스트용 Development Build와 실제 전달용 Release Build를 구분합니다.
- Windows Player.log: `%USERPROFILE%\\AppData\\LocalLow\\CompanyName\\ProductName\\Player.log` (실제 회사명/상품명 적용)
- `Time.timeScale`을 0에서 1로 복원하지 않고 재시작하면 다음 씬이 멈출 수 있습니다.
- Codex는 코드 수정·테스트 계획을 지원하지만, 실제 환경 실행 여부와 성공 판정은 로그/빌드 산출물로 확인해야 합니다.
- 사용자 변경 파일, Git 상태를 확인하고 최소 변경만 적용합니다.

## 수업 진행 권장(120분)
- 10분: 테스트 목표와 실패 판정
- 25분: Editor 수동 Play Test
- 20분: Test Runner·Profiler 기초
- 30분: Build Profiles 및 Windows 빌드
- 25분: 실행 파일·로그·Codex 검증
- 10분: 결과 보고·제출

## 공식 문서
- Build Profiles: https://docs.unity3d.com/kr/current/Manual/build-profiles-reference.html
- BuildPipeline.BuildPlayer: https://docs.unity3d.com/kr/current/ScriptReference/BuildPipeline.BuildPlayer.html
- Windows Player.log: https://docs.unity.com/en-us/engine/6000.3/manual/get-started/project-configuration/log-files
