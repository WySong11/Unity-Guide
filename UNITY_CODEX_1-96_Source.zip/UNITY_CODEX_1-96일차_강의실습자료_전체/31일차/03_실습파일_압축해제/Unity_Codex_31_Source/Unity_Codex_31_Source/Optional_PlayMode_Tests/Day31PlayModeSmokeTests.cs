using System.Collections;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;

/// <summary>
/// Unity Test Framework 패키지와 PlayMode Test Assembly가 필요합니다.
/// 본 코드를 Assets 아래 아무 곳에 놓기만 하면 바로 컴파일되는 것이 아닙니다.
/// Test Assembly를 만든 뒤 해당 위치로 파일을 옮기고 테스트를 실행하세요.
/// </summary>
public class Day31PlayModeSmokeTests
{
    [UnityTest]
    public IEnumerator ActiveScene_IsValid_AfterOneFrame()
    {
        yield return null;
        Assert.IsTrue(SceneManager.GetActiveScene().IsValid(), "활성 씬이 유효해야 합니다.");
    }

    [UnityTest]
    public IEnumerator TimeScale_CanPauseAndResume()
    {
        float previous = Time.timeScale;
        try
        {
            Time.timeScale = 0f;
            yield return null;
            Assert.AreEqual(0f, Time.timeScale);
            Time.timeScale = 1f;
            yield return null;
            Assert.AreEqual(1f, Time.timeScale);
        }
        finally
        {
            Time.timeScale = previous;
        }
    }
}
