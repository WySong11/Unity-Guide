using UnityEngine;
using UnityEngine.InputSystem;

// 입력만 담당한다. 이동·공격의 실제 처리는 하지 않는다.
public sealed class Day45InputReader : MonoBehaviour
{
    public Vector2 Move { get; private set; }
    public bool JumpPressed { get; private set; }
    public bool AttackPressed { get; private set; }

    // Coordinator.Update()가 호출하므로 실행 순서에 의존하지 않는다.
    public void Sample()
    {
        Move = Vector2.zero;
        JumpPressed = false;
        AttackPressed = false;
        if (Time.timeScale <= 0f) return;

        Keyboard kb = Keyboard.current;
        if (kb != null)
        {
            float horizontal = (kb.dKey.isPressed ? 1f : 0f) - (kb.aKey.isPressed ? 1f : 0f);
            float vertical = (kb.wKey.isPressed ? 1f : 0f) - (kb.sKey.isPressed ? 1f : 0f);
            Move = Vector2.ClampMagnitude(new Vector2(horizontal, vertical), 1f);
            JumpPressed = kb.spaceKey.wasPressedThisFrame;
            AttackPressed = kb.jKey.wasPressedThisFrame;
        }
        Mouse mouse = Mouse.current;
        if (mouse != null && mouse.leftButton.wasPressedThisFrame)
            AttackPressed = true;
    }
}
