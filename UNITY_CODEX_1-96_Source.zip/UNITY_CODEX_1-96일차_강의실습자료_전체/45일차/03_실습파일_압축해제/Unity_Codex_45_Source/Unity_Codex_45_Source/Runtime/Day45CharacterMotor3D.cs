using UnityEngine;

// 이동과 중력만 담당한다. 키 입력을 직접 읽지 않는다.
[RequireComponent(typeof(CharacterController))]
public sealed class Day45CharacterMotor3D : MonoBehaviour
{
    [SerializeField, Min(0f)] private float moveSpeed = 4.5f;
    [SerializeField, Min(0f)] private float acceleration = 20f;
    [SerializeField, Min(0f)] private float jumpHeight = 1.5f;
    [SerializeField] private float gravity = -18f;
    [SerializeField] private Transform cameraTransform;

    private CharacterController controller;
    private Vector3 planarVelocity;
    private float verticalVelocity;

    public float PlanarSpeed => planarVelocity.magnitude;
    public bool IsGrounded => controller != null && controller.isGrounded;

    private void Awake()
    {
        controller = GetComponent<CharacterController>();
        if (cameraTransform == null && Camera.main != null)
            cameraTransform = Camera.main.transform;
    }

    public void Tick(Vector2 move, bool jump)
    {
        if (controller == null || Time.timeScale <= 0f) return;

        Vector3 forward = cameraTransform != null ? cameraTransform.forward : Vector3.forward;
        Vector3 right = cameraTransform != null ? cameraTransform.right : Vector3.right;
        forward.y = 0f;
        right.y = 0f;
        forward.Normalize();
        right.Normalize();
        Vector3 wishDirection = Vector3.ClampMagnitude(forward * move.y + right * move.x, 1f);
        planarVelocity = Vector3.MoveTowards(planarVelocity, wishDirection * moveSpeed, acceleration * Time.deltaTime);

        if (controller.isGrounded && verticalVelocity < 0f)
            verticalVelocity = -2f;
        if (controller.isGrounded && jump)
            verticalVelocity = Mathf.Sqrt(jumpHeight * -2f * gravity);
        verticalVelocity += gravity * Time.deltaTime;

        CollisionFlags flags = controller.Move((planarVelocity + Vector3.up * verticalVelocity) * Time.deltaTime);
        if ((flags & CollisionFlags.Above) != 0 && verticalVelocity > 0f)
            verticalVelocity = 0f;
        if (wishDirection.sqrMagnitude > 0.001f)
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(wishDirection), 12f * Time.deltaTime);
    }
}
