using UnityEngine;

// 원본 게임 로직을 바꾸지 않고 관찰만 수행.
public sealed class Day45ArchitectureDiagnostics : MonoBehaviour
{
    [SerializeField] private Day45CharacterCoordinator player;
    private void Awake()
    {
        if (player == null) player = FindFirstObjectByType<Day45CharacterCoordinator>();
    }
    private void OnGUI()
    {
        if (player == null || player.Health == null || player.Motor == null) return;
        GUILayout.BeginArea(new Rect(12, 12, 290, 105), GUI.skin.box);
        GUILayout.Label($"Day45 | HP: {player.Health.CurrentHealth}/{player.Health.MaxHealth}");
        GUILayout.Label($"Grounded: {player.Motor.IsGrounded}");
        GUILayout.Label($"Speed: {player.Motor.PlanarSpeed:F2}");
        GUILayout.Label("WASD 이동 / Space 점프 / J 또는 클릭 사격");
        GUILayout.EndArea();
    }
}
