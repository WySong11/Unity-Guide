using System;
using UnityEngine;

// 사격과 쿨다운만 담당한다. 입력·체력 UI에는 의존하지 않는다.
public sealed class Day45CombatController : MonoBehaviour
{
    [SerializeField] private Camera aimCamera;
    [SerializeField, Min(0.1f)] private float range = 30f;
    [SerializeField, Min(0.05f)] private float cooldown = 0.4f;
    [SerializeField, Min(1)] private int damage = 20;
    [SerializeField] private LayerMask hitLayers = ~(1 << 2); // Ignore Raycast 레이어 제외
    private float nextFireTime;
    public event Action Fired;
    public bool CanFire => Time.timeScale > 0f && Time.time >= nextFireTime;

    private void Awake()
    {
        if (aimCamera == null) aimCamera = Camera.main;
    }

    public bool TryFire()
    {
        if (!CanFire) return false;
        if (aimCamera == null) { Debug.LogWarning("[Day45] Aim Camera 연결 필요", this); return false; }
        nextFireTime = Time.time + cooldown;
        Ray ray = aimCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f));
        if (Physics.Raycast(ray, out RaycastHit hit, range, hitLayers, QueryTriggerInteraction.Ignore))
        {
            // 자식 Collider가 있더라도 상위 Receiver와 연결.
            Day45DamageReceiver receiver = hit.collider.GetComponentInParent<Day45DamageReceiver>();
            if (receiver != null && receiver.transform.root != transform.root)
            {
                IDay45Damageable target = receiver;
                target.ApplyDamage(damage);
            }
        }
        Fired?.Invoke();
        return true;
    }
}
