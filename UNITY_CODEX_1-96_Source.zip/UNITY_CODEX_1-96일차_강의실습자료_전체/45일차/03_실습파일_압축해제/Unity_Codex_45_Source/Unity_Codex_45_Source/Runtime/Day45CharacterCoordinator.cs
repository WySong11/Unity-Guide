using UnityEngine;

// 연결/흐름 조정만 담당한다. 세부 이동·공격·HP 계산을 하지 않는다.
[RequireComponent(typeof(Day45InputReader), typeof(Day45CharacterMotor3D))]
[RequireComponent(typeof(Day45CombatController))]
public sealed class Day45CharacterCoordinator : MonoBehaviour
{
    [SerializeField] private Day45InputReader input;
    [SerializeField] private Day45CharacterMotor3D motor;
    [SerializeField] private Day45CombatController combat;
    [SerializeField] private Day45CharacterHealth health;
    [SerializeField] private Day45AnimatorBridge animationBridge;
    public Day45CharacterHealth Health => health;
    public Day45CharacterMotor3D Motor => motor;

    private void Awake()
    {
        if (input == null) input = GetComponent<Day45InputReader>();
        if (motor == null) motor = GetComponent<Day45CharacterMotor3D>();
        if (combat == null) combat = GetComponent<Day45CombatController>();
        if (health == null) health = GetComponent<Day45CharacterHealth>();
        if (animationBridge == null) animationBridge = GetComponentInChildren<Day45AnimatorBridge>();
    }

    private void Update()
    {
        if (input == null || motor == null || combat == null) return;
        if (health != null && health.IsDead) return;
        input.Sample();
        motor.Tick(input.Move, input.JumpPressed);
        if (input.AttackPressed && combat.TryFire())
            animationBridge?.ShowAttack();
        animationBridge?.ShowMovement(motor.PlanarSpeed, motor.IsGrounded);
    }
}
