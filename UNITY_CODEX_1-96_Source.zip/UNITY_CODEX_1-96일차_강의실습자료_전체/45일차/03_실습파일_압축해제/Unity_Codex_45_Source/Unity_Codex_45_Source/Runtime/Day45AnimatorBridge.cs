using UnityEngine;

// 애니메이션 표현만 담당한다. Animator가 없어도 다른 게임 기능은 실행된다.
public sealed class Day45AnimatorBridge : MonoBehaviour
{
    [SerializeField] private Animator animator;
    [SerializeField] private string speedParameter = "Speed";
    [SerializeField] private string groundedParameter = "IsGrounded";
    [SerializeField] private string attackTrigger = "Attack";
    private bool hasSpeed, hasGrounded, hasAttack;

    private void Awake()
    {
        if (animator == null) animator = GetComponentInChildren<Animator>();
        if (animator == null) return;
        foreach (AnimatorControllerParameter p in animator.parameters)
        {
            if (p.name == speedParameter && p.type == AnimatorControllerParameterType.Float) hasSpeed = true;
            if (p.name == groundedParameter && p.type == AnimatorControllerParameterType.Bool) hasGrounded = true;
            if (p.name == attackTrigger && p.type == AnimatorControllerParameterType.Trigger) hasAttack = true;
        }
    }

    public void ShowMovement(float speed, bool grounded)
    {
        if (animator == null) return;
        if (hasSpeed) animator.SetFloat(speedParameter, speed);
        if (hasGrounded) animator.SetBool(groundedParameter, grounded);
    }

    public void ShowAttack()
    {
        if (animator != null && hasAttack) animator.SetTrigger(attackTrigger);
    }
}
