using TMPro;
using UnityEngine;
using UnityEngine.UI;

// UI는 Health의 데이터를 읽고 표시만 한다. HP를 수정하지 않는다.
public sealed class Day45HealthHUD : MonoBehaviour
{
    [SerializeField] private Day45CharacterHealth health;
    [SerializeField] private Slider slider;
    [SerializeField] private TMP_Text valueText;

    private void OnEnable()
    {
        if (health == null) return;
        health.HealthChanged += Refresh;
        Refresh(health.CurrentHealth, health.MaxHealth); // 구독 직후 초기 동기화
    }

    private void OnDisable()
    {
        if (health != null) health.HealthChanged -= Refresh;
    }

    private void Refresh(int current, int max)
    {
        if (slider != null)
        {
            slider.minValue = 0;
            slider.maxValue = Mathf.Max(1, max);
            slider.SetValueWithoutNotify(current);
        }
        if (valueText != null) valueText.text = $"HP {current} / {max}";
    }
}
