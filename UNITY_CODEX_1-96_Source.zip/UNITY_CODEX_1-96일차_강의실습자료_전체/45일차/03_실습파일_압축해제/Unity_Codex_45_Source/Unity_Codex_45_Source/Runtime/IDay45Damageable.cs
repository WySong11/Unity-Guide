// 대미지 요청 계약: 공격 시스템은 구체적 Health 타입을 몰라도 된다.
public interface IDay45Damageable
{
    void ApplyDamage(int damage);
}
