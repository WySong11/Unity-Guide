using UnityEngine;

// 인터페이스 계약을 구현하는 어댑터: Health에 피해 전달만 담당.
[RequireComponent(typeof(Day45CharacterHealth))]
public sealed class Day45DamageReceiver : MonoBehaviour, IDay45Damageable
{
    private Day45CharacterHealth health;
    private void Awake() => health = GetComponent<Day45CharacterHealth>();

    public void ApplyDamage(int damage)
    {
        if (health != null) health.TakeDamage(damage);
    }
}
