using System;
using UnityEngine;

// 체력 데이터의 유일한 소유자. UI를 직접 참조하지 않는다.
public sealed class Day45CharacterHealth : MonoBehaviour
{
    [SerializeField, Min(1)] private int maxHealth = 100;
    public int MaxHealth => maxHealth;
    public int CurrentHealth { get; private set; }
    public bool IsDead => CurrentHealth <= 0;

    public event Action<int, int> HealthChanged;
    public event Action Died;

    private void Awake() => CurrentHealth = maxHealth;
    private void Start() => HealthChanged?.Invoke(CurrentHealth, maxHealth);

    public void TakeDamage(int amount)
    {
        if (amount <= 0 || IsDead) return;
        CurrentHealth = Mathf.Max(0, CurrentHealth - amount);
        HealthChanged?.Invoke(CurrentHealth, maxHealth);
        if (CurrentHealth == 0) Died?.Invoke();
    }

    public void Heal(int amount)
    {
        if (amount <= 0 || IsDead) return;
        CurrentHealth = Mathf.Min(maxHealth, CurrentHealth + amount);
        HealthChanged?.Invoke(CurrentHealth, maxHealth);
    }

    public void ResetHealth()
    {
        CurrentHealth = maxHealth;
        HealthChanged?.Invoke(CurrentHealth, maxHealth);
    }
}
