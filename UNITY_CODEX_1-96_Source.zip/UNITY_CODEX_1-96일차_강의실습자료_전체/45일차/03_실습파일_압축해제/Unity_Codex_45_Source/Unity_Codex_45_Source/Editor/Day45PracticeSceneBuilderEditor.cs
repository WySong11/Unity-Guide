#if UNITY_EDITOR
using System;
using System.IO;
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public static class Day45PracticeSceneBuilderEditor
{
    [MenuItem("Tools/Unity Codex/Day45/Create Component Practice Scene")]
    public static void Create()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        var folder = "Assets/Day45Generated/Scenes";
        Directory.CreateDirectory(folder);

        GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
        floor.name = "Ground";
        floor.transform.position = new Vector3(0, -0.5f, 0);
        floor.transform.localScale = new Vector3(24, 1, 24);

        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "PlayerRoot";
        player.layer = 2; // Ignore Raycast: 카메라 사격이 자기 자신에 맞지 않도록 구성
        player.transform.position = new Vector3(0, 1, 0);
        CapsuleCollider oldCollider = player.GetComponent<CapsuleCollider>();
        if (oldCollider != null) UnityEngine.Object.DestroyImmediate(oldCollider);
        CharacterController cc = player.AddComponent<CharacterController>();
        cc.height = 2f;
        cc.radius = 0.4f;
        player.AddComponent<Day45CharacterHealth>();
        player.AddComponent<Day45InputReader>();
        player.AddComponent<Day45CharacterMotor3D>();
        player.AddComponent<Day45CombatController>();
        player.AddComponent<Day45CharacterCoordinator>();
        // Animator는 수강생이 직접 넣어도 된다. 없으면 Bridge는 표시를 건너뛴다.
        player.AddComponent<Day45AnimatorBridge>();

        Camera camera = Camera.main;
        if (camera == null)
        {
            GameObject camObj = new GameObject("Main Camera");
            camObj.tag = "MainCamera";
            camera = camObj.AddComponent<Camera>();
            camObj.AddComponent<AudioListener>();
        }
        camera.transform.position = new Vector3(0, 3.0f, -7.0f);
        camera.transform.LookAt(new Vector3(0, 1.0f, 6));

        for (int i = -1; i <= 1; i++)
        {
            GameObject target = GameObject.CreatePrimitive(PrimitiveType.Cube);
            target.name = $"Target_{i + 2}";
            target.transform.position = new Vector3(i * 3.0f, 1.0f, 10);
            target.transform.localScale = new Vector3(1.8f, 2.0f, 0.8f);
            target.AddComponent<Day45CharacterHealth>();
            target.AddComponent<Day45DamageReceiver>();
        }

        GameObject canvasObj = new GameObject("HUD", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        Canvas canvas = canvasObj.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasObj.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        GameObject sliderObj = new GameObject("HealthSlider", typeof(RectTransform), typeof(Slider));
        sliderObj.transform.SetParent(canvasObj.transform, false);
        RectTransform sliderRect = sliderObj.GetComponent<RectTransform>();
        sliderRect.anchorMin = sliderRect.anchorMax = new Vector2(0, 1);
        sliderRect.anchoredPosition = new Vector2(235, -92);
        sliderRect.sizeDelta = new Vector2(360, 32);
        // Slider를 눈으로 볼 수 있도록 Background / Fill을 생성한다.
        GameObject bgObj = new GameObject("Background", typeof(RectTransform), typeof(Image));
        bgObj.transform.SetParent(sliderObj.transform, false);
        RectTransform bgRect = bgObj.GetComponent<RectTransform>();
        bgRect.anchorMin = Vector2.zero; bgRect.anchorMax = Vector2.one;
        bgRect.offsetMin = bgRect.offsetMax = Vector2.zero;
        Image bgImage = bgObj.GetComponent<Image>();
        bgImage.color = new Color(0.12f, 0.19f, 0.3f, 0.9f);
        GameObject fillObj = new GameObject("Fill", typeof(RectTransform), typeof(Image));
        fillObj.transform.SetParent(sliderObj.transform, false);
        RectTransform fillRect = fillObj.GetComponent<RectTransform>();
        fillRect.anchorMin = Vector2.zero; fillRect.anchorMax = new Vector2(1, 1);
        fillRect.offsetMin = new Vector2(4, 4); fillRect.offsetMax = new Vector2(-4, -4);
        fillObj.GetComponent<Image>().color = new Color(0.23f, 0.83f, 0.48f, 1f);
        var slider = sliderObj.GetComponent<Slider>();
        slider.fillRect = fillRect;
        slider.transition = Selectable.Transition.None;
        slider.interactable = false;
        GameObject textObj = new GameObject("HealthText", typeof(RectTransform), typeof(TextMeshProUGUI));
        textObj.transform.SetParent(canvasObj.transform, false);
        RectTransform textRect = textObj.GetComponent<RectTransform>();
        textRect.anchorMin = textRect.anchorMax = new Vector2(0, 1);
        textRect.anchoredPosition = new Vector2(235, -47);
        textRect.sizeDelta = new Vector2(400, 50);
        TextMeshProUGUI text = textObj.GetComponent<TextMeshProUGUI>();
        text.text = "HP 100 / 100";
        text.color = Color.white;
        var hud = canvasObj.AddComponent<Day45HealthHUD>();
        var so = new SerializedObject(hud);
        so.FindProperty("health").objectReferenceValue = player.GetComponent<Day45CharacterHealth>();
        so.FindProperty("slider").objectReferenceValue = sliderObj.GetComponent<Slider>();
        so.FindProperty("valueText").objectReferenceValue = text;
        so.ApplyModifiedPropertiesWithoutUndo();
        player.AddComponent<Day45ArchitectureDiagnostics>();

        string path = AssetDatabase.GenerateUniqueAssetPath($"{folder}/Day45_ComponentLab.unity");
        EditorSceneManager.SaveScene(scene, path);
        AssetDatabase.Refresh();
        Selection.activeGameObject = player;
        Debug.Log($"[Day45] 새 실습 씬 저장 완료: {path}. 필수 참조 및 UI를 점검하세요.");
    }
}
#endif
