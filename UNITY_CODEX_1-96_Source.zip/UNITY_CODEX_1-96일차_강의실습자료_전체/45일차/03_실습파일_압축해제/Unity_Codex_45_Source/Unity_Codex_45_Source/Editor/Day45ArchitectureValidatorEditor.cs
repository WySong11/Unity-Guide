#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

public static class Day45ArchitectureValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day45/Validate Current Scene")]
    public static void Validate()
    {
        var roots = Object.FindObjectsByType<Day45CharacterCoordinator>(FindObjectsSortMode.None);
        if (roots.Length == 0)
        {
            Debug.LogError("[Day45] Day45CharacterCoordinator를 찾지 못했습니다.");
            return;
        }
        int problems = 0;
        foreach (var root in roots)
        {
            problems += Check(root.GetComponent<CharacterController>(), root, "CharacterController");
            problems += Check(root.GetComponent<Day45InputReader>(), root, "Day45InputReader");
            problems += Check(root.GetComponent<Day45CharacterMotor3D>(), root, "Day45CharacterMotor3D");
            problems += Check(root.GetComponent<Day45CombatController>(), root, "Day45CombatController");
            problems += Check(root.GetComponent<Day45CharacterHealth>(), root, "Day45CharacterHealth");
        }
        if (Camera.main == null) { Debug.LogWarning("[Day45] MainCamera 태그 카메라가 필요합니다."); problems++; }
        Debug.Log(problems == 0 ? "[Day45] 필수 컴포넌트 검사 통과" : $"[Day45] 검사 결과: {problems}개 점검 필요");
    }
    private static int Check(Component component, Component owner, string label)
    {
        if (component != null) return 0;
        Debug.LogWarning($"[Day45] {owner.name}: {label} 없음", owner);
        return 1;
    }
}
#endif
