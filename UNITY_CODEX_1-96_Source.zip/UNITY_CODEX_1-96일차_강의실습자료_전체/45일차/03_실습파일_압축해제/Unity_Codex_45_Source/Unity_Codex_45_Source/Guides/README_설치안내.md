# Unity Codex 45일차 – 컴포넌트 분리 설계

대상: Unity 6.3 LTS (Universal 3D / Input System / TextMeshPro 패키지)

## 실습 목표
- 단일 스크립트의 책임을 Input, Motor, Combat, Health, Animator, HUD로 구분한다.
- Coordinator는 순서 조정만 하고 개별 기능을 직접 구현하지 않는다.
- Health 데이터는 이벤트로 알리고 UI는 읽어서 표시만 한다.
- 최소한의 인터페이스와 어댑터를 사용해 데미지 호출 방향을 고정한다.

## 설치
1. 이 ZIP의 Runtime 폴더 C# 파일을 Assets/Scripts/Day45에 복사합니다.
2. Editor 폴더 C# 파일을 Assets/Editor/Day45에 복사합니다. (UnityEditor API는 빌드에 포함되면 안 됩니다.)
3. Unity Console에서 컴파일 오류가 없는지 확인합니다.
4. Tools > Unity Codex > Day45 > Create Component Practice Scene을 실행합니다.
5. HUD의 Slider에는 Background/Fill이 생성됩니다. 화면에서 위치와 Fill 표시를 확인하세요.
6. Play Mode에서 WASD 이동, Space 점프, J/왼쪽 클릭 Raycast 공격을 확인합니다. PlayerRoot는 Ignore Raycast(2번) 레이어로 설정됩니다.
7. Tools > Unity Codex > Day45 > Validate Current Scene으로 필수 컴포넌트를 검사합니다.

## 클래스 책임
- Day45InputReader: 입력 샘플링
- Day45CharacterMotor3D: 이동/중력/점프/회전
- Day45CombatController: 레이캐스트/사격/쿨다운
- Day45CharacterHealth: 체력/사망/이벤트
- Day45DamageReceiver: IDay45Damageable 계약을 Health에 전달
- Day45AnimatorBridge: Animator에 값 전달 (Animator 미설치 시 선택 생략)
- Day45CharacterCoordinator: 입력→이동→공격→애니메이션의 호출 순서 관리
- Day45HealthHUD: HP 구독과 표시
- Day45ArchitectureDiagnostics: 관찰 HUD
- Editor 2종: 실습 씬 생성, Inspector 구성 검사

## 40~44일차 프로젝트와 통합 주의
- 독립 실습용 Day45 코드를 기존 PlayerRoot에 전부 중복 부착하지 마세요.
- 40일차 PlayerMotor와 Day45CharacterMotor를 동시에 작동시키면 CharacterController.Move가 중복 호출됩니다.
- 41~44일차 공격/체력 시스템은 기존 것을 살린 채 역할 구분만 적용하세요. 데미지 경로가 두 개가 되지 않도록 주의합니다.
- 기존 Health가 이미 있다면 Day45CharacterHealth를 추가하는 대신 이벤트/UI 어댑터로 연결하는 것이 좋습니다.
- 샘플은 Keyboard + Mouse Input System 기반입니다. 기존 프로젝트 InputManager/InputAction 경로로 교체할 때는 InputReader만 수정합니다.
- Animator 파라미터(Speed, IsGrounded, Attack)는 선택 사항입니다. 없는 경우 안전하게 건너뜁니다.

## 제출물
- Hierarchy/Inspector 스크린샷(2장 이상)
- 신규 구조 다이어그램, 책임표, git diff, 테스트 기록
- 프로젝트의 C# 스크립트 및 Play Mode 테스트 결과

## 유의 사항
- 이 실행 예제는 실제 Unity Editor에서 컴파일/Play Mode 검증하지 않았습니다.
- Editor 씬 생성 도구는 새 씬 경로에 저장하며 기존 씬을 직접 덮어쓰지 않습니다.
