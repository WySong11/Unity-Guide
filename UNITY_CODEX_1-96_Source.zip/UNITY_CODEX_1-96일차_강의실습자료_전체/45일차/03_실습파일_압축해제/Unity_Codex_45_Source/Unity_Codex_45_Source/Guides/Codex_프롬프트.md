# 45일차 Codex 프롬프트

## 1. 분석만
Unity 6.3 기반 3D 프로젝트에서 플레이어 입력, 이동, 공격, 체력, Animator, HUD의 책임과 의존 방향을 조사해줘. 파일을 수정하지 말고 책임이 두 개 이상인 클래스를 식별한 뒤, 어떤 컴포넌트로 분리할지 표로 제안해줘. 기존 40~44일차 입력/이동/피해 시스템을 중복 생성하지 마.

## 2. 최소 리팩터링
합의한 변경 범위만 구현해줘. Day45InputReader, CharacterMotor3D, CombatController, CharacterHealth, HealthHUD, AnimatorBridge, CharacterCoordinator 역할을 구분하고, 입력→Coordinator→모터/공격 흐름으로 통합해줘. Health는 UI를 참조하지 말고 HealthChanged 이벤트만 제공하며, HUD는 OnEnable/OnDisable에서 이벤트 구독을 관리해줘. 필요한 Inspector 연결 항목을 표시하고 git diff를 리뷰할 수 있도록 작성해줘. 기존 에셋/씬을 삭제하거나 덮어쓰지 마.

## 3. 테스트
컴파일 오류를 먼저 수집해 수정하고, 가능하면 Unity MCP/CLI 또는 Unity Editor에서 Play Mode를 실제 실행해줘. 이동, 점프, 공격 1회 데미지, 사망 후 입력 차단, HP UI 초기값, UI 비활성화/재활성화, 일시정지, 씬 재시작을 테스트해줘. 실제 실행하지 못한 테스트는 '미검증'으로 분리하고 예상 결과만 성공했다고 보고하지 마. 변경 파일·Console 로그·남은 위험을 요약해줘.
