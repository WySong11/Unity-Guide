# 11일차 — Transform과 Unity 실행 순서

교육 환경: Unity 6.3 LTS (URP) / C# / VS Code / Codex

## 학습 파일

- `TransformMover.cs`: `Translate`, `Space.World`, `Space.Self`, `Time.deltaTime` 실험
- `LifecycleLogger.cs`: `Awake`, `OnEnable`, `Start`, `FixedUpdate`, `Update`, `LateUpdate`, `OnDisable`, `OnDestroy`의 호출 기록
- `FollowTargetLate.cs`: 카메라의 `LateUpdate` 추적 기능

## 실행 방법

1. Unity 6.3 URP 프로젝트를 열고 `Assets/Scripts`에 스크립트를 복사합니다.
2. `CubeA`, `CubeB`, `Parent`, `Child`를 생성하고 위치를 변경해 봅니다.
3. 두 큐브에 `TransformMover`를 붙인 후 한쪽은 `World`, 다른 쪽은 `Self`로 설정합니다. 회전값을 다르게 해 동작을 비교합니다.
4. Empty GameObject에 `LifecycleLogger`를 부착하고 Console을 연 뒤 Play하여 로그를 확인합니다.
5. `FollowTargetLate`를 Main Camera에 부착한 후 `target`에 CubeA를 연결합니다.
6. `Parent`는 Position (3,0,0), Rotation (0,0,0), Scale (1,1,1)로 설정하고 자식 `Child`의 localPosition을 (2,0,0)으로 설정해 월드 좌표 (5,0,0)을 확인합니다.
7. 부모 Rotation Y를 90도로 바꾸고 Child의 월드 좌표가 어떻게 달라지는지 관찰합니다.

## 유의사항

- `Update`와 `FixedUpdate`의 호출 관계는 프레임마다 바뀔 수 있습니다. 모든 이벤트가 단일 선형 순서로 1회씩 실행되는 것은 아닙니다.
- 서로 다른 GameObject의 `Awake` 또는 `Update` 실행 순서를 임의로 가정하지 마세요.
- 실제 Rigidbody 물리 이동이 필요한 경우에는 Transform 기반 이동 예제가 아닌 Rigidbody 기반 구현을 사용하세요.
- 이 파일은 학습용 예제입니다. 프로젝트의 Unity 컴파일·Play Mode 실행은 수강생 환경에서 확인해야 합니다.
