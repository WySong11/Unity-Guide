using UnityEngine;

/// <summary>
/// 플레이어가 Update에서 이동한 뒤 LateUpdate에서 따라가는 카메라 예제입니다.
/// Main Camera에 추가한 다음 Inspector의 target을 할당하세요.
/// </summary>
public class FollowTargetLate : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private Vector3 offset = new Vector3(0f, 4f, -6f);

    private void LateUpdate()
    {
        if (target == null)
            return;

        transform.position = target.position + offset;
    }
}
