using UnityEngine;

/// <summary>
/// Transform.Translate로 GameObject를 움직이는 입문 예제입니다.
/// Rigidbody 물리 이동용 예제와 구분하여 사용합니다.
/// </summary>
public class TransformMover : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField, Min(0f)] private float speed = 2f;
    [SerializeField] private Vector3 moveDirection = Vector3.right;
    [SerializeField] private Space coordinateSpace = Space.World;

    private void Update()
    {
        if (moveDirection.sqrMagnitude <= 0.000001f)
            return;

        Vector3 step = moveDirection.normalized * speed * Time.deltaTime;
        transform.Translate(step, coordinateSpace);
    }
}
