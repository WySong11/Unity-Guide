using UnityEngine;

/// <summary>
/// Unity 생명주기의 대표 이벤트를 Console에서 확인합니다.
/// 반복 이벤트 로그는 최대 3회로 제한해 Console 폭주를 방지합니다.
/// </summary>
public class LifecycleLogger : MonoBehaviour
{
    private int updateCount;
    private int fixedUpdateCount;
    private int lateUpdateCount;

    private void Awake()
    {
        Debug.Log($"[{name}] Awake", this);
    }

    private void OnEnable()
    {
        Debug.Log($"[{name}] OnEnable", this);
    }

    private void Start()
    {
        Debug.Log($"[{name}] Start", this);
    }

    private void FixedUpdate()
    {
        if (fixedUpdateCount++ < 3)
            Debug.Log($"[{name}] FixedUpdate {fixedUpdateCount}", this);
    }

    private void Update()
    {
        if (updateCount++ < 3)
            Debug.Log($"[{name}] Update {updateCount}", this);
    }

    private void LateUpdate()
    {
        if (lateUpdateCount++ < 3)
            Debug.Log($"[{name}] LateUpdate {lateUpdateCount}", this);
    }

    private void OnDisable()
    {
        Debug.Log($"[{name}] OnDisable", this);
    }

    private void OnDestroy()
    {
        Debug.Log($"[{name}] OnDestroy", this);
    }
}
