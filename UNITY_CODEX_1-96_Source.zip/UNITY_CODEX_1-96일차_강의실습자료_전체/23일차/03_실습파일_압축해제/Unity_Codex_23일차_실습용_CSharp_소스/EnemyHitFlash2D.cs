using System.Collections;
using UnityEngine;

public class EnemyHitFlash2D : MonoBehaviour
{
    [SerializeField] private EnemyHealth2D health;
    [SerializeField] private SpriteRenderer targetSprite;
    [SerializeField] private Color hitColor = new Color(1f, 0.45f, 0.45f);
    [SerializeField, Min(0f)] private float flashSeconds = 0.12f;
    private Color originalColor;
    private Coroutine routine;

    private void Awake()
    {
        if (health == null) health = GetComponentInParent<EnemyHealth2D>();
        if (targetSprite == null) targetSprite = GetComponentInChildren<SpriteRenderer>();
        if (targetSprite != null) originalColor = targetSprite.color;
    }

    private void OnEnable()
    {
        if (health != null) health.HealthChanged += OnHealthChanged;
    }

    private void OnDisable()
    {
        if (health != null) health.HealthChanged -= OnHealthChanged;
        if (routine != null) StopCoroutine(routine);
        routine = null;
        if (targetSprite != null) targetSprite.color = originalColor;
    }

    private void OnHealthChanged(int current, int maximum)
    {
        if (current <= 0 || targetSprite == null) return;
        if (routine != null) StopCoroutine(routine);
        routine = StartCoroutine(Flash());
    }

    private IEnumerator Flash()
    {
        targetSprite.color = hitColor;
        yield return new WaitForSeconds(flashSeconds);
        targetSprite.color = originalColor;
        routine = null;
    }
}
