# 23일차 — Enemy 체력 및 사망 시스템 (Unity 6.3 계열)

## 21·22일차와 연결
- `EnemyHealth2D.cs`는 22일차 버전을 **교체**합니다. 같은 이름의 클래스를 두 개 두면 컴파일 오류가 납니다.
- 21일차의 `Projectile2D`에서 호출하는 `TakeDamage(int amount)` 서명을 유지합니다.
- `EnemyDeathPresenter2D`를 같은 Enemy GameObject에 추가합니다. 같은 이름의 컴포넌트를 중복으로 추가하지 않습니다.
- 기존 EnemyHealth2D의 Inspector `onHit`/`onDie` UnityEvent 할당은 가능하면 보존하되, 오브젝트 파괴는 새 Presenter 하나만 담당합니다. `onDie`에 기존 Destroy 동작이 연결돼 있다면 **반드시 해제**해야 사망 애니메이션이 재생됩니다.

## 추천 Hierarchy / Inspector
Enemy (Tag: Enemy)
  - Rigidbody2D (선택, Physics 처리시)
  - Collider2D (Is Trigger는 게임 설계에 맞게)
  - EnemyHealth2D (Max Health=100)
  - EnemyDeathPresenter2D (Health/Animator/Colliders/Body/DropPrefab/DespawnDelay 연결)
  - EnemyHitFlash2D (Health / SpriteRenderer 연결)
  - EnemyDamageDebug2D (테스트용)
  - Visual / SpriteRenderer / Animator
  - HP_Canvas (World Space) / BarFill(Image, Type: Filled) / EnemyHealthBar2D

## Animator
- Parameters에 Trigger `Die` 생성(대소문자 동일).
- Any State → Die 또는 적절한 전이를 만들고 Conditions=Die, Has Exit Time 해제.
- Die 애니메이션 클립 Loop Time 끄기. `despawnDelay`는 클립 길이보다 길거나 같게.
- 애니메이션이 없으면 Animator를 비워두어도 됩니다. 그 경우 Delay 후 제거됩니다.

## 테스트 순서
1. HP=100에서 30,30,40 데미지를 적용해 70→40→0으로 감소하는지 확인.
2. 음수 또는 0 데미지를 무시하는지 확인.
3. 사망 후 추가 피해가 무시되고 Drop이 한 번만 생성되는지 확인.
4. 사망 즉시 Collider·Rigidbody 시뮬레이션이 비활성화되는지 확인.
5. Die Animation이 보인 뒤 `despawnDelay` 후 제거되는지 확인.
6. HP UI Fill이 1.0→0.7→0.4→0으로 바뀌는지 확인.
7. Codex로 `git diff` 범위를 확인한 뒤 결과를 기록.

## 유의 사항
- 21일차 발사체 `Projectile2D`는 기본적으로 `OnTriggerEnter2D`에서 `EnemyHealth2D.TakeDamage(int)`를 호출합니다. 발사체에 추가 Damage 스크립트를 붙여 중복 호출하지 마세요.
- Destroy 기반 구현입니다. Object Pool 버전으로 바꾸려면 Enable/Disable 이벤트 해제, HP 재초기화, 지연 정리 타이머 중복 등을 별도로 설계해야 합니다.
- 입력, 발사체 방향, UI 폰트는 프로젝트 환경에 따라 조정합니다.
- Unity 에디터에서 컴파일/실행은 아직 수행하지 않았습니다.
