using System;
using UnityEngine;
using UnityEngine.Events;

/// <summary>22일차 EnemyHealth2D를 이 파일 하나로 교체하세요.</summary>
public class EnemyHealth2D : MonoBehaviour
{
    [SerializeField, Min(1)] private int maxHealth = 100;
    [SerializeField] private UnityEvent onHit;
    [SerializeField] private UnityEvent onDie;

    private int currentHealth;
    private bool isDead;

    public int CurrentHealth => currentHealth;
    public int MaxHealth => maxHealth;
    public bool IsDead => isDead;

    public event Action<int, int> HealthChanged;
    public event Action Died;

    private void Awake()
    {
        maxHealth = Mathf.Max(1, maxHealth);
        currentHealth = maxHealth;
    }

    // 21일차 Projectile2D가 호출하는 시그니처를 그대로 유지합니다.
    public void TakeDamage(int amount)
    {
        if (isDead || amount <= 0) return;

        currentHealth = Mathf.Max(0, currentHealth - amount);
        HealthChanged?.Invoke(currentHealth, maxHealth);
        Debug.Log($"[Enemy] HP {currentHealth}/{maxHealth}", this);

        if (currentHealth > 0)
        {
            onHit?.Invoke();
            return;
        }

        isDead = true;  // 이벤트보다 먼저 중복 사망 차단
        Died?.Invoke();
        onDie?.Invoke();
        // Destroy는 연출 컴포넌트(EnemyDeathPresenter2D)에서 처리합니다.
    }
}
