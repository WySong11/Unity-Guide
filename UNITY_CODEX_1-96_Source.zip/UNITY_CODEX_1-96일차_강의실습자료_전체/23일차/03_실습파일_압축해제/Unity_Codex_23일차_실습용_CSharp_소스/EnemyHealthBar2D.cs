using UnityEngine;
using UnityEngine.UI;

/// <summary>World Space Canvas 아래 Fill 이미지 연결.</summary>
public class EnemyHealthBar2D : MonoBehaviour
{
    [SerializeField] private EnemyHealth2D health;
    [SerializeField] private Image fill;

    private void OnEnable()
    {
        if (health != null) health.HealthChanged += Refresh;
        if (health != null) Refresh(health.CurrentHealth, health.MaxHealth);
    }

    private void OnDisable()
    {
        if (health != null) health.HealthChanged -= Refresh;
    }

    private void Refresh(int current, int maximum)
    {
        if (fill == null) return;
        fill.fillAmount = maximum > 0 ? (float)current / maximum : 0f;
    }
}
