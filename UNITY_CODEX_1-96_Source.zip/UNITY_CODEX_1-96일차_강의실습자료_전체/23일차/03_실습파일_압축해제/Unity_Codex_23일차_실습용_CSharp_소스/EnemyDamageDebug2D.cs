using UnityEngine;

/// <summary>에디터의 컨텍스트 메뉴로 체력 경계값을 확인.</summary>
public class EnemyDamageDebug2D : MonoBehaviour
{
    [SerializeField] private EnemyHealth2D enemy;
    [SerializeField, Min(1)] private int testDamage = 30;

    [ContextMenu("Test / Apply Damage")]
    private void ApplyTestDamage()
    {
        if (Application.isPlaying && enemy != null)
            enemy.TakeDamage(testDamage);
    }
}
