using UnityEngine;

/// <summary>사망 시 충돌 중단, 연출, 드롭, 제거 담당.</summary>
[RequireComponent(typeof(EnemyHealth2D))]
public class EnemyDeathPresenter2D : MonoBehaviour
{
    [SerializeField] private EnemyHealth2D health;
    [SerializeField] private Animator animator;
    [SerializeField] private Collider2D[] collidersToDisable;
    [SerializeField] private Rigidbody2D body;
    [SerializeField] private GameObject dropPrefab;
    [SerializeField, Min(0f)] private float despawnDelay = 0.8f;

    private static readonly int DieHash = Animator.StringToHash("Die");
    private bool handled;

    private void Awake()
    {
        if (health == null) health = GetComponent<EnemyHealth2D>();
        if (animator == null) animator = GetComponentInChildren<Animator>();
        if (body == null) body = GetComponent<Rigidbody2D>();
    }

    private void OnEnable()
    {
        if (health != null) health.Died += HandleDied;
    }

    private void OnDisable()
    {
        if (health != null) health.Died -= HandleDied;
    }

    private void HandleDied()
    {
        if (handled) return;
        handled = true;

        foreach (Collider2D c in collidersToDisable)
            if (c != null) c.enabled = false;
        if (body != null) body.simulated = false;
        if (animator != null) animator.SetTrigger(DieHash);
        if (dropPrefab != null)
            Instantiate(dropPrefab, transform.position, Quaternion.identity);
        Destroy(gameObject, despawnDelay);
    }
}
