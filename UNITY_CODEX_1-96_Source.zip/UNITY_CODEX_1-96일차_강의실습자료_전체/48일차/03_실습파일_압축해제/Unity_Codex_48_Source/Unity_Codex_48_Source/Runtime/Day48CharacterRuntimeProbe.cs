using UnityEngine;

/// <summary>
/// 48일차 선택형 관찰 도구입니다. 기존 게임플레이 데이터를 변경하지 않습니다.
/// 샘플 출력은 Inspector에서 enableSampling을 켰을 때만 실행됩니다.
/// </summary>
public sealed class Day48CharacterRuntimeProbe : MonoBehaviour
{
    [Header("Optional references")]
    [SerializeField] private Transform player;
    [SerializeField] private CharacterController characterController;
    [SerializeField] private Camera targetCamera;

    [Header("Read-only diagnostics")]
    [SerializeField] private bool enableSampling = false;
    [SerializeField, Min(0.1f)] private float sampleIntervalSeconds = 1f;

    private float nextSampleAt;

    private void Awake()
    {
        if (player == null)
            player = transform;

        if (characterController == null)
            characterController = player.GetComponent<CharacterController>();

        if (targetCamera == null)
            targetCamera = Camera.main;
    }

    private void Update()
    {
        if (!enableSampling || Time.unscaledTime < nextSampleAt)
            return;

        nextSampleAt = Time.unscaledTime + sampleIntervalSeconds;
        bool grounded = characterController != null && characterController.isGrounded;
        float cameraDistance = targetCamera != null
            ? Vector3.Distance(player.position, targetCamera.transform.position)
            : -1f;

        Debug.Log($"[Day48Probe] position={player.position}, " +
                  $"grounded={grounded}, cameraDistance={cameraDistance:F2}, " +
                  $"timeScale={Time.timeScale:F2}", this);
    }
}
