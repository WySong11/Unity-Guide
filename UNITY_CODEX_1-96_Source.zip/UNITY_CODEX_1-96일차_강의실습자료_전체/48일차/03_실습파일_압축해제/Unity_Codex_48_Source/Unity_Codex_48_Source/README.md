# Unity × Codex 48일차 — 3D 캐릭터 통합 평가

## 자료 구성
- `Forms/Teacher_Rubric_100.csv`: 교강사용 100점 세부 채점표 (32개 항목)
- `Forms/Day48_Test_Matrix.csv`: 3D 캐릭터 통합 테스트 24개
- `Forms/Student_Self_Evaluation.csv`: 학생 자기평가
- `Forms/Peer_Review.csv`: 동료평가
- `Forms/Submission_Checklist.csv`: 파일 제출 확인표
- `Forms/Evaluation_Example.csv`: **가상 채점 예시**
- `Guides/`: 발표 가이드, 채점 운영 지침, Codex 프롬프트, 평가 후 계획
- `Runtime/Day48CharacterRuntimeProbe.cs`: 선택형 관찰 로그 스크립트
- `Editor/Day48SceneValidatorEditor.cs`: 읽기 전용 씬 점검 메뉴

## 수업 운영
수업 120분: 오리엔테이션 10분 → 시연 준비 10분 → 8팀 기준 발표/시연 80분 → 동료 평가 10분 → 종합 피드백 5분 → 제출 확인 5분. 발표 팀 수가 다른 경우에는 동일한 팀별 시간을 다시 산정하여 공지합니다.

## 채점 영역 / 합계 100
이동·카메라 25 + 전투·체력·UI 25 + 구조·재사용 20 + 안정성·테스트 15 + 발표·시연 10 + 제출물 5 = **100점**.

## 평가 운영 원칙
1. 제출한 빌드와 시연 버전·Git 커밋을 일치시킵니다.
2. 실제 관찰과 주관적 판단을 분리합니다.
3. 반복되는 하나의 문제로 중복 감점하지 않도록 영역별 감점 사유를 명시합니다.
4. 미구현, 실행 실패, 장비 문제, 미검증을 구분합니다.
5. Codex 결과는 평가 보조 자료이며 최종 판단과 실제 Play Mode 검증은 교강사가 수행합니다.

## 선택형 진단 코드 사용
`Day48CharacterRuntimeProbe.cs`는 `enableSampling=false`로 시작합니다. 진단이 필요할 때만 켜고 Console 로그 빈도를 관리하세요. `Day48SceneValidatorEditor.cs`는 프로젝트 `Assets/Editor/`에 넣으면 Tools 메뉴에서 실행할 수 있습니다. 두 파일 모두 점수 산정의 필수 조건이 아닙니다.

**환경 전제:** Unity 6.3 계열에서 구성한 수업 예제 기준. 게임 프로젝트마다 실제 입력·컴포넌트 이름을 확인하세요. 코드의 Unity Editor 컴파일·실행 검증은 별도로 필요합니다.
