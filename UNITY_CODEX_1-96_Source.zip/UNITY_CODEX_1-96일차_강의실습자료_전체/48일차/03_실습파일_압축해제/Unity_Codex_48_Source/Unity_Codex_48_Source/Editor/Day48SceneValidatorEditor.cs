#if UNITY_EDITOR
using System.Text;
using UnityEditor;
using UnityEngine;

/// <summary>
/// 현재 활성 Scene을 읽기 전용으로 확인합니다.
/// 사용자 프로젝트의 GameObject, Prefab, Scene을 수정하지 않습니다.
/// </summary>
public static class Day48SceneValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day48/Validate Active Scene")]
    private static void ValidateActiveScene()
    {
        var controllers = Object.FindObjectsByType<CharacterController>(
            FindObjectsInactive.Include, FindObjectsSortMode.None);
        var animators = Object.FindObjectsByType<Animator>(
            FindObjectsInactive.Include, FindObjectsSortMode.None);
        var cameras = Object.FindObjectsByType<Camera>(
            FindObjectsInactive.Include, FindObjectsSortMode.None);
        var rigidbodies = Object.FindObjectsByType<Rigidbody>(
            FindObjectsInactive.Include, FindObjectsSortMode.None);

        var sb = new StringBuilder();
        sb.AppendLine("[Day48 Scene Validator] 읽기 전용 점검");
        sb.AppendLine($"CharacterController: {controllers.Length}");
        sb.AppendLine($"Animator: {animators.Length}");
        sb.AppendLine($"Camera: {cameras.Length}");
        sb.AppendLine($"Rigidbody: {rigidbodies.Length}");
        sb.AppendLine($"Camera.main found: {Camera.main != null}");
        sb.AppendLine("Input Actions, 공격 이벤트, HUD와 Prefab은 Inspector에서 직접 확인하세요.");
        sb.AppendLine("결과는 자동 합격 판정이 아니며 Play Mode 기능 테스트가 필요합니다.");
        Debug.Log(sb.ToString());
    }
}
#endif
