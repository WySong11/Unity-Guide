using UnityEngine;
using UnityEngine.InputSystem;
public class Day54LabControls : MonoBehaviour
{
    [SerializeField] private Day54MonsterPool monsters;
    [SerializeField] private Day54ProjectilePool projectiles;
    [SerializeField] private Day54WaveSpawner spawner;
    [SerializeField] private Transform muzzle;
    private void Update()
    {
        var keyboard = Keyboard.current;
        if (keyboard == null) return;
        if (keyboard.digit1Key.wasPressedThisFrame) spawner?.StartWave();
        if (keyboard.digit2Key.wasPressedThisFrame) monsters?.DamageAll(9999);
        if (keyboard.digit3Key.wasPressedThisFrame && muzzle != null)
            projectiles?.Fire(muzzle.position, muzzle.forward);
        if (keyboard.digit4Key.wasPressedThisFrame)
        {
            spawner?.StopWave(true);
            projectiles?.ReleaseAll();
        }
    }
}
