using System;
using System.Collections;
using UnityEngine;

[RequireComponent(typeof(Rigidbody), typeof(Collider))]
public class Day54Projectile : MonoBehaviour
{
    [Min(.05f)] [SerializeField] private float lifeSeconds = 2f;
    private Rigidbody rb;
    private Coroutine lifeRoutine;
    private bool inFlight;
    private bool isReturning;
    public event Action<Day54Projectile> ReturnRequested;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
        rb.useGravity = false;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
    }
    public void Launch(Vector3 position, Vector3 direction, float speed)
    {
        StopLifetime();
        if (rb == null) rb = GetComponent<Rigidbody>();
        transform.SetPositionAndRotation(position, Quaternion.LookRotation(direction.normalized));
        rb.linearVelocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
        inFlight = true;
        isReturning = false;
        gameObject.SetActive(true);
        rb.WakeUp();
        rb.linearVelocity = direction.normalized * speed;
        lifeRoutine = StartCoroutine(Lifetime());
    }
    private IEnumerator Lifetime()
    {
        yield return new WaitForSeconds(lifeSeconds);
        RequestReturn();
    }
    private void OnCollisionEnter(Collision collision) { RequestReturn(); }
    private void RequestReturn()
    {
        if (!inFlight || isReturning) return;
        isReturning = true;
        ReturnRequested?.Invoke(this);
    }
    public void PrepareForPool()
    {
        StopLifetime();
        if (rb == null) rb = GetComponent<Rigidbody>();
        rb.linearVelocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
        if (gameObject.activeInHierarchy) rb.Sleep();
        inFlight = false;
        isReturning = false;
    }
    private void StopLifetime()
    {
        if (lifeRoutine == null) return;
        StopCoroutine(lifeRoutine);
        lifeRoutine = null;
    }
}
