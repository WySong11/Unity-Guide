using UnityEngine;
using UnityEngine.AI;
public class Day54SpawnPoint : MonoBehaviour
{
    [Min(0)] [SerializeField] private float radius = 1.5f;
    [SerializeField] private bool requireNavMesh = false;
    [Min(0.1f)] [SerializeField] private float sampleRadius = 1.5f;
    public bool TrySample(out Vector3 position)
    {
        Vector2 offset = Random.insideUnitCircle * radius;
        position = transform.position + new Vector3(offset.x, 0, offset.y);
        if (!requireNavMesh) return true;
        if (!NavMesh.SamplePosition(position, out NavMeshHit hit, sampleRadius, NavMesh.AllAreas)) return false;
        position = hit.position;
        return true;
    }
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(transform.position, radius);
    }
}
