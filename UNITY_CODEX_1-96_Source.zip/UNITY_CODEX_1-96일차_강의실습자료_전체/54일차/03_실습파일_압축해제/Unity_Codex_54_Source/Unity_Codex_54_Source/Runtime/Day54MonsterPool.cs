using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Pool;

/// <summary>몬스터의 소유권·초기 준비·대여·회수를 단독 관리하는 ObjectPool.</summary>
public class Day54MonsterPool : MonoBehaviour
{
    [Header("Prefab / storage")]
    [SerializeField] private Day54Monster prefab;
    [SerializeField] private Transform poolRoot;
    [Header("Capacity")]
    [Min(0)] [SerializeField] private int prewarm = 8;
    [Min(1)] [SerializeField] private int defaultCapacity = 8;
    [Min(1)] [SerializeField] private int maxSize = 30;
    [Header("Spawn / Death")]
    [SerializeField] private bool requireNavMesh = false;
    [Min(0.01f)] [SerializeField] private float navMeshSampleRadius = 1.5f;
    [Min(0)] [SerializeField] private float deathReturnDelay = 0.25f;

    private ObjectPool<Day54Monster> pool;
    private readonly HashSet<Day54Monster> active = new HashSet<Day54Monster>();
    private readonly Dictionary<Day54Monster, Coroutine> pending = new Dictionary<Day54Monster, Coroutine>();

    public int CountActive => active.Count;
    public int CountInactive => pool == null ? 0 : pool.CountInactive;
    public int CountAll => pool == null ? 0 : pool.CountAll;

    private void Awake()
    {
        if (prefab == null) { Debug.LogError("[Day54] Monster prefab missing", this); enabled = false; return; }
        if (poolRoot == null) poolRoot = transform;
        int size = Mathf.Max(1, maxSize);
        pool = new ObjectPool<Day54Monster>(CreateItem, OnGet, OnRelease, OnDestroyItem,
            collectionCheck: true, defaultCapacity: Mathf.Max(1, defaultCapacity), maxSize: size);
        Prewarm(Mathf.Min(prewarm, size));
    }

    private Day54Monster CreateItem()
    {
        var unit = Instantiate(prefab, poolRoot);
        unit.gameObject.SetActive(false);
        unit.Died += HandleDeath;
        return unit;
    }
    private void OnGet(Day54Monster unit) { /* Spawn에서 활성화: Prewarm 중 불필요한 Awake/AI 실행 회피 */ }
    private void OnRelease(Day54Monster unit)
    {
        if (unit == null) return;
        unit.PrepareForPool();
        unit.gameObject.SetActive(false);
    }
    private void OnDestroyItem(Day54Monster unit)
    {
        if (unit == null) return;
        unit.Died -= HandleDeath;
        Destroy(unit.gameObject);
    }

    private void Prewarm(int count)
    {
        // Get -> 즉시 Release를 반복하면 한 객체만 재사용되므로 먼저 모두 Get한다.
        var temp = new List<Day54Monster>(count);
        for (int i = 0; i < count; i++) temp.Add(pool.Get());
        foreach (var unit in temp) pool.Release(unit);
    }

    public bool TrySpawn(Vector3 requestedPosition, out Day54Monster unit)
    {
        unit = null;
        if (pool == null) return false;
        Vector3 position = requestedPosition;
        if (requireNavMesh)
        {
            if (!NavMesh.SamplePosition(position, out NavMeshHit hit, navMeshSampleRadius, NavMesh.AllAreas))
                return false;
            position = hit.position;
        }

        Day54Monster candidate = pool.Get();
        if (!candidate.Spawn(position))
        {
            pool.Release(candidate); // 아직 active에 등록하지 않았으므로 직접 반환
            return false;
        }
        active.Add(candidate);
        unit = candidate;
        return true;
    }

    private void HandleDeath(Day54Monster unit)
    {
        if (!active.Contains(unit) || pending.ContainsKey(unit)) return;
        if (deathReturnDelay <= 0f) { Release(unit); return; }
        pending[unit] = StartCoroutine(ReturnAfterDeath(unit));
    }
    private IEnumerator ReturnAfterDeath(Day54Monster unit)
    {
        yield return new WaitForSeconds(deathReturnDelay);
        pending.Remove(unit);
        Release(unit);
    }

    public bool Release(Day54Monster unit)
    {
        if (unit == null || !active.Remove(unit))
        {
            Debug.LogWarning("[Day54] Duplicate/foreign Monster Release ignored", this);
            return false;
        }
        if (pending.TryGetValue(unit, out Coroutine running))
        {
            if (running != null) StopCoroutine(running);
            pending.Remove(unit);
        }
        pool.Release(unit);
        return true;
    }

    public void ReleaseAll()
    {
        var copy = new List<Day54Monster>(active);
        foreach (Day54Monster unit in copy) Release(unit);
    }

    public void DamageAll(int damage)
    {
        var copy = new List<Day54Monster>(active);
        foreach (Day54Monster unit in copy)
            if (unit != null) unit.TakeDamage(damage);
    }

    private void OnDestroy()
    {
        foreach (var entry in pending)
            if (entry.Value != null) StopCoroutine(entry.Value);
        pending.Clear();
        foreach (Day54Monster unit in active)
            if (unit != null) unit.Died -= HandleDeath;
        active.Clear();
        pool?.Dispose(); // 비활성 풀 요소 정리; 활성 개체는 씬과 함께 파괴됨
    }
}
