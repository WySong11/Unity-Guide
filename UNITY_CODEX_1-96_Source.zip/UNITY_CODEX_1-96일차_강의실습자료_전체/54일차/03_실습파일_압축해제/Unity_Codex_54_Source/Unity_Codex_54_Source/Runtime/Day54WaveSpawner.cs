using System.Collections;
using UnityEngine;

/// <summary>생성 시점·위치·개수만 결정. 인스턴스의 수명은 MonsterPool이 관리.</summary>
public class Day54WaveSpawner : MonoBehaviour
{
    [SerializeField] private Day54MonsterPool pool;
    [SerializeField] private Day54SpawnPoint[] spawnPoints;
    [Min(1)] [SerializeField] private int perWave = 12;
    [Min(1)] [SerializeField] private int maxConcurrent = 8;
    [Min(.02f)] [SerializeField] private float interval = .35f;
    [SerializeField] private bool autoStart = false;
    private Coroutine waveRoutine;
    public int Spawned { get; private set; }
    public bool IsRunning => waveRoutine != null;
    private void Start() { if (autoStart) StartWave(); }
    public void StartWave()
    {
        if (waveRoutine != null || pool == null || spawnPoints == null || spawnPoints.Length == 0) return;
        Spawned = 0;
        waveRoutine = StartCoroutine(SpawnRoutine());
    }
    private IEnumerator SpawnRoutine()
    {
        while (Spawned < perWave)
        {
            if (pool.CountActive < maxConcurrent)
            {
                Day54SpawnPoint point = spawnPoints[Random.Range(0, spawnPoints.Length)];
                if (point != null && point.TrySample(out Vector3 pos) && pool.TrySpawn(pos, out _))
                    Spawned++; // 실제 성공 시에만 증가
            }
            yield return new WaitForSeconds(interval);
        }
        while (pool.CountActive > 0) yield return new WaitForSeconds(.2f);
        waveRoutine = null;
        Debug.Log("[Day54] Wave complete", this);
    }
    public void StopWave(bool releaseAll)
    {
        if (waveRoutine != null) StopCoroutine(waveRoutine);
        waveRoutine = null;
        if (releaseAll && pool != null) pool.ReleaseAll();
    }
    private void OnDisable() { StopWave(false); }
}
