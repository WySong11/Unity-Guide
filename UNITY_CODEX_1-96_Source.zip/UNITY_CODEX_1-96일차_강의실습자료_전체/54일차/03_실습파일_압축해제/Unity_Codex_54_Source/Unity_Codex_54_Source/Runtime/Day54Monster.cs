using System;
using UnityEngine;
using UnityEngine.AI;

/// <summary>Day54 독립 실습용 몬스터. 실제 프로젝트는 52일차 AI와 어댑터로 연결합니다.</summary>
public class Day54Monster : MonoBehaviour
{
    [Min(1)] [SerializeField] private int maxHealth = 100;
    private NavMeshAgent agent;
    private bool isSpawned;
    private bool isDead;
    private int health;
    public event Action<Day54Monster> Died;
    public int Health => health;
    public bool IsSpawned => isSpawned;

    private void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        health = maxHealth;
    }

    public bool Spawn(Vector3 position)
    {
        if (agent == null) agent = GetComponent<NavMeshAgent>();
        transform.position = position;
        health = maxHealth;
        isDead = false;
        isSpawned = true;
        gameObject.SetActive(true);

        if (agent != null && agent.enabled)
        {
            // NavMesh 베이크 이후에만 Agent가 정상적으로 바인딩됩니다.
            if (!agent.isOnNavMesh || !agent.Warp(position))
            {
                PrepareForPool();
                gameObject.SetActive(false);
                return false;
            }
            agent.ResetPath();
            agent.isStopped = false;
        }
        return true;
    }

    public void TakeDamage(int damage)
    {
        if (!isSpawned || isDead || damage <= 0) return;
        health = Mathf.Max(0, health - damage);
        if (health != 0) return;
        isDead = true;
        Died?.Invoke(this); // 정확히 한 번 발행
    }

    public void PrepareForPool()
    {
        isSpawned = false;
        isDead = false;
        StopAllCoroutines();
        if (agent != null && agent.enabled && agent.isOnNavMesh)
        {
            agent.ResetPath();
            agent.isStopped = true;
        }
        health = maxHealth;
    }
}
