using System.Collections;
using UnityEngine;
/// <summary>기초 반복 검사. 수치를 Profiler와 함께 기록하세요.</summary>
public class Day54PoolStressTest : MonoBehaviour
{
    [SerializeField] private Day54MonsterPool monsters;
    [SerializeField] private Transform center;
    [Min(1)] [SerializeField] private int cycles = 100;
    [Min(1)] [SerializeField] private int batchSize = 8;
    [Min(0)] [SerializeField] private float cycleDelay = .03f;
    private bool running;
    [ContextMenu("Run Stress Test")]
    public void Run()
    {
        if (!Application.isPlaying || running || monsters == null) return;
        StartCoroutine(TestRoutine());
    }
    private IEnumerator TestRoutine()
    {
        running = true;
        for (int i = 0; i < cycles; i++)
        {
            for (int j = 0; j < batchSize; j++)
            {
                Vector3 origin = center != null ? center.position : transform.position;
                monsters.TrySpawn(origin + new Vector3(j * 1.2f, 0f, 0f), out _);
            }
            monsters.ReleaseAll();
            yield return cycleDelay <= 0 ? null : new WaitForSeconds(cycleDelay);
        }
        Debug.Log($"[Day54] Stress done: All={monsters.CountAll} Active={monsters.CountActive} Inactive={monsters.CountInactive}");
        running = false;
    }
}
