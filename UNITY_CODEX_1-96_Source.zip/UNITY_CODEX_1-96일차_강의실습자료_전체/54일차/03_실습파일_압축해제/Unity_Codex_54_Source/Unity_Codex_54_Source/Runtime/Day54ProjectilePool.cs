using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

public class Day54ProjectilePool : MonoBehaviour
{
    [SerializeField] private Day54Projectile prefab;
    [Min(0)] [SerializeField] private int prewarm = 20;
    [Min(1)] [SerializeField] private int maxSize = 60;
    [Min(.1f)] [SerializeField] private float speed = 16f;
    private ObjectPool<Day54Projectile> pool;
    private readonly HashSet<Day54Projectile> active = new HashSet<Day54Projectile>();
    public int CountActive => active.Count;
    public int CountInactive => pool == null ? 0 : pool.CountInactive;
    public int CountAll => pool == null ? 0 : pool.CountAll;

    private void Awake()
    {
        if (prefab == null) { Debug.LogError("[Day54] Projectile prefab missing", this); enabled = false; return; }
        pool = new ObjectPool<Day54Projectile>(Create, null, OnRelease, OnDestroyItem,
            collectionCheck: true, defaultCapacity: Mathf.Max(1, prewarm), maxSize: Mathf.Max(1, maxSize));
        var temp = new List<Day54Projectile>();
        for (int i = 0; i < Mathf.Min(prewarm, maxSize); i++) temp.Add(pool.Get());
        foreach (var proj in temp) pool.Release(proj);
    }
    private Day54Projectile Create()
    {
        var obj = Instantiate(prefab, transform);
        obj.gameObject.SetActive(false);
        obj.ReturnRequested += Return;
        return obj;
    }
    private void OnRelease(Day54Projectile obj)
    {
        if (obj == null) return;
        obj.PrepareForPool();
        obj.gameObject.SetActive(false);
    }
    private void OnDestroyItem(Day54Projectile obj)
    {
        if (obj == null) return;
        obj.ReturnRequested -= Return;
        Destroy(obj.gameObject);
    }
    public bool Fire(Vector3 position, Vector3 direction)
    {
        if (pool == null || direction.sqrMagnitude < 0.0001f) return false;
        var bullet = pool.Get();
        active.Add(bullet);
        bullet.Launch(position, direction, speed);
        return true;
    }
    public void Return(Day54Projectile bullet)
    {
        if (bullet == null || !active.Remove(bullet)) return; // 런타임 중복 방어
        pool.Release(bullet);
    }
    public void ReleaseAll()
    {
        var copy = new List<Day54Projectile>(active);
        foreach (var bullet in copy) Return(bullet);
    }
    private void OnDestroy()
    {
        foreach (var obj in active)
            if (obj != null) obj.ReturnRequested -= Return;
        active.Clear();
        pool?.Dispose();
    }
}
