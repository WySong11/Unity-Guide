using UnityEngine;
public class Day54PoolHUD : MonoBehaviour
{
    [SerializeField] private Day54MonsterPool monsters;
    [SerializeField] private Day54ProjectilePool projectiles;
    [SerializeField] private Day54WaveSpawner spawner;
    private void OnGUI()
    {
        GUILayout.BeginArea(new Rect(16, 16, 400, 170), GUI.skin.box);
        GUILayout.Label("[Day54 ObjectPool Lab]");
        if (monsters != null)
            GUILayout.Label($"Monster: All={monsters.CountAll} Active={monsters.CountActive} Inactive={monsters.CountInactive}");
        if (projectiles != null)
            GUILayout.Label($"Projectile: All={projectiles.CountAll} Active={projectiles.CountActive} Inactive={projectiles.CountInactive}");
        if (spawner != null)
            GUILayout.Label($"Wave: spawned={spawner.Spawned}, running={spawner.IsRunning}");
        GUILayout.Label("[1] Wave  [2] Damage All  [3] Fire  [4] Release All");
        GUILayout.EndArea();
    }
}
