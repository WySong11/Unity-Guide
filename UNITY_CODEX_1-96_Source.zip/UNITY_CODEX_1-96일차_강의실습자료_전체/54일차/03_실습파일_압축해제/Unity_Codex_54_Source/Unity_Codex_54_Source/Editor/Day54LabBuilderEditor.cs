#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Tools/Unity Codex/Day54/Build ObjectPool Lab: 독립 실습 씬과 Prefab 생성.</summary>
public static class Day54LabBuilderEditor
{
    private const string Root = "Assets/Day54_ObjectPoolLab";

    [MenuItem("Tools/Unity Codex/Day54/Build ObjectPool Lab")]
    private static void Build()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        EnsureFolders();
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
        floor.name = "Ground";
        floor.transform.position = new Vector3(0, -.5f, 0);
        floor.transform.localScale = new Vector3(24, 1, 24);

        var mainCam = new GameObject("Main Camera");
        mainCam.tag = "MainCamera";
        mainCam.AddComponent<Camera>();
        mainCam.AddComponent<AudioListener>();
        mainCam.transform.position = new Vector3(0, 12, -17);
        mainCam.transform.LookAt(Vector3.zero);

        var light = new GameObject("Directional Light");
        var lamp = light.AddComponent<Light>();
        lamp.type = LightType.Directional;
        lamp.intensity = 1f;
        light.transform.rotation = Quaternion.Euler(50, -30, 0);

        var monsterPrefab = MakeMonsterPrefab();
        var projectilePrefab = MakeProjectilePrefab();
        var monsterPoolGo = new GameObject("MonsterPool");
        var monsters = monsterPoolGo.AddComponent<Day54MonsterPool>();
        SetReference(monsters, "prefab", monsterPrefab);

        var projectilePoolGo = new GameObject("ProjectilePool");
        var bullets = projectilePoolGo.AddComponent<Day54ProjectilePool>();
        SetReference(bullets, "prefab", projectilePrefab);

        var points = new Day54SpawnPoint[3];
        for (int i = 0; i < points.Length; i++)
        {
            var spawnGo = new GameObject("SpawnPoint_" + (i + 1));
            spawnGo.transform.position = new Vector3(-6 + 6 * i, .1f, 3f);
            points[i] = spawnGo.AddComponent<Day54SpawnPoint>();
        }

        var waveGo = new GameObject("WaveSpawner");
        var wave = waveGo.AddComponent<Day54WaveSpawner>();
        SetReference(wave, "pool", monsters);
        var so = new SerializedObject(wave);
        var prop = so.FindProperty("spawnPoints");
        prop.arraySize = points.Length;
        for (int i = 0; i < points.Length; i++) prop.GetArrayElementAtIndex(i).objectReferenceValue = points[i];
        so.ApplyModifiedPropertiesWithoutUndo();

        var muzzle = new GameObject("ProjectileMuzzle");
        muzzle.transform.SetPositionAndRotation(new Vector3(0, 1.4f, -5f), Quaternion.identity);
        var hudGo = new GameObject("DebugHUD");
        var hud = hudGo.AddComponent<Day54PoolHUD>();
        SetReference(hud, "monsters", monsters);
        SetReference(hud, "projectiles", bullets);
        SetReference(hud, "spawner", wave);
        var inputs = hudGo.AddComponent<Day54LabControls>();
        SetReference(inputs, "monsters", monsters);
        SetReference(inputs, "projectiles", bullets);
        SetReference(inputs, "spawner", wave);
        SetReference(inputs, "muzzle", muzzle.transform);

        var stress = new GameObject("StressTest").AddComponent<Day54PoolStressTest>();
        SetReference(stress, "monsters", monsters);
        var path = AssetDatabase.GenerateUniqueAssetPath(Root + "/Scenes/Day54_ObjectPool_Lab.unity");
        EditorSceneManager.SaveScene(scene, path);
        AssetDatabase.SaveAssets();
        EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<SceneAsset>(path));
        Debug.Log("[Day54] New lab scene created: " + path + " (NavMesh optional; bake separately if Agent added)");
    }

    private static Day54Monster MakeMonsterPrefab()
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        go.name = "Day54_Monster";
        go.transform.localScale = Vector3.one * 1.1f;
        var unit = go.AddComponent<Day54Monster>();
        string path = AssetDatabase.GenerateUniqueAssetPath(Root + "/Prefabs/Day54_Monster.prefab");
        var asset = PrefabUtility.SaveAsPrefabAsset(go, path);
        Object.DestroyImmediate(go);
        return asset.GetComponent<Day54Monster>();
    }
    private static Day54Projectile MakeProjectilePrefab()
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        go.name = "Day54_Projectile";
        go.transform.localScale = Vector3.one * .3f;
        go.AddComponent<Rigidbody>().useGravity = false;
        go.AddComponent<Day54Projectile>();
        string path = AssetDatabase.GenerateUniqueAssetPath(Root + "/Prefabs/Day54_Projectile.prefab");
        var asset = PrefabUtility.SaveAsPrefabAsset(go, path);
        Object.DestroyImmediate(go);
        return asset.GetComponent<Day54Projectile>();
    }
    private static void SetReference(Object target, string field, Object value)
    {
        var so = new SerializedObject(target);
        var property = so.FindProperty(field);
        if (property == null) { Debug.LogError("[Day54] Missing serialized field: " + field); return; }
        property.objectReferenceValue = value;
        so.ApplyModifiedPropertiesWithoutUndo();
    }
    private static void EnsureFolders()
    {
        if (!AssetDatabase.IsValidFolder(Root)) AssetDatabase.CreateFolder("Assets", "Day54_ObjectPoolLab");
        foreach (var name in new [] { "Prefabs", "Scenes" })
            if (!AssetDatabase.IsValidFolder(Root + "/" + name)) AssetDatabase.CreateFolder(Root, name);
    }
}
#endif
