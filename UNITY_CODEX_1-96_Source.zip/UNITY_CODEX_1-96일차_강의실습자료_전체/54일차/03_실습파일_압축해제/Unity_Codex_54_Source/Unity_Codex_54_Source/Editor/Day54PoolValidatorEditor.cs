#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

public static class Day54PoolValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day54/Validate Pools")]
    private static void Validate()
    {
        var monsters = Object.FindObjectsByType<Day54MonsterPool>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        var projectiles = Object.FindObjectsByType<Day54ProjectilePool>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        var waves = Object.FindObjectsByType<Day54WaveSpawner>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        Debug.Log($"[Day54 Validator] MonsterPool={monsters.Length}, ProjectilePool={projectiles.Length}, WaveSpawner={waves.Length}");
        foreach (var mon in monsters)
        {
            SerializedObject so = new SerializedObject(mon);
            if (so.FindProperty("prefab").objectReferenceValue == null)
                Debug.LogError("[Day54] Monster prefab not assigned", mon);
            if (so.FindProperty("prewarm").intValue > so.FindProperty("maxSize").intValue)
                Debug.LogWarning("[Day54] Prewarm exceeds maxSize", mon);
        }
        foreach (var pro in projectiles)
        {
            SerializedObject so = new SerializedObject(pro);
            if (so.FindProperty("prefab").objectReferenceValue == null)
                Debug.LogError("[Day54] Projectile prefab not assigned", pro);
        }
        if (monsters.Length == 0 || projectiles.Length == 0 || waves.Length == 0)
            Debug.LogWarning("[Day54] Missing one or more lab systems");
    }
}
#endif
