# 54일차 Codex 지시 프롬프트

## Prompt A — 코드 구조 검사
```
Unity 6.3 / Day54 ObjectPool 실습 프로젝트를 검토해줘.
현재 코드를 수정하기 전에 아래 사항을 분석하고 문제점만 보고해줘.
1) MonsterPool / ProjectilePool의 유일한 Get/Release 소유권
2) defaultCapacity / Prewarm / maxSize 의미와 실제 초기 객체 수
3) Monster의 HP·FSM·Animator·NavMesh 상태 재사용 초기화
4) Projectile의 velocity·lifetime·collision 중복 반환 방어
5) 씬과 Prefab 레퍼런스 / null / 추가 생성 가능성
분석 근거로 관련 파일과 메서드를 지목하고, 변경 제안의 위험도를 적어줘.
```

## Prompt B — 최소 범위 개선
```
방금 확인한 문제 중 실제 재현된 [오류 이름]만 수정해줘.
- Day53/Day52 원본과 기존 Scene을 유지할 것
- 외부 API / C# 클래스명 변경 금지 (필요시 사전 보고)
- Pool 생명주기와 상태 초기화에 필요한 최소 변경만 적용
- 변경 전후 git diff와 기대 동작·부작용·회귀 테스트를 보고
- Unity Editor 실행이 불가능하면 테스트를 실행했다고 주장하지 말 것
```

## Prompt C — 반복 테스트
```
Unity Editor에서 가능한 도구 범위 안에서 Object Pool 안정성을 테스트해줘.
TC01: Prewarm(8) 직후 8/0/8
TC02: 3개 Get → 8/3/5 → Release 후 8/0/8
TC03: Monster 죽은 후 재사용해도 HP와 AI 초기화
TC04: Projectile 충돌+수명 만료 중복 반환 차단
TC05: 100회/500회 스폰 반복 후 CountAll 추이 기록
TC06: 일시정지·재시작 후 이전 Coroutine의 반환 간섭 없음
실행 가능한 검사는 실제 로그·스크린샷을 남기고, 검증하지 못한 검사는 미검증으로 표시해줘.
```
