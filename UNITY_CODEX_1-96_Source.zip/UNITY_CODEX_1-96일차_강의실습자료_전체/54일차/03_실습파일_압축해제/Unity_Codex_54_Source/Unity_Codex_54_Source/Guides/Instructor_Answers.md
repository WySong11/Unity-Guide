# 54일차 강사용 정답·설명

1. `createFunc`: 풀이 비어 있을 때 새 객체 만들기. `actionOnGet`: 풀에서 꺼낸 후 동작. `actionOnRelease`: 반환 시 정리/비활성. `actionOnDestroy`: 보관 한도 초과 등으로 객체를 폐기할 때 실행.
2. `defaultCapacity`: Stack의 초기 내부 용량일 뿐 객체 선생성을 실행하지 않음.
3. 1개. 하나를 반환하면 다음 Get이 같은 객체를 다시 가져오므로 실제 20개가 만들어지지 않음. Get을 20번 모았다가 Release해야 함.
4. `maxSize`는 주로 풀에 **보관할 비활성 객체의 상한**, `maxConcurrent`는 Spawner의 **활성화 동시 수 제한**.
5. Prewarm=8이면 초기 All=8, Active=0, Inactive=8 (생성·해제 콜백이 정상이라는 전제).
6. 스폰 3번이면 All=8, Active=3, Inactive=5, 모두 반환 후 8/0/8.
7. 스폰 최대 제한보다 생성 요청이 많아도 Pool.Get이 추가 객체를 만들 수 있음. 활성을 제한하려면 Spawner 가드 필요.
8. 플레이어와 Agent가 교전 중 사망하면 Animator/Brain/Agent 경로·타이머 등 이전 상태가 다음 Spawn에 남지 않도록 초기화.
9. Projectile 중복 반환의 대표 원인은 충돌·수명 만료가 같은 프레임에 발생하는 경우. `isReturning`과 Pool의 `HashSet`으로 이중 방어.
10. 성능은 기기·시나리오마다 다르므로 `CountAll`만이 아니라 Profiler CPU Usage, GC Alloc, Memory와 프레임 타임을 함께 기록해야 함.
