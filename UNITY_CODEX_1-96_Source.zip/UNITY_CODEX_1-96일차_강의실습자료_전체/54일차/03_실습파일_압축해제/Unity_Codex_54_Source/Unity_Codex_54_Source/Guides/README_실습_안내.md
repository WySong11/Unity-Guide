# 54일차 — ObjectPool 설계 실습 (Unity 6.3)

> 핵심 학습: `UnityEngine.Pool.ObjectPool<T>`의 책임 분리, 실제 Prewarm, `Get`/`Release` 수명주기, 재사용 상태 초기화, 런타임 중복 반환 방어, Profiler 검증.

## 1. 개발 환경
- Unity **6.3 (6000.3 계열)** / **Universal 3D(URP)** 권장
- Input System 패키지가 설치되고 **Active Input Handling**에 Input System이 활성화된 프로젝트
- `UnityEngine.Pool.ObjectPool<T>` 사용 (별도 에셋 불필요)
- 실습 씬 기본 생성은 **NavMesh가 없어도 동작**하도록 설계했음
- NavMeshAgent를 추가할 경우 **AI Navigation을 구성하고 NavMesh Bake** 후 사용해야 함

## 2. 설치
1. `Runtime/*.cs` → `Assets/Day54_ObjectPoolLab/Runtime/`에 복사
2. `Editor/*.cs` → `Assets/Day54_ObjectPoolLab/Editor/`에 복사 (`Editor` 폴더 필수)
3. 컴파일 오류가 없는지 Unity Console에서 확인
4. **Tools → Unity Codex → Day54 → Build ObjectPool Lab** 실행
5. 새로 생성된 `Day54_ObjectPool_Lab.unity` 씬이 열렸는지 확인
6. **Tools → Unity Codex → Day54 → Validate Pools** 실행
7. Play 클릭 후 Game 뷰 좌측 상단의 풀 카운터 확인

Editor 도구는 원래 씬을 자동으로 덮어쓰지 않습니다. 저장되지 않은 씬 변경 사항은 저장 여부를 물으며, 새 폴더/에셋 경로가 이미 있으면 고유 경로를 생성합니다.

## 3. 키 조작
| 키 | 실습 기능 |
|---|---|
| `1` | Monster Wave 시작 (한 Wave에 12마리 생성 시도, 최대 동시 8마리) |
| `2` | 활성 Monster 전체에 큰 데미지 → 사망 후 Pool 반환 |
| `3` | Muzzle 방향으로 Projectile 한 발 발사 |
| `4` | 현재 Wave 취소 + Monster·Projectile 모두 Pool 반환 |

### 반드시 알아야 할 초기 상태
- **Prewarm**은 `Get` 결과를 목록에 모두 보관했다가 `Release` 하여 실제 프리팹 인스턴스를 생성합니다.
- `defaultCapacity`는 **스택 초기 용량**이지, GameObject를 자동으로 선생성하는 기능이 아닙니다.
- `maxSize`는 **비활성 객체 저장 한도**이며 활성 몬스터 수 제한은 `Day54WaveSpawner.maxConcurrent`가 담당합니다.
- 실습 몬스터는 일부러 AI를 배제하고 **풀링과 수명주기**를 관찰하도록 했습니다. **52일차 FSM이 자동 연결되지는 않습니다.**
- 죽은 몬스터는 `deathReturnDelay` 만큼 기다렸다가 반환합니다. `Time.timeScale=0`에서는 해당 WaitForSeconds도 멈춥니다.

## 4. Inspector 권장 시작값
| GameObject | 항목 | 기본값 |
|---|---|---|
| MonsterPool | prewarm / defaultCapacity / maxSize | 8 / 8 / 30 |
| MonsterPool | requireNavMesh | false (Bake 전 독립 실습) |
| MonsterPool | deathReturnDelay | 0.25s |
| ProjectilePool | prewarm / maxSize / speed | 20 / 60 / 16 |
| WaveSpawner | perWave / maxConcurrent / interval | 12 / 8 / 0.35s |

## 5. 53일차·52일차 시스템과 연동할 때
- 53일차 `Day53MonsterPool`, `Day53WaveSpawner`와 54일차 풀을 **같은 몬스터에 이중 적용하지 않습니다.** 비교 실습은 별도 씬에서 수행합니다.
- 52일차 `Day52EnemyBrain`과 연결하려면 전용 **Respawn Adapter**를 설계합니다.
  - `OnSpawn`: Health 최대치 복구 → NavMeshAgent 유효 지점/`Warp` → Brain 최초 상태로 초기화 → Animator 상태 초기화
  - `OnDespawn`: Brain 중지 → 코루틴/타이머 취소 → NavMesh 경로 정지 → Event 구독 상태 점검
- 이 패키지의 `Day54Monster`는 단순한 실습 스텁이며 **52일차 코드 변경 없이 완전 통합된 AI가 아닙니다.**

## 6. 필수 테스트
- Start 직후 Monster `All=8, Active=0, Inactive=8`인지 확인
- `1`을 누르고 활성 몬스터 8마리까지 증가하면 새 생성이 대기하는지 확인
- `2`를 누른 뒤 딜레이 경과 후 Active가 0이 되고 Inactive가 증가하는지 확인
- 다시 `1`을 눌러 새 인스턴스만 늘어나지 않고 기존 개체가 재사용되는지 확인
- `3`으로 발사한 Projectile이 충돌 또는 수명 만료 후 1회만 반환되는지 확인
- `4`로 모두 반환해도 중복 Release 오류가 없는지 확인
- `Day54PoolStressTest` 컴포넌트 컨텍스트 메뉴에서 **Run Stress Test** 실행 (Play 모드 전용)

## 7. 코드 구조와 주의사항
- `Day54MonsterPool`과 `Day54ProjectilePool`이 유일한 `Release()` 창구입니다.
- `Day54Monster`의 `Died` 이벤트는 체력 0에 도달한 순간 한 번만 발행됩니다.
- `Day54Projectile`은 `isReturning` 가드로 충돌과 수명 만료의 중복 반환을 방지합니다.
- 카운터는 **한 실습 씬에서** 일관되게 비교합니다. 다른 스크립트가 오브젝트를 직접 `Destroy()`하지 않도록 합니다.
- Pool 성능의 개선 효과는 보장되지 않으며 **Profiler의 실측**을 기준으로 판단합니다.
- 실제 Unity Editor에서의 컴파일·Play Mode 검증은 **수강생과 강사가 수행해야 합니다.**

## 8. 참고 문서 (Unity 공식)
- ObjectPool: https://docs.unity3d.com/ScriptReference/Pool.ObjectPool_1.html
- 생성자: https://docs.unity3d.com/ScriptReference/Pool.ObjectPool_1-ctor.html
- IObjectPool: https://docs.unity3d.com/ScriptReference/Pool.IObjectPool_1.html
- NavMeshAgent.Warp: https://docs.unity3d.com/ScriptReference/AI.NavMeshAgent.Warp.html
