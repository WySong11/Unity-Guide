# 54일차 학생 워크시트 — ObjectPool 설계

## A. 코드 읽기
1. `CreateItem`, `OnGet`, `OnRelease`, `OnDestroyItem` 각각의 책임을 자신의 언어로 설명하시오.
2. `defaultCapacity=20`을 설정해도 Start 직후 실제 Monster가 20개 생성되지 않는 이유는?
3. Prewarm 코드에서 한 개씩 Get→Release하는 실수가 발생하면 몇 개의 인스턴스만 유지되는가?
4. `maxSize=30`의 의미와 `maxConcurrent=8`의 의미가 어떻게 다른가?

## B. 구현 실습
- [ ] Pool 생성자 콜백을 Inspector 기본값으로 실행한다.
- [ ] `Prewarm=8` 직후 CountInactive를 확인한다.
- [ ] `1`로 Wave를 실행하고 Active/Inactive 변화를 기록한다.
- [ ] 몬스터 사망 후 두 번째 Wave를 시작하여 HP가 초기화됐는지 확인한다.
- [ ] `3`으로 Projectile 10회 발사 후 속도와 수명 초기화를 관찰한다.
- [ ] 500회 반복 테스트 시 유실·중복 객체가 없는지 기록한다.

## C. 실제 관찰 값
| 단계 | CountAll | CountActive | CountInactive | 메모 |
|---|---:|---:|---:|---|
| Prewarm 직후 | | | | |
| 3마리 스폰 | | | | |
| 3마리 반환 | | | | |
| Wave 종료 | | | | |
| 100회 반복 | | | | |

## D. Codex 디버깅
발견한 오류를 한 가지 선택해 기록하시오.
- 오류 증상 / 재현 단계:
- Console Stack Trace:
- CountAll / Active / Inactive:
- 예상 원인과 수정 범위:
- 실제 수정 사항 (`git diff`):
- 수정 후 회귀 테스트 결과:

## E. 제출물
- 새 씬·Prefab·스크립트, Inspector 사진 2장 이상, HUD 변화 사진 3장 이상
- Profiler 캡처, 테스트 체크리스트, Codex 변경 보고
