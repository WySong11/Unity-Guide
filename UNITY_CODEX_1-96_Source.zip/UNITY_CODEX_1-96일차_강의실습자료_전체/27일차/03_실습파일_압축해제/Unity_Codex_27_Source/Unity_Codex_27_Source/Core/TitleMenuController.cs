using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// TitleScene 메뉴 버튼 담당. Button > On Click()에서 public 메서드를 연결합니다.
/// </summary>
public sealed class TitleMenuController : MonoBehaviour
{
    [Header("Scene Names (Build Profiles > Scene List)")]
    [SerializeField] private string gameSceneName = "GameScene";

    private bool isLoading;

    private void Awake()
    {
        // 이전 씬에서 일시정지한 상태가 넘어오지 않도록 항상 복구합니다.
        Time.timeScale = 1f;
    }

    public void StartGame()
    {
        if (isLoading)
            return;

        if (string.IsNullOrWhiteSpace(gameSceneName) ||
            !Application.CanStreamedLevelBeLoaded(gameSceneName))
        {
            Debug.LogError($"[Title] Scene List에서 '{gameSceneName}' 씬을 확인하세요.", this);
            return;
        }

        StartCoroutine(LoadGameScene());
    }

    private IEnumerator LoadGameScene()
    {
        isLoading = true;  // 시작 버튼 연타 방지
        AsyncOperation loading = SceneManager.LoadSceneAsync(gameSceneName);
        if (loading == null)
        {
            isLoading = false;
            yield break;
        }

        while (!loading.isDone)
            yield return null;
    }

    public void QuitGame()
    {
        Time.timeScale = 1f;
#if UNITY_EDITOR
        // 에디터에서는 Application.Quit()이 Play Mode를 종료하지 않습니다.
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}
