using UnityEngine;

/// <summary>
/// 강의 테스트 전용. 버튼에 메서드를 연결해 결과/점수 흐름을 확인합니다.
/// 실제 게임에서는 적 처치·골인·사망 이벤트에서 GameFlowController를 호출합니다.
/// </summary>
public sealed class Day27DebugButtons : MonoBehaviour
{
    [SerializeField] private GameFlowController gameFlow;
    [SerializeField] private int demoScore;

    public void AddDemoScore100()
    {
        demoScore += 100;
        if (gameFlow != null) gameFlow.SetScore(demoScore);
    }

    public void Win()
    {
        if (gameFlow != null) gameFlow.ShowVictory();
    }

    public void Lose()
    {
        if (gameFlow != null) gameFlow.ShowDefeat();
    }
}
