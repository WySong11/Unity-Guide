using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>
/// GameScene의 진행 상태, 결과 UI, 씬 이동을 담당합니다.
/// 26일차 체력/점수 컴포넌트와의 연결은 Optional_Day26_Integration을 사용합니다.
/// </summary>
public sealed class GameFlowController : MonoBehaviour
{
    public enum GameState { Playing, Paused, Finished, Transitioning }

    [Header("Panels (GameScene)")]
    [SerializeField] private GameObject pausePanel;
    [SerializeField] private GameObject resultPanel;
    [SerializeField] private TMP_Text resultTitleText;
    [SerializeField] private TMP_Text finalScoreText;

    [Header("Scenes (Build Profiles > Scene List)")]
    [SerializeField] private string titleSceneName = "TitleScene";
    [SerializeField] private string gameSceneName = "GameScene";

    [Header("Input")]
    [SerializeField] private bool allowEscapePause = true;

    private bool isLoading;
    private int currentScore;
    public GameState CurrentState { get; private set; }
    public event Action<GameState> StateChanged;

    private void Awake()
    {
        Time.timeScale = 1f; // 이전 Play Mode 또는 씬의 정지 상태 복구
        if (pausePanel != null) pausePanel.SetActive(false);
        if (resultPanel != null) resultPanel.SetActive(false);
        ChangeState(GameState.Playing);
    }

    private void Update()
    {
        if (!allowEscapePause || isLoading)
            return;

        bool pressed = false;
#if ENABLE_INPUT_SYSTEM
        pressed = Keyboard.current != null && Keyboard.current.escapeKey.wasPressedThisFrame;
#elif ENABLE_LEGACY_INPUT_MANAGER
        pressed = Input.GetKeyDown(KeyCode.Escape);
#endif
        if (!pressed)
            return;

        if (CurrentState == GameState.Playing) PauseGame();
        else if (CurrentState == GameState.Paused) ResumeGame();
    }

    public void SetScore(int score)
    {
        currentScore = Mathf.Max(0, score);
        // 점수 데이터의 진실값은 26일차 GameScore에서 유지합니다.
    }

    public void PauseGame()
    {
        if (CurrentState != GameState.Playing || isLoading) return;
        if (pausePanel != null) pausePanel.SetActive(true);
        Time.timeScale = 0f;
        ChangeState(GameState.Paused);
    }

    public void ResumeGame()
    {
        if (CurrentState != GameState.Paused || isLoading) return;
        if (pausePanel != null) pausePanel.SetActive(false);
        Time.timeScale = 1f;
        ChangeState(GameState.Playing);
    }

    // 27일차에는 결과 화면을 구현합니다. 성공/실패 판정 로직은 게임마다 다릅니다.
    public void ShowVictory() => ShowResult(true);
    public void ShowDefeat() => ShowResult(false);

    private void ShowResult(bool isVictory)
    {
        if (isLoading || CurrentState == GameState.Finished ||
            CurrentState == GameState.Transitioning)
            return;

        if (pausePanel != null) pausePanel.SetActive(false);
        if (resultPanel != null) resultPanel.SetActive(true);
        if (resultTitleText != null)
            resultTitleText.text = isVictory ? "VICTORY!" : "GAME OVER";
        if (finalScoreText != null)
            finalScoreText.text = $"SCORE  {currentScore:N0}";

        Time.timeScale = 0f;  // 결과 화면이 열린 동안 게임 진행 정지
        ChangeState(GameState.Finished);
    }

    public void RestartGame() => LoadScene(gameSceneName);
    public void ReturnToTitle() => LoadScene(titleSceneName);

    private void LoadScene(string sceneName)
    {
        if (isLoading) return;
        if (string.IsNullOrWhiteSpace(sceneName) ||
            !Application.CanStreamedLevelBeLoaded(sceneName))
        {
            Debug.LogError($"[GameFlow] Scene List에서 '{sceneName}' 씬을 확인하세요.", this);
            return;
        }
        StartCoroutine(LoadSceneRoutine(sceneName));
    }

    private IEnumerator LoadSceneRoutine(string sceneName)
    {
        isLoading = true;
        ChangeState(GameState.Transitioning);
        Time.timeScale = 1f;  // 반드시 씬 전환 전에 정상 속도로 복원

        AsyncOperation loading = SceneManager.LoadSceneAsync(sceneName);
        if (loading == null)
        {
            isLoading = false;
            ChangeState(GameState.Playing);
            yield break;
        }
        while (!loading.isDone)
            yield return null;
    }

    private void ChangeState(GameState next)
    {
        if (CurrentState == next) return;
        CurrentState = next;
        StateChanged?.Invoke(next);
    }

    private void OnApplicationQuit() => Time.timeScale = 1f;
}
