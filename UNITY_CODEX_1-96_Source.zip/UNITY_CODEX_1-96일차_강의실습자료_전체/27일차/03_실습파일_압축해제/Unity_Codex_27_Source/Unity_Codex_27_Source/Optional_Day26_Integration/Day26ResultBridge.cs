using UnityEngine;

/// <summary>
/// 선택 파일: 26일차 PlayerHealth와 GameScore 클래스가 프로젝트에 있을 때만
/// 이 파일을 Assets에 복사하세요. 없으면 컴파일 오류가 납니다.
/// 26일차 PlayerHealth: public event Action Died;
/// 26일차 GameScore: public event Action<int> ScoreChanged; public int Score { get; }
/// </summary>
public sealed class Day26ResultBridge : MonoBehaviour
{
    [SerializeField] private PlayerHealth playerHealth;
    [SerializeField] private GameScore gameScore;
    [SerializeField] private GameFlowController gameFlow;

    private void OnEnable()
    {
        if (playerHealth != null) playerHealth.Died += OnPlayerDied;
        if (gameScore != null) gameScore.ScoreChanged += OnScoreChanged;
    }

    private void Start()
    {
        // 이벤트가 아직 발생하지 않았더라도 초기 점수를 표시하도록 동기화합니다.
        if (gameScore != null) OnScoreChanged(gameScore.Score);
    }

    private void OnDisable()
    {
        if (playerHealth != null) playerHealth.Died -= OnPlayerDied;
        if (gameScore != null) gameScore.ScoreChanged -= OnScoreChanged;
    }

    private void OnPlayerDied()
    {
        if (gameFlow != null) gameFlow.ShowDefeat();
    }

    private void OnScoreChanged(int score)
    {
        if (gameFlow != null) gameFlow.SetScore(score);
    }
}
