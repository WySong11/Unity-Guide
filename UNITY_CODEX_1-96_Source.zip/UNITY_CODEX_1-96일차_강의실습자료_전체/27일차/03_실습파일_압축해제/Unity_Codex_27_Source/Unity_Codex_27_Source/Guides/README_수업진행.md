# Unity + Codex / 27일차: 게임 시작/종료 시스템

Unity 6.3 (6000.3 계열) · uGUI + TextMeshPro · Input System(선택) · 120분

## 파일 구성
- Core/TitleMenuController.cs : 타이틀의 시작 / 종료 버튼
- Core/GameFlowController.cs : 플레이 / 일시정지 / 결과 / 재시작 / 타이틀 이동
- Core/Day27DebugButtons.cs : 결과 테스트용 버튼(실전 배포 때 제거)
- Optional_Day26_Integration/Day26ResultBridge.cs : **26일차 PlayerHealth, GameScore가 있는 프로젝트에서만** 사용

## 1. 씬 준비
1. Assets/Scenes/TitleScene.unity 및 GameScene.unity 저장.
2. File > Build Profiles > Platforms > Scene List에서 두 씬을 등록하고 활성화.
3. TitleScene이 처음 실행되도록 앞에 배치.
4. **이름 대소문자 및 씬 등록 여부**를 확인.

## 2. 타이틀 설정
1. TitleScene에 Canvas > TitlePanel, 버튼 StartButton, QuitButton 생성.
2. 빈 GameObject 'TitleMenu'에 TitleMenuController 컴포넌트 추가.
3. gameSceneName='GameScene'.
4. StartButton > Button > On Click(): TitleMenuController.StartGame().
5. QuitButton > Button > On Click(): TitleMenuController.QuitGame().

## 3. 게임 설정
1. GameScene에 Canvas/HUD, PausePanel, ResultPanel 생성.
2. ResultPanel 아래 ResultTitle(TMP), ResultScore(TMP), RestartButton, TitleButton 생성.
3. PausePanel에 ResumeButton, TitleButton 생성. 모두 시작 시 끄거나 GameFlowController가 Awake에서 끄게 구성.
4. 빈 GameObject 'GameFlow'에 GameFlowController 부착.
5. GameFlowController Inspector의 pausePanel/resultPanel/resultTitleText/finalScoreText를 연결.
6. 타이틀·게임 씬 이름을 TitleScene, GameScene으로 입력.
7. 버튼 On Click(): PauseGame / ResumeGame / RestartGame / ReturnToTitle을 각각 연결.
8. 임시 디버그 버튼에 Day27DebugButtons.AddDemoScore100 / Win / Lose 연결해 플레이 테스트.

## 4. 26일차 프로젝트와 연결(선택)
1. **이미 PlayerHealth.cs와 GameScore.cs가 있다면 다시 복사하지 말 것.**
2. Optional_Day26_Integration/Day26ResultBridge.cs만 Assets에 복사.
3. 같은 게임 오브젝트 또는 별도 GameObject에 붙여 PlayerHealth, GameScore, GameFlow 참조 연결.
4. PlayerHealth.Died 이벤트가 발생하면 게임 오버 표시, GameScore.ScoreChanged를 통해 최종 점수 연동.
5. 승리 판정(목표 점수, 보스 처치 등)은 실제 게임 로직에서 GameFlowController.ShowVictory() 호출.

## 5. 반드시 테스트할 사항
- 버튼 연타 시 한 번만 이동하는가?
- 잘못된 씬 이름에서 오류 로그를 보고 안전하게 남아 있는가?
- PausePanel에서 Resume 시 timeScale=1인가?
- 죽거나 이겼을 때 ResultPanel이 열리고 점수가 맞는가?
- 결과 화면에서 Restart/Title 복귀 후 timeScale=1로 회복하는가?
- Unity Editor Quit는 Play Mode 종료, 실제 Build Quit는 앱 종료인가?
- Build Profiles의 Scene List가 각 씬을 포함하는가?
- 실제 빌드 / 모바일 백 버튼 동작은 별도로 점검할 것.

## 참고
- Time.timeScale=0은 게임 시간과 물리 진행을 멈추지만 Update와 UI 이벤트는 계속 처리됩니다.
- Time.timeScale=0인 동안 일반 WaitForSeconds/Animator(일반 모드)는 멈춥니다.
  결과 화면의 애니메이션은 unscaled time 또는 Animator Unscaled Time을 사용하세요.
- GameFlowController는 27일차 기본 기능을 위해 최소 Pause 기능을 넣었습니다. 28일차에서 상태 관리, 사운드, 입력 차단을 확장합니다.
- Unity Editor 내에서 실제 Unity 컴파일/플레이 테스트는 수행하지 않았습니다.

공식 Unity 문서:
https://docs.unity.com/en-us/engine/6000.3/manual/scripting/object-oriented-development/managing-time-and-frame-rate/time-scale
https://docs.unity.com/en-us/engine/6000.3/manual/building-and-publishing/build-settings/build-profiles
https://docs.unity.com/en-us/engine/6000.3/script-reference/unityengine/scenemanagement/scenemanager
