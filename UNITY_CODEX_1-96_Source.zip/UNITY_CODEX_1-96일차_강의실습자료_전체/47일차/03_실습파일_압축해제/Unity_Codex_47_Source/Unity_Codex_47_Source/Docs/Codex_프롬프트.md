# Codex 지시 프롬프트 — 47일차

## 1단계: 분석
현재 Unity 6.3 URP 프로젝트에서 `Assets/Day47` 코드와 기존 45~46일차 구조를 분석해줘. 먼저 사용 중인 Prefab, Scene, 공통 서비스 의존성을 표로 정리해줘. 이 단계에서 파일은 수정하지 말고 새 스크립트와 기존 스크립트의 클래스명 충돌도 확인해줘.

## 2단계: 개선
Prefab 원본과 Variant의 공통 기능을 중복 구현하지 않도록 개선해줘. 역할은 `EnemyUnit(개별 상태)`, `Spawner(생성·이벤트 연결)`, `ScoreService(점수)`, `AudioService(사운드)`, `ScoreHUD(표시)`로 유지하고, 기존 씬/Prefab 연결을 보존해줘. 적용 전 변경 계획과 영향 받는 에셋을 알려줘. Prefab Apply, Revert, Unpack 같은 되돌리기 어려운 변경은 내 승인 없이 진행하지 마.

## 3단계: 검증
Unity 콘솔의 컴파일 오류 여부, Editor Scene Validator, Base/Strong/Fast 프리팹 연결, Variant Override 상속 관계, HUD 점수 갱신, `OnDisable` 이벤트 구독 해제, 서비스 중복 생성, 씬 전환 후 상태를 검증해줘. 직접 실행하지 못한 테스트는 `미실행`으로 표시하고 결과를 꾸미지 마. 변경 파일과 `git diff`를 요약해줘.
