# Unity Codex 47일차 — Prefab, 공통 시스템

대상: Unity 6.3 / URP(Universal 3D) / TextMeshPro 사용 가능 프로젝트

## 설치
1. `Assets/Day47` 폴더를 Unity 프로젝트의 `Assets/` 아래로 복사합니다.
2. 컴파일 오류가 없는지 Console을 확인합니다. **Unity 6의 TMP Essentials가 없다면 TMP 메뉴에서 가져옵니다.**
3. 메뉴 **Tools → Unity Codex → Day47 → Create Prefab Lab**을 실행합니다.
4. 씬 저장 여부 팝업에 응답하면 `Assets/Day47Generated/Lab_날짜/` 폴더에 새 씬·Prefabs·Materials가 생성됩니다.
5. 생성된 `Day47PrefabLab.unity` 씬을 열고 Play를 누릅니다.
6. 화면 왼쪽 Debug UI로 Base/Strong/Fast Prefab 생성, Damage, Reset Score 기능을 확인합니다.
7. 메뉴 **Validate Open Scene**으로 구성 검사를 실행합니다.

## 구성과 의도
- `Enemy_Base.prefab`: 최대 HP 30, 처치 점수 10의 원본 Prefab.
- `Enemy_Strong.prefab`: 원본을 상속한 Variant (HP 65, 점수 25).
- `Enemy_Fast.prefab`: 원본을 상속한 Variant (HP 20, 점수 15). 이름은 실습용이며 이동 속도 차이는 47일차에서 구현하지 않습니다.
- 씬에는 기본 Prefab 인스턴스 1개와 두 Variant 인스턴스 1개씩 배치됩니다.
- 추가 생성은 `Instantiate`로 처리합니다. Object Pool은 24/42일차 연계 심화 과제입니다.
- `Day47GameServices`는 Score/Audio 공통 서비스 접근을 묶는 Composition Root이며, `persistBetweenScenes`의 기본값은 `false`입니다.
- 점수 UI는 ScoreService의 이벤트 구독으로 갱신합니다. `OnEnable`에서 현재 점수 즉시 표시, `OnDisable`에서 해제합니다.

## 주의 사항
- Source 안에 임포트 가능한 완성 `.prefab` / `.unity` 바이너리가 있는 것은 아닙니다. 생성 코드를 통해 에디터에서 제작합니다.
- `AssetDatabase.GenerateUniqueAssetPath`를 사용하므로 기존 실습 결과를 덮어쓰지 않습니다.
- 실습용 Debug Panel은 OnGUI 기반이며 실제 게임에서는 uGUI/TMP 버튼으로 교체하세요.
- 여러 씬에 GameServices를 두고 `DontDestroyOnLoad`를 활성화할 때는 중복 생성/의존성 문제를 반드시 확인하세요.
- Prefab Apply는 원본을 수정하므로 수업 실습에선 별도 복제본에 실습하는 편이 안전합니다.
- 실제 컴파일/Play Mode 테스트는 Unity Editor에서 직접 실행해야 합니다. 패키지 제작 단계에서는 Unity Editor 실행 테스트를 수행하지 않았습니다.

## 추가 학습
- `Strong` Variant의 HP를 85로 변경하고, 원본 Prefab의 머티리얼만 수정하여 상속 여부를 확인합니다.
- 개별 인스턴스의 Reward를 Override한 후 `Revert`를 실행하여 원복 여부를 확인합니다.
- `persistBetweenScenes` 활성화 시 새로운 씬의 GameServices 중복 처리를 검증합니다.

## 참고 문서
- https://docs.unity3d.com/Manual/CreatingPrefabs.html
- https://docs.unity3d.com/Manual/PrefabVariants.html
- https://docs.unity3d.com/Manual/prefabs-override.html
