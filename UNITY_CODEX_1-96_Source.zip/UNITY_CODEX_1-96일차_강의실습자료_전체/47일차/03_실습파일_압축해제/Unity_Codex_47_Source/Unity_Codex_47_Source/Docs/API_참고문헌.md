# 47일차 Unity 공식 문서 참고

다음 항목은 Unity 6 계열에서 사용되는 공식 매뉴얼의 Prefab 절차를 바탕으로 구성했습니다.

- [Create prefabs](https://docs.unity3d.com/Manual/CreatingPrefabs.html): Scene 객체를 Prefab Asset으로 저장
- [Introduction to Prefabs](https://docs.unity3d.com/Manual/prefabs-introduction.html): Prefab·Instance·Nested Prefab·Variant 개요
- [Prefab overrides](https://docs.unity3d.com/Manual/prefabs-override.html): 개별 Instance 데이터 Override
- [Prefab instance Inspector reference](https://docs.unity3d.com/Manual/prefab-instance-inspector-reference.html): Apply·Revert
- [Prefab variants](https://docs.unity3d.com/Manual/PrefabVariants.html): 원본을 상속한 Variant

Unity 편집기 메뉴명 및 API 지원 여부는 수업 당시 설치된 Unity 6.3의 패치 버전에 따라 확인하세요.
