#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

public static class Day47PrefabValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day47/Validate Open Scene")]
    private static void Validate()
    {
        int errors = 0;
        Day47GameServices[] roots = Object.FindObjectsByType<Day47GameServices>(FindObjectsSortMode.None);
        if (roots.Length != 1)
        {
            Debug.LogError($"[Day47] Expected exactly 1 GameServices, found {roots.Length}");
            errors++;
        }
        var spawners = Object.FindObjectsByType<Day47EnemySpawner>(FindObjectsSortMode.None);
        if (spawners.Length != 1)
        {
            Debug.LogError($"[Day47] Expected 1 spawner, found {spawners.Length}");
            errors++;
        }
        var enemies = Object.FindObjectsByType<Day47EnemyUnit>(FindObjectsSortMode.None);
        foreach (Day47EnemyUnit enemy in enemies)
        {
            if (!PrefabUtility.IsPartOfPrefabInstance(enemy.gameObject))
            {
                Debug.LogWarning($"[Day47] Not a Prefab instance: {enemy.name}", enemy);
                errors++;
            }
            else
            {
                var asset = PrefabUtility.GetCorrespondingObjectFromSource(enemy.gameObject);
                Debug.Log($"[Day47] {enemy.name}: source={asset?.name}, hp={enemy.MaxHealth}, reward={enemy.ScoreReward}", enemy);
            }
        }
        Debug.Log(errors == 0 ? "[Day47] PASS: Scene structure verified" : $"[Day47] FAIL: {errors} issue(s)");
    }

    [MenuItem("Tools/Unity Codex/Day47/Inspect Selected Prefab")]
    private static void InspectSelected()
    {
        var obj = Selection.activeObject as GameObject;
        if (obj == null) { Debug.LogWarning("Select a prefab asset or scene instance"); return; }
        Debug.Log($"[Day47] Name={obj.name}; AssetType={PrefabUtility.GetPrefabAssetType(obj)}; " +
            $"InstanceStatus={PrefabUtility.GetPrefabInstanceStatus(obj)}; " +
            $"IsInstance={PrefabUtility.IsPartOfPrefabInstance(obj)}");
    }
}
#endif
