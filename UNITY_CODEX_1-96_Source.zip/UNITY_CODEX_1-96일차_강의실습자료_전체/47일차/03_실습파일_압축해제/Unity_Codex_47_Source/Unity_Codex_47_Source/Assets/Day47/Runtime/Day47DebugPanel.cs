using UnityEngine;

// Debug UI only. Replace with normal buttons in a production project.
public sealed class Day47DebugPanel : MonoBehaviour
{
    [SerializeField] private Day47EnemySpawner spawner;
    [SerializeField] private Day47GameServices services;

    private void OnGUI()
    {
        GUILayout.BeginArea(new Rect(18, 88, 240, 220), GUI.skin.box);
        GUILayout.Label("Day47 Prefab & Shared Systems");
        if (GUILayout.Button("Spawn Base")) spawner?.SpawnOption(0);
        if (GUILayout.Button("Spawn Strong Variant")) spawner?.SpawnOption(1);
        if (GUILayout.Button("Spawn Fast Variant")) spawner?.SpawnOption(2);
        if (GUILayout.Button("Damage one enemy (-20 HP)"))
        {
            Day47EnemyUnit[] units = FindObjectsByType<Day47EnemyUnit>(FindObjectsSortMode.None);
            if (units.Length > 0) units[0].TakeDamage(20);
        }
        if (GUILayout.Button("Reset score")) services?.Score?.ResetScore();
        GUILayout.EndArea();
    }

    public void ConfigureForLesson(Day47EnemySpawner value, Day47GameServices root)
    {
        spawner = value;
        services = root;
    }
}
