using UnityEngine;

[RequireComponent(typeof(AudioSource))]
public sealed class Day47AudioService : MonoBehaviour
{
    [SerializeField] private AudioSource audioSource;
    [SerializeField] private AudioClip defeatSfx; // Optional lesson asset
    [Range(0, 1)] [SerializeField] private float volume = 0.6f;

    private void Awake()
    {
        if (audioSource == null) audioSource = GetComponent<AudioSource>();
        audioSource.playOnAwake = false;
        audioSource.spatialBlend = 0f;
    }

    public void PlayDefeat()
    {
        if (audioSource != null && defeatSfx != null)
            audioSource.PlayOneShot(defeatSfx, volume);
    }
}
