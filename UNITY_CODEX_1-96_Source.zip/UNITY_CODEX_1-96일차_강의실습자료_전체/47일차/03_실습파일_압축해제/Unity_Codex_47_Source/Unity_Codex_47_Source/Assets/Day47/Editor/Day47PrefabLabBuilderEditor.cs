#if UNITY_EDITOR
using System;
using System.IO;
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;

public static class Day47PrefabLabBuilderEditor
{
    private const string Root = "Assets/Day47Generated";

    [MenuItem("Tools/Unity Codex/Day47/Create Prefab Lab")]
    public static void Build()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        if (!AssetDatabase.IsValidFolder(Root)) AssetDatabase.CreateFolder("Assets", "Day47Generated");
        string folder = AssetDatabase.GenerateUniqueAssetPath($"{Root}/Lab_{DateTime.Now:yyyyMMdd_HHmmss}");
        AssetDatabase.CreateFolder(Root, Path.GetFileName(folder));

        Material blue = CreateMaterial(folder, "BaseBlue", new Color(.22f, .48f, .91f));
        Material red = CreateMaterial(folder, "StrongRed", new Color(.89f, .34f, .34f));
        Material green = CreateMaterial(folder, "FastGreen", new Color(.17f, .72f, .48f));

        GameObject raw = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        raw.name = "Enemy_Base";
        raw.GetComponent<Renderer>().sharedMaterial = blue;
        raw.AddComponent<Day47EnemyUnit>().ConfigureForLesson(30, 10);
        string basePath = $"{folder}/Enemy_Base.prefab";
        GameObject baseAsset = PrefabUtility.SaveAsPrefabAsset(raw, basePath);
        UnityEngine.Object.DestroyImmediate(raw);

        GameObject strong = CreateVariant(baseAsset, $"{folder}/Enemy_Strong.prefab", 65, 25, red);
        GameObject fast = CreateVariant(baseAsset, $"{folder}/Enemy_Fast.prefab", 20, 15, green);
        if (PrefabUtility.GetPrefabAssetType(strong) != PrefabAssetType.Variant ||
            PrefabUtility.GetPrefabAssetType(fast) != PrefabAssetType.Variant)
            Debug.LogError("[Day47] Variant creation did not retain base relationship");

        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        Camera mainCamera = Camera.main;
        if (mainCamera != null)
        {
            mainCamera.transform.position = new Vector3(0, 12, -22);
            mainCamera.transform.rotation = Quaternion.LookRotation(new Vector3(0, 1, 0) - mainCamera.transform.position);
            mainCamera.clearFlags = CameraClearFlags.Skybox;
        }
        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.name = "Ground";
        ground.transform.localScale = new Vector3(18, .5f, 10);
        ground.transform.position = new Vector3(0, -.25f, 0);
        ground.GetComponent<Renderer>().sharedMaterial = CreateMaterial(folder, "Ground", new Color(.7f,.77f,.83f));

        GameObject systemsObj = new GameObject("GameServices");
        systemsObj.AddComponent<AudioSource>();
        Day47ScoreService score = systemsObj.AddComponent<Day47ScoreService>();
        systemsObj.AddComponent<Day47AudioService>();
        Day47GameServices services = systemsObj.AddComponent<Day47GameServices>();

        var options = new[] { baseAsset.GetComponent<Day47EnemyUnit>(),
            strong.GetComponent<Day47EnemyUnit>(), fast.GetComponent<Day47EnemyUnit>() };
        var existing = new Day47EnemyUnit[3];
        for (int i = 0; i < existing.Length; i++)
        {
            GameObject actor = (GameObject)PrefabUtility.InstantiatePrefab(
                i == 0 ? baseAsset : i == 1 ? strong : fast);
            actor.name = $"SceneUnit_{i + 1}";
            actor.transform.position = new Vector3((i - 1) * 4, 1, 0);
            existing[i] = actor.GetComponent<Day47EnemyUnit>();
        }
        GameObject spawnRoot = new GameObject("SpawnPoints");
        var points = new Transform[3];
        for (int i = 0; i < points.Length; i++)
        {
            GameObject point = new GameObject($"Spawn_{i + 1}");
            point.transform.SetParent(spawnRoot.transform);
            point.transform.position = new Vector3((i - 1) * 4, 1, 3);
            points[i] = point.transform;
        }
        GameObject controller = new GameObject("GameController");
        Day47EnemySpawner spawner = controller.AddComponent<Day47EnemySpawner>();
        spawner.ConfigureForLesson(options, points, existing, services);
        controller.AddComponent<Day47DebugPanel>().ConfigureForLesson(spawner, services);

        GameObject canvasObject = new GameObject("Canvas", typeof(RectTransform),
            typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        Canvas canvas = canvasObject.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        CanvasScaler scaler = canvasObject.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);
        GameObject labelObject = new GameObject("ScoreText", typeof(RectTransform), typeof(TextMeshProUGUI));
        labelObject.transform.SetParent(canvasObject.transform, false);
        RectTransform rect = labelObject.GetComponent<RectTransform>();
        rect.anchorMin = rect.anchorMax = new Vector2(1, 1);
        rect.pivot = new Vector2(1, 1);
        rect.anchoredPosition = new Vector2(-35, -25);
        rect.sizeDelta = new Vector2(540, 90);
        TextMeshProUGUI label = labelObject.GetComponent<TextMeshProUGUI>();
        label.fontSize = 40;
        label.alignment = TextAlignmentOptions.Right;
        label.color = Color.white;
        labelObject.AddComponent<Day47ScoreHUD>().ConfigureForLesson(score, label);

        string scenePath = $"{folder}/Day47PrefabLab.unity";
        EditorSceneManager.SaveScene(scene, scenePath);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Selection.activeObject = AssetDatabase.LoadAssetAtPath<GameObject>(basePath);
        Debug.Log($"[Day47] Prefab lab created in {folder}. Press Play to test.");
    }

    private static GameObject CreateVariant(GameObject baseAsset, string path, int hp, int reward, Material color)
    {
        GameObject instance = (GameObject)PrefabUtility.InstantiatePrefab(baseAsset);
        instance.GetComponent<Day47EnemyUnit>().ConfigureForLesson(hp, reward);
        instance.GetComponent<Renderer>().sharedMaterial = color;
        GameObject variant = PrefabUtility.SaveAsPrefabAsset(instance, path);
        UnityEngine.Object.DestroyImmediate(instance);
        return variant;
    }

    private static Material CreateMaterial(string folder, string name, Color color)
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard") ?? Shader.Find("Unlit/Color");
        if (shader == null) throw new InvalidOperationException("No supported shader found");
        Material material = new Material(shader);
        if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
        else material.color = color;
        AssetDatabase.CreateAsset(material, $"{folder}/{name}.mat");
        return material;
    }
}
#endif
