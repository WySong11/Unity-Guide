using System;
using UnityEngine;

[DisallowMultipleComponent]
[RequireComponent(typeof(Collider))]
public sealed class Day47EnemyUnit : MonoBehaviour
{
    [Header("Prefab / Variant settings")]
    [Min(1)] [SerializeField] private int maxHealth = 30;
    [Min(0)] [SerializeField] private int scoreReward = 10;

    private int currentHealth;
    private bool defeated;
    public int CurrentHealth => currentHealth;
    public int MaxHealth => maxHealth;
    public int ScoreReward => scoreReward;
    public event Action<Day47EnemyUnit, int> Defeated;

    private void OnEnable()
    {
        currentHealth = Mathf.Max(1, maxHealth);
        defeated = false;
    }

    public void TakeDamage(int amount)
    {
        if (defeated || amount <= 0) return;
        currentHealth = Mathf.Max(0, currentHealth - amount);
        Debug.Log($"[Day47] {name} HP: {currentHealth}/{maxHealth}", this);
        if (currentHealth > 0) return;
        defeated = true;
        Defeated?.Invoke(this, scoreReward);
        Destroy(gameObject, 0.05f); // Day47 lesson: non-pooled instance lifecycle
    }

    public void ConfigureForLesson(int health, int reward)
    {
        maxHealth = Mathf.Max(1, health);
        scoreReward = Mathf.Max(0, reward);
    }
}
