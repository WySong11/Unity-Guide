using TMPro;
using UnityEngine;

public sealed class Day47ScoreHUD : MonoBehaviour
{
    [SerializeField] private Day47ScoreService scoreService;
    [SerializeField] private TMP_Text scoreText;

    private void OnEnable()
    {
        if (scoreService == null) return;
        scoreService.ScoreChanged += Refresh;
        Refresh(scoreService.Score); // Events don't replay prior values.
    }

    private void OnDisable()
    {
        if (scoreService != null) scoreService.ScoreChanged -= Refresh;
    }

    private void Refresh(int score)
    {
        if (scoreText != null) scoreText.text = $"SCORE  {score:0000}";
    }

    public void ConfigureForLesson(Day47ScoreService service, TMP_Text label)
    {
        if (isActiveAndEnabled && scoreService != null)
            scoreService.ScoreChanged -= Refresh;
        scoreService = service;
        scoreText = label;
        if (isActiveAndEnabled && scoreService != null)
        {
            scoreService.ScoreChanged += Refresh;
            Refresh(scoreService.Score);
        }
    }
}
