using System;
using UnityEngine;

public sealed class Day47ScoreService : MonoBehaviour
{
    [Min(0)] [SerializeField] private int startingScore;
    public int Score { get; private set; }
    public event Action<int> ScoreChanged;

    private void Awake() => Score = startingScore;

    public void AddScore(int amount)
    {
        if (amount <= 0) return;
        Score = amount > int.MaxValue - Score ? int.MaxValue : Score + amount;
        ScoreChanged?.Invoke(Score);
    }

    public void ResetScore()
    {
        Score = startingScore;
        ScoreChanged?.Invoke(Score);
    }
}
