using System.Collections.Generic;
using UnityEngine;

public sealed class Day47EnemySpawner : MonoBehaviour
{
    [SerializeField] private Day47EnemyUnit[] prefabOptions;
    [SerializeField] private Transform[] spawnPoints;
    [SerializeField] private Day47EnemyUnit[] placedSceneUnits;
    [SerializeField] private Day47GameServices services;

    private readonly List<Day47EnemyUnit> tracked = new();
    private int nextSpawnPoint;

    private void OnEnable()
    {
        if (placedSceneUnits == null) return;
        foreach (Day47EnemyUnit unit in placedSceneUnits) Track(unit);
    }

    private void OnDisable()
    {
        foreach (Day47EnemyUnit unit in tracked)
            if (unit != null) unit.Defeated -= HandleDefeated;
        tracked.Clear();
    }

    public Day47EnemyUnit SpawnOption(int index)
    {
        if (prefabOptions == null || index < 0 || index >= prefabOptions.Length || prefabOptions[index] == null)
        {
            Debug.LogWarning("[Day47] Missing prefab option", this);
            return null;
        }
        Vector3 pos = transform.position;
        if (spawnPoints != null && spawnPoints.Length > 0)
        {
            Transform point = spawnPoints[nextSpawnPoint % spawnPoints.Length];
            nextSpawnPoint++;
            if (point != null) pos = point.position;
        }
        Day47EnemyUnit unit = Instantiate(prefabOptions[index], pos, Quaternion.identity);
        Track(unit);
        return unit;
    }

    private void Track(Day47EnemyUnit unit)
    {
        if (unit == null || tracked.Contains(unit)) return;
        tracked.Add(unit);
        unit.Defeated += HandleDefeated;
    }

    private void HandleDefeated(Day47EnemyUnit unit, int reward)
    {
        if (unit != null) unit.Defeated -= HandleDefeated;
        tracked.Remove(unit);
        if (services != null)
        {
            services.Score?.AddScore(reward);
            services.Audio?.PlayDefeat();
        }
    }

    public void ConfigureForLesson(Day47EnemyUnit[] options, Transform[] points,
        Day47EnemyUnit[] sceneUnits, Day47GameServices root)
    {
        if (isActiveAndEnabled) OnDisable(); // Unsubscribe previous scene units safely.
        prefabOptions = options;
        spawnPoints = points;
        placedSceneUnits = sceneUnits;
        services = root;
        if (isActiveAndEnabled) OnEnable();
    }
}
