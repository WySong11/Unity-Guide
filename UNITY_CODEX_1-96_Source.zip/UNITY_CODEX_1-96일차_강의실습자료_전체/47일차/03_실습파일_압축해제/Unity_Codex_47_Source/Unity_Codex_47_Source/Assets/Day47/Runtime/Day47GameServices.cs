using UnityEngine;

[DisallowMultipleComponent]
[RequireComponent(typeof(Day47ScoreService), typeof(Day47AudioService))]
public sealed class Day47GameServices : MonoBehaviour
{
    // Single access point only; each service retains its own responsibility.
    public static Day47GameServices Instance { get; private set; }
    [SerializeField] private bool persistBetweenScenes = false;

    public Day47ScoreService Score { get; private set; }
    public Day47AudioService Audio { get; private set; }

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    private static void ResetStaticForDomainReloadDisabled() => Instance = null;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Debug.LogWarning("[Day47] Duplicate GameServices removed", this);
            Destroy(gameObject);
            return;
        }
        Instance = this;
        Score = GetComponent<Day47ScoreService>();
        Audio = GetComponent<Day47AudioService>();
        if (persistBetweenScenes) DontDestroyOnLoad(gameObject);
    }

    private void OnDestroy()
    {
        if (Instance == this) Instance = null;
    }
}
