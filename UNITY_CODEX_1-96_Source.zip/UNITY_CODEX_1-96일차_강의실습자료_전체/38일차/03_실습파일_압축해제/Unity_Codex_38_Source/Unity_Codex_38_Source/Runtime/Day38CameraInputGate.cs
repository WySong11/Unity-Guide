using UnityEngine;

/// <summary>Hook these methods to the pause/menu UI events of Day 28.</summary>
public sealed class Day38CameraInputGate : MonoBehaviour
{
    [SerializeField] private Day38OrbitCamera3D orbitCamera;

    public void PauseCameraInput()
    {
        if (orbitCamera != null) orbitCamera.SetCameraInputEnabled(false);
    }

    public void ResumeCameraInput()
    {
        if (orbitCamera != null) orbitCamera.SetCameraInputEnabled(true);
    }
}
