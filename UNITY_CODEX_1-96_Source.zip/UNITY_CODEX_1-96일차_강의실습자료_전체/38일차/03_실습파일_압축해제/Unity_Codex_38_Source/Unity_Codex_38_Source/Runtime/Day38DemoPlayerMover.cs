using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// Standalone demo-only keyboard movement for Day38_CameraLab.
/// Remove/disable this when using the Day37CharacterMotor3D in your own scene.
/// </summary>
[RequireComponent(typeof(CharacterController))]
public sealed class Day38DemoPlayerMover : MonoBehaviour
{
    [SerializeField] private Transform viewCamera;
    [SerializeField, Min(0f)] private float moveSpeed = 4f;
    [SerializeField, Min(0f)] private float turnSpeed = 540f;
    [SerializeField] private float gravity = -20f;
    [SerializeField, Min(0f)] private float jumpHeight = 1.3f;

    private CharacterController controller;
    private float verticalSpeed;

    public void SetCamera(Transform cameraTransform) => viewCamera = cameraTransform;
    private void Awake() => controller = GetComponent<CharacterController>();

    private void Update()
    {
        if (Time.timeScale <= 0f) return;
        Keyboard kb = Keyboard.current;
        if (kb == null) return;

        Vector2 input = new Vector2(
            (kb.dKey.isPressed ? 1 : 0) - (kb.aKey.isPressed ? 1 : 0),
            (kb.wKey.isPressed ? 1 : 0) - (kb.sKey.isPressed ? 1 : 0));
        input = Vector2.ClampMagnitude(input, 1f);

        Vector3 forward = viewCamera != null
            ? Vector3.ProjectOnPlane(viewCamera.forward, Vector3.up)
            : Vector3.forward;
        if (forward.sqrMagnitude < 0.001f) forward = Vector3.forward;
        forward.Normalize();
        Vector3 right = Vector3.Cross(Vector3.up, forward).normalized;
        Vector3 planar = Vector3.ClampMagnitude(right * input.x + forward * input.y, 1f);

        if (controller.isGrounded && verticalSpeed < 0f)
            verticalSpeed = -2f;
        if (controller.isGrounded && kb.spaceKey.wasPressedThisFrame)
            verticalSpeed = Mathf.Sqrt(jumpHeight * -2f * gravity);
        verticalSpeed += gravity * Time.deltaTime;
        controller.Move((planar * moveSpeed + Vector3.up * verticalSpeed) * Time.deltaTime);

        if (planar.sqrMagnitude > 0.0001f)
        {
            Quaternion desired = Quaternion.LookRotation(planar, Vector3.up);
            transform.rotation = Quaternion.RotateTowards(transform.rotation,
                desired, turnSpeed * Time.deltaTime);
        }
    }
}
