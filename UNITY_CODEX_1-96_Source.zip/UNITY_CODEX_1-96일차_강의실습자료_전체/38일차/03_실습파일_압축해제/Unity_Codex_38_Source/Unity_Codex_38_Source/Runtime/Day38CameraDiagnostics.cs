using UnityEngine;

/// <summary>Scene view visual debugging. Does not change camera state.</summary>
public sealed class Day38CameraDiagnostics : MonoBehaviour
{
    [SerializeField] private Day38OrbitCamera3D orbitCamera;
    [SerializeField] private Color lineColor = Color.cyan;

    private void OnDrawGizmosSelected()
    {
        if (orbitCamera == null || orbitCamera.Target == null) return;
        Vector3 target = orbitCamera.Target.position + Vector3.up * 1.6f;
        Gizmos.color = lineColor;
        Gizmos.DrawLine(target, orbitCamera.transform.position);
        Gizmos.DrawWireSphere(target, 0.15f);
        Gizmos.DrawWireSphere(orbitCamera.transform.position, 0.12f);
    }

    [ContextMenu("Print Camera State")]
    private void PrintState()
    {
        if (orbitCamera == null)
        {
            Debug.LogWarning("[Day38] Orbit Camera reference missing.", this);
            return;
        }
        Debug.Log($"[Day38] target={orbitCamera.Target?.name ?? "null"}, " +
            $"yaw={orbitCamera.Yaw:F1}, pitch={orbitCamera.Pitch:F1}, " +
            $"distance={orbitCamera.CameraDistance:F2}", this);
    }
}
