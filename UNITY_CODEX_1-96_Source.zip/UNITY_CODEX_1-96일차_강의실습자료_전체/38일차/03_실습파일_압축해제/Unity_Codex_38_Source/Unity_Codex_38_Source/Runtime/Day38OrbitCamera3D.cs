using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// Day 38: A third-person orbit camera without a Cinemachine dependency.
/// Mouse: hold RMB and drag; Gamepad: right stick; zoom: mouse wheel.
/// Attach ONLY one camera controller to the Main Camera.
/// </summary>
[DisallowMultipleComponent]
[RequireComponent(typeof(Camera))]
public sealed class Day38OrbitCamera3D : MonoBehaviour
{
    [Header("Target")]
    [SerializeField] private Transform target;
    [SerializeField, Min(0f)] private float targetHeight = 1.6f;
    [SerializeField, Min(0f)] private float followSmoothTime = 0.12f;

    [Header("Orbit")]
    [SerializeField] private float yaw = 0f;
    [SerializeField] private float pitch = 20f;
    [SerializeField, Range(-85f, 85f)] private float minPitch = -20f;
    [SerializeField, Range(-85f, 85f)] private float maxPitch = 65f;
    [SerializeField, Min(0f)] private float mouseDegreesPerPixel = 0.14f;
    [SerializeField, Min(0f)] private float stickDegreesPerSecond = 140f;
    [SerializeField] private bool holdRightMouseToOrbit = true;

    [Header("Zoom")]
    [SerializeField, Min(0.1f)] private float distance = 5f;
    [SerializeField, Min(0.1f)] private float minDistance = 1f;
    [SerializeField, Min(0.1f)] private float maxDistance = 8f;
    [SerializeField, Min(0f)] private float zoomUnitsPerWheelUnit = 0.015f;
    [SerializeField, Min(0f)] private float restoreDistanceSpeed = 8f;

    [Header("Camera collision")]
    [SerializeField] private LayerMask obstructionMask = 1; // Default only: keep Player off this layer.
    [SerializeField, Min(0.01f)] private float collisionRadius = 0.25f;
    [SerializeField, Min(0f)] private float wallPadding = 0.08f;

    [Header("Optional Input Action references")]
    [Tooltip("Value/Vector2: <Mouse>/delta. Falls back to Mouse.current.delta when unassigned.")]
    [SerializeField] private InputActionReference lookMouse;
    [Tooltip("Value/Vector2: <Gamepad>/rightStick. Falls back to Gamepad.current when unassigned.")]
    [SerializeField] private InputActionReference lookStick;

    private Vector3 pivot;
    private Vector3 pivotVelocity;
    private float actualDistance;
    private bool inputEnabled = true;
    private bool enabledMouseActionHere;
    private bool enabledStickActionHere;

    public Transform Target => target;
    public float CameraDistance => actualDistance;
    public float Yaw => yaw;
    public float Pitch => pitch;

    public void SetTarget(Transform newTarget)
    {
        target = newTarget;
        SnapToTarget();
    }

    public void SetCameraInputEnabled(bool value) => inputEnabled = value;

    private void OnEnable()
    {
        enabledMouseActionHere = EnableIfNeeded(lookMouse);
        enabledStickActionHere = EnableIfNeeded(lookStick);
    }

    private static bool EnableIfNeeded(InputActionReference reference)
    {
        InputAction action = reference != null ? reference.action : null;
        if (action == null || action.enabled) return false;
        action.Enable();
        return true;
    }

    private void OnDisable()
    {
        if (enabledMouseActionHere && lookMouse != null && lookMouse.action != null)
            lookMouse.action.Disable();
        if (enabledStickActionHere && lookStick != null && lookStick.action != null)
            lookStick.action.Disable();
        enabledMouseActionHere = false;
        enabledStickActionHere = false;
    }

    private void Start() => SnapToTarget();

    private void OnValidate()
    {
        minDistance = Mathf.Max(0.1f, minDistance);
        maxDistance = Mathf.Max(minDistance, maxDistance);
        distance = Mathf.Clamp(distance, minDistance, maxDistance);
        if (minPitch > maxPitch) maxPitch = minPitch;
        pitch = Mathf.Clamp(pitch, minPitch, maxPitch);
    }

    public void SnapToTarget()
    {
        if (target == null) return;
        pivot = target.position + Vector3.up * targetHeight;
        pivotVelocity = Vector3.zero;
        actualDistance = Mathf.Clamp(distance, minDistance, maxDistance);
        UpdateTransform(true);
    }

    private void LateUpdate()
    {
        if (target == null || Time.timeScale <= 0f) return;

        // Mouse deltas are already pixels accumulated for THIS frame; do not multiply by dt.
        if (inputEnabled)
        {
            bool canUseMouse = !holdRightMouseToOrbit ||
                (Mouse.current != null && Mouse.current.rightButton.isPressed);
            if (canUseMouse)
            {
                Vector2 delta = lookMouse != null && lookMouse.action != null
                    ? lookMouse.action.ReadValue<Vector2>()
                    : (Mouse.current != null ? Mouse.current.delta.ReadValue() : Vector2.zero);
                yaw += delta.x * mouseDegreesPerPixel;
                pitch -= delta.y * mouseDegreesPerPixel;
            }

            // Stick is a normalized axis value, so scale by frame time.
            Vector2 stick = lookStick != null && lookStick.action != null
                ? lookStick.action.ReadValue<Vector2>()
                : (Gamepad.current != null ? Gamepad.current.rightStick.ReadValue() : Vector2.zero);
            yaw += stick.x * stickDegreesPerSecond * Time.deltaTime;
            pitch -= stick.y * stickDegreesPerSecond * Time.deltaTime;

            if (Mouse.current != null)
                distance -= Mouse.current.scroll.ReadValue().y * zoomUnitsPerWheelUnit;
        }

        pitch = Mathf.Clamp(pitch, minPitch, maxPitch);
        distance = Mathf.Clamp(distance, minDistance, maxDistance);

        Vector3 desiredPivot = target.position + Vector3.up * targetHeight;
        pivot = followSmoothTime <= 0f ? desiredPivot : Vector3.SmoothDamp(
            pivot, desiredPivot, ref pivotVelocity, followSmoothTime);
        UpdateTransform(false);
    }

    private void UpdateTransform(bool snap)
    {
        Quaternion orbitRotation = Quaternion.Euler(pitch, yaw, 0f);
        Vector3 directionToCamera = orbitRotation * Vector3.back;
        float safeDistance = distance;

        // The Player should be on a layer excluded from obstructionMask.
        if (Physics.SphereCast(pivot, collisionRadius, directionToCamera,
            out RaycastHit hit, distance, obstructionMask, QueryTriggerInteraction.Ignore))
        {
            safeDistance = Mathf.Max(0.1f, hit.distance - wallPadding);
        }

        if (snap || safeDistance < actualDistance)
            actualDistance = safeDistance; // immediately retract when blocked
        else
            actualDistance = Mathf.MoveTowards(actualDistance, safeDistance,
                restoreDistanceSpeed * Time.deltaTime); // gradually restore

        transform.position = pivot + directionToCamera * actualDistance;
        Vector3 toPivot = pivot - transform.position;
        if (toPivot.sqrMagnitude > 0.000001f)
            transform.rotation = Quaternion.LookRotation(toPivot, Vector3.up);
    }
}
