# Unity Codex 38일차 — 카메라 추적과 회전

**대상:** Unity 6.3 (6000.3) / URP / Input System, 120분 실습. 37일차 CharacterController 이동 시스템 다음 단계.

## 제공 파일
- `Runtime/Day38OrbitCamera3D.cs` — 타깃 추적, Orbit Yaw·Pitch, 줌, SphereCast 벽 충돌 방지
- `Runtime/Day38DemoPlayerMover.cs` — 독립 실습 씬을 위한 WASD·Space 캐릭터. **37일차 이동 시스템과 동시에 사용하지 마세요.**
- `Runtime/Day38CameraDiagnostics.cs` — Camera 상태 로그/Gizmos
- `Runtime/Day38CameraInputGate.cs` — 일시정지 UI 연계용 입력 허용·차단
- `Editor/Day38CameraSceneBuilderEditor.cs` — 새로운 Day38_CameraLab 씬 생성. 기존 씬을 덮어쓰지 않음
- `STUDENT_WORKSHEET.md`, `CODEX_PROMPTS.md`, `INSTRUCTOR_GUIDE.md`, `TEST_CHECKLIST.csv`

## 방법 A: 새 실습 씬 자동 생성 (처음 배우는 학생)
1. Unity 프로젝트의 `Assets/Unity_Codex/Day38/` 아래에 Runtime/Editor 폴더를 복사합니다. **Editor 스크립트는 반드시 Editor 폴더 안에** 위치합니다.
2. Package Manager에서 **Input System**이 설치돼 있는지 확인합니다. Active Input Handling이 새 Input System을 사용할 수 있어야 합니다.
3. 컴파일 오류가 없다면 **Tools → Unity Codex → Day38 → Create Camera Lab**을 실행합니다.
4. 새 씬은 `Assets/Unity_Codex/Day38/Scenes/Day38_CameraLab.unity` 이름으로 생성됩니다. 이미 파일이 있으면 Unity가 새 이름을 생성합니다.
5. Play: **WASD = 걷기, Space = 점프, 마우스 오른쪽 버튼을 누르고 드래그 = Orbit, 휠 = 줌, 게임패드 오른쪽 스틱 = Orbit**.
6. 벽 앞에서 카메라가 앞으로 이동하는지 확인하고, 원래 위치로 돌아오면 복귀 움직임도 검사합니다.

## 방법 B: 37일차 Player 연결 (권장 통합 실습)
1. 37일차 씬을 **다른 이름으로 복제**하거나 백업합니다.
2. `Main Camera`의 기존 `Day37ThirdPersonCamera3D` 등을 **제거 또는 비활성화**합니다. 같은 Transform을 두 컴포넌트에서 갱신하면 흔들림이 생깁니다.
3. `Main Camera`에 `Day38OrbitCamera3D`를 붙이고 **Target**을 37일차 Player Transform에 연결합니다.
4. Player에 새 `Day38DemoPlayerMover`는 붙이지 않습니다. `Day37CharacterMotor3D`를 사용합니다.
5. Player를 **Ignore Raycast 레이어** 같은 충돌 마스크 제외 레이어로 설정하거나, `Obstruction Mask`에서 Player 레이어만 제외합니다. 장애물 벽·바닥은 검사 대상에 포함합니다.
6. 카메라 기준 Player 이동이 동작하는지, 카메라 Orbit 중 W 방향이 달라지는지 확인합니다.

## Inspector 시작값
| 항목 | 예시값 | 설명 |
|---|---:|---|
| Target Height | 1.6 | 플레이어 기준 시선 높이 |
| Distance | 5.0 | 초기 카메라 거리 |
| Min Distance / Max Distance | 1 / 8 | 허용 Zoom 범위 |
| Min Pitch / Max Pitch | -20 / 65 | 수직 회전 한계 |
| Follow Smooth Time | 0.12 | Position 보간 시간 |
| Mouse Degrees Per Pixel | 0.14 | 마우스 감도 |
| Stick Degrees Per Second | 140 | 오른쪽 스틱 회전 속도 |
| Collision Radius | 0.25 | SphereCast 반경 |
| Wall Padding | 0.08 | 장애물 여유 거리 |
| Obstruction Mask | Environment 등 | Player 제외 권장 |

## 선택: Input Action 참조 연결
- `LookMouse`: Value / Vector2 / `<Mouse>/delta`
- `LookStick`: Value / Vector2 / `<Gamepad>/rightStick`
- Inspector 연결이 없으면 스크립트는 `Mouse.current`와 `Gamepad.current`를 사용합니다.
- Mouse delta는 **프레임별 픽셀 변화량**이므로 `deltaTime`을 다시 곱하지 않습니다. Gamepad right stick은 초당 회전 속도로 변환하므로 `Time.deltaTime`을 곱합니다.

## Cinemachine 3은 별도 선택 학습
- **Package Manager**에서 설치된 버전을 확인한 다음 `Cinemachine Camera`, `Cinemachine Brain`, `Orbital Follow`, `Input Axis Controller`의 현재 메뉴 이름을 확인하세요.
- 이 소스에는 Cinemachine 참조가 없어서 Cinemachine을 설치하지 않은 프로젝트도 컴파일 가능하도록 작성했습니다.
- **중요:** 직접 구현 카메라 스크립트와 Cinemachine 제어를 동일한 Main Camera에 동시에 적용하지 마세요.
- 공식 정보: https://docs.unity3d.com/Manual/com.unity.cinemachine.html

## 실제 테스트 주의
제공 코드는 참고·수업용 코드입니다. Unity 6.3 Editor에서의 자동 컴파일·Play 테스트는 제공 환경에서 수행하지 않았습니다. 실행 결과가 확인되기 전까지 테스트표는 **미실행**으로 두세요.
