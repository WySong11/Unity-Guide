# 강사용 진행 메모 | Day38

**120분 권장 배분:** 도입 10 / 추적 개념 20 / 추적 구현 25 / Orbit 입력 20 / 충돌·줌 25 / 테스트·정리 20.

**정답 포인트:**
1. `LateUpdate`는 Player의 일반적인 `Update` 이동 이후 카메라 위치를 보정하는 데 유용합니다.
2. Yaw=좌우, Pitch=상하, Roll=기울기이며 일반적인 TPS Orbit에서 Roll=0으로 유지합니다.
3. `SphereCast`는 카메라에 반경이 있을 때 광선 하나보다 두께 있는 충돌 판정이 가능합니다.
4. `Mouse.delta`는 화면 픽셀의 프레임 변화량, RightStick은 축 입력값입니다.
5. Player가 Obstruction Mask에 포함되면 카메라 거리가 과도하게 줄어들 수 있습니다.
6. Cinemachine 3은 선택 도구이며, 필수 실습 코드는 Cinemachine을 참조하지 않습니다.

**오류 시 점검 순서:** Main Camera 중복 컨트롤러 → Target 할당 → Game View 포커스/우클릭 → Input System → Pitch Clamp → Collider/LayerMask → 실행 테스트.

**주의:** 독립 데모 이동 스크립트와 Day37 플레이어 이동 스크립트를 동시에 한 오브젝트에 붙이지 않도록 지도합니다. 애니메이션/네트워크 시스템과 연결할 때는 카메라 자체가 Player의 회전을 직접 변경하지 않게 합니다.
