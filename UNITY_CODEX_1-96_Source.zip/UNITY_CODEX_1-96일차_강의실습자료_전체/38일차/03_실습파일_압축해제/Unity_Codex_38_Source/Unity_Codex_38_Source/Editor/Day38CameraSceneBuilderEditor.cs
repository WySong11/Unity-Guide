#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

/// <summary>Builds a NEW scene; does not replace existing Day37 scene.</summary>
public static class Day38CameraSceneBuilderEditor
{
    private const string Root = "Assets/Unity_Codex/Day38/Scenes";

    [MenuItem("Tools/Unity Codex/Day38/Create Camera Lab")]
    public static void CreateLab()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode)
        {
            Debug.LogWarning("[Day38] Stop Play Mode before creating a scene.");
            return;
        }
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        Directory.CreateDirectory(Root);
        AssetDatabase.Refresh();
        EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);

        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Player_Day38";
        player.transform.position = new Vector3(0f, 1f, 0f);
        // Keep player out of the Camera SphereCast mask while remaining visible.
        player.layer = 2; // Ignore Raycast
        Object.DestroyImmediate(player.GetComponent<CapsuleCollider>());
        CharacterController controller = player.AddComponent<CharacterController>();
        controller.height = 2f;
        controller.center = Vector3.zero;
        player.AddComponent<Day38DemoPlayerMover>();

        GameObject ground = CreateCube("Ground", new Vector3(0, -0.3f, 0), new Vector3(30, 0.6f, 30));
        GameObject wall = CreateCube("Wall_Blocker", new Vector3(0, 2f, -4f), new Vector3(8f, 4f, 0.8f));
        GameObject pillar = CreateCube("Pillar", new Vector3(4f, 1.5f, 3f), new Vector3(1.2f, 3f, 1.2f));
        ground.layer = wall.layer = pillar.layer = 0; // Default, included in mask 1

        Camera camera = Camera.main;
        if (camera == null)
        {
            GameObject cameraGO = new GameObject("Main Camera");
            cameraGO.tag = "MainCamera";
            camera = cameraGO.AddComponent<Camera>();
            cameraGO.AddComponent<AudioListener>();
        }
        camera.transform.position = new Vector3(0, 3, -5);
        Day38OrbitCamera3D orbit = camera.gameObject.AddComponent<Day38OrbitCamera3D>();
        orbit.SetTarget(player.transform);
        player.GetComponent<Day38DemoPlayerMover>().SetCamera(camera.transform);
        Day38CameraDiagnostics probe = camera.gameObject.AddComponent<Day38CameraDiagnostics>();
        // Diagnostic component can be linked from the Inspector as needed.

        string scenePath = AssetDatabase.GenerateUniqueAssetPath(Root + "/Day38_CameraLab.unity");
        EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene(), scenePath);
        Selection.activeGameObject = camera.gameObject;
        Debug.Log($"[Day38] Created new camera lab: {scenePath}. Right-drag to orbit; wheel to zoom.");
    }

    private static GameObject CreateCube(string name, Vector3 pos, Vector3 scale)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = name;
        go.transform.position = pos;
        go.transform.localScale = scale;
        return go;
    }
}
#endif
