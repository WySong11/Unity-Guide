# 학생 실습 워크시트 | 38일차 카메라 추적·회전

## 사전 점검 (10분)
- [ ] Unity 6.3과 Input System 설치 확인
- [ ] 37일차 Player의 WASD 이동·점프 정상 동작 확인
- [ ] 기존 카메라 제어 스크립트를 중복해서 실행하지 않는지 확인

## 실습 A — 카메라 추적과 Orbit (25분)
1. Main Camera에 `Day38OrbitCamera3D`를 연결하고 Target을 설정합니다.
2. Game View에서 WASD와 점프를 진행하며 Follow 상태를 관찰합니다.
3. 오른쪽 마우스 버튼 드래그로 좌우·상하 회전합니다.
4. `Min Pitch`·`Max Pitch`를 변경해 관찰합니다.

**질문:** `Update()`와 `LateUpdate()`를 구분하면 어떤 문제가 줄어드나요? ______________

## 실습 B — 충돌·줌 (25분)
1. Main Camera의 `Obstruction Mask`에 환경 레이어만 설정합니다.
2. 벽에 접근해 SphereCast의 거리 보정이 발생하는지 관찰합니다.
3. 마우스 휠을 사용해 카메라 거리를 줄이고 늘려 봅니다.
4. 장애물에서 벗어날 때 원래 거리로 돌아오는지 확인합니다.

**질문:** Player의 레이어를 카메라 충돌 마스크에 포함하면 어떤 문제가 생기나요? ______________

## 실습 C — Codex 검증 (20분)
오류 재현 조건·Inspector 값·Console 로그를 함께 첨부해 Codex에 원인 분석을 요청합니다. 수정 전후 git diff와 테스트 결과를 기록합니다.

**제출물:** `Day38_CameraLab.unity` 또는 기존 씬 수정본, 카메라 스크립트, Game View 스크린샷 3장, `TEST_CHECKLIST.csv`.
