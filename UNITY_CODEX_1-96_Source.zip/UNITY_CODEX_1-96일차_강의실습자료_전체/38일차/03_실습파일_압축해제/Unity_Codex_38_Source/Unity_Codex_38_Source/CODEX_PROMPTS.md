# Codex 실습 프롬프트 | Day38

## 1. 구현 전 분석
Unity 6.3 / URP / Input System 프로젝트입니다. Day37의 CharacterController 플레이어와 기존 씬을 보존한 상태로 카메라 추적·회전 기능을 추가하려고 합니다. 먼저 Main Camera, Camera Controller, Input Action, LayerMask 구성을 조사하고 중복된 카메라 제어 스크립트를 찾아 목록으로 보고해 주세요. 조사 전에는 파일을 수정하지 마세요.

## 2. 최소 구현
수정 허용 경로: `Assets/Unity_Codex/Day38/`. `Day37CharacterMotor3D` 코드 변경은 사전 승인 없이 금지합니다. `LateUpdate` 기반 Follow Target, Yaw/Pitch Orbit, 마우스 및 게임패드 Look, Pitch Clamp, Wheel Zoom, SphereCast 벽 충돌 방지를 구현해 주세요. 기존 UI와 씬 설정을 유지하고 각 파일의 역할과 Inspector 연결법을 설명해 주세요.

## 3. 오류 수정
증상: [여기에 직접 재현한 현상 작성].
재현: [씬, 위치, 입력 순서].\n증거: [Console 로그, Inspector 스크린샷].
추측으로 코드를 변경하지 말고 원인 후보를 우선순위별로 정리해 주세요. 수정은 최소 diff로 제한하고 기능 회귀 위험을 함께 보고해 주세요.

## 4. 검증
수정 후 컴파일 오류 여부, Player 이동/점프, Yaw/Pitch 범위, Zoom, 벽 관통, 일시정지 입력 차단을 점검해 주세요. 실행한 항목에는 구체적인 결과·증거를 적고, 실행하지 못한 검사는 '미실행'으로 표기하세요. 빌드 성공을 가정하지 마세요.
