# 30일차 재현 · 검증 체크리스트

| ID | 검사 | 기대 결과 |
|---|---|---|
| A1 | Buggy UI 참조를 비우고 Play | 의도된 NullReferenceException 재현 |
| A2 | Fixed UI 참조 연결 및 Play | 에러 0개, 초기 HP 정상 표시 |
| A3 | Damage10/Heal10 클릭 | HP 및 Slider 즉시 변화 |
| A4 | HUD를 비활성/재활성 3회 | 이벤트 중복 없이 정상 표시 |
| B1 | 발사체 Prefab Rigidbody2D/Collider2D 연결 | Inspector 누락 없음 |
| B2 | Fire 20회 이상 + 여러 회 재사용 | 크기 원복, 이전 속도/회전 잔류 없음 |
| B3 | 수명 만료와 충돌이 동시에 발생 | 중복 반환 예외 없음 |
| B4 | Prewarm 8 / max 32로 실행 | 시작 시 지정된 오브젝트 준비 확인 |
| C1 | Pause → Resume | timeScale이 1로 복귀 |
| C2 | Pause → Restart | 새 씬에서 timeScale이 1 |
| C3 | Restart 후 발사·HP UI | 정상 동작 유지 |
| D1 | Console 에러/경고 검사 | 의도된 Buggy 제거 후 새 오류 없음 |
| D2 | git diff 검토 | 무관한 파일 변경 없음 |

각 행에 PASS/FAIL/NOT RUN, 실행일, 증거(로그/캡처)를 기록하세요. 현 제공 자료는 Unity Editor 실제 테스트를 수행하지 않았습니다.
