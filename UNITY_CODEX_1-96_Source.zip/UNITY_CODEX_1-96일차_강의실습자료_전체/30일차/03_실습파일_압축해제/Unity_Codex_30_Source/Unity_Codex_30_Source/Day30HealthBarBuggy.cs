using UnityEngine;
using UnityEngine.UI;

/// <summary>실습 전용: healthModel을 Inspector에 연결하지 않으면 NRE가 발생합니다.</summary>
/// <remarks>오류를 관찰한 뒤 같은 GameObject에서 제거하고 Fixed 버전을 붙이세요.</remarks>
public sealed class Day30HealthBarBuggy : MonoBehaviour
{
    [SerializeField] private Day30HealthModel healthModel;
    [SerializeField] private Slider healthSlider;

    private void OnEnable()
    {
        // 고의로 null 검사와 초기 UI 갱신을 생략함.
        healthModel.HealthChanged += UpdateView;
    }

    private void OnDisable()
    {
        if (healthModel != null)
            healthModel.HealthChanged -= UpdateView;
    }

    private void UpdateView(int current, int maximum)
    {
        healthSlider.value = (float)current / maximum;
    }
}
