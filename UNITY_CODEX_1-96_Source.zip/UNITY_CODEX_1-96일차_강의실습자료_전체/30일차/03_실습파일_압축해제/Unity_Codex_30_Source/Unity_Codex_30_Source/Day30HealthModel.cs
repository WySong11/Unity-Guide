using System;
using UnityEngine;

/// <summary>30일차 실습용 체력 데이터. UI와 독립적으로 체력을 관리합니다.</summary>
public sealed class Day30HealthModel : MonoBehaviour
{
    [Min(1)] [SerializeField] private int maxHealth = 100;
    [SerializeField] private int currentHealth = 100;

    public event Action<int, int> HealthChanged;
    public int CurrentHealth => currentHealth;
    public int MaxHealth => maxHealth;

    private void Awake()
    {
        maxHealth = Mathf.Max(1, maxHealth);
        currentHealth = Mathf.Clamp(currentHealth, 0, maxHealth);
    }

    public void TakeDamage(int amount)
    {
        if (amount <= 0) return;
        SetHealth(currentHealth - amount);
    }

    public void Heal(int amount)
    {
        if (amount <= 0) return;
        SetHealth(currentHealth + amount);
    }

    public void SetHealth(int value)
    {
        int next = Mathf.Clamp(value, 0, maxHealth);
        if (next == currentHealth) return;
        currentHealth = next;
        HealthChanged?.Invoke(currentHealth, maxHealth);
    }
}
