using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>Null 검증 + 이벤트 구독 수명 관리 + 시작 화면 갱신의 수정 예제.</summary>
public sealed class Day30HealthBarFixed : MonoBehaviour
{
    [SerializeField] private Day30HealthModel healthModel;
    [SerializeField] private Slider healthSlider;
    [SerializeField] private TMP_Text healthText; // 선택

    private bool subscribed;

    private void OnEnable()
    {
        if (healthModel == null || healthSlider == null)
        {
            Debug.LogError("[Day30] HealthModel 또는 Slider 참조가 없습니다.", this);
            return;
        }

        if (!subscribed)
        {
            healthModel.HealthChanged += UpdateView;
            subscribed = true;
        }
        UpdateView(healthModel.CurrentHealth, healthModel.MaxHealth);
    }

    private void OnDisable()
    {
        if (subscribed && healthModel != null)
            healthModel.HealthChanged -= UpdateView;
        subscribed = false;
    }

    private void UpdateView(int current, int maximum)
    {
        if (healthSlider == null) return;
        float normalized = maximum <= 0 ? 0f : (float)current / maximum;
        healthSlider.minValue = 0f;
        healthSlider.maxValue = 1f;
        healthSlider.value = Mathf.Clamp01(normalized);
        if (healthText != null)
            healthText.text = $"HP {current}/{maximum}";
    }
}
