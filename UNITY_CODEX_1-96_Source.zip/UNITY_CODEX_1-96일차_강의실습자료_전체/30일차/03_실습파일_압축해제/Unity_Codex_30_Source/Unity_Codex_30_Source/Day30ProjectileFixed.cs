using System.Collections;
using UnityEngine;

/// <summary>재사용 시 상태 초기화, 수명 만료, 중복 반환을 다루는 수정 예제.</summary>
[RequireComponent(typeof(Rigidbody2D))]
public sealed class Day30ProjectileFixed : MonoBehaviour
{
    [SerializeField] private Rigidbody2D body;
    [SerializeField] private LayerMask hitLayers = ~0;
    private Day30ProjectilePool2D owner;
    private Vector3 initialScale;
    private Coroutine lifetimeRoutine;
    private bool isReturning;

    private void Awake()
    {
        if (body == null) body = GetComponent<Rigidbody2D>();
        initialScale = transform.localScale;
    }

    public void SetOwner(Day30ProjectilePool2D pool) => owner = pool;

    public void Launch(Vector3 position, Vector2 direction, float speed, float lifetime)
    {
        if (body == null || owner == null)
        {
            Debug.LogError("[Day30] Rigidbody2D / Pool 참조가 없습니다.", this);
            return;
        }
        CancelLifetime();
        isReturning = false;
        transform.localScale = initialScale;
        transform.position = position;
        transform.rotation = Quaternion.identity;
        body.linearVelocity = Vector2.zero;
        body.angularVelocity = 0f;
        body.linearVelocity = direction.sqrMagnitude < 0.0001f
            ? Vector2.right * speed : direction.normalized * speed;
        lifetimeRoutine = StartCoroutine(ReturnAfter(Mathf.Max(0.05f, lifetime)));
    }

    private IEnumerator ReturnAfter(float seconds)
    {
        yield return new WaitForSeconds(seconds);
        lifetimeRoutine = null;
        ReturnToPool();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if ((hitLayers.value & (1 << other.gameObject.layer)) == 0) return;
        ReturnToPool();
    }

    public void ReturnToPool()
    {
        if (isReturning) return;
        isReturning = true;
        CancelLifetime();
        if (body != null)
        {
            body.linearVelocity = Vector2.zero;
            body.angularVelocity = 0f;
        }
        if (owner != null) owner.Release(this);
        else gameObject.SetActive(false);
    }

    private void OnDisable() => CancelLifetime();

    private void CancelLifetime()
    {
        if (lifetimeRoutine == null) return;
        StopCoroutine(lifetimeRoutine);
        lifetimeRoutine = null;
    }
}
