using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>실습용: Pause 중 재시작 시 timeScale 복원 누락 방지.</summary>
public sealed class Day30TimeScaleGuard : MonoBehaviour
{
    private void Awake() => Time.timeScale = 1f;

    public void Pause() => Time.timeScale = 0f;
    public void Resume() => Time.timeScale = 1f;

    public void RestartCurrentScene()
    {
        Time.timeScale = 1f; // 씬 전환 전에 반드시 복원
        Scene scene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(scene.buildIndex);
    }

    private void OnDestroy()
    {
        // 기존 게임 흐름 관리자가 별도로 있는 프로젝트에서는 정책 충돌 주의.
    }
}
