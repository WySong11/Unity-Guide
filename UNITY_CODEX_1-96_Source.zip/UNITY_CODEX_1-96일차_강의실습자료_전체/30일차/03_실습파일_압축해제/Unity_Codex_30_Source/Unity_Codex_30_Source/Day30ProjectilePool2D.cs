using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

/// <summary>Unity 6 ObjectPool을 이용한 2D 발사체 실습용 풀.</summary>
public sealed class Day30ProjectilePool2D : MonoBehaviour
{
    [SerializeField] private Day30ProjectileFixed projectilePrefab;
    [SerializeField] private Transform firePoint;
    [Min(1)] [SerializeField] private int prewarmCount = 8;
    [Min(1)] [SerializeField] private int maxPoolSize = 32;
    [Min(0.1f)] [SerializeField] private float speed = 8f;
    [Min(0.1f)] [SerializeField] private float lifetime = 2f;

    private ObjectPool<Day30ProjectileFixed> pool;

    private void Awake()
    {
        if (projectilePrefab == null)
        {
            Debug.LogError("[Day30] Projectile Prefab이 없습니다.", this);
            enabled = false;
            return;
        }
        int capacity = Mathf.Max(1, maxPoolSize);
        pool = new ObjectPool<Day30ProjectileFixed>(
            Create,
            item => item.gameObject.SetActive(true),
            item => item.gameObject.SetActive(false),
            item => { if (item != null) Destroy(item.gameObject); },
            collectionCheck: true,
            defaultCapacity: Mathf.Min(prewarmCount, capacity),
            maxSize: capacity);
        Prewarm(Mathf.Min(prewarmCount, capacity));
    }

    private Day30ProjectileFixed Create()
    {
        Day30ProjectileFixed item = Instantiate(projectilePrefab, transform);
        item.SetOwner(this);
        item.gameObject.SetActive(false);
        return item;
    }

    private void Prewarm(int count)
    {
        List<Day30ProjectileFixed> temp = new List<Day30ProjectileFixed>(count);
        for (int i = 0; i < count; i++) temp.Add(pool.Get());
        foreach (Day30ProjectileFixed item in temp) pool.Release(item);
    }

    public void Fire()
    {
        if (pool == null) return;
        Vector3 start = firePoint != null ? firePoint.position : transform.position;
        Vector2 direction = firePoint != null ? firePoint.right : transform.right;
        pool.Get().Launch(start, direction, speed, lifetime);
    }

    public void Release(Day30ProjectileFixed item)
    {
        if (pool != null && item != null) pool.Release(item);
    }
}
