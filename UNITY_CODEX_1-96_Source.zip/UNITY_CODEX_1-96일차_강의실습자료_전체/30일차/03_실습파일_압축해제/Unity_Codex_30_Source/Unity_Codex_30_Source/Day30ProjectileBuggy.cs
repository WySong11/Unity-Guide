using UnityEngine;

/// <summary>실습 전용: 재사용할 때마다 스케일이 누적되고 속도가 남는 잘못된 예시.</summary>
/// <remarks>Day30ProjectileFixed와 동시에 붙이지 마세요.</remarks>
[RequireComponent(typeof(Rigidbody2D))]
public sealed class Day30ProjectileBuggy : MonoBehaviour
{
    private Rigidbody2D body;

    private void Awake() => body = GetComponent<Rigidbody2D>();

    private void OnEnable()
    {
        // 고의 버그: 풀에서 재사용할 때 1.2배씩 계속 커짐.
        transform.localScale *= 1.2f;
    }

    public void Launch(Vector2 direction, float speed)
    {
        // 고의 버그: 기존 각속도·이전 상태 초기화가 없음.
        body.linearVelocity = direction.normalized * speed;
    }
}
