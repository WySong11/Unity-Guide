using UnityEngine;

/// <summary>UI Button OnClick에서 호출할 수 있는 실습 테스트 진입점.</summary>
public sealed class Day30DebugHarness : MonoBehaviour
{
    [SerializeField] private Day30HealthModel healthModel;
    [SerializeField] private Day30ProjectilePool2D projectilePool;
    [SerializeField] private Day30TimeScaleGuard timeScaleGuard;

    public void Damage10()
    {
        if (healthModel != null) healthModel.TakeDamage(10);
        else Debug.LogWarning("[Day30] HealthModel을 연결하세요.", this);
    }

    public void Heal10()
    {
        if (healthModel != null) healthModel.Heal(10);
        else Debug.LogWarning("[Day30] HealthModel을 연결하세요.", this);
    }

    public void Fire()
    {
        if (projectilePool != null) projectilePool.Fire();
        else Debug.LogWarning("[Day30] ProjectilePool을 연결하세요.", this);
    }

    public void Pause() => timeScaleGuard?.Pause();
    public void Resume() => timeScaleGuard?.Resume();
    public void Restart() => timeScaleGuard?.RestartCurrentScene();
}
