# Unity × Codex — 30일차 실습 코드

대상: Unity 6.3 (6000.3 계열), uGUI 및 TextMeshPro, 2D 물리. **실습용 예제이며 Unity Editor 실행 검증 전입니다.**

## 파일 구성

- `Day30HealthModel.cs`: 0~최대 체력, `HealthChanged` 이벤트.
- `Day30HealthBarBuggy.cs`: 의도적으로 Inspector null 검사를 생략한 잘못된 코드.
- `Day30HealthBarFixed.cs`: null 방어 + UI 초기값 + 이벤트 구독/해제.
- `Day30ProjectileBuggy.cs`: 재사용 시 스케일 누적 등의 의도적 결함.
- `Day30ProjectileFixed.cs`: 위치/스케일/속도 초기화 + 수명 관리 + 반환 중복 방지.
- `Day30ProjectilePool2D.cs`: `ObjectPool<T>` 및 Prewarm, `Fire`/`Release`.
- `Day30TimeScaleGuard.cs`: Pause/Resume/Restart에서 timeScale 초기화.
- `Day30DebugHarness.cs`: Inspector 버튼으로 테스트.
- `CODEX_PROMPTS.md`: 복사하여 사용할 분석/수정/검증 프롬프트.
- `TEST_CHECKLIST.md`: 재현 조건과 회귀 검사.

## 실습 A: 체력바 NullReferenceException

1. 새 씬에 `HealthModel` 게임 오브젝트를 생성하고 `Day30HealthModel` 부착.
2. Canvas > Slider + TextMeshPro 텍스트를 배치.
3. UI 오브젝트에 `Day30HealthBarBuggy`를 붙이고 `healthModel` 슬롯을 일부러 비운 채 Play.
4. Console > `NullReferenceException` 및 Stack Trace 관찰. Play 중 변경 결과는 영구 저장되지 않을 수 있음.
5. Play 종료 후 **Buggy 제거**, `Day30HealthBarFixed` 부착, `healthModel`·`healthSlider` 연결.
6. HP 버튼을 눌러 초기 표기와 변화, UI 비활성/재활성화 시 구독 안정성을 검사.

## 실습 B: Object Pool 재사용 상태

1. Sprite가 있는 발사체 Prefab에 `Rigidbody2D`(Gravity Scale 0), `Collider2D`(Is Trigger)를 추가.
2. `Day30ProjectileFixed`를 붙이고 Rigidbody2D를 연결. 별도 `Day30ProjectileBuggy`는 **같이 붙이지 않음**.
3. 빈 오브젝트에 `Day30ProjectilePool2D`를 붙이고 프리팹 참조 및 Spawn용 FirePoint 설정.
4. Play 후 `Day30DebugHarness.Fire()` 또는 UI Button 이벤트로 여러 번 발사.
5. 각 재사용마다 원래 스케일·위치·속도가 초기화되는지 검증.
6. **Buggy를 비교하려면** 테스트용 별도 Prefab/오브젝트를 만들고 직접 On/Off를 반복해 스케일 누적을 관찰. 이 파일은 정상 풀 드라이버에 연결하지 않음.

## 실습 C: Pause 후 재시작

1. `Day30TimeScaleGuard`를 GameScene의 오브젝트에 부착.
2. `Day30DebugHarness`의 TimeScaleGuard 참조 연결.
3. Pause → Restart Current Scene을 테스트. 게임이 0배속으로 남지 않아야 함.
4. 기존 28일차 `GameFlowControllerV2`와 함께 사용할 경우 **시간 관리는 하나의 컨트롤러만** 담당하도록 통합. 별도의 중복 사용을 권장하지 않음.
5. Restart가 같은 씬을 로딩하므로 대상 씬을 Build Profiles의 Scene List에 추가.

## 도구 한계 및 안전 주의

- Codex나 MCP가 연결되어 있더라도 **실제 Unity Editor에서 실행해 보지 않으면 통과를 주장하면 안 됩니다.**
- Unity MCP는 설치·권한·활성 Editor 연결 상태에 따라 테스트 가능 범위가 달라집니다.
- 스크립트의 이름이 같거나 기존 수업 코드와 충돌하는 경우에는 Unity Console의 CS 오류를 먼저 해결합니다.
- 작업 전 `git status` 및 변경 사항 확인, 자동 수정 후 `git diff`와 수정 범위 검토.
- 강의용으로 의도된 `Buggy` 컴포넌트는 최종 제출물에서 제거.

## 주요 공식 참고

- Unity Console: https://docs.unity3d.com/kr/current/Manual/Console.html
- Unity 6 Rigidbody2D.linearVelocity: https://docs.unity.cn/6000.1/Documentation/ScriptReference/Rigidbody2D-linearVelocity.html
- Codex 개선 반복: https://developers.openai.com/cookbook/examples/codex/build_iterative_repair_loops_with_codex
- Codex AGENTS.md 워크플로: https://developers.openai.com/cookbook/examples/codex/iterating-development-workflows-with-codex
