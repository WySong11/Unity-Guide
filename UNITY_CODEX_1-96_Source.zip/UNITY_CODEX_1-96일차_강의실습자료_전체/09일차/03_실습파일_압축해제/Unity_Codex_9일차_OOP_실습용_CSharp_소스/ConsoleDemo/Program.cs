using System;

Character hero = new PlayerCharacter("Hero", 100);
Character slime = new EnemyCharacter("Slime", 30);

Console.WriteLine(hero.Attack());
Console.WriteLine(slime.Attack());
slime.TakeDamage(12);
Console.WriteLine($"{slime.Name} HP: {slime.Hp}");

// 간단 테스트
Character test = new Character("Test", 20);
test.TakeDamage(999);
AssertEqual(test.Hp, 0, "과도한 피해 후 HP는 0");
test.Heal(999);
AssertEqual(test.Hp, 0, "사망 후 Heal은 무효");

Character test2 = new Character("Test2", 20);
test2.TakeDamage(-5);
AssertEqual(test2.Hp, 20, "음수 데미지는 무시");
test2.TakeDamage(8);
test2.Heal(999);
AssertEqual(test2.Hp, 20, "최대 HP 초과 회복 방지");

Console.WriteLine("모든 테스트를 완료했습니다.");

static void AssertEqual(int actual, int expected, string testName)
{
    if (actual != expected)
        throw new Exception($"테스트 실패: {testName}, expected={expected}, actual={actual}");
    Console.WriteLine($"PASS: {testName}");
}
