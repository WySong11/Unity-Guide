using System;

/// <summary>
/// 이름과 체력을 관리하는 일반 C# 데이터 클래스입니다.
/// MonoBehaviour가 아니므로 new로 생성할 수 있습니다.
/// </summary>
public class Character
{
    public string Name { get; }
    public int MaxHp { get; }
    public int Hp { get; private set; }
    public bool IsDead => Hp == 0;

    public Character(string name, int maxHp)
    {
        Name = name;
        MaxHp = Math.Max(1, maxHp);
        Hp = MaxHp;
    }

    public void TakeDamage(int amount)
    {
        if (amount <= 0 || IsDead)
            return;

        Hp = Math.Max(0, Hp - amount);
    }

    public void Heal(int amount)
    {
        // 이 실습에서는 사망한 캐릭터를 Heal로 부활시킬 수 없습니다.
        if (amount <= 0 || IsDead)
            return;

        Hp = Math.Min(MaxHp, Hp + amount);
    }

    public virtual string Attack() => $"{Name} attacks";
}
