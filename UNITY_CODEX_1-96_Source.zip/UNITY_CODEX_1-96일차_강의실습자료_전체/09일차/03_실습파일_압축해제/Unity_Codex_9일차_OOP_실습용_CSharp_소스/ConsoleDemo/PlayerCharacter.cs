/// <summary>
/// 플레이어 캐릭터: Character의 공통 체력 기능을 상속합니다.
/// </summary>
public class PlayerCharacter : Character
{
    public PlayerCharacter(string name, int maxHp)
        : base(name, maxHp)
    {
    }

    public override string Attack()
    {
        return $"{Name} uses Sword Slash!";
    }
}
