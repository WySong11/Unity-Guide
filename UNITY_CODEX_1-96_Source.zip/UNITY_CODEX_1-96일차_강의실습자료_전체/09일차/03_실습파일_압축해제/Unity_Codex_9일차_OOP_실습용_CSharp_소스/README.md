# 9일차 - C# 클래스와 객체지향 실습 소스

## 폴더 구성
- `UnityScripts/`: Unity 6.x 프로젝트 `Assets/Scripts/Day09/`에 복사해 사용하는 예제
- `ConsoleDemo/`: .NET 10 콘솔 앱 예제 및 간단한 경계값 검증

## Unity 사용법
1. 새 Unity 6.x 프로젝트를 열고 `Assets/Scripts/Day09/` 폴더를 만듭니다.
2. `UnityScripts/`의 C# 스크립트 4개를 복사합니다.
3. Scene에 빈 GameObject를 만들고 `BattleDemo` 컴포넌트를 붙입니다.
4. Play 후 Console을 확인합니다.

예상 출력의 앞 세 줄:
```
Hero uses Sword Slash!
Slime uses Bite!
Slime HP: 18
```

**주의:** `Character`는 일반 C# 클래스이므로 `new`로 생성합니다. `BattleDemo`는 `MonoBehaviour`이므로 `new BattleDemo()`를 호출하지 마세요.

## 콘솔 앱 사용법
.NET 10 SDK가 설치된 PC에서:
```
cd ConsoleDemo
dotnet run
```

`ConsoleDemo`는 Unity 엔진 없이 실행할 수 있습니다. 체력이 0 미만으로 내려가지 않는지, 음수 데미지를 무시하는지, 최대 HP를 초과하지 않는지 검사합니다.

## 강의 주제
- Class / Object / Field / Property / Method / Constructor
- Encapsulation / Inheritance / Polymorphism / Abstraction
- `MonoBehaviour`와 일반 C# 클래스의 차이
- Codex 읽기 전용 분석 및 변경 검증

## 검증 안내
소스 내용의 정적 검토를 수행했지만 여기서는 .NET SDK/Unity Editor를 직접 실행하지 않았습니다. 수업 시작 전에 실제 개발 PC에서 Console 출력과 컴파일을 확인하세요.
