using UnityEngine;

/// <summary>
/// 빈 GameObject에 붙인 다음 Play 버튼을 눌러 테스트합니다.
/// MonoBehaviour는 new로 직접 생성하지 않습니다.
/// </summary>
public class BattleDemo : MonoBehaviour
{
    private void Start()
    {
        Character hero = new PlayerCharacter("Hero", 100);
        Character slime = new EnemyCharacter("Slime", 30);

        Debug.Log(hero.Attack());
        Debug.Log(slime.Attack());
        slime.TakeDamage(12);
        Debug.Log($"{slime.Name} HP: {slime.Hp}");

        // 경계값 검증 (교강사 시연용)
        slime.TakeDamage(-3); // 변경 없음
        slime.TakeDamage(999); // 0까지 감소
        Debug.Log($"{slime.Name} is dead: {slime.IsDead}");
    }
}
