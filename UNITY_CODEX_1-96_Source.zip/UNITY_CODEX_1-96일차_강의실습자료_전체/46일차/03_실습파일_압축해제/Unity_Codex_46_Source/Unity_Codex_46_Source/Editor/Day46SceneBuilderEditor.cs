#if UNITY_EDITOR
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public static class Day46SceneBuilderEditor
{
    [MenuItem("Tools/Unity Codex/Day46/Create Practice Scene")]
    private static void Create()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        var ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Ground";
        ground.transform.localScale = new Vector3(2f, 1f, 2f);

        var lightObj = new GameObject("Directional Light");
        var light = lightObj.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.2f;
        lightObj.transform.rotation = Quaternion.Euler(45, -40, 0);

        var cameraObj = new GameObject("Main Camera");
        cameraObj.tag = "MainCamera";
        var camera = cameraObj.AddComponent<Camera>();
        cameraObj.AddComponent<AudioListener>();
        cameraObj.transform.position = new Vector3(0, 2.3f, -7f);
        cameraObj.transform.LookAt(new Vector3(0, 1.2f, 6));
        var attack = cameraObj.AddComponent<Day46RaycastAttack>();
        attack.Configure(camera, 25);

        var root = new GameObject("Day46_GameSystems");
        var score = root.AddComponent<Day46ScoreModel>();
        var target = GameObject.CreatePrimitive(PrimitiveType.Cube);
        target.name = "Target_Damageable";
        target.SetActive(false);
        target.transform.position = new Vector3(0, 1.1f, 6);
        target.transform.localScale = new Vector3(2, 2, 1);
        var health = target.AddComponent<Day46Health>();
        var reward = target.AddComponent<Day46TargetReward>();
        reward.Configure(health, score, 50);
        target.SetActive(true);

        var loggerObj = new GameObject("EventLogger");
        loggerObj.SetActive(false);
        loggerObj.transform.SetParent(root.transform);
        loggerObj.AddComponent<Day46EventLogger>().Configure(health, score);
        loggerObj.SetActive(true);

        var canvasObj = new GameObject("Canvas", typeof(RectTransform),
            typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        var canvas = canvasObj.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        var scaler = canvasObj.GetComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920, 1080);

        var hpLabel = Text(canvasObj.transform, "HP Label", "HP 100/100",
            new Vector2(0.1f, 0.9f), 42, Color.white);
        var scoreLabel = Text(canvasObj.transform, "Score Label", "SCORE 0",
            new Vector2(0.85f, 0.9f), 42, Color.yellow);
        var deathLabel = Text(canvasObj.transform, "Death Label", "TARGET DOWN!",
            new Vector2(0.5f, 0.7f), 64, Color.red);
        deathLabel.gameObject.SetActive(false);

        var sliderObj = new GameObject("HP Slider", typeof(RectTransform),
            typeof(Image), typeof(Slider));
        sliderObj.transform.SetParent(canvasObj.transform, false);
        var sliderRect = sliderObj.GetComponent<RectTransform>();
        sliderRect.anchorMin = sliderRect.anchorMax = new Vector2(0.1f, .84f);
        sliderRect.sizeDelta = new Vector2(380, 32);
        var bg = sliderObj.GetComponent<Image>(); bg.color = new Color(.15f, .15f, .15f, .9f);
        var fillObj = new GameObject("Fill", typeof(RectTransform), typeof(Image));
        fillObj.transform.SetParent(sliderObj.transform, false);
        var fillRect = fillObj.GetComponent<RectTransform>();
        fillRect.anchorMin = Vector2.zero; fillRect.anchorMax = Vector2.one;
        fillRect.offsetMin = new Vector2(3,3); fillRect.offsetMax = new Vector2(-3,-3);
        fillObj.GetComponent<Image>().color = new Color(.3f, .9f, .5f, 1f);
        var slider = sliderObj.GetComponent<Slider>();
        slider.fillRect = fillRect; slider.interactable = false;
        slider.minValue = 0; slider.maxValue = 100; slider.value = 100;

        var healthHudGo = new GameObject("HealthHUD");
        healthHudGo.SetActive(false);
        healthHudGo.transform.SetParent(canvasObj.transform, false);
        healthHudGo.AddComponent<Day46HealthHUD>().Configure(health, slider, hpLabel);
        healthHudGo.SetActive(true);

        var scoreHudGo = new GameObject("ScoreHUD");
        scoreHudGo.SetActive(false);
        scoreHudGo.transform.SetParent(canvasObj.transform, false);
        scoreHudGo.AddComponent<Day46ScoreHUD>().Configure(score, scoreLabel);
        scoreHudGo.SetActive(true);

        var noticeGo = new GameObject("DeathNotice");
        noticeGo.SetActive(false);
        noticeGo.transform.SetParent(canvasObj.transform, false);
        noticeGo.AddComponent<Day46DeathNotice>().Configure(health, deathLabel.gameObject);
        noticeGo.SetActive(true);

        var damageBtn = Button(canvasObj.transform, "Damage Button", "TAKE 25", new Vector2(.36f,.12f));
        var damageLink = damageBtn.gameObject.AddComponent<Day46DamageButton>();
        damageLink.Configure(damageBtn, health, 25);
        var resetBtn = Button(canvasObj.transform, "Reset Button", "RESET", new Vector2(.64f,.12f));
        var resetLink = resetBtn.gameObject.AddComponent<Day46ResetButton>();
        resetLink.Configure(resetBtn, health, score);

        new GameObject("EventSystem", typeof(EventSystem), typeof(InputSystemUIInputModule));
        string path = AssetDatabase.GenerateUniqueAssetPath("Assets/Day46_Event_Interface_Practice.unity");
        EditorSceneManager.SaveScene(scene, path);
        Selection.activeObject = target;
        Debug.Log($"[Day46] Created {path}. F: shoot, UI: damage/reset. Check Input System package + TMP Essentials.");
    }

    private static TextMeshProUGUI Text(Transform parent, string name, string text,
                                         Vector2 anchors, float fontSize, Color color)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(TextMeshProUGUI));
        go.transform.SetParent(parent, false);
        var rect = go.GetComponent<RectTransform>();
        rect.anchorMin = rect.anchorMax = anchors;
        rect.sizeDelta = new Vector2(500, 90);
        var label = go.GetComponent<TextMeshProUGUI>();
        label.text = text; label.fontSize = fontSize; label.color = color;
        label.alignment = TextAlignmentOptions.Center;
        return label;
    }

    private static Button Button(Transform parent, string name, string label, Vector2 anchor)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(Image), typeof(Button));
        go.SetActive(false); // listener를 연결한 뒤 활성화하여 OnEnable 1회만 구독.
        go.transform.SetParent(parent, false);
        var rect = go.GetComponent<RectTransform>();
        rect.anchorMin = rect.anchorMax = anchor;
        rect.sizeDelta = new Vector2(220, 82);
        go.GetComponent<Image>().color = new Color(.15f, .35f, .75f, 1f);
        Text(go.transform, "Label", label, new Vector2(.5f,.5f), 34, Color.white);
        go.SetActive(true);
        return go.GetComponent<Button>();
    }
}
#endif
