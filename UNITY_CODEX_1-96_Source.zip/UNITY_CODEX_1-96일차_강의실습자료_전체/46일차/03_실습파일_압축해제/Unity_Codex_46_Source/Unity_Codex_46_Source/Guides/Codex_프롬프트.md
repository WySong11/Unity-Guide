# Day46 Codex 프롬프트

## 프롬프트 1: 기존 코드 구조 분석(read-only)
Unity 6.3 프로젝트에서 Day45 Input/Motor/Combat/Health/HUD를 분석해줘. 먼저 파일을 수정하지 말고 직접 참조, 인터페이스 사용 가능 지점, C# 이벤트 발행자/구독자, 이벤트 구독 해제 누락을 표로 정리해줘. Unity의 현재 활성 씬/Prefab은 수정하지 마.

## 프롬프트 2: 기능 보존 리팩터링
IDamageable 계약으로 피해 수신 경로를 분리하고 HealthChanged/Died 구독 구조로 HUD를 변경해줘. 기존 이동·점프·공격·HP 수치와 Inspector 참조를 보존하고 최소 범위만 수정해줘. OnEnable/OnDisable 대칭을 검사하고 사용 중인 원본 파일을 삭제하지 마.

## 프롬프트 3: 오류 재현과 검증
Console 오류와 Stack Trace, 이벤트 구독/해제 코드, 관련 씬/Prefab을 함께 분석해. Play Mode에서 대상 4회 공격→사망 1회→보상 점수 1회→Reset→재시도, HUD 비활성/활성 3회, 씬 재시작 후 중복 호출 없음 조건을 검증해줘. Unity Editor에서 실행할 수 없다면 미실행이라고 분명히 보고해줘. 변경 파일과 git diff도 제시해.
