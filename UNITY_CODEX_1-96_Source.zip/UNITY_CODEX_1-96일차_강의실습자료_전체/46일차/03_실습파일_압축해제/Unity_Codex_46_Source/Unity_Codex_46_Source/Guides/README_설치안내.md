# Unity Codex 46일차: C# 이벤트와 인터페이스

## 목적
45일차 컴포넌트 분리 설계를 확장하여 `IDay46Damageable` 인터페이스와 `event Action<T>`로 피해·UI·점수·사망 처리의 결합도를 낮춥니다.

## 준비
- Unity 6.3 기반 Universal 3D 프로젝트
- Unity Input System 패키지 및 Active Input Handling = Input System Package (또는 Both)
- TextMeshPro Essentials 설치: Window → TextMeshPro → Import TMP Essential Resources
- Unity UI(uGUI), TMPro 패키지 사용
- 기존 45일차 씬을 덮어쓰지 않도록 Git 커밋 또는 별도 프로젝트 사용

## 설치 및 생성
1. `Runtime/*.cs`를 `Assets/Scripts/Day46/`에 복사합니다.
2. `Editor/Day46SceneBuilderEditor.cs`를 `Assets/Editor/Day46/`에 복사합니다.
3. 컴파일 오류가 없는지 Console을 확인합니다.
4. 메뉴 `Tools → Unity Codex → Day46 → Create Practice Scene` 실행 후 저장 경로를 확인합니다.
5. Play 버튼을 누르고 화면 중심의 큐브를 F 키로 발사하거나 TAKE 25 버튼을 누릅니다.
6. HP가 0이 되면 사망 메시지가 표시되고 점수가 50 증가하는지 확인합니다.
7. RESET으로 HP/점수를 초기화하고 재실행합니다.

## 파일 역할
- `IDay46Damageable.cs`: 데미지 수신 인터페이스
- `Day46Health.cs`: 체력 소유자, `HealthChanged`, `Died` 이벤트 발행자
- `Day46ScoreModel.cs`: 점수 데이터·변경 이벤트 발행자
- `Day46HealthHUD.cs`, `Day46ScoreHUD.cs`: UI 이벤트 구독자
- `Day46TargetReward.cs`: Died 발생 시 점수 보상
- `Day46RaycastAttack.cs`: IDay46Damageable 계약을 이용한 공격
- `Day46DamageButton.cs`, `Day46ResetButton.cs`: UI Button.onClick(UnityEvent) 리스너
- `Day46DeathNotice.cs`: 사망 메시지 표시
- `Day46EventLogger.cs`: 콘솔 진단 구독자
- `Day46SceneBuilderEditor.cs`: 독립 실습 씬 생성

## 핵심 개념과 함정
- `public event Action`의 호출은 선언한 타입 내부에서만 가능. 외부 구독자는 `+=`, `-=`로만 통신합니다.
- `interface`는 계약이며 `[SerializeField] IDay46Damageable`은 일반 Inspector 직접 직렬화 대상이 아닙니다. 구현 `MonoBehaviour`를 찾아 인터페이스로 캐스팅합니다.
- `OnEnable`에서 구독한 콜백은 `OnDisable`에서 동일한 핸들러를 해제해야 합니다.
- `event`와 `UnityEvent`는 용도가 다릅니다. `UnityEvent`는 Inspector 연결을 지원하며 `Button.onClick`에 적합합니다.
- C# `event`와 `UnityEvent`는 모두 `Invoke` 시 호출자를 해당 프레임에서 동기 실행합니다. 비동기 처리가 아닙니다.
- 소스 파일은 독립 Day46 실습용이며 기존 Day41~45 공격·체력 컴포넌트와 중복 장착하지 마세요.

## 검증 수준
코드 파일과 PPT 구조/압축 무결성을 검사했습니다. Unity Editor 실제 컴파일 및 실행 테스트는 수행하지 않았으므로 수업 전에 Play Mode 테스트가 필요합니다.
