public interface IDay46Damageable
{
    void TakeDamage(int amount);
}
