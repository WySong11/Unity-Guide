using UnityEngine;

public sealed class Day46TargetReward : MonoBehaviour
{
    [SerializeField] private Day46Health health;
    [SerializeField] private Day46ScoreModel scoreModel;
    [SerializeField, Min(1)] private int rewardPoints = 50;
    private bool rewarded;

    public void Configure(Day46Health targetHealth, Day46ScoreModel model, int points)
    {
        if (isActiveAndEnabled) Unsubscribe();
        health = targetHealth; scoreModel = model; rewardPoints = Mathf.Max(1, points);
        rewarded = health != null && health.IsDead;
        if (isActiveAndEnabled) Subscribe();
    }
    private void OnEnable() { rewarded = health != null && health.IsDead; Subscribe(); }
    private void OnDisable() => Unsubscribe();
    private void Subscribe()
    {
        if (health == null) return;
        health.HealthChanged += OnHealthChanged;
        health.Died += OnDied;
    }
    private void Unsubscribe()
    {
        if (health == null) return;
        health.HealthChanged -= OnHealthChanged;
        health.Died -= OnDied;
    }
    private void OnHealthChanged(int current, int max)
    {
        if (current > 0) rewarded = false; // ResetHealth 이후 보상 재획득 가능.
    }
    private void OnDied()
    {
        if (rewarded || scoreModel == null) return;
        rewarded = true;
        scoreModel.AddScore(rewardPoints);
    }
}
