using System;
using UnityEngine;

[DisallowMultipleComponent]
public sealed class Day46ScoreModel : MonoBehaviour
{
    public int Score { get; private set; }
    public event Action<int> ScoreChanged;

    public void AddScore(int amount)
    {
        if (amount <= 0) return;
        Score = Score > int.MaxValue - amount ? int.MaxValue : Score + amount;
        ScoreChanged?.Invoke(Score);
    }

    public void ResetScore()
    {
        Score = 0;
        ScoreChanged?.Invoke(Score);
    }
}
