using TMPro;
using UnityEngine;
using UnityEngine.UI;

public sealed class Day46HealthHUD : MonoBehaviour
{
    [SerializeField] private Day46Health source;
    [SerializeField] private Slider hpSlider;
    [SerializeField] private TMP_Text hpLabel;

    public void Configure(Day46Health health, Slider slider, TMP_Text label)
    {
        if (isActiveAndEnabled && source != null) source.HealthChanged -= Refresh;
        source = health; hpSlider = slider; hpLabel = label;
        if (isActiveAndEnabled) { Subscribe(); RefreshInitial(); }
    }

    private void OnEnable() { Subscribe(); RefreshInitial(); }
    private void OnDisable()
    {
        if (source != null) source.HealthChanged -= Refresh;
    }
    private void Subscribe()
    {
        if (source != null) source.HealthChanged += Refresh;
    }
    private void RefreshInitial()
    {
        if (source != null) Refresh(source.CurrentHealth, source.MaxHealth);
    }
    private void Refresh(int current, int max)
    {
        if (hpSlider != null)
        {
            hpSlider.minValue = 0;
            hpSlider.maxValue = max;
            hpSlider.SetValueWithoutNotify(current);
        }
        if (hpLabel != null) hpLabel.text = $"HP {current}/{max}";
    }
}
