using UnityEngine;
using UnityEngine.UI;

public sealed class Day46DamageButton : MonoBehaviour
{
    [SerializeField] private Button button;
    [SerializeField] private Day46Health target;
    [SerializeField, Min(1)] private int damage = 25;

    public void Configure(Button uiButton, Day46Health targetHealth, int amount)
    {
        if (isActiveAndEnabled && button != null) button.onClick.RemoveListener(Damage);
        button = uiButton; target = targetHealth; damage = Mathf.Max(1, amount);
        if (isActiveAndEnabled && button != null) button.onClick.AddListener(Damage);
    }
    private void OnEnable()
    {
        if (button != null) button.onClick.AddListener(Damage);
    }
    private void OnDisable()
    {
        if (button != null) button.onClick.RemoveListener(Damage);
    }
    public void Damage()
    {
        if (target != null) target.TakeDamage(damage);
    }
}
