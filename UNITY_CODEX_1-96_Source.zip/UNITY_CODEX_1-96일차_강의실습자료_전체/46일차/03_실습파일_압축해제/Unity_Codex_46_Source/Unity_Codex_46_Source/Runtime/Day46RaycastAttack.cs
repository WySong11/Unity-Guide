using System;
using UnityEngine;
using UnityEngine.InputSystem;

public sealed class Day46RaycastAttack : MonoBehaviour
{
    [SerializeField] private Camera aimCamera;
    [SerializeField, Min(0.1f)] private float range = 50f;
    [SerializeField, Min(1)] private int damage = 25;
    [SerializeField] private LayerMask hitMask = ~0;

    public event Action<bool> ShotResolved; // 명중여부를 다른 컴포넌트에 알림.

    public void Configure(Camera camera, int damageAmount)
    {
        aimCamera = camera;
        damage = Mathf.Max(1, damageAmount);
    }
    private void Awake()
    {
        if (aimCamera == null) aimCamera = Camera.main;
    }
    private void Update()
    {
        if (Time.timeScale <= 0f) return;
        if (Keyboard.current != null && Keyboard.current.fKey.wasPressedThisFrame)
            Fire();
    }
    public bool Fire()
    {
        if (aimCamera == null) return false;
        Ray ray = aimCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f));
        bool damaged = false;
        if (Physics.Raycast(ray, out RaycastHit hit, range, hitMask,
                            QueryTriggerInteraction.Ignore))
        {
            foreach (MonoBehaviour behaviour in hit.collider.GetComponentsInParent<MonoBehaviour>())
            {
                if (behaviour is IDay46Damageable target)
                {
                    target.TakeDamage(damage);
                    damaged = true;
                    break;
                }
            }
        }
        Debug.DrawRay(ray.origin, ray.direction * range,
                      damaged ? Color.green : Color.yellow, 1f);
        ShotResolved?.Invoke(damaged);
        return damaged;
    }
}
