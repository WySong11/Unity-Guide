using UnityEngine;
using UnityEngine.UI;

public sealed class Day46ResetButton : MonoBehaviour
{
    [SerializeField] private Button button;
    [SerializeField] private Day46Health health;
    [SerializeField] private Day46ScoreModel score;

    public void Configure(Button uiButton, Day46Health target, Day46ScoreModel scoreModel)
    {
        if (isActiveAndEnabled && button != null) button.onClick.RemoveListener(ResetAll);
        button = uiButton; health = target; score = scoreModel;
        if (isActiveAndEnabled && button != null) button.onClick.AddListener(ResetAll);
    }
    private void OnEnable() { if (button != null) button.onClick.AddListener(ResetAll); }
    private void OnDisable() { if (button != null) button.onClick.RemoveListener(ResetAll); }
    public void ResetAll()
    {
        if (health != null) health.ResetHealth();
        if (score != null) score.ResetScore();
    }
}
