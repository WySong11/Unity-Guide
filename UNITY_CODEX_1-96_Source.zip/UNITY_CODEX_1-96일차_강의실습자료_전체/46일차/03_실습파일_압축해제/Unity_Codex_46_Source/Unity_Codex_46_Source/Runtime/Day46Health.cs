using System;
using UnityEngine;

[DisallowMultipleComponent]
public sealed class Day46Health : MonoBehaviour, IDay46Damageable
{
    [SerializeField, Min(1)] private int maxHealth = 100;

    public int MaxHealth => maxHealth;
    public int CurrentHealth { get; private set; }
    public bool IsDead => CurrentHealth <= 0;

    // 발행자인 Health만 Invoke할 수 있는 C# event.
    public event Action<int, int> HealthChanged;
    public event Action Died;

    private void Awake() => CurrentHealth = maxHealth;

    public void TakeDamage(int amount)
    {
        if (amount <= 0 || IsDead) return;
        CurrentHealth = Mathf.Max(0, CurrentHealth - amount);
        HealthChanged?.Invoke(CurrentHealth, maxHealth);
        if (IsDead) Died?.Invoke(); // 0으로 떨어진 단 한 번만 발생.
    }

    public void Heal(int amount)
    {
        if (amount <= 0 || IsDead) return;
        int updated = Mathf.Min(maxHealth, CurrentHealth + amount);
        if (updated == CurrentHealth) return;
        CurrentHealth = updated;
        HealthChanged?.Invoke(CurrentHealth, maxHealth);
    }

    public void ResetHealth()
    {
        CurrentHealth = maxHealth;
        HealthChanged?.Invoke(CurrentHealth, maxHealth);
    }

    private void OnValidate() => maxHealth = Mathf.Max(1, maxHealth);
}
