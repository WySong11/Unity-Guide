using UnityEngine;

public sealed class Day46DeathNotice : MonoBehaviour
{
    [SerializeField] private Day46Health target;
    [SerializeField] private GameObject deathMessage;

    public void Configure(Day46Health health, GameObject ui)
    {
        if (isActiveAndEnabled && target != null)
        {
            target.Died -= OnDied;
            target.HealthChanged -= OnHealthChanged;
        }
        target = health; deathMessage = ui;
        if (isActiveAndEnabled) { Subscribe(); Refresh(); }
    }
    private void OnEnable() { Subscribe(); Refresh(); }
    private void OnDisable()
    {
        if (target == null) return;
        target.Died -= OnDied;
        target.HealthChanged -= OnHealthChanged;
    }
    private void Subscribe()
    {
        if (target == null) return;
        target.Died += OnDied;
        target.HealthChanged += OnHealthChanged;
    }
    private void Refresh()
    {
        if (deathMessage != null)
            deathMessage.SetActive(target != null && target.IsDead);
    }
    private void OnDied() => Refresh();
    private void OnHealthChanged(int current, int max) => Refresh();
}
