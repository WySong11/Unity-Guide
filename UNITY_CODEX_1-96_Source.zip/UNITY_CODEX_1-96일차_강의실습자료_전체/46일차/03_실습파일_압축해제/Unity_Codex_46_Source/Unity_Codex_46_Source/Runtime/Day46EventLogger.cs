using UnityEngine;

public sealed class Day46EventLogger : MonoBehaviour
{
    [SerializeField] private Day46Health health;
    [SerializeField] private Day46ScoreModel score;

    public void Configure(Day46Health target, Day46ScoreModel model)
    {
        if (isActiveAndEnabled) Unsubscribe();
        health = target; score = model;
        if (isActiveAndEnabled) Subscribe();
    }
    private void OnEnable() => Subscribe();
    private void OnDisable() => Unsubscribe();
    private void Subscribe()
    {
        if (health != null)
        {
            health.HealthChanged += OnHealth;
            health.Died += OnDied;
        }
        if (score != null) score.ScoreChanged += OnScore;
    }
    private void Unsubscribe()
    {
        if (health != null)
        {
            health.HealthChanged -= OnHealth;
            health.Died -= OnDied;
        }
        if (score != null) score.ScoreChanged -= OnScore;
    }
    private void OnHealth(int hp, int max) => Debug.Log($"[Day46] HP {hp}/{max}");
    private void OnDied() => Debug.Log("[Day46] Target died");
    private void OnScore(int value) => Debug.Log($"[Day46] Score {value}");
}
