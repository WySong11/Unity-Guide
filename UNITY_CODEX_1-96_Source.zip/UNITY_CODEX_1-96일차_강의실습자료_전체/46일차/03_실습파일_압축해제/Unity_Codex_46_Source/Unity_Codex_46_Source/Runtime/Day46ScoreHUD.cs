using TMPro;
using UnityEngine;

public sealed class Day46ScoreHUD : MonoBehaviour
{
    [SerializeField] private Day46ScoreModel source;
    [SerializeField] private TMP_Text scoreLabel;

    public void Configure(Day46ScoreModel model, TMP_Text label)
    {
        if (isActiveAndEnabled && source != null) source.ScoreChanged -= Refresh;
        source = model; scoreLabel = label;
        if (isActiveAndEnabled) { Subscribe(); RefreshInitial(); }
    }
    private void OnEnable() { Subscribe(); RefreshInitial(); }
    private void OnDisable()
    {
        if (source != null) source.ScoreChanged -= Refresh;
    }
    private void Subscribe()
    {
        if (source != null) source.ScoreChanged += Refresh;
    }
    private void RefreshInitial()
    {
        if (source != null) Refresh(source.Score);
    }
    private void Refresh(int score)
    {
        if (scoreLabel != null) scoreLabel.text = $"SCORE {score}";
    }
}
