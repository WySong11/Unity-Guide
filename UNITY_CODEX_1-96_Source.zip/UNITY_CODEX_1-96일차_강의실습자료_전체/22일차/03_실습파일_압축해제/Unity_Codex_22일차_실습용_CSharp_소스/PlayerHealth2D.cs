using System.Collections;
using UnityEngine;
using UnityEngine.Events;

public class PlayerHealth2D : MonoBehaviour
{
    [SerializeField, Min(1)] private int maxHealth = 5;
    [SerializeField, Min(0f)] private float invincibleSeconds = 0.8f;
    [SerializeField] private SpriteRenderer spriteRenderer;
    [SerializeField] private Color hitTint = new Color(1f, 0.45f, 0.45f, 1f);
    [SerializeField] private UnityEvent onHit;
    [SerializeField] private UnityEvent onDie;

    private int currentHealth;
    private bool isInvincible;
    private bool isDead;
    private Color normalTint = Color.white;
    private Coroutine invincibleRoutine;

    public int CurrentHealth => currentHealth;
    public int MaxHealth => maxHealth;
    public bool IsDead => isDead;

    private void Awake()
    {
        currentHealth = maxHealth;
        if (spriteRenderer != null) normalTint = spriteRenderer.color;
    }

    public bool TryTakeDamage(int amount)
    {
        if (isDead || isInvincible || amount <= 0) return false;
        currentHealth = Mathf.Max(0, currentHealth - amount);
        Debug.Log($"[Player] HP {currentHealth}/{maxHealth}", this);
        onHit?.Invoke();
        if (currentHealth == 0)
        {
            isDead = true;
            onDie?.Invoke();
            return true;
        }
        if (invincibleSeconds > 0f)
            invincibleRoutine = StartCoroutine(InvincibilityRoutine());
        return true;
    }

    private IEnumerator InvincibilityRoutine()
    {
        isInvincible = true;
        if (spriteRenderer != null) spriteRenderer.color = hitTint;
        yield return new WaitForSeconds(invincibleSeconds);
        if (spriteRenderer != null) spriteRenderer.color = normalTint;
        isInvincible = false;
        invincibleRoutine = null;
    }

    private void OnDisable()
    {
        if (invincibleRoutine != null) StopCoroutine(invincibleRoutine);
        invincibleRoutine = null;
        isInvincible = false;
        if (spriteRenderer != null) spriteRenderer.color = normalTint;
    }
}
