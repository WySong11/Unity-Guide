using UnityEngine;
using UnityEngine.UI;

public class HealthBar2D : MonoBehaviour
{
    [SerializeField] private PlayerHealth2D target;
    [SerializeField] private Image hpFill; // Image Type = Filled / Fill Method = Horizontal

    private void Update()
    {
        if (target == null || hpFill == null) return;
        hpFill.fillAmount = (float)target.CurrentHealth / target.MaxHealth;
    }
}
