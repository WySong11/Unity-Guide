# 22일차 Codex 실습 프롬프트

1. 현재 Unity 6.3 프로젝트를 읽기 전용으로 조사하고 PlayerShooter2D / Projectile2D / EnemyHealth2D 호출 관계를 표로 정리해줘. 아직 파일을 수정하지 마.
2. 충돌이 감지되지 않는 증상을 재현하기 위한 체크리스트를 Rigidbody2D, Collider2D, IsTrigger, Layer Collision Matrix, 스크립트 위치로 분류해줘.
3. EnemyHealth2D의 TakeDamage(int)에서 체력이 0 아래로 내려가거나 Die가 중복 호출될 수 있는지 분석하고, 최소 수정안과 Diff를 제시해줘.
4. PlayerHealth2D의 무적 시간이 끝나기 전에 추가 피해가 들어오는 경우를 테스트하는 시나리오를 작성해줘.
5. 21일차 발사체와 22일차 적 체력 연동을 검증해줘. 기존 이동과 공격 코드는 건드리지 말고, 수정 전 변경 예상 파일과 영향 범위를 먼저 설명해줘.
6. 테스트 매트릭스 12개를 기준으로 확인했는지, 직접 실행한 항목과 코드 검토만 한 항목을 분리해서 보고해줘.
