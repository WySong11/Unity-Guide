# 22일차 충돌·데미지 버그 보고서

- 문제 제목:
- Unity 버전 / Input System 버전:
- 재현 장면·GameObject·Collider 설정:
- 예상 결과:
- 실제 결과:
- Console 로그 / Stack Trace:
- 원인 가설:
- 변경 파일 및 핵심 Diff:
- 재검증 항목 / 결과:
- Git Commit:
