using UnityEngine;

// 물리 충돌과 Trigger 중 실습 중 선택해 관찰하세요.
public class CollisionLogger2D : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log($"[Collision ENTER] {name} <-> {collision.collider.name}", this);
    }
    private void OnCollisionExit2D(Collision2D collision)
    {
        Debug.Log($"[Collision EXIT] {name} <-> {collision.collider.name}", this);
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log($"[Trigger ENTER] {name} <-> {other.name}", this);
    }
    private void OnTriggerExit2D(Collider2D other)
    {
        Debug.Log($"[Trigger EXIT] {name} <-> {other.name}", this);
    }
}
