using UnityEngine;

// 충돌 처리 스크립트에서 실제 공격 위치를 넘겨 호출하는 선택형 예제.
[RequireComponent(typeof(Rigidbody2D))]
public class PlayerKnockback2D : MonoBehaviour
{
    [SerializeField, Min(0f)] private float knockbackX = 5f;
    [SerializeField, Min(0f)] private float knockbackY = 3f;
    private Rigidbody2D rb;
    private void Awake() => rb = GetComponent<Rigidbody2D>();

    public void KnockbackFrom(Vector2 sourcePosition)
    {
        float horizontal = transform.position.x >= sourcePosition.x ? 1f : -1f;
        rb.linearVelocity = new Vector2(horizontal * knockbackX, knockbackY);
    }
}
