using UnityEngine;

// 플레이어와 트리거가 겹치면 한 번 피해를 시도합니다.
[RequireComponent(typeof(Collider2D))]
public class HazardDamage2D : MonoBehaviour
{
    [SerializeField, Min(1)] private int damage = 1;
    private void Reset() => GetComponent<Collider2D>().isTrigger = true;

    private void OnTriggerEnter2D(Collider2D other)
    {
        PlayerHealth2D player = other.GetComponentInParent<PlayerHealth2D>();
        if (player != null) player.TryTakeDamage(damage);
    }
}
