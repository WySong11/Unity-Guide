using UnityEngine;
using UnityEngine.Events;

// Day 21의 EnemyHealth2D.cs를 이 파일로 교체합니다. 중복 클래스 금지.
public class EnemyHealth2D : MonoBehaviour
{
    [SerializeField, Min(1)] private int maxHealth = 3;
    [SerializeField] private UnityEvent onHit;
    [SerializeField] private UnityEvent onDie;
    private int currentHealth;
    private bool defeated;

    public int CurrentHealth => currentHealth;
    public int MaxHealth => maxHealth;
    public bool IsDead => defeated;

    private void Awake() => currentHealth = maxHealth;

    // Day 21 Projectile2D에서 호출하던 시그니처 유지
    public void TakeDamage(int amount)
    {
        if (defeated || amount <= 0) return;
        currentHealth = Mathf.Max(0, currentHealth - amount);
        Debug.Log($"[Enemy] HP {currentHealth}/{maxHealth}", this);
        onHit?.Invoke();
        if (currentHealth > 0) return;
        defeated = true; // 사망 이벤트 중복 방지
        onDie?.Invoke();
        Destroy(gameObject);
    }
}
