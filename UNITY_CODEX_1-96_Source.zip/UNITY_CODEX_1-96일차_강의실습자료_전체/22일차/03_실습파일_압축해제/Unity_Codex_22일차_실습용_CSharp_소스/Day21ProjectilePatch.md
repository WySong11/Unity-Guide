# 21일차 발사체와 연동하기

- 21일차 `PlayerShooter2D.cs`, `Projectile2D.cs`는 유지합니다.
- 이전 `EnemyHealth2D.cs`만 이 ZIP의 새 버전으로 **교체**합니다 (중복 클래스 금지).
- 현재 `Projectile2D.OnTriggerEnter2D()`에는 `spent` 플래그가 있어 한 발의 중복 명중이 방지됩니다.
- 21일차 데모는 대상의 비-Trigger Collider2D에 충돌하는 방식입니다. 적 Collider를 Trigger로 바꿀 경우 기존 코드의 `other.isTrigger` 가드와의 관계를 검토하세요.
- 플레이어 본인 충돌은 소유자 하위 Transform 검사로 제외합니다.
- HazardDamage2D는 플레이어 피해 전용이며 발사체에 함께 붙이지 않습니다.
