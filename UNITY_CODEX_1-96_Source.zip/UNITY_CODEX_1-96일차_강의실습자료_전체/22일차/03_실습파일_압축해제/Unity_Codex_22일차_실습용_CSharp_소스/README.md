# UNITY × CODEX | 22일차 충돌 및 데미지 실습

**기준:** Unity 6.3 (6000.3 계열), 2D URP, C#.

## 이전 수업 연동
21일차 `PlayerShooter2D.cs`·`Projectile2D.cs`를 그대로 사용하고 `EnemyHealth2D.cs` 파일만 이 자료의 버전으로 교체합니다. 동일한 이름의 클래스가 2개 남아 있으면 컴파일 오류가 발생합니다.

## 설정 순서
1. 적 GameObject: Rigidbody2D (예: Kinematic), Collider2D (기본 데모는 Is Trigger OFF), 새 EnemyHealth2D 추가. 적과 발사체 Layer 충돌이 허용되어야 합니다.
2. 21일차 발사체: Rigidbody2D (Gravity Scale=0), Collider2D (Is Trigger ON), Projectile2D. 공격자·타깃 레이어 설정.
3. 플레이어: Rigidbody2D + Collider2D + PlayerHealth2D 추가, SpriteRenderer 참조 연결.
4. 위험물: Collider2D (Is Trigger ON), HazardDamage2D. 플레이어와 레이어 상호작용 허용.
5. UI: Canvas Image (Type=Filled, Horizontal), HealthBar2D에 PlayerHealth2D 및 Image 연결.
6. CollisionLogger2D를 테스트 대상에 임시로 붙이고 Console에서 ENTER/EXIT 이벤트 확인.

**주의:** 2D 물리 이벤트에는 Collider2D가 필요하고 적절한 Rigidbody2D·Trigger·레이어 조합이 요구됩니다. `OnTriggerEnter2D`와 `OnCollisionEnter2D`를 혼동하지 마세요.

## 검증
ManualTestMatrix.csv에서 PASS/FAIL을 기록하고, 오류가 있으면 BugReportTemplate.md로 재현 방법을 작성합니다. Git에는 이번 수업 수정 파일만 Commit합니다.

## 참고
https://docs.unity3d.com/ScriptReference/MonoBehaviour.OnTriggerEnter2D.html
https://docs.unity3d.com/ScriptReference/MonoBehaviour.OnCollisionEnter2D.html
https://docs.unity3d.com/ScriptReference/Physics2D.html
