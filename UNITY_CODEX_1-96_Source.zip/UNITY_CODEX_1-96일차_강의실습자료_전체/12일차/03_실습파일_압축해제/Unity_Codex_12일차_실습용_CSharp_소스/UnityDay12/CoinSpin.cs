using UnityEngine;

public class CoinSpin : MonoBehaviour
{
    [Header("Coin Settings")]
    [SerializeField, Range(0f, 360f)]
    private float degreesPerSecond = 90f;

    private void Update()
    {
        transform.Rotate(0f, degreesPerSecond * Time.deltaTime, 0f, Space.World);
    }
}
