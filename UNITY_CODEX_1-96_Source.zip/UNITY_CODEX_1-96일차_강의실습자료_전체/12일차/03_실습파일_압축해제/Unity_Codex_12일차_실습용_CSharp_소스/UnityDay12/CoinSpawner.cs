using UnityEngine;

public class CoinSpawner : MonoBehaviour
{
    [SerializeField] private GameObject coinPrefab;
    [SerializeField, Min(1)] private int count = 5;

    private void Start()
    {
        if (coinPrefab == null)
        {
            Debug.LogError("Coin Prefab을 Inspector에 할당하세요.", this);
            return;
        }

        for (int i = 0; i < count; i++)
        {
            Vector3 position = new Vector3(i * 2f, 1f, 0f);
            Instantiate(coinPrefab, position, Quaternion.identity);
        }
    }
}
