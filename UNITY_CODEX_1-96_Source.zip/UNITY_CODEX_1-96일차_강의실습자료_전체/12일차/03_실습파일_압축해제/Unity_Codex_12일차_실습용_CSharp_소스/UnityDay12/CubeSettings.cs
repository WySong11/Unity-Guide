using UnityEngine;

public class CubeSettings : MonoBehaviour
{
    [Header("Cube Settings")]
    [SerializeField, Range(0f, 180f)]
    private float spinSpeed = 90f;

    [SerializeField] private Color cubeColor = Color.cyan;

    private void Start()
    {
        Debug.Log($"Spin: {spinSpeed}, Color: {cubeColor}");
    }
}
