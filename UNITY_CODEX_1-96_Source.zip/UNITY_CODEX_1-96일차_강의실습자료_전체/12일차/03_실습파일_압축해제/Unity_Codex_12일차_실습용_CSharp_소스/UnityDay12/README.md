# Unity × Codex 12일차 실습 소스

Unity 6.3 LTS (6000.3 계열) 교육용 예제. 학습 주제: `[SerializeField]`, Inspector, Prefab.

## 파일과 역할
- `CubeSettings.cs`: Inspector 직렬화와 기본값 실험용 (실제 회전 로직은 포함하지 않음).
- `CoinSpin.cs`: `Update`에서 회전하는 코인 컴포넌트.
- `CoinSpawner.cs`: Inspector에 할당한 `Coin.prefab`을 일정한 간격으로 생성.

## Unity 실습 순서
1. Unity URP 프로젝트에서 `Assets/Scripts` 폴더를 만듭니다.
2. 세 `.cs` 파일을 Scripts에 복사하고 컴파일 오류가 없는지 확인합니다.
3. Cube에 `CubeSettings`를 붙이고 Inspector 설정을 확인합니다.
4. Cylinder를 생성하고 적절히 크기를 조정해 `CoinSpin`을 붙입니다.
5. Hierarchy의 코인을 `Assets/Prefabs` 폴더로 드래그하여 `Coin.prefab`을 만듭니다.
6. Scene에 3개 배치하여 개별 회전 속도를 45, 90, 180으로 바꾸고 Play를 누릅니다.
7. 빈 GameObject에 `CoinSpawner`를 붙이고 `Coin.prefab`을 슬롯에 할당합니다. Count를 5로 지정한 후 Play합니다.
8. Prefab의 Overrides 메뉴에서 Apply와 Revert를 테스트합니다. 원본을 변경하므로 Git 작업 상태를 확인합니다.

**주의:** `CubeSettings.cubeColor`는 값만 표시하고 Renderer 색을 변경하지 않습니다. 추가 구현 과제로 사용할 수 있습니다.

테스트 상태: 정적 코드 검토를 마쳤으며, Unity 에디터에서의 실제 실행 검증은 수강생 환경에서 수행해야 합니다.
