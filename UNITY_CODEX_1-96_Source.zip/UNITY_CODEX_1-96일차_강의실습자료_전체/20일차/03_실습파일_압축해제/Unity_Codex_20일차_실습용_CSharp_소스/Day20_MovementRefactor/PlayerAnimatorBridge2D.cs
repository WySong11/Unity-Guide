using UnityEngine;

/// <summary>Only owner of locomotion Animator parameters and visual facing.</summary>
public sealed class PlayerAnimatorBridge2D : MonoBehaviour
{
    [SerializeField] private PlayerMotor2D motor;
    [SerializeField] private Animator animator;
    [SerializeField] private SpriteRenderer sprite;

    private static readonly int Speed = Animator.StringToHash("Speed");
    private static readonly int VerticalSpeed = Animator.StringToHash("VerticalSpeed");
    private static readonly int IsGrounded = Animator.StringToHash("IsGrounded");

    private void LateUpdate()
    {
        if (motor == null || animator == null) return;
        Vector2 velocity = motor.Velocity;
        animator.SetFloat(Speed, Mathf.Abs(velocity.x));
        animator.SetFloat(VerticalSpeed, velocity.y);
        animator.SetBool(IsGrounded, motor.IsGrounded);
        if (sprite != null) sprite.flipX = motor.FacingX < 0f;
    }
}
