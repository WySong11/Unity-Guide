using UnityEngine;

/// <summary>Temporary diagnostic overlay via Inspector + rate-limited logs.</summary>
public sealed class MovementDiagnostics2D : MonoBehaviour
{
    [SerializeField] private PlayerMotor2D motor;
    [SerializeField, Min(0.1f)] private float logInterval = 1f;
    [SerializeField] private bool logEnabled;

    private float nextLogTime;

    private void Update()
    {
        if (!logEnabled || motor == null || Time.unscaledTime < nextLogTime) return;
        nextLogTime = Time.unscaledTime + logInterval;
        Debug.Log($"grounded={motor.IsGrounded} velocity={motor.Velocity}", this);
    }
}
