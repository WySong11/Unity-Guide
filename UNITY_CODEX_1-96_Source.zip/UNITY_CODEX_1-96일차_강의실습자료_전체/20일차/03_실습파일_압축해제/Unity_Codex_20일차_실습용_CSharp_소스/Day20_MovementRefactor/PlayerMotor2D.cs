using UnityEngine;

/// <summary>Only owner of horizontal Rigidbody2D velocity and jump impulses.</summary>
[RequireComponent(typeof(Rigidbody2D))]
public sealed class PlayerMotor2D : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private PlayerInputReader2D input;
    [SerializeField] private PlayerGroundSensor2D groundSensor;

    [Header("Move")]
    [SerializeField, Min(0f)] private float maxSpeed = 6f;
    [SerializeField, Min(0f)] private float acceleration = 30f;
    [SerializeField, Min(0f)] private float deceleration = 40f;
    [SerializeField, Range(0f, 1f)] private float airControl = 0.7f;

    [Header("Jump")]
    [SerializeField, Min(0f)] private float jumpSpeed = 9f;
    [SerializeField, Min(0f)] private float coyoteSeconds = 0.10f;
    [SerializeField, Min(0f)] private float jumpBufferSeconds = 0.12f;

    private Rigidbody2D rb;
    private float coyoteRemaining;
    private float jumpBufferRemaining;
    private bool jumpUsedSinceGrounded;
    private bool wasGrounded; // Tracks a real airborne-to-grounded transition.

    public bool IsGrounded { get; private set; }
    public Vector2 Velocity => rb != null ? rb.linearVelocity : Vector2.zero;
    public float FacingX { get; private set; } = 1f;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        if (input == null) Debug.LogError("Input reader is missing", this);
        if (groundSensor == null) Debug.LogError("Ground sensor is missing", this);
    }

    private void FixedUpdate()
    {
        if (input == null || groundSensor == null) return;
        groundSensor.Sample();
        IsGrounded = groundSensor.IsGrounded;

        // Reset the jump lock only after a real landing. A single fixed step
        // can still detect the feet touching the ground immediately after jumping.
        if (IsGrounded && !wasGrounded)
            jumpUsedSinceGrounded = false;

        if (IsGrounded && !jumpUsedSinceGrounded)
            coyoteRemaining = coyoteSeconds;
        else
            coyoteRemaining = Mathf.Max(0f, coyoteRemaining - Time.fixedDeltaTime);

        wasGrounded = IsGrounded;

        if (input.ConsumeJumpPressed())
            jumpBufferRemaining = Mathf.Max(jumpBufferSeconds, Time.fixedDeltaTime);

        float x = input.Horizontal;
        if (Mathf.Abs(x) > 0.05f) FacingX = Mathf.Sign(x);
        Vector2 velocity = rb.linearVelocity;
        float targetSpeed = x * maxSpeed;
        float rate = Mathf.Abs(x) > 0.05f ? acceleration : deceleration;
        if (!IsGrounded) rate *= airControl;
        velocity.x = Mathf.MoveTowards(velocity.x, targetSpeed, rate * Time.fixedDeltaTime);

        bool canJump = IsGrounded || coyoteRemaining > 0f;
        if (jumpBufferRemaining > 0f && canJump && !jumpUsedSinceGrounded)
        {
            velocity.y = jumpSpeed;
            jumpBufferRemaining = 0f;
            coyoteRemaining = 0f;
            jumpUsedSinceGrounded = true;
            IsGrounded = false;
        }

        rb.linearVelocity = velocity;
        jumpBufferRemaining = Mathf.Max(0f, jumpBufferRemaining - Time.fixedDeltaTime);
    }
}
