# 20일차 — 이동 / 애니메이션 코드 개선

## 실습 목표
입력 수집, 물리 이동, 접지 검사, Animator 표시를 각각 하나의 스크립트로 분리해 유지보수성을 높입니다.

## Unity 환경
- Unity 6.3 계열 (Rigidbody2D.linearVelocity)
- Input System 패키지 및 `Active Input Handling = Input System Package` (프로젝트 설정에 맞게 확인)
- 2D URP 또는 2D Core, Rigidbody2D + CapsuleCollider2D

## 씬 설정
1. `Player` GameObject에 Rigidbody2D, CapsuleCollider2D, `PlayerInputReader2D`, `PlayerMotor2D`, `PlayerGroundSensor2D`, `PlayerAnimatorBridge2D`를 추가합니다.
2. Rigidbody2D: Body Type = Dynamic, Gravity Scale = 3(예시), Constraints = Freeze Rotation Z. 값은 프로젝트의 기존 이동 느낌에 맞게 조정하세요.
3. `FootPoint` 자식 Transform을 발끝에 놓고 `PlayerGroundSensor2D.footPoint`로 연결합니다. Ground 레이어를 생성해 지형에 적용한 뒤 `groundLayers`에 지정합니다.
4. Input Actions Asset에 `Move` (Value/Vector2, WASD 2D Vector Composite), `Jump` (Button, Space)를 만들고 각각 InputActionReference에 할당합니다.
5. `PlayerMotor2D`: input과 groundSensor 참조를 연결합니다.
6. 자식 `Visual`에 SpriteRenderer와 Animator를 연결하고, Bridge의 motor/animator/sprite 참조를 지정합니다.
7. Animator에 정확히 `Speed` (Float), `VerticalSpeed` (Float), `IsGrounded` (Bool)를 생성합니다. Idle/Run/Jump/Fall 상태에 맞게 Transition 조건을 설정합니다.
8. 비교 실습 시 15~17일차의 이전 이동/Animator 갱신 스크립트는 비활성화해야 합니다. **한 Rigidbody2D에 둘 이상의 스크립트가 속도를 기록하지 않도록 주의**합니다.
9. InputActionReference를 직접 Enable/Disable하는 경로이므로 같은 InputAction Asset을 `PlayerInput`이 별도로 활성화/비활성화하도록 혼용하지 않습니다. 기존 프로젝트에서는 입력 관리자의 소유권 정책에 맞게 수정하세요.

## 알아둘 제한사항
- 강의 학습용 구현 예시입니다. 플레이 모드/컴파일 실측은 Unity 에디터에서 확인하세요.
- `PlayerGroundSensor2D.Sample()`은 `PlayerMotor2D.FixedUpdate()`에서 먼저 실행하므로 서로 다른 MonoBehaviour FixedUpdate의 순서에 의존하지 않습니다.
- JumpBuffer/코요테 타임은 기본 교육용. 플랫폼 통과, 슬로프, 이동 플랫폼, 벽 점프 등 복잡한 게임에는 별도 확장이 필요합니다.
- Rigidbody2D 보간(Interpolation)은 카메라 떨림 감소에 도움 될 수 있지만, 카메라 설정과 함께 확인해야 합니다.

## 제출
씬 스크린샷, Inspector 참조 스크린샷, 시연 영상, ManualTestMatrix.csv, BugReportTemplate.md, Codex 검토 Diff와 Git Commit을 제출합니다.
