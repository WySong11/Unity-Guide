# 참고 공식 문서 (2026-10-24 확인)

- Unity Rigidbody2D.linearVelocity: https://docs.unity3d.com/6000.0/Documentation/ScriptReference/Rigidbody2D-linearVelocity.html
- Unity fixed updates: https://docs.unity3d.com/kr/current/Manual/fixed-updates.html
- Unity Input System: https://docs.unity3d.com/kr/current/Manual/com.unity.inputsystem.html
- Unity Animator parameters: https://docs.unity3d.com/kr/current/Manual/AnimationParameters.html
- OpenAI Codex code review guidance: https://developers.openai.com/blog/custom-code-review-rules-for-codex

Unity 6.3 에디터의 패키지 버전을 수업 전 확인하세요. 설치된 Input System의 업데이트 모드와 PlayerInput 소유권에 따라 입력 연결 코드는 조정할 수 있습니다.
