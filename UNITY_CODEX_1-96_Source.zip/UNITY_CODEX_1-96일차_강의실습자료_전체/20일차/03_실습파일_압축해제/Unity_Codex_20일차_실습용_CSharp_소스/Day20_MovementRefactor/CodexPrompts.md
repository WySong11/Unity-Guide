# Codex 수업 프롬프트

## 1 — 수정 전 분석 (읽기 전용)
현재 2D 플레이어의 입력, 물리 이동, 접지, Animator 관련 스크립트를 파일별로 읽고 역할·데이터 흐름·같은 Rigidbody2D에 중복 기록하는 코드를 표로 정리해줘. 코드는 아직 수정하지 마. Unity 6.3 API 기준으로 확인하고 문제 재현 절차를 제안해줘.

## 2 — 최소 변경 계획
기존 WASD/점프 조작감, Inspector 값, Animator 파라미터명과 Prefab 참조를 유지하면서 책임을 Input/Move/Ground/Animation으로 분리하는 최소 변경 계획을 작성해줘. 바뀔 파일과 회귀 위험을 먼저 보여줘. 승인 전에는 파일을 수정하지 마.

## 3 — 단계별 수정
승인된 파일에서만 변경하고, Update에서 입력을 수집하고 FixedUpdate에서 Rigidbody2D.linearVelocity를 적용해줘. GroundSensor.Sample은 Motor에서 호출하도록 하며 Animator 파라미터는 Bridge 한 곳에서만 쓰게 해줘. 변경 후 파일별 Diff와 수정 이유를 보여줘.

## 4 — 검증
Unity MCP 또는 프로젝트에서 접근 가능한 검증 수단으로 컴파일 오류, Inspector 참조, Play Mode 동작을 확인해줘. 실제 실행하지 못한 항목은 '미검증'으로 명시하고, 12개 회귀 테스트 체크리스트를 만들어줘. Git Commit/Push는 아직 실행하지 마.

## 5 — 코드 리뷰
이동/애니메이션 코드에서 null 참조, 중복 이동 갱신, 입력 이벤트 누락, 접지 체크 순서, Animator 파라미터 오타, GC 할당, 물리 프레임 안정성 문제를 우선순위와 파일/행으로 검토해줘. 수정 전후 사용자 행동이 동일한지 비교해줘.
