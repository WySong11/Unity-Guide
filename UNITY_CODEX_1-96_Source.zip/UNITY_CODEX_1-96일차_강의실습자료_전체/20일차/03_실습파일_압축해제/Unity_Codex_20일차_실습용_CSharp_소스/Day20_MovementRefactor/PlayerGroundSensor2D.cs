using UnityEngine;

/// <summary>One place to determine whether feet overlap the ground layer.</summary>
public sealed class PlayerGroundSensor2D : MonoBehaviour
{
    [SerializeField] private Transform footPoint;
    [SerializeField, Min(0.01f)] private float radius = 0.12f;
    [SerializeField] private LayerMask groundLayers;

    public bool IsGrounded { get; private set; }

    /// <summary>Call from the motor's FixedUpdate before using IsGrounded.</summary>
    public void Sample()
    {
        if (footPoint == null)
        {
            IsGrounded = false;
            return;
        }
        IsGrounded = Physics2D.OverlapCircle(footPoint.position, radius, groundLayers) != null;
    }

    private void OnDrawGizmosSelected()
    {
        if (footPoint == null) return;
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(footPoint.position, radius);
    }
}
