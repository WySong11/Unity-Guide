using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>Collects input once per rendered frame, for later physics consumption.</summary>
public sealed class PlayerInputReader2D : MonoBehaviour
{
    [SerializeField] private InputActionReference moveAction;
    [SerializeField] private InputActionReference jumpAction;

    private bool jumpQueued;
    public float Horizontal { get; private set; }

    private void OnEnable()
    {
        moveAction?.action?.Enable();
        jumpAction?.action?.Enable();
    }

    private void OnDisable()
    {
        moveAction?.action?.Disable();
        jumpAction?.action?.Disable();
        Horizontal = 0f;
        jumpQueued = false;
    }

    private void Update()
    {
        if (moveAction?.action != null)
            Horizontal = moveAction.action.ReadValue<Vector2>().x;

        if (jumpAction?.action != null && jumpAction.action.WasPressedThisFrame())
            jumpQueued = true;
    }

    public bool ConsumeJumpPressed()
    {
        bool result = jumpQueued;
        jumpQueued = false;
        return result;
    }
}
