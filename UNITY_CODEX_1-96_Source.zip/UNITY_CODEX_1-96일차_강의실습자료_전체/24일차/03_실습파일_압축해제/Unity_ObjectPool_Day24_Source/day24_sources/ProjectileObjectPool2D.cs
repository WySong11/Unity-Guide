using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

/// <summary>Unity 6.3: 2D projectile pool with explicit prewarming.</summary>
public class ProjectileObjectPool2D : MonoBehaviour
{
    [SerializeField] private Projectile2D_ObjectPool m_projectilePrefab;
    [SerializeField, Min(0)] private int m_prewarmCount = 12;
    [SerializeField, Min(1)] private int m_defaultCapacity = 12;
    [SerializeField, Min(1)] private int m_maxSize = 40;

    private ObjectPool<Projectile2D_ObjectPool> m_pool;

    public int CountAll => m_pool?.CountAll ?? 0;
    public int CountActive => m_pool?.CountActive ?? 0;
    public int CountInactive => m_pool?.CountInactive ?? 0;

    private void Awake()
    {
        if (m_projectilePrefab == null)
        {
            Debug.LogError("[Pool] Projectile Prefab is not assigned.", this);
            enabled = false;
            return;
        }

        int maxSize = Mathf.Max(1, m_maxSize);
        m_pool = new ObjectPool<Projectile2D_ObjectPool>(
            CreateProjectile, OnGet, OnRelease, OnDestroyPooled,
            collectionCheck: true,
            defaultCapacity: Mathf.Clamp(m_defaultCapacity, 1, maxSize),
            maxSize: maxSize);

        Prewarm(Mathf.Min(m_prewarmCount, maxSize));
        Debug.Log($"[Pool] Ready: all={CountAll}, idle={CountInactive}", this);
    }

    private Projectile2D_ObjectPool CreateProjectile()
    {
        var projectile = Instantiate(m_projectilePrefab, transform);
        projectile.SetPool(this);
        projectile.gameObject.SetActive(false);
        return projectile;
    }

    private static void OnGet(Projectile2D_ObjectPool projectile)
    {
        projectile.PrepareForReuse();
        projectile.gameObject.SetActive(true);
    }

    private static void OnRelease(Projectile2D_ObjectPool projectile)
    {
        projectile.gameObject.SetActive(false);
    }

    private static void OnDestroyPooled(Projectile2D_ObjectPool projectile)
    {
        if (projectile != null)
            Destroy(projectile.gameObject);
    }

    private void Prewarm(int count)
    {
        var warmed = new List<Projectile2D_ObjectPool>(count);
        for (int i = 0; i < count; i++)
            warmed.Add(m_pool.Get());
        foreach (var projectile in warmed)
            m_pool.Release(projectile);
    }

    public void Fire(Vector2 position, Vector2 direction, float speed)
    {
        if (m_pool == null || direction.sqrMagnitude <= 0.0001f) return;
        var projectile = m_pool.Get();
        projectile.Launch(position, direction, speed);
    }

    public void Return(Projectile2D_ObjectPool projectile)
    {
        if (m_pool == null || projectile == null) return;
        m_pool.Release(projectile);
    }
}
