24일차 — Unity 6.3 LTS Object Pool을 이용한 발사체 개선

1) 기존 Day 23 코드의 EnemyHealth2D.TakeDamage(int)를 사용합니다.
2) Projectile2D_ObjectPool을 Projectile Prefab에 추가합니다. Rigidbody2D: Dynamic, Gravity Scale=0, CircleCollider2D: Is Trigger=true.
3) 빈 GameObject "ProjectilePool"에 ProjectileObjectPool2D를 붙이고 Prefab을 연결합니다.
4) Player에 ProjectileShooter2D를 붙이고 Pool 및 FirePoint를 연결합니다.
5) Input System 패키지 활성화(Keyboard.current), Space로 발사. UI Button OnClick에도 Fire()를 연결할 수 있습니다.
6) m_collisionLayerMask에서 Enemy/Wall 등 반납할 대상을 선택합니다. 플레이어·발사체 충돌은 제외합니다.
7) 기본 수치: Prewarm=12, defaultCapacity=12, maxSize=40, lifeTime=2, damage=10, speed=12.
8) 중요: defaultCapacity만 설정해도 발사체가 미리 만들어지는 것은 아닙니다. Prewarm의 Get→Release가 실제로 생성합니다.
9) 중요: maxSize는 비활성 보관 수 상한이며, 활성 동시 발사체 수의 하드 제한이 아닙니다.
10) Projectile을 이동 방향 +X로 그리도록 Sprite 회전 방향을 맞추세요.

참고: https://docs.unity.com/en-us/engine/6000.3/manual/analysis/performance-memory/managed-memory/optimizing-code-managed-memory/reusable-code
