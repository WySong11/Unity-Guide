using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>Space to fire; the public Fire() method can be bound to a UI Button.</summary>
public class ProjectileShooter2D : MonoBehaviour
{
    [SerializeField] private ProjectileObjectPool2D m_pool;
    [SerializeField] private Transform m_firePoint;
    [SerializeField, Min(0.1f)] private float m_speed = 12f;
    [SerializeField, Min(0)] private float m_cooldown = 0.15f;
    private float m_nextFireTime;

    private void Update()
    {
        if (Keyboard.current != null && Keyboard.current.spaceKey.wasPressedThisFrame)
            Fire();
    }

    public void Fire()
    {
        if (m_pool == null || m_firePoint == null || Time.time < m_nextFireTime)
            return;
        m_nextFireTime = Time.time + m_cooldown;
        m_pool.Fire(m_firePoint.position, m_firePoint.right, m_speed);
    }
}
