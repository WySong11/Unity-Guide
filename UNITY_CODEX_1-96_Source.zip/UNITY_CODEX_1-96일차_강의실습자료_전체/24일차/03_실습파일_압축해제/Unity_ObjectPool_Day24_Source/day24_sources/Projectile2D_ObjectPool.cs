using System.Collections;
using UnityEngine;

[RequireComponent(typeof(Rigidbody2D), typeof(Collider2D))]
public class Projectile2D_ObjectPool : MonoBehaviour
{
    [SerializeField, Min(0.1f)] private float m_lifeTime = 2f;
    [SerializeField, Min(1)] private int m_damage = 10;
    [SerializeField] private LayerMask m_collisionLayerMask = ~0;

    private Rigidbody2D m_rb;
    private Collider2D m_col;
    private ProjectileObjectPool2D m_pool;
    private Coroutine m_lifeCo;
    private bool m_isReturning;

    private void Awake() => EnsureComponents();

    private void EnsureComponents()
    {
        if (m_rb == null) m_rb = GetComponent<Rigidbody2D>();
        if (m_col == null) m_col = GetComponent<Collider2D>();
    }

    public void SetPool(ProjectileObjectPool2D pool) => m_pool = pool;

    public void PrepareForReuse()
    {
        EnsureComponents();
        if (m_lifeCo != null)
        {
            StopCoroutine(m_lifeCo);
            m_lifeCo = null;
        }
        m_isReturning = false;
        m_rb.linearVelocity = Vector2.zero;
        m_rb.angularVelocity = 0f;
        m_col.enabled = true;
    }

    public void Launch(Vector2 position, Vector2 direction, float speed)
    {
        if (m_isReturning || direction.sqrMagnitude <= 0.0001f) return;
        Vector2 unit = direction.normalized;
        m_rb.position = position;
        m_rb.rotation = Mathf.Atan2(unit.y, unit.x) * Mathf.Rad2Deg;
        m_rb.linearVelocity = unit * speed;
        m_lifeCo = StartCoroutine(LifeRoutine());
    }

    private IEnumerator LifeRoutine()
    {
        yield return new WaitForSeconds(m_lifeTime);
        m_lifeCo = null;
        ReturnToPool();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (m_isReturning) return;
        if ((m_collisionLayerMask.value & (1 << other.gameObject.layer)) == 0) return;

        // EnemyHealth2D is implemented in Day 23.
        var health = other.GetComponentInParent<EnemyHealth2D>();
        if (health != null) health.TakeDamage(m_damage);
        ReturnToPool();
    }

    public void ReturnToPool()
    {
        if (m_isReturning) return;
        m_isReturning = true;
        if (m_lifeCo != null)
        {
            StopCoroutine(m_lifeCo);
            m_lifeCo = null;
        }
        m_rb.linearVelocity = Vector2.zero;
        m_rb.angularVelocity = 0f;
        m_col.enabled = false;
        if (m_pool != null) m_pool.Return(this);
        else Destroy(gameObject);
    }
}
