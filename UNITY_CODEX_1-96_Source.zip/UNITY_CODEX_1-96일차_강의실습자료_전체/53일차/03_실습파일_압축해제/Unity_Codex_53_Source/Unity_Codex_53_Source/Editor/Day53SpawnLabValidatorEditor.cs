#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using UnityEngine.AI;

public static class Day53SpawnLabValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day53/Validate Spawn Lab")]
    public static void Validate()
    {
        var pool = Object.FindFirstObjectByType<Day53MonsterPool>();
        var spawner = Object.FindFirstObjectByType<Day53WaveSpawner>();
        var points = Object.FindObjectsByType<Day53SpawnPoint>(FindObjectsSortMode.None);
        bool success = pool != null && spawner != null && points.Length > 0;
        if (!success) Debug.LogError("[Day53] Pool / WaveSpawner / SpawnPoint 구성 누락");
        if (NavMesh.CalculateTriangulation().vertices.Length == 0)
        {
            Debug.LogError("[Day53] NavMesh 데이터 없음: AI Navigation 설치·Surface Bake 확인");
            success = false;
        }
        else Debug.Log("[Day53] NavMesh 데이터 확인됨");
        Debug.Log(success ? "[Day53] 기본 Scene 검사 통과 (실행 검증 별도)" : "[Day53] Scene 검사 실패");
    }
}
#endif
