#if UNITY_EDITOR
using System;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.SceneManagement;

/// <summary>Tools > Unity Codex > Day53 > Create Spawn Lab. 기존 자산 덮어쓰기 없음.</summary>
public static class Day53SpawnLabBuilderEditor
{
    [MenuItem("Tools/Unity Codex/Day53/Create Monster Spawn Lab")]
    public static void CreateLab()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        const string root = "Assets/UnityCodex_Day53";
        if (!AssetDatabase.IsValidFolder(root))
            AssetDatabase.CreateFolder("Assets", "UnityCodex_Day53");
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.name = "Ground";
        ground.transform.position = new Vector3(0, -.5f, 0);
        ground.transform.localScale = new Vector3(32, 1, 32);
        for (int i = 0; i < 4; i++)
        {
            var wall = GameObject.CreatePrimitive(PrimitiveType.Cube);
            wall.name = "Wall_" + i;
            bool horizontal = i < 2;
            wall.transform.position = horizontal ?
                new Vector3(0, 1, i == 0 ? -16 : 16) :
                new Vector3(i == 2 ? -16 : 16, 1, 0);
            wall.transform.localScale = horizontal ? new Vector3(32, 2, 1) : new Vector3(1, 2, 32);
        }
        var player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Player";
        UnityEngine.Object.DestroyImmediate(player.GetComponent<Collider>());
        player.transform.position = new Vector3(0, 1.1f, 0);
        player.AddComponent<CharacterController>();
        player.AddComponent<Day53DemoPlayerMover>();

        var monsterObject = new GameObject("Monster_Prototype");
        var visual = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        visual.name = "Visual";
        visual.transform.SetParent(monsterObject.transform);
        visual.transform.localPosition = new Vector3(0, 1f, 0);
        UnityEngine.Object.DestroyImmediate(visual.GetComponent<Collider>());
        monsterObject.AddComponent<NavMeshAgent>();
        monsterObject.AddComponent<Day53MonsterChaser>();
        monsterObject.AddComponent<Day53MonsterUnit>();
        string prefabPath = AssetDatabase.GenerateUniqueAssetPath(root + "/Day53Monster.prefab");
        var prefab = PrefabUtility.SaveAsPrefabAsset(monsterObject, prefabPath);
        UnityEngine.Object.DestroyImmediate(monsterObject);

        var spawnRoot = new GameObject("SpawnPoints");
        var points = new Day53SpawnPoint[4];
        Vector3[] positions = { new(-10, 0, -10), new(10, 0, -10), new(-10, 0, 10), new(10, 0, 10) };
        for (int i = 0; i < points.Length; i++)
        {
            var item = new GameObject("SpawnPoint_" + (i + 1));
            item.transform.SetParent(spawnRoot.transform);
            item.transform.position = positions[i];
            points[i] = item.AddComponent<Day53SpawnPoint>();
        }
        var poolGo = new GameObject("MonsterPool");
        var pool = poolGo.AddComponent<Day53MonsterPool>();
        var poolData = new SerializedObject(pool);
        poolData.FindProperty("prefab").objectReferenceValue = prefab.GetComponent<Day53MonsterUnit>();
        poolData.ApplyModifiedPropertiesWithoutUndo();

        var spawnerGo = new GameObject("WaveSpawner");
        var spawner = spawnerGo.AddComponent<Day53WaveSpawner>();
        var spawnerData = new SerializedObject(spawner);
        spawnerData.FindProperty("pool").objectReferenceValue = pool;
        spawnerData.FindProperty("player").objectReferenceValue = player.transform;
        var pointsProp = spawnerData.FindProperty("spawnPoints");
        pointsProp.arraySize = points.Length;
        for (int i = 0; i < points.Length; i++)
            pointsProp.GetArrayElementAtIndex(i).objectReferenceValue = points[i];
        spawnerData.ApplyModifiedPropertiesWithoutUndo();

        var inputGo = new GameObject("DebugControls");
        var controls = inputGo.AddComponent<Day53DemoControls>();
        var controlsSO = new SerializedObject(controls);
        controlsSO.FindProperty("player").objectReferenceValue = player.transform;
        controlsSO.ApplyModifiedPropertiesWithoutUndo();
        var hud = inputGo.AddComponent<Day53WaveDebugHUD>();
        var hudSO = new SerializedObject(hud);
        hudSO.FindProperty("pool").objectReferenceValue = pool;
        hudSO.FindProperty("spawner").objectReferenceValue = spawner;
        hudSO.ApplyModifiedPropertiesWithoutUndo();

        var cameraGo = new GameObject("Main Camera", typeof(Camera), typeof(AudioListener));
        cameraGo.tag = "MainCamera";
        cameraGo.transform.position = new Vector3(0, 23, -24);
        cameraGo.transform.LookAt(Vector3.zero);
        var lightGo = new GameObject("Directional Light", typeof(Light));
        lightGo.GetComponent<Light>().type = LightType.Directional;
        lightGo.transform.rotation = Quaternion.Euler(45, -25, 0);

        var navRoot = new GameObject("NavigationGeometry");
        Type navType = Type.GetType("Unity.AI.Navigation.NavMeshSurface, Unity.AI.Navigation") ??
            TypeCache.GetTypesDerivedFrom<Component>().FirstOrDefault(x => x.Name == "NavMeshSurface");
        if (navType != null)
        {
            var surface = navRoot.AddComponent(navType);
            try { navType.GetMethod("BuildNavMesh")?.Invoke(surface, null); }
            catch (Exception ex) { Debug.LogWarning("[Day53] Bake 실패: " + ex.Message); }
        }
        else Debug.LogWarning("[Day53] AI Navigation 패키지 설치 후 NavMeshSurface 추가·Bake 필요");

        string scenePath = AssetDatabase.GenerateUniqueAssetPath(root + "/Day53MonsterSpawnLab.unity");
        EditorSceneManager.SaveScene(scene, scenePath);
        AssetDatabase.SaveAssets();
        EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<SceneAsset>(scenePath));
        Debug.Log("[Day53] 생성 완료: " + scenePath + ". NavMesh Bake 확인 후 Play.");
    }
}
