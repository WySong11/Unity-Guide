using UnityEngine;

/// <summary>씬에 배치할 몬스터 생성 후보 위치. Gizmo는 Scene 뷰에서 확인.</summary>
public sealed class Day53SpawnPoint : MonoBehaviour
{
    [Min(0f)] [SerializeField] float randomRadius = 1.2f;
    public Vector3 RandomCandidate()
    {
        Vector2 offset = Random.insideUnitCircle * randomRadius;
        return transform.position + new Vector3(offset.x, 0f, offset.y);
    }
    void OnDrawGizmosSelected()
    {
        Gizmos.color = new Color(0.15f, 0.85f, 0.65f, 0.7f);
        Gizmos.DrawWireSphere(transform.position, randomRadius);
    }
}
