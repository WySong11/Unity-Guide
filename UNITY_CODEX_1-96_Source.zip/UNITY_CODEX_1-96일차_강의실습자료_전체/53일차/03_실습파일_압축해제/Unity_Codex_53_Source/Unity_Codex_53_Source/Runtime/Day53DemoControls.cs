using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>K: 가장 가까운 몬스터 처치, L: 전체 처치 (Wave 진행 테스트).</summary>
public sealed class Day53DemoControls : MonoBehaviour
{
    [SerializeField] Transform player;
    void Update()
    {
        bool killNearest = false, killAll = false;
#if ENABLE_INPUT_SYSTEM
        if (Keyboard.current != null)
        {
            killNearest = Keyboard.current.kKey.wasPressedThisFrame;
            killAll = Keyboard.current.lKey.wasPressedThisFrame;
        }
#elif ENABLE_LEGACY_INPUT_MANAGER
        killNearest = Input.GetKeyDown(KeyCode.K);
        killAll = Input.GetKeyDown(KeyCode.L);
#endif
        if (!killNearest && !killAll) return;
        var units = FindObjectsByType<Day53MonsterUnit>(FindObjectsSortMode.None);
        Day53MonsterUnit nearest = null;
        float nearestDistance = float.MaxValue;
        foreach (var unit in units)
        {
            if (unit == null || !unit.IsAlive) continue;
            if (killAll) unit.ApplyDamage(int.MaxValue);
            else
            {
                float distance = player == null ? 0f :
                    (unit.transform.position - player.position).sqrMagnitude;
                if (distance < nearestDistance)
                {
                    nearest = unit;
                    nearestDistance = distance;
                }
            }
        }
        if (killNearest && nearest != null) nearest.ApplyDamage(int.MaxValue);
    }
}
