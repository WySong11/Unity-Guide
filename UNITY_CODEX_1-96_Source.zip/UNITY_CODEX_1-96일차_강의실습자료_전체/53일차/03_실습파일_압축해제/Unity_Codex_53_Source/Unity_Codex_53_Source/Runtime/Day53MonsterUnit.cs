using System;
using System.Collections;
using UnityEngine;
using UnityEngine.AI;

/// <summary>풀에서 재활용되는 몬스터의 체력/사망/상태 초기화 전담.</summary>
[RequireComponent(typeof(NavMeshAgent))]
public sealed class Day53MonsterUnit : MonoBehaviour
{
    [Min(1)] [SerializeField] int maxHealth = 30;
    [Min(0f)] [SerializeField] float despawnDelay = 0.4f;
    NavMeshAgent agent;
    Day53MonsterChaser chaser;
    Coroutine despawnRoutine;
    int health;
    bool dead;
    public bool IsAlive => gameObject.activeInHierarchy && !dead;
    public int Health => health;
    public event Action<Day53MonsterUnit> DespawnRequested;

    void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        chaser = GetComponent<Day53MonsterChaser>();
    }

    /// <summary>활성화된 Agent를 NavMesh에 배치하고 체력과 추적 상태를 재설정.</summary>
    public bool PrepareSpawn(Vector3 navPosition, Transform player)
    {
        if (despawnRoutine != null)
        {
            StopCoroutine(despawnRoutine);
            despawnRoutine = null;
        }
        dead = false;
        health = maxHealth;
        transform.position = navPosition;
        if (agent == null) agent = GetComponent<NavMeshAgent>();
        if (agent == null || !agent.enabled || !agent.Warp(navPosition))
        {
            Debug.LogWarning($"[Day53] NavMeshAgent Warp 실패: {name}", this);
            return false;
        }
        agent.ResetPath();
        agent.isStopped = false;
        if (chaser == null) chaser = GetComponent<Day53MonsterChaser>();
        if (chaser != null) chaser.ResetForSpawn(player);
        return true;
    }

    public void ApplyDamage(int amount)
    {
        if (!IsAlive || amount <= 0) return;
        health = Mathf.Max(0, health - amount);
        if (health == 0) Die();
    }

    void Die()
    {
        if (dead) return;
        dead = true;
        if (agent != null && agent.enabled && agent.isOnNavMesh)
        {
            agent.isStopped = true;
            agent.ResetPath();
        }
        if (chaser != null) chaser.SetActiveAI(false);
        despawnRoutine = StartCoroutine(DespawnAfterDelay());
    }

    IEnumerator DespawnAfterDelay()
    {
        yield return new WaitForSeconds(despawnDelay);
        despawnRoutine = null;
        DespawnRequested?.Invoke(this);
    }

    void OnDisable()
    {
        if (despawnRoutine != null)
        {
            StopCoroutine(despawnRoutine);
            despawnRoutine = null;
        }
    }
}
