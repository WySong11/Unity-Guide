using System.Collections.Generic;
using UnityEngine;

/// <summary>사전 생성(Prewarm), 획득, 중복 반환 차단을 담당하는 몬스터 풀.</summary>
public sealed class Day53MonsterPool : MonoBehaviour
{
    [SerializeField] Day53MonsterUnit prefab;
    [Min(0)] [SerializeField] int prewarmCount = 8;
    [Min(1)] [SerializeField] int maxInstances = 24;
    readonly Queue<Day53MonsterUnit> available = new();
    readonly HashSet<Day53MonsterUnit> all = new();
    readonly HashSet<Day53MonsterUnit> inUse = new();
    public int ActiveCount => inUse.Count;
    public int PooledCount => available.Count;
    public int TotalCount => all.Count;

    void Awake()
    {
        for (int i = 0; i < Mathf.Min(prewarmCount, maxInstances); i++)
            CreateOne();
    }
    Day53MonsterUnit CreateOne()
    {
        if (prefab == null || all.Count >= maxInstances) return null;
        Day53MonsterUnit unit = Instantiate(prefab, transform);
        unit.name = $"Monster_{all.Count + 1:00}";
        unit.gameObject.SetActive(false);
        unit.DespawnRequested += HandleDespawnRequested;
        all.Add(unit);
        available.Enqueue(unit);
        return unit;
    }

    public bool TrySpawn(Vector3 position, Transform player)
    {
        if (available.Count == 0 && CreateOne() == null) return false;
        var unit = available.Dequeue();
        unit.transform.position = position;
        unit.gameObject.SetActive(true);
        if (!unit.PrepareSpawn(position, player))
        {
            unit.gameObject.SetActive(false);
            available.Enqueue(unit);
            return false;
        }
        inUse.Add(unit);
        return true;
    }

    void HandleDespawnRequested(Day53MonsterUnit unit)
    {
        if (unit == null || !inUse.Remove(unit)) return; // 중복 반환 차단
        unit.gameObject.SetActive(false);
        unit.transform.SetParent(transform);
        available.Enqueue(unit);
    }

    void OnDestroy()
    {
        foreach (var unit in all)
            if (unit != null) unit.DespawnRequested -= HandleDespawnRequested;
    }
}
