using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

/// <summary>Wave별 생성 수/간격/동시 수를 제한하고 NavMesh 위치를 검증.</summary>
public sealed class Day53WaveSpawner : MonoBehaviour
{
    [Serializable]
    public sealed class Wave
    {
        [Min(1)] public int monsterCount = 5;
        [Min(0.05f)] public float spawnInterval = 0.75f;
        [Min(1)] public int maxAlive = 4;
        [Min(0f)] public float restAfterWave = 2f;
    }

    [SerializeField] Day53MonsterPool pool;
    [SerializeField] Transform player;
    [SerializeField] Day53SpawnPoint[] spawnPoints;
    [SerializeField] List<Wave> waves = new()
    {
        new Wave { monsterCount = 4, maxAlive = 3 },
        new Wave { monsterCount = 6, maxAlive = 4, spawnInterval = .6f },
        new Wave { monsterCount = 8, maxAlive = 5, spawnInterval = .45f }
    };
    [Min(0.1f)] [SerializeField] float navMeshSampleRadius = 1.5f;
    [Min(1)] [SerializeField] int failedAttemptLimit = 24;

    public int CurrentWave { get; private set; }
    public int SpawnedThisWave { get; private set; }
    public int FailedAttempts { get; private set; }
    public bool Completed { get; private set; }
    public int WaveCount => waves.Count;
    public int Alive => pool == null ? 0 : pool.ActiveCount;
    public event Action<int> WaveStarted;
    public event Action<int> WaveCleared;

    IEnumerator Start()
    {
        if (pool == null || player == null || spawnPoints == null || spawnPoints.Length == 0)
        {
            Debug.LogError("[Day53] Pool/Player/SpawnPoints Inspector 연결 필요", this);
            yield break;
        }
        for (int w = 0; w < waves.Count; w++)
        {
            CurrentWave = w + 1;
            SpawnedThisWave = 0;
            FailedAttempts = 0;
            Wave wave = waves[w];
            WaveStarted?.Invoke(CurrentWave);
            while (SpawnedThisWave < wave.monsterCount)
            {
                if (pool.ActiveCount >= wave.maxAlive)
                {
                    yield return new WaitForSeconds(.2f);
                    continue;
                }
                if (TrySpawnOne())
                {
                    SpawnedThisWave++;
                    FailedAttempts = 0;
                }
                else if (++FailedAttempts >= failedAttemptLimit)
                {
                    Debug.LogError("[Day53] 스폰 실패가 반복되어 Wave 중단: NavMesh/Prefab 확인", this);
                    yield break;
                }
                yield return new WaitForSeconds(Mathf.Max(.05f, wave.spawnInterval));
            }
            while (pool.ActiveCount > 0) yield return null; // 처치 완료 대기
            WaveCleared?.Invoke(CurrentWave);
            yield return new WaitForSeconds(wave.restAfterWave);
        }
        Completed = true;
        Debug.Log("[Day53] 모든 Wave 완료", this);
    }

    bool TrySpawnOne()
    {
        int startIndex = UnityEngine.Random.Range(0, spawnPoints.Length);
        for (int offset = 0; offset < spawnPoints.Length; offset++)
        {
            var point = spawnPoints[(startIndex + offset) % spawnPoints.Length];
            if (point == null) continue;
            // NavMesh.SamplePosition은 위치 유효성만 보장하며 도달성은 보장하지 않음
            if (NavMesh.SamplePosition(point.RandomCandidate(), out NavMeshHit hit,
                    navMeshSampleRadius, NavMesh.AllAreas))
                return pool.TrySpawn(hit.position, player);
        }
        return false;
    }
}
