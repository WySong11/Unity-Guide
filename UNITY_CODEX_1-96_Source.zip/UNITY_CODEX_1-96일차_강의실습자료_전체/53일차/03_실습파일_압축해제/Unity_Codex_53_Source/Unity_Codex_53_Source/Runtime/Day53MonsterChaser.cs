using UnityEngine;
using UnityEngine.AI;

/// <summary>독립 실습용 간단 추적 AI. 52일차 Brain과 동시에 사용하지 않음.</summary>
[RequireComponent(typeof(NavMeshAgent))]
public sealed class Day53MonsterChaser : MonoBehaviour
{
    [Min(0.1f)] [SerializeField] float repathInterval = 0.35f;
    [Min(0.1f)] [SerializeField] float stopDistance = 1.5f;
    NavMeshAgent agent;
    Transform target;
    float nextRepathAt;
    bool enabledAI;

    void Awake() => agent = GetComponent<NavMeshAgent>();
    public void ResetForSpawn(Transform newTarget)
    {
        target = newTarget;
        nextRepathAt = 0f;
        enabledAI = target != null;
        if (agent != null && agent.enabled && agent.isOnNavMesh)
            agent.stoppingDistance = stopDistance;
    }
    public void SetActiveAI(bool value) => enabledAI = value;

    void Update()
    {
        if (!enabledAI || target == null || agent == null ||
            !agent.enabled || !agent.isOnNavMesh || agent.isStopped ||
            Time.time < nextRepathAt) return;
        nextRepathAt = Time.time + repathInterval;
        agent.SetDestination(target.position);
    }
}
