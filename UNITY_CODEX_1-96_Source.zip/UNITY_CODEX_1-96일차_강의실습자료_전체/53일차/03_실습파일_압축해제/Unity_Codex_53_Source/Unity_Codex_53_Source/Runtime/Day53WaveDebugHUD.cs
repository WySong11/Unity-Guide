using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>런타임 진단 HUD: F1로 표시/숨김.</summary>
public sealed class Day53WaveDebugHUD : MonoBehaviour
{
    [SerializeField] Day53WaveSpawner spawner;
    [SerializeField] Day53MonsterPool pool;
    bool visible = true;
    void Update()
    {
#if ENABLE_INPUT_SYSTEM
        if (Keyboard.current != null && Keyboard.current.f1Key.wasPressedThisFrame)
            visible = !visible;
#elif ENABLE_LEGACY_INPUT_MANAGER
        if (Input.GetKeyDown(KeyCode.F1)) visible = !visible;
#endif
    }
    void OnGUI()
    {
        if (!visible || spawner == null || pool == null) return;
        GUI.Box(new Rect(15, 15, 360, 185), "DAY 53 : MONSTER SPAWN LAB");
        GUI.Label(new Rect(30, 42, 330, 25), $"Wave: {spawner.CurrentWave}/{spawner.WaveCount}");
        GUI.Label(new Rect(30, 66, 330, 25), $"Created in wave: {spawner.SpawnedThisWave}");
        GUI.Label(new Rect(30, 90, 330, 25), $"Alive: {pool.ActiveCount} / Pool: {pool.PooledCount}");
        GUI.Label(new Rect(30, 114, 330, 25), $"Total instances: {pool.TotalCount}");
        GUI.Label(new Rect(30, 138, 330, 25), $"Failed attempts: {spawner.FailedAttempts}");
        GUI.Label(new Rect(30, 162, 330, 25), "WASD: move · K: kill 1 · L: kill all · F1: HUD");
    }
}
