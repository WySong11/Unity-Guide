using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>CharacterController + WASD. 새 Input System/Legacy 둘 다 선택 지원.</summary>
[RequireComponent(typeof(CharacterController))]
public sealed class Day53DemoPlayerMover : MonoBehaviour
{
    [Min(.1f)] [SerializeField] float speed = 5f;
    [SerializeField] float gravity = -18f;
    CharacterController controller;
    float verticalSpeed;
    void Awake() => controller = GetComponent<CharacterController>();
    void Update()
    {
        Vector2 move = Vector2.zero;
#if ENABLE_INPUT_SYSTEM
        if (Keyboard.current != null)
        {
            var kb = Keyboard.current;
            move = new Vector2((kb.dKey.isPressed ? 1 : 0) - (kb.aKey.isPressed ? 1 : 0),
                               (kb.wKey.isPressed ? 1 : 0) - (kb.sKey.isPressed ? 1 : 0));
        }
#elif ENABLE_LEGACY_INPUT_MANAGER
        move = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
#endif
        move = Vector2.ClampMagnitude(move, 1f);
        if (controller.isGrounded && verticalSpeed < 0f) verticalSpeed = -1f;
        verticalSpeed += gravity * Time.deltaTime;
        Vector3 delta = new Vector3(move.x * speed, verticalSpeed, move.y * speed);
        controller.Move(delta * Time.deltaTime);
    }
}
