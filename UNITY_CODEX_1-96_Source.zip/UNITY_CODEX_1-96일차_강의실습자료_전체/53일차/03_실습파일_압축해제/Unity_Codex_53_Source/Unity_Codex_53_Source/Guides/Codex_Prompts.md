# Codex 실습 프롬프트

## A. 코드 구조 검토
Unity 6.3 / URP / AI Navigation 환경이다. Assets/Day53의 몬스터 생성 시스템을 읽기 전용으로 분석하라. `WaveSpawner → MonsterPool → MonsterUnit → Chaser` 의존성을 설명하고, Inspector 필드 누락·중복 이벤트 구독·Pool 중복 반환·NavMesh 미배치 위험을 표로 보고하라. 자동 수정하지 말 것.

## B. 몬스터 생성 오류 재현 및 최소 수정
증상: [여기에 Console 원문, Stack Trace, 재현 단계, 예상/실제 결과를 기록]. 관련 C# 파일과 씬 참조를 점검하고 원인을 하나씩 가설로 분리하라. 변경 전에 수정 범위와 회귀 위험을 설명하고, 승인된 부분만 최소 수정하라. 49~52일차 원본 컴포넌트는 덮어쓰지 말 것.

## C. 풀 재사용 검증
Play Mode에서 3 Wave를 진행한 후 몬스터가 다시 생성될 때 (1) HP (2) dead 상태 (3) NavMeshAgent.isStopped (4) 추적 타깃 (5) 기존 반환 코루틴 (6) Alive 카운트가 정상인지 점검하라. 접근 가능한 Unity MCP/CLI가 있으면 해당 기능만 사용하고 실제 수행 항목을 기록하라. 없다면 수행하지 못한 항목을 분리하여 수동 체크리스트를 제공하라.

## D. 완료 보고
변경 파일 목록, git diff 요약, 컴파일 결과, Play Mode 테스트 결과, 남은 문제, 롤백 방법을 보고하라. 확인하지 못한 테스트는 성공으로 표시하지 말 것.
