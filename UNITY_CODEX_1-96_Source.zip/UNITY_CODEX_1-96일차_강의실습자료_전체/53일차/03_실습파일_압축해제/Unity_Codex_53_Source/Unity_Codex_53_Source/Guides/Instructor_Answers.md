# 강사용 예시 정답

1. NavMeshAgent, Day53MonsterUnit, Day53MonsterChaser(독립 실습용). Collider·표현 메시·Animator는 필요에 따라 추가.
2. Pool은 생성/파괴 빈도를 줄이고 재사용하지만, 초기화와 반환 관리 부담이 증가한다.
3. 보장하지 않는다. SamplePosition은 NavMesh 상 근접 좌표만 찾고 접근 가능한지 판정하지 않는다.
4. 동시 최대 3개.
5. 즉시 사망, 정지된 Agent, 잘못된 타깃 추적, 오래된 코루틴의 조기 반환 등이 발생한다.
6. 해당 Wave의 목표 생성 수를 충족했고 몬스터가 모두 풀에 반환된 경우.
7. ActiveCount는 감소하고 PooledCount는 증가한다. TotalCount는 최대 풀 규모 안에서 유지된다.
8. Bake 데이터 누락, SamplePosition 실패, 스폰 반복 실패 로그를 기대한다.
9. 실제 콘솔·스택·재현 조건·기대 결과·수정 범위를 포함해야 한다.
10. IRespawnResettable.ResetForSpawn(Transform target) 같이 생명주기 초기화 계약을 제안한다.
