# Unity × Codex · 53일차 — 몬스터 생성 시스템

## 1. 실습 환경
- Unity 6.3 / Universal 3D(URP) 프로젝트를 권장합니다.
- Package Manager > AI Navigation을 설치합니다. NavMeshAgent는 UnityEngine.AI이며 NavMeshSurface는 AI Navigation 패키지에서 제공합니다.
- `Runtime`은 Assets/Day53/Runtime, `Editor`는 Assets/Day53/Editor에 복사합니다. 기존 Day52 소스를 덮어쓰지 않습니다.
- 새로운 프로젝트에 적용할 때는 **Unity Console 컴파일 오류 0개**를 먼저 확인합니다.

## 2. 씬 만들기
1. Unity 메뉴 `Tools > Unity Codex > Day53 > Create Monster Spawn Lab`을 실행합니다.
2. 새 씬·새 Monster Prefab·Pool·4개 SpawnPoint가 생성됩니다. 기존 씬을 덮어쓰지 않습니다.
3. Hierarchy의 `NavigationGeometry`에서 NavMeshSurface 컴포넌트와 Bake 결과를 확인합니다. 자동 Bake가 실패하면 수동으로 Bake합니다.
4. `Tools > Unity Codex > Day53 > Validate Spawn Lab`에서 검사합니다.
5. Play 후 WASD 이동, K(가까운 몬스터 제거), L(전부 제거), F1(HUD)을 사용합니다.

## 3. 수업 흐름
- 0~20분: 몬스터 생성 파이프라인과 Day52 AI 연결 지점
- 20~70분: Prefab, SpawnPoint, NavMesh.SamplePosition, Prewarm, MonsterPool
- 70~100분: WaveSpawner, 생성 한도·재사용·사망 처리
- 100~120분: Codex 오류 수정, Play Mode 점검, 회귀 테스트

## 4. 중요 구조
`Day53WaveSpawner → Day53MonsterPool → Day53MonsterUnit → Day53MonsterChaser`

- WaveSpawner: 총 생성 수, 간격, 동시 최대 생존 수. Pool에 몬스터 생성 요청.
- Pool: 미리 오브젝트 생성(Prewarm), 활성 인스턴스 추적, 이벤트를 통한 반환.
- Unit: HP 초기화, 사망 시 반환 요청, NavMeshAgent.Warp 성공 여부 확인.
- Chaser: 본 패키지 **독립 실습용** AI. 기존 `Day52EnemyBrain`과 같은 GameObject에서 동시에 사용하면 안 됩니다.

## 5. 기존 Day52 Enemy AI와 연결하기
1. 수업 완료 후 `Day53MonsterChaser` 대신 Day52 Enemy 구성 요소가 붙은 Prefab을 사용합니다.
2. Day52 FSM, Perception, Attack, Health가 몬스터 재생성 시 초기화되는 메서드를 제공하도록 **어댑터를 작성**해야 합니다. 이 패키지는 Day52 내부 구현을 직접 포함하지 않으므로 자동 호환을 보증하지 않습니다.
3. Active/Inactive 과정에서 NavMeshAgent, 타깃 참조, 이벤트 구독, 체력 및 애니메이션 상태를 모두 재설정합니다.
4. `Day52EnemyBrain`과 `Day53MonsterChaser`를 동시에 부착하지 마세요.

## 6. 오류 점검
- 스폰 0개: AI Navigation 설치 / NavMesh Bake / SpawnPoint 배열 / Pool Prefab 확인
- `Warp` 실패: 몬스터가 NavMesh 위에 있는지, Agent Radius·Agent Type 확인
- 사망해도 Wave 미완료: Unit 이벤트가 Pool에 전달되었는지, Alive 카운트 확인
- 몬스터가 과도하게 생성됨: maxInstances 및 maxAlive 검사
- 재사용 몬스터 즉시 사망: HP·dead 플래그·코루틴 초기화 검사
- F1 HUD 없음: Game 뷰 포커스, Active Input Handling 및 Input System 설치 확인

## 7. 실행 테스트 기준
본 소스는 학습용 예제이며 Unity Editor에서 실제 컴파일·Play Mode를 대신 실행하지 않았습니다. Build 전 `Test_Cases.csv`의 항목을 수강생이 검증해야 합니다.
