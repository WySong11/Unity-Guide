# 학생 워크시트 — 53일차

1. Monster Prefab에서 필요한 컴포넌트 3가지를 적으세요.
2. `Instantiate/Destroy`를 매번 사용하는 방식과 Prewarm+Pool 방식을 비교하세요.
3. `NavMesh.SamplePosition`은 **경로 도달성까지** 보장하나요? 이유는 무엇인가요?
4. Wave 1: 생성 4개, 동시 제한 3개. 세 번째 몬스터가 살아 있을 때 몇 개까지 활성인가요?
5. 스폰 시 HP, 코루틴, AI 타깃을 초기화하지 않으면 어떤 문제가 생길까요?
6. `WaveCleared`를 언제 발생시키는 것이 정확할까요?
7. `K`와 `L` 키로 Wave를 끝낸 뒤, TotalCount와 ActiveCount 변화가 어떻게 다른지 기록하세요.
8. 씬에서 NavMeshBake를 없애고 재시도했을 때 Console에 어떤 메시지가 발생했나요?
9. Codex에게 재현 단계·오류 로그·기대 동작을 포함한 최소 수정 프롬프트를 작성하세요.
10. 49~52일차 FSM과 연결할 때 어떤 초기화 인터페이스를 추가하면 좋을까요?

제출물: 씬, Prefab, 스폰 파라미터 스크린샷, 3 Wave HUD 스크린샷, 테스트 결과, 변경 diff.
