[25일차 - Canvas와 UI 기초]
Unity 6.3, Unity UI(uGUI), TextMeshPro를 기준으로 작성되었습니다.

실습 목표: MainPanel(시작/설정 버튼) ↔ SettingsPanel(뒤로 버튼) 전환

1. 빈 Scene에 Canvas(UI -> Canvas)를 추가합니다.
2. Canvas의 Render Mode를 Screen Space - Overlay로 설정합니다.
3. Canvas Scaler의 UI Scale Mode를 Scale With Screen Size로 변경합니다.
4. Reference Resolution 1920x1080, Screen Match Mode Match Width Or Height, Match 0.5로 시작합니다.
5. Canvas 아래 MainPanel, SettingsPanel을 만듭니다.
6. MainPanel 아래 PlayButton, SettingsButton 및 안내용 TMP Text를 만듭니다.
7. SettingsPanel 아래 BackButton을 만듭니다.
8. 별도 MenuUIManager 게임오브젝트에 MenuUIController를 부착합니다.
9. Inspector의 MainPanel/SettingsPanel/Buttons/Message Text 필드를 연결합니다.
10. EventSystem 및 UI 입력 모듈이 올바른지 확인합니다.
11. Play 모드에서 시작/설정/돌아가기 버튼을 클릭해 확인합니다.
12. 해상도를 바꿔 Anchor와 Canvas Scaler 결과를 점검합니다.

참고:
- Button.onClick은 코드의 AddListener 방식으로 연결하므로
  Inspector의 On Click()에 같은 함수를 중복 등록하지 마세요.
- 26일차에 HP바, 점수 데이터 연동을 추가하고
  27일차에서 '게임 시작' 버튼을 씬 전환으로 확장합니다.
