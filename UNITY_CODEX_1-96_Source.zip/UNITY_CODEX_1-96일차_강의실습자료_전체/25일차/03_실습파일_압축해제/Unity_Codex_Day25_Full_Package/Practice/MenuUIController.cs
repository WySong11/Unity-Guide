using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 25일차 Canvas와 UI 기초 실습: 기본 메뉴와 설정 패널 전환
/// Unity 6.3 / Unity UI(uGUI) / TextMeshPro
/// </summary>
public class MenuUIController : MonoBehaviour
{
    [Header("Panels")]
    [SerializeField] private GameObject mainPanel;
    [SerializeField] private GameObject settingsPanel;

    [Header("Buttons")]
    [SerializeField] private Button playButton;
    [SerializeField] private Button settingsButton;
    [SerializeField] private Button backButton;

    [Header("Message")]
    [SerializeField] private TMP_Text messageText;

    private void Awake()
    {
        // 이벤트 연결은 코드에서만 한다. Inspector On Click과 중복 등록하지 않는다.
        if (playButton != null)
            playButton.onClick.AddListener(OnPlayClicked);

        if (settingsButton != null)
            settingsButton.onClick.AddListener(ShowSettings);

        if (backButton != null)
            backButton.onClick.AddListener(ShowMain);

        ShowMain();
    }

    private void OnDestroy()
    {
        // 비활성/재생 종료 시 이벤트 참조 정리
        if (playButton != null)
            playButton.onClick.RemoveListener(OnPlayClicked);

        if (settingsButton != null)
            settingsButton.onClick.RemoveListener(ShowSettings);

        if (backButton != null)
            backButton.onClick.RemoveListener(ShowMain);
    }

    private void OnPlayClicked()
    {
        // 27일차에서 씬 전환으로 확장할 수 있다.
        if (messageText != null)
            messageText.text = "게임 시작 버튼 클릭!";
    }

    private void ShowSettings()
    {
        if (mainPanel != null)
            mainPanel.SetActive(false);

        if (settingsPanel != null)
            settingsPanel.SetActive(true);
    }

    private void ShowMain()
    {
        if (mainPanel != null)
            mainPanel.SetActive(true);

        if (settingsPanel != null)
            settingsPanel.SetActive(false);
    }
}
