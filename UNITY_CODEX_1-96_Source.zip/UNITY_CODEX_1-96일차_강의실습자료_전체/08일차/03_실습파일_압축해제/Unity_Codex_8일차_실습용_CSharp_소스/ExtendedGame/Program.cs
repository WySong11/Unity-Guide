using System;
using System.Collections.Generic;

Random random = new();
bool playAgain;

do
{
    PlayRound(random);
    Console.Write("\n다시 시작하시겠습니까? (y/n) > ");
    string? answer = Console.ReadLine();
    playAgain = string.Equals(answer?.Trim(), "y", StringComparison.OrdinalIgnoreCase);
} while (playAgain);

Console.WriteLine("게임을 종료합니다.");

static void PlayRound(Random random)
{
    const int maxTries = 7;
    int secret = random.Next(1, 101);
    int tries = 0;
    bool isWin = false;
    List<int> guesses = new();

    Console.WriteLine("\n=== 숫자 맞히기: 확장판 ===");
    Console.WriteLine("1~100 사이의 정수를 7회 안에 맞혀보세요.");

    while (tries < maxTries && !isWin)
    {
        Console.Write($"[남은 기회 {maxTries - tries}] 숫자 입력 > ");
        string? input = Console.ReadLine();

        if (input is null)
        {
            Console.WriteLine("입력이 종료되었습니다.");
            return;
        }

        if (!int.TryParse(input, out int guess) || guess < 1 || guess > 100)
        {
            Console.WriteLine("1~100 사이 정수만 입력하세요. 기회는 차감되지 않습니다.");
            continue;
        }

        tries++;
        guesses.Add(guess);
        if (guess == secret)
        {
            isWin = true;
            int score = Math.Max(0, (maxTries - tries + 1) * 100);
            Console.WriteLine($"정답! {tries}번 만에 성공! 점수: {score}");
            break;
        }

        string hint = guess < secret ? "UP!" : "DOWN!";
        Console.WriteLine($"{hint} 남은 기회: {maxTries - tries}");
    }

    if (!isWin)
        Console.WriteLine($"실패! 정답은 {secret}입니다.");

    Console.WriteLine($"추측 기록: {string.Join(", ", guesses)}");
}
