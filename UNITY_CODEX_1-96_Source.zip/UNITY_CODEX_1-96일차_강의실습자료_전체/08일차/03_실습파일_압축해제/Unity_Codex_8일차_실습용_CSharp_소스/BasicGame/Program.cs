using System;

Random random = new();
int secret = random.Next(1, 101); // 1~100
int tries = 0;
const int maxTries = 7;
bool isWin = false;

Console.WriteLine("=== 숫자 맞히기 ===");
Console.WriteLine("1~100 사이 정수를 최대 7번 안에 맞혀보세요.");

while (tries < maxTries && !isWin)
{
    Console.Write($"[남은 기회 {maxTries - tries}] 숫자 입력 > ");
    string? input = Console.ReadLine();

    if (input is null)
    {
        Console.WriteLine("입력이 종료되었습니다.");
        return;
    }

    if (!int.TryParse(input, out int guess) || guess < 1 || guess > 100)
    {
        Console.WriteLine("1~100 사이 정수만 입력해 주세요.");
        continue; // 유효하지 않은 입력은 횟수 증가 없음
    }

    tries++;
    if (guess == secret)
    {
        isWin = true;
        Console.WriteLine($"정답! {tries}번 만에 성공!");
        break;
    }

    Console.WriteLine(guess < secret ? "UP! 더 큰 숫자입니다." : "DOWN! 더 작은 숫자입니다.");
}

if (!isWin)
{
    Console.WriteLine($"게임 오버! 정답은 {secret}입니다.");
}
