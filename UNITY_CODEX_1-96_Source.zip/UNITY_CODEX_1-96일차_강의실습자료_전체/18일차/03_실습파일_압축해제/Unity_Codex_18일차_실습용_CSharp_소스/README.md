# Unity × Codex — 18일차 Animator / Animation 실습

권장 환경: Unity 6.3 LTS(6000.3 계열), Universal 2D 또는 URP 2D 프로젝트.

## 파일
- `SimpleGroundSensor2D.cs`: 발밑 GroundPoint/LayerMask를 이용한 접지 판정.
- `PlayerAnimationBridge2D.cs`: Rigidbody2D 속도와 접지 상태를 Animator 파라미터에 전달.
- `DemoPlayerMover2D.cs`: 별도 데모 씬 전용 이동·점프 입력(선택). 17일차 이동 스크립트와 동시에 사용하지 않습니다.
- `FlipVisual2D.cs`: 물리 루트가 아닌 SpriteRenderer의 좌우 반전.

## 씬 구조
```
PlayerRoot                  Rigidbody2D, CapsuleCollider2D,
  |                         (기존 이동 스크립트), SimpleGroundSensor2D,
  |                         PlayerAnimationBridge2D
  +-- Visual               SpriteRenderer, Animator
  +-- GroundPoint          발 아래 빈 Transform
```

1. `Assets/Animations/` 폴더를 만들고 `Player_Idle.anim`, `Player_Run.anim`, `Player_Jump.anim`, `Player_Fall.anim`을 만듭니다.
2. `Player.controller`에 Idle/Run/Jump/Fall 상태를 만들고 기본 상태를 Idle로 지정합니다.
3. Animator Parameters (철자 및 대소문자 일치):
   - `Speed` : Float (월드 단위/초, 절댓값)
   - `VerticalSpeed`: Float (Rigidbody2D.linearVelocity.y)
   - `IsGrounded`: Bool
4. 권장 Transition (즉각적 캐릭터 응답을 위해 Has Exit Time OFF, Duration 0~0.05초부터 튜닝):
   - Idle → Run: Speed > 0.10
   - Run → Idle: Speed < 0.10
   - Idle/Run → Jump: IsGrounded == false AND VerticalSpeed > 0.05
   - Idle/Run → Fall: IsGrounded == false AND VerticalSpeed < -0.05
   - Jump → Fall: VerticalSpeed < -0.05
   - Jump → Idle/Run: IsGrounded == true (Speed 조건으로 분기; 빠른 착지 대응)
   - Fall → Idle: IsGrounded == true AND Speed < 0.10
   - Fall → Run: IsGrounded == true AND Speed > 0.10
   - 실습에서 시작값은 임계값을 사용하고, 필요한 경우 0.05/0.15 히스테리시스를 적용합니다.
5. PlayerRoot의 GroundPoint와 GroundLayer는 발밑 지형만 검출하도록 설정합니다. Player 레이어가 Ground에 포함되면 자기 자신을 잡을 수 있습니다.
6. PlayerAnimationBridge2D의 Animator에 자식 Visual의 컴포넌트를 연결합니다.
7. **물리 움직임은 PlayerRoot의 Rigidbody2D가 담당**합니다. Animation Clip은 Visual의 `SpriteRenderer.sprite`만 바꾸도록 구성합니다. `PlayerRoot.Transform.position` 키프레임은 넣지 않습니다.
8. 데모를 독립 실행할 때만 `DemoPlayerMover2D`를 붙입니다. 기존 17일차 이동 스크립트와 동시 활성화하지 않습니다.

## Test matrix
| ID | 상황 | 기대 결과 |
|---|---|---|
| A1 | 입력 없음·지상 | Idle |
| A2 | A/D 이동·지상 | Run |
| A3 | Space 점프·상승 | Jump |
| A4 | 정점 이후 하강 | Fall |
| A5 | 정지한 채 착지 | Idle |
| A6 | 이동 중 착지 | Run |
| A7 | 허공으로 떨어지기 | Fall |
| A8 | 좌우 방향 전환 | SpriteRenderer만 좌우 반전 |
| A9 | Animator 제거 후 Play | 오류 로그 1회 + 예외 없이 실행 지속 |

## Codex 프롬프트
"이 프로젝트의 PlayerRoot 이동과 Visual Animator 구성을 읽기 전용으로 분석해줘. Speed/VerticalSpeed/IsGrounded, Transition 조건, 애니메이션이 Rigidbody2D 위치를 덮어쓰는지 점검해줘. 변경 전 원인과 최소 수정안을 설명하고, 수정 후 수동 테스트 A1~A9를 제시해줘. 임의로 기존 이동 코드를 바꾸지 마."

## 참고
- https://docs.unity.com/en-us/engine/6000.3/manual/animation-section/animation-mecanim/animation-clips/animation-editor-guide/animeditor-creating-anew-animation-clip
- https://docs.unity3d.com/kr/6000.0/Manual/class-Transition.html
- https://docs.unity3d.com/kr/6000.0/Manual/AnimationParameters.html

## 수강생 실습용 Sprite 이미지(추가 제공)
`PracticeSprites/` 아래에는 Idle 4프레임·Run 6프레임·Jump 2프레임·Fall 2프레임의 **간단한 학습용 캐릭터 Sprite PNG**가 들어 있습니다.
실제 프로젝트에 사용할 최종 아트는 아니며, Unity에서 즉시 Clip을 만드는 실습을 위해 제공합니다.
각 PNG 파일을 Texture Type=`Sprite (2D and UI)`, Sprite Mode=`Multiple`, Sprite Editor > Slice > Grid by Cell Size **96×96**으로 분할합니다. Pixel Per Unit은 96부터 시작하고 Clip을 생성하세요. 원본 PNG의 프레임마다 동일한 하단 기준선을 사용합니다.
