using UnityEngine;

/// <summary>
/// Reads 2D movement/ground state and updates an Animator.
/// Does not control the Rigidbody2D; it can be added to Day 17's player.
/// </summary>
[DisallowMultipleComponent]
public sealed class PlayerAnimationBridge2D : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Rigidbody2D body;
    [SerializeField] private SimpleGroundSensor2D groundSensor;
    [SerializeField] private Animator animator;

    [Header("Animator Parameters")]
    [SerializeField, Min(0f)] private float speedDampTime = 0.08f;

    private static readonly int SpeedId = Animator.StringToHash("Speed");
    private static readonly int VerticalSpeedId = Animator.StringToHash("VerticalSpeed");
    private static readonly int IsGroundedId = Animator.StringToHash("IsGrounded");

    private void Awake()
    {
        if (body == null) body = GetComponent<Rigidbody2D>();
        if (groundSensor == null) groundSensor = GetComponent<SimpleGroundSensor2D>();
        if (animator == null) animator = GetComponentInChildren<Animator>();

        if (body == null || groundSensor == null || animator == null)
            Debug.LogError("[AnimationBridge] Assign Body, GroundSensor and Animator.", this);
    }

    private void Update()
    {
        if (body == null || groundSensor == null || animator == null) return;

        float horizontalSpeed = Mathf.Abs(body.linearVelocity.x);
        float verticalSpeed = body.linearVelocity.y;

        animator.SetFloat(SpeedId, horizontalSpeed, speedDampTime, Time.deltaTime);
        animator.SetFloat(VerticalSpeedId, verticalSpeed);
        animator.SetBool(IsGroundedId, groundSensor.IsGrounded);
    }
}
