using UnityEngine;

/// <summary>
/// Detects whether a 2D character is standing on a ground-layer collider.
/// Ground Point should be positioned just below the character's feet.
/// </summary>
[DisallowMultipleComponent]
public sealed class SimpleGroundSensor2D : MonoBehaviour
{
    [SerializeField] private Transform groundPoint;
    [SerializeField] private LayerMask groundLayers;
    [SerializeField, Min(0.01f)] private float radius = 0.10f;

    public bool IsGrounded { get; private set; }

    private void FixedUpdate()
    {
        if (groundPoint == null)
        {
            IsGrounded = false;
            return;
        }

        IsGrounded = Physics2D.OverlapCircle(
            groundPoint.position, radius, groundLayers) != null;
    }

    private void OnDrawGizmosSelected()
    {
        if (groundPoint == null) return;
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(groundPoint.position, radius);
    }
}
