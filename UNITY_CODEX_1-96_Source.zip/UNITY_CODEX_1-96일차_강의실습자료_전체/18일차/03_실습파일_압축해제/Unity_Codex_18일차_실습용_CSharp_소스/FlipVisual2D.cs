using UnityEngine;

/// <summary>
/// Turns only the visual sprite without flipping physics colliders.
/// Attach to the player root and assign the child SpriteRenderer.
/// </summary>
public sealed class FlipVisual2D : MonoBehaviour
{
    [SerializeField] private Rigidbody2D body;
    [SerializeField] private SpriteRenderer visual;
    [SerializeField, Min(0f)] private float minHorizontalSpeed = 0.1f;

    private void Awake()
    {
        if (body == null) body = GetComponent<Rigidbody2D>();
    }

    private void LateUpdate()
    {
        if (body == null || visual == null) return;
        float vx = body.linearVelocity.x;
        if (Mathf.Abs(vx) < minHorizontalSpeed) return;
        visual.flipX = vx < 0f;
    }
}
