using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// Optional standalone practice mover for a separate Day 18 demo scene.
/// Do not attach alongside your existing Day 17 movement controller.
/// </summary>
[RequireComponent(typeof(Rigidbody2D))]
public sealed class DemoPlayerMover2D : MonoBehaviour
{
    [SerializeField, Min(0f)] private float moveSpeed = 5f;
    [SerializeField, Min(0f)] private float jumpSpeed = 8f;
    [SerializeField] private SimpleGroundSensor2D groundSensor;

    private Rigidbody2D body;
    private float horizontal;
    private bool jumpQueued;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        if (groundSensor == null) groundSensor = GetComponent<SimpleGroundSensor2D>();
    }

    private void Update()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null) { horizontal = 0f; return; }

        horizontal = (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed ? 1f : 0f)
            - (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed ? 1f : 0f);
        if (keyboard.spaceKey.wasPressedThisFrame)
            jumpQueued = true;
    }

    private void FixedUpdate()
    {
        Vector2 v = body.linearVelocity;
        v.x = horizontal * moveSpeed;
        if (jumpQueued && groundSensor != null && groundSensor.IsGrounded)
            v.y = jumpSpeed;

        body.linearVelocity = v;
        jumpQueued = false;
    }
}
