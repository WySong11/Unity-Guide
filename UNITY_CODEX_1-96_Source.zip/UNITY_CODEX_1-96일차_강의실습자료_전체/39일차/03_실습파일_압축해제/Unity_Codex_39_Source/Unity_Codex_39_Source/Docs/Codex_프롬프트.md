# Codex용 예제 프롬프트

## 1. 사전 분석
Unity 6.3, URP, Input System 프로젝트입니다. 37일차 CharacterController 이동과 38일차 Orbit 카메라 구현을 분석해 주세요. 기존 이동 스크립트와 충돌하는 입력 처리·Update 순서·카메라 중복 여부를 먼저 보고하고, 파일 변경은 하지 마세요.

## 2. 기능 구현
다음 제약을 지키며 Jump, Sprint, Dash, Idle/Walk/Sprint/Jump/Fall/Dash 상태를 구현해 주세요.
- 기존 Scene, Prefab 및 37/38일차 원본 파일은 보존
- 신규 코드는 Assets/Unity_Codex/Day39에만 추가
- Input System Move(Vector2)/Jump/Sprint/Dash(Button)
- CharacterController.Move, 직접 중력, 충돌과 쿨다운, StateChanged 이벤트
- Time.timeScale=0에서 진행 중지
- 코드 수정 전/후 git diff 요약 및 Inspector 연결 절차 제공

## 3. 검증
Play Mode에서 각각의 단계에 대해 재현 조건, 관찰 결과, Console 오류, 판정(PASS/FAIL/NOT RUN)을 표로 작성해 주세요. 실제 Unity Editor에서 실행하지 못한 항목은 반드시 NOT RUN으로 표시하고 통과라고 주장하지 마세요.
