# Unity × Codex | 39일차 점프·대시·이동 상태

- 기준 환경: Unity 6.3 (6000.3), URP, Input System 패키지
- 목표: 37일차 이동과 38일차 카메라에 Jump/Sprint/Dash를 추가하고 이동 상태를 검증한다.
- `Day39PlayerMotor3D`는 독립 실습용 통합 모터입니다. `Day37CharacterMotor3D`와 **같은 Player에서 동시에 Enable하지 마세요**.
- 38일차 Orbit 카메라를 사용할 때는 `Day39SimpleFollowCamera`를 비활성화/제거하세요. 카메라 2개에서 서로 위치를 갱신하면 흔들립니다.

## 설치

1. `Runtime/*.cs`를 `Assets/Unity_Codex/Day39/Runtime`에 복사합니다.
2. `Editor/*.cs`를 `Assets/Unity_Codex/Day39/Editor`에 복사합니다. Editor 폴더 밖에 두지 않습니다.
3. `Day39Gameplay.inputactions`를 프로젝트 `Assets/Unity_Codex/Day39`에 복사하고 Input System 패키지 및 Active Input Handling을 확인합니다.
4. Unity 메뉴 **Tools → Unity Codex → Day39 → Create Movement Lab**을 실행합니다. 저장 전 현재 열린 씬의 저장 여부를 먼저 묻고, 결과는 새 경로로 저장됩니다.
5. `Player_Day39`의 `Day39PlayerMotor3D` 컴포넌트에서 InputActionReference 필드 4개에 `Day39Gameplay/Player/Move, Jump, Sprint, Dash`를 각각 연결합니다.
6. 카메라 기준 이동을 시험하려면 Main Camera를 `Camera Transform`에 할당합니다(없으면 첫 Awake에서 `Camera.main` 자동 탐색).
7. Play Mode 실행 후 `WASD` 이동, `Shift` 스프린트, `Space` 점프, `Ctrl` 대시를 확인합니다.
8. `Tools → Unity Codex → Day39 → Validate Open Scene` 검증은 구성 점검이며, 실제 Play 동작까지 대신 검증하지는 않습니다.

## 초기값

| 설정 | 값 | 의미 |
|---|---:|---|
| Walk Speed | 4 | 보행 m/s |
| Sprint Speed | 6.5 | 달리기 m/s |
| Jump Height | 1.6 | 점프 높이 m |
| Gravity | -22 | 하향 가속도 m/s² |
| Dash Speed | 12 | 대시 m/s |
| Dash Duration | 0.2 | 대시 지속 시간 s |
| Dash Cooldown | 1 | 쿨다운 s |
| Allow Air Dash | false | 공중 대시 차단 |

## 주의할 점

- `CharacterController.Move()`는 중력을 자동 적용하지 않습니다. `verticalSpeed += gravity * deltaTime`이 필요합니다.
- `isGrounded`는 **직전 Move 결과**를 반영합니다. 코드에서 Move 전/후 상태를 구분해 사용합니다.
- CharacterController와 Rigidbody를 같은 캐릭터에 동시에 사용하지 마세요(별도 설계 필요).
- 대시는 `CollisionFlags` 및 CharacterController의 충돌 제약을 따릅니다. `transform.position`으로 벽을 관통시키지 않습니다.
- 대시 중 점프 입력은 무시되며, `Time.timeScale == 0`이면 업데이트/쿨다운이 진행되지 않습니다.
- 대시 거리(12m/s × 0.2초 = 약 2.4m)는 충돌·프레임별 시간에 따라 달라질 수 있습니다.
- 이번 Animator 연동은 선택 사항입니다. Animator Controller에 동일한 Parameter 이름을 직접 만들어 연결해야 합니다.
- `Day39MovementDiagnostics`의 OnGUI는 학습용 디버그 HUD이므로 배포 빌드에서는 꺼주세요.

## 제출물

- 실행 중 Idle/Walk/Sprint/Jump/Fall/Dash 상태가 보이는 3장 이상의 스크린샷
- 대시 벽 충돌 + 대시 쿨다운 테스트 기록
- 수정한 `.cs`와 `Day39Gameplay.inputactions` 및 Codex 변경내역 설명
