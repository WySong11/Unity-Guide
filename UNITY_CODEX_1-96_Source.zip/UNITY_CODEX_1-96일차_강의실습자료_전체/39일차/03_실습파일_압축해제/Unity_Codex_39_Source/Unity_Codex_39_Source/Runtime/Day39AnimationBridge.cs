using UnityEngine;

/// <summary>
/// Animator Parameters (직접 생성): MoveSpeed float, VerticalSpeed float,
/// IsGrounded bool, IsDashing bool, MoveState int.
/// </summary>
public sealed class Day39AnimationBridge : MonoBehaviour
{
    [SerializeField] private Day39PlayerMotor3D motor;
    [SerializeField] private Animator animator;
    [SerializeField, Min(0.01f)] private float speedDampTime = 0.1f;

    private static readonly int MoveSpeed = Animator.StringToHash("MoveSpeed");
    private static readonly int VerticalSpeed = Animator.StringToHash("VerticalSpeed");
    private static readonly int IsGrounded = Animator.StringToHash("IsGrounded");
    private static readonly int IsDashing = Animator.StringToHash("IsDashing");
    private static readonly int MoveState = Animator.StringToHash("MoveState");

    private void Awake()
    {
        if (motor == null) motor = GetComponentInParent<Day39PlayerMotor3D>();
        if (animator == null) animator = GetComponentInChildren<Animator>();
    }

    private void Update()
    {
        if (motor == null || animator == null) return;
        animator.SetFloat(MoveSpeed, motor.HorizontalSpeed, speedDampTime, Time.deltaTime);
        animator.SetFloat(VerticalSpeed, motor.VerticalSpeed);
        animator.SetBool(IsGrounded, motor.IsGrounded);
        animator.SetBool(IsDashing, motor.CurrentState == Day39MoveState.Dash);
        animator.SetInteger(MoveState, (int)motor.CurrentState);
    }
}
