using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// Unity 6.3 / Input System / CharacterController.
/// 37일차 이동 기능을 독립 실습용으로 확장한 점프·스프린트·대시 모터입니다.
/// 기존 Day37CharacterMotor3D와 같은 오브젝트에서 동시에 활성화하지 마세요.
/// </summary>
[RequireComponent(typeof(CharacterController))]
public sealed class Day39PlayerMotor3D : MonoBehaviour
{
    [Header("Input Actions (Move: Vector2 / Jump, Sprint, Dash: Button)")]
    [SerializeField] private InputActionReference moveAction;
    [SerializeField] private InputActionReference jumpAction;
    [SerializeField] private InputActionReference sprintAction;
    [SerializeField] private InputActionReference dashAction;
    [Header("Camera-relative movement")]
    [SerializeField] private Transform cameraTransform;
    [SerializeField, Min(0f)] private float walkSpeed = 4f;
    [SerializeField, Min(0f)] private float sprintSpeed = 6.5f;
    [SerializeField, Min(0f)] private float turnSpeed = 12f;
    [Header("Jump & Gravity")]
    [SerializeField, Min(0.1f)] private float jumpHeight = 1.6f;
    [SerializeField] private float gravity = -22f;
    [SerializeField] private float groundedStickVelocity = -2f;
    [Header("Dash")]
    [SerializeField, Min(0.1f)] private float dashSpeed = 12f;
    [SerializeField, Min(0.05f)] private float dashDuration = 0.2f;
    [SerializeField, Min(0f)] private float dashCooldown = 1f;
    [SerializeField] private bool allowAirDash;

    public event Action<Day39MoveState> StateChanged;
    public Day39MoveState CurrentState { get; private set; } = Day39MoveState.Idle;
    public bool IsGrounded => controller != null && controller.isGrounded;
    public float VerticalSpeed => verticalSpeed;
    public float HorizontalSpeed => horizontalVelocity.magnitude;
    public float DashCooldownRemaining => cooldownLeft;

    private readonly List<InputAction> enabledByThisComponent = new();
    private CharacterController controller;
    private float verticalSpeed;
    private float dashTimeLeft;
    private float cooldownLeft;
    private Vector3 dashDirection;
    private Vector3 horizontalVelocity;
    private bool movementEnabled = true;

    private void Awake()
    {
        controller = GetComponent<CharacterController>();
        if (cameraTransform == null && Camera.main != null)
            cameraTransform = Camera.main.transform;
        if (gravity >= 0f)
        {
            Debug.LogWarning("[Day39] Gravity는 음수여야 합니다. -22로 보정합니다.", this);
            gravity = -22f;
        }
    }

    private void OnEnable()
    {
        EnableIfNeeded(moveAction);
        EnableIfNeeded(jumpAction);
        EnableIfNeeded(sprintAction);
        EnableIfNeeded(dashAction);
    }

    private void OnDisable()
    {
        foreach (var action in enabledByThisComponent)
            if (action != null) action.Disable();
        enabledByThisComponent.Clear();
    }

    private void EnableIfNeeded(InputActionReference reference)
    {
        InputAction action = reference != null ? reference.action : null;
        if (action == null || action.enabled) return;
        action.Enable();
        if (!enabledByThisComponent.Contains(action)) enabledByThisComponent.Add(action);
    }

    public void SetMovementEnabled(bool enabled)
    {
        movementEnabled = enabled;
        if (!enabled) horizontalVelocity = Vector3.zero;
    }

    private void Update()
    {
        // 일시정지 중 입력·대시 타이머·쿨다운 모두 정지
        if (Time.timeScale <= 0f || !movementEnabled) return;
        float dt = Time.deltaTime;
        bool grounded = controller.isGrounded; // 이전 Move 결과
        if (grounded && verticalSpeed < 0f)
            verticalSpeed = groundedStickVelocity;

        cooldownLeft = Mathf.Max(0f, cooldownLeft - dt);
        Vector2 raw = moveAction != null && moveAction.action != null
            ? moveAction.action.ReadValue<Vector2>() : Vector2.zero;
        Vector2 move = Vector2.ClampMagnitude(raw, 1f);
        Vector3 desired = GetCameraRelativeDirection(move);
        bool sprinting = IsPressed(sprintAction) && move.sqrMagnitude > 0.01f;
        if (Pressed(jumpAction) && grounded && dashTimeLeft <= 0f)
            verticalSpeed = Mathf.Sqrt(jumpHeight * -2f * gravity);

        if (Pressed(dashAction) && dashTimeLeft <= 0f && cooldownLeft <= 0f &&
            (grounded || allowAirDash))
        {
            Vector3 facing = transform.forward;
            facing.y = 0f;
            dashDirection = desired.sqrMagnitude > 0.01f ? desired : facing.normalized;
            if (dashDirection.sqrMagnitude < 0.001f) dashDirection = Vector3.forward;
            dashTimeLeft = dashDuration;
            cooldownLeft = dashCooldown;
        }

        bool isDashing = dashTimeLeft > 0f;
        horizontalVelocity = isDashing
            ? dashDirection * dashSpeed
            : desired * (sprinting ? sprintSpeed : walkSpeed);
        if (isDashing) dashTimeLeft = Mathf.Max(0f, dashTimeLeft - dt);

        Vector3 rotateToward = isDashing ? dashDirection : desired;
        if (rotateToward.sqrMagnitude > 0.01f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(rotateToward, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation,
                1f - Mathf.Exp(-turnSpeed * dt));
        }

        verticalSpeed += gravity * dt;
        CollisionFlags hit = controller.Move(
            (horizontalVelocity + Vector3.up * verticalSpeed) * dt);
        if ((hit & CollisionFlags.Above) != 0 && verticalSpeed > 0f)
            verticalSpeed = 0f;

        // Move 직후 충돌 결과 사용. 점프한 첫 프레임과 착지 프레임을 구분.
        bool nowGrounded = (hit & CollisionFlags.Below) != 0;
        Day39MoveState state = isDashing ? Day39MoveState.Dash
            : !nowGrounded ? (verticalSpeed > 0f ? Day39MoveState.Jump : Day39MoveState.Fall)
            : move.sqrMagnitude < 0.01f ? Day39MoveState.Idle
            : sprinting ? Day39MoveState.Sprint : Day39MoveState.Walk;
        SetState(state);
    }

    private Vector3 GetCameraRelativeDirection(Vector2 input)
    {
        Vector3 forward = cameraTransform != null ? cameraTransform.forward : Vector3.forward;
        Vector3 right = cameraTransform != null ? cameraTransform.right : Vector3.right;
        forward.y = 0f;
        right.y = 0f;
        forward.Normalize(); right.Normalize();
        Vector3 direction = forward * input.y + right * input.x;
        return Vector3.ClampMagnitude(direction, 1f);
    }

    private static bool Pressed(InputActionReference reference) =>
        reference != null && reference.action != null && reference.action.WasPressedThisFrame();
    private static bool IsPressed(InputActionReference reference) =>
        reference != null && reference.action != null && reference.action.IsPressed();

    private void SetState(Day39MoveState state)
    {
        if (CurrentState == state) return;
        CurrentState = state;
        StateChanged?.Invoke(state);
    }
}
