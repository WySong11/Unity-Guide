/// <summary>39일차 플레이어 이동 상태. Dash > Jump/Fall > Sprint > Walk > Idle 우선순위.</summary>
public enum Day39MoveState
{
    Idle, Walk, Sprint, Jump, Fall, Dash
}
