using UnityEngine;

/// <summary>독립 Day39 테스트 씬용 카메라. 38일차 카메라가 있으면 중복 사용하지 마세요.</summary>
public sealed class Day39SimpleFollowCamera : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private Vector3 offset = new Vector3(0f, 4f, -7f);
    [SerializeField, Min(0.01f)] private float followSmoothTime = 0.12f;
    [SerializeField] private float lookHeight = 1.2f;
    private Vector3 currentVelocity;
    public void SetTarget(Transform value) => target = value;
    private void LateUpdate()
    {
        if (target == null) return;
        transform.position = Vector3.SmoothDamp(transform.position,
            target.position + offset, ref currentVelocity, followSmoothTime);
        transform.LookAt(target.position + Vector3.up * lookHeight);
    }
}
