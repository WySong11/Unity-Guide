using UnityEngine;

/// <summary>런타임 상태 변경과 대시 쿨다운 추적. Animator 없이도 검증 가능.</summary>
public sealed class Day39MovementDiagnostics : MonoBehaviour
{
    [SerializeField] private Day39PlayerMotor3D motor;
    [SerializeField] private bool logStateChanges = true;
    [SerializeField] private bool showOverlay = true;
    private GUIStyle textStyle;

    private void Awake()
    {
        if (motor == null) motor = GetComponent<Day39PlayerMotor3D>();
    }
    private void OnEnable()
    {
        if (motor != null) motor.StateChanged += OnStateChanged;
    }
    private void OnDisable()
    {
        if (motor != null) motor.StateChanged -= OnStateChanged;
    }
    private void OnStateChanged(Day39MoveState state)
    {
        if (logStateChanges) Debug.Log($"[Day39] State -> {state}", this);
    }
    private void OnGUI()
    {
        if (!showOverlay || motor == null) return;
        textStyle ??= new GUIStyle(GUI.skin.box) { alignment = TextAnchor.UpperLeft, fontSize = 17 };
        GUI.Box(new Rect(12, 12, 335, 110),
            $"STATE: {motor.CurrentState}\n" +
            $"Ground: {motor.IsGrounded}   Y: {motor.VerticalSpeed:F2}\n" +
            $"Speed: {motor.HorizontalSpeed:F2}   Dash CD: {motor.DashCooldownRemaining:F2}", textStyle);
    }
}
