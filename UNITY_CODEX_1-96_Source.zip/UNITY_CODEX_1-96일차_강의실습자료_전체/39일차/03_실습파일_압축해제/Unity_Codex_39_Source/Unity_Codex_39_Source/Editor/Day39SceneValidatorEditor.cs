#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using UnityEngine.InputSystem;

public static class Day39SceneValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day39/Validate Open Scene")]
    public static void Validate()
    {
        var motors = Object.FindObjectsByType<Day39PlayerMotor3D>(FindObjectsSortMode.None);
        var cameras = Object.FindObjectsByType<Camera>(FindObjectsSortMode.None);
        int errors = 0;
        if (motors.Length != 1) { Debug.LogError($"[Day39] Day39PlayerMotor3D 수: {motors.Length} (기대 1)"); errors++; }
        if (cameras.Length == 0) { Debug.LogError("[Day39] Camera 없음"); errors++; }
        if (motors.Length == 1)
        {
            if (motors[0].GetComponent<CharacterController>() == null) { errors++; Debug.LogError("[Day39] CharacterController 누락"); }
            var so = new SerializedObject(motors[0]);
            foreach (string field in new[] {"moveAction", "jumpAction", "sprintAction", "dashAction"})
            {
                var prop = so.FindProperty(field);
                if (prop == null || prop.objectReferenceValue == null)
                { errors++; Debug.LogWarning($"[Day39] {field} Inspector 연결 필요"); }
            }
        }
        Debug.Log(errors == 0 ? "[Day39] 구성 검증 통과 (실행 테스트는 별도)" : $"[Day39] 검증 결과: 확인 사항 {errors}개");
    }
}
#endif
