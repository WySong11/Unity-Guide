#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class Day39SceneBuilderEditor
{
    private const string Root = "Assets/Unity_Codex/Day39";
    [MenuItem("Tools/Unity Codex/Day39/Create Movement Lab")]
    public static void CreateLab()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        Directory.CreateDirectory(Root + "/Scenes");
        string path = AssetDatabase.GenerateUniqueAssetPath(Root + "/Scenes/Day39_MovementLab.unity");
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.name = "Ground";
        ground.transform.position = new Vector3(0f, -0.5f, 0f);
        ground.transform.localScale = new Vector3(40f, 1f, 40f);
        for (int i = 0; i < 3; i++)
        {
            GameObject platform = GameObject.CreatePrimitive(PrimitiveType.Cube);
            platform.name = $"Step_{i+1}";
            platform.transform.position = new Vector3(5f + i * 2.5f, (i + 1) * 0.6f, 4f);
            platform.transform.localScale = new Vector3(2.5f, 0.5f + i * 0.4f, 2.5f);
        }
        GameObject wall = GameObject.CreatePrimitive(PrimitiveType.Cube);
        wall.name = "DashCollisionWall";
        wall.transform.position = new Vector3(0f, 1f, 8f);
        wall.transform.localScale = new Vector3(6f, 2f, 0.8f);

        GameObject player = new GameObject("Player_Day39");
        player.transform.position = new Vector3(0f, 0.1f, 0f);
        CharacterController cc = player.AddComponent<CharacterController>();
        cc.height = 2f; cc.radius = 0.45f; cc.center = Vector3.up;
        player.AddComponent<Day39PlayerMotor3D>();
        player.AddComponent<Day39MovementDiagnostics>();
        GameObject visual = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        visual.name = "Visual";
        visual.transform.SetParent(player.transform, false);
        visual.transform.localPosition = Vector3.up;
        Collider extra = visual.GetComponent<Collider>();
        if (extra != null) Object.DestroyImmediate(extra);

        GameObject camera = new GameObject("Main Camera");
        camera.tag = "MainCamera";
        camera.transform.position = new Vector3(0f, 4f, -7f);
        camera.AddComponent<Camera>();
        camera.AddComponent<AudioListener>();
        camera.AddComponent<Day39SimpleFollowCamera>().SetTarget(player.transform);
        GameObject light = new GameObject("Directional Light");
        Light sun = light.AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.intensity = 1.25f;
        light.transform.rotation = Quaternion.Euler(45f, -30f, 0f);

        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene, path);
        AssetDatabase.Refresh();
        Selection.activeObject = player;
        Debug.Log($"[Day39] 실습 씬 생성: {path} / 다음 단계: InputActionReference 4개 연결");
    }
}
#endif
