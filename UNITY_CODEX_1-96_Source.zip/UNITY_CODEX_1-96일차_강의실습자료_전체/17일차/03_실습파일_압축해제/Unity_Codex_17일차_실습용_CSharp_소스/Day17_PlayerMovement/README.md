# Day 17 — 플레이어 이동 개선 (Unity 6.3 / 2D Input System)

- 강의 시간: 120분
- 목표: 가속/감속, 공중 제어, 짧은/긴 점프, 코요테 타임, 점프 버퍼를 적용한 개선된 2D 플레이어 이동 시스템
- 주의: **Unity Editor에서 컴파일/실제 실행을 확인한 산출물은 아닙니다.** 수업 시작 전 교육 환경에서 검증하세요.

## 포함 파일
- `PlayerMovementPolished2D.cs` — 완성 이동 컨트롤러
- `MovementTelemetry2D.cs` — 선택적 속도/접지 진단 로그
- `ManualTestMatrix.csv` — 12개 테스트 항목
- `CodexPrompts.md` — 분석, 개선, 디버깅, 리뷰 프롬프트
- `BugReportTemplate.md` — 오류 기록 양식

## 15~16일차 프로젝트에서 이어 시작하기
1. 프로젝트를 Git에 커밋한 뒤 씬을 `Day17_MovementPolish`로 복제합니다.
2. 이전 `PlayerMover2D` 같은 **기존 플레이어 이동 스크립트를 비활성화**합니다. 한 GameObject에 서로 다른 이동 컨트롤러를 동시에 켜 두지 마세요.
3. `Assets/Scripts/Player/`에 새 스크립트를 넣고 Player에 `PlayerMovementPolished2D`를 부착합니다.
4. Rigidbody2D(Dynamic), CapsuleCollider2D, SpriteRenderer 및 자식 GroundCheck를 사용합니다. 시작 설정 예시는 Gravity Scale=2.5, Freeze Rotation Z.
5. GroundCheck는 캐릭터 발밑에, Ground 오브젝트는 전용 Layer(`Ground`)로 지정합니다. **플레이어 자신의 Collider가 Ground Layer에 포함되지 않게** 하세요.
6. Input Actions 자산의 `Player/Move`는 Value/Vector2 + WASD 2D Composite, `Player/Jump`는 Button + Space를 지정합니다. Inspector의 `moveAction`, `jumpAction`에 참조를 드래그해 연결합니다.
7. `visualSprite`, `groundCheck`, `groundLayer`를 지정하고 Play Mode를 실행합니다.

## 주요 조작 및 튜닝 값
| 항목 | 기본값 | 역할 |
|---|---:|---|
| Move Speed | 7 | 최대 좌우 속도 |
| Ground Acceleration | 48 | 지상 가속 |
| Ground Deceleration | 58 | 지상 감속 |
| Air Acceleration | 24 | 공중 방향 제어 |
| Air Deceleration | 25 | 공중에서 입력 해제할 때의 감속 |
| Jump Speed | 12 | 점프 초기 상승 속도 |
| Coyote Time | 0.10 | 발판을 벗어난 직후 점프 허용 시간 |
| Jump Buffer Time | 0.12 | 착지 직전 점프 입력 유효 시간 |
| Jump Cut Multiplier | 0.45 | 점프 키를 일찍 뗐을 때 상승 속도 비율 |
| Ground Radius | 0.12 | 접지 검사 반경 |

## 학습상 중요한 구현 규칙
- `Update`: Input System 키 상태/액션을 읽고 값을 저장합니다.
- `FixedUpdate`: Physics2D 접지 검사 및 `Rigidbody2D.linearVelocity` 적용을 처리합니다.
- 가속/감속은 `Mathf.MoveTowards`와 `Time.fixedDeltaTime`을 사용합니다.
- 수평 속도만 개선할 때는 **현재 Y 속도를 유지**합니다.
- 플레이어 그래픽만 뒤집기 위해 `SpriteRenderer.flipX`를 사용합니다.
- 이번 예제는 스크립트가 InputAction을 Enable/Disable합니다. **동일한 Action을 `PlayerInput` 또는 다른 컨트롤러와 동시에 관리하지 마세요.** 수업에서는 단일 컨트롤러만 사용합니다.
- 입력 처리 방식/ground checking이 프로젝트에 따라 다르므로 `GroundCheck`의 크기와 위치는 씬에 맞게 조정하세요.

## 테스트
`ManualTestMatrix.csv`의 T01~T12를 기록합니다. 특히 코요테·버퍼의 경우 설정 시간을 0으로 바꿔 전/후 차이를 비교하면 효과적입니다.

## 공식 문서
- Unity 6.3 2D 개발: https://docs.unity.com/en-us/engine/6000.3/manual/unity2d
- Unity 6 Rigidbody2D: https://docs.unity3d.com/kr/current/ScriptReference/Rigidbody2D.html
- Unity 6.3 2D Player movement: https://learn.unity.com/course/2D-adventure-robot-repair/unit/player-character-and-movement?version=6.3
