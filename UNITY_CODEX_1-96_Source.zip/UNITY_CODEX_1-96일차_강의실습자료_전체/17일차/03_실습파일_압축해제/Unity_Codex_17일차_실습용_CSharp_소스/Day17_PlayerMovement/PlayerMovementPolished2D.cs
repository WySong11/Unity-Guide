using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// Day 17: acceleration/braking, air control, coyote time,
/// jump buffering, variable-height jump and sprite flip.
/// Unity 6.x + Input System. Use as the only movement controller.
/// </summary>
[RequireComponent(typeof(Rigidbody2D))]
public class PlayerMovementPolished2D : MonoBehaviour
{
    [Header("Input Actions (this script owns their lifetime)")]
    [SerializeField] private InputActionReference moveAction;
    [SerializeField] private InputActionReference jumpAction;

    [Header("Horizontal movement")]
    [SerializeField, Min(0f)] private float moveSpeed = 7f;
    [SerializeField, Min(0f)] private float groundAcceleration = 48f;
    [SerializeField, Min(0f)] private float groundDeceleration = 58f;
    [SerializeField, Min(0f)] private float airAcceleration = 24f;
    [SerializeField, Min(0f)] private float airDeceleration = 25f;

    [Header("Jump feel")]
    [SerializeField, Min(0f)] private float jumpSpeed = 12f;
    [SerializeField, Min(0f)] private float coyoteTime = 0.10f;
    [SerializeField, Min(0f)] private float jumpBufferTime = 0.12f;
    [SerializeField, Range(0.1f, 1f)] private float jumpCutMultiplier = 0.45f;

    [Header("Ground check")]
    [SerializeField] private Transform groundCheck;
    [SerializeField] private LayerMask groundLayer;
    [SerializeField, Min(0.01f)] private float groundRadius = 0.12f;
    [SerializeField] private SpriteRenderer visualSprite;

    private Rigidbody2D body;
    private float moveX;
    private float coyoteRemaining;
    private float bufferRemaining;
    private bool jumpHeld;
    private bool jumpQueued;
    private bool jumpCutUsed;
    private bool jumpInProgress;
    private bool isGrounded;

    public bool IsGrounded => isGrounded;
    public float HorizontalSpeed => body != null ? body.linearVelocity.x : 0f;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
    }

    private void OnEnable()
    {
        // Do not also let PlayerInput or another script own these shared Actions.
        moveAction?.action?.Enable();
        jumpAction?.action?.Enable();
    }

    private void OnDisable()
    {
        jumpAction?.action?.Disable();
        moveAction?.action?.Disable();
        moveX = 0f;
        jumpHeld = false;
        jumpQueued = false;
        bufferRemaining = 0f;
    }

    private void Update()
    {
        moveX = moveAction?.action != null
            ? moveAction.action.ReadValue<Vector2>().x : 0f;

        if (jumpAction?.action != null)
        {
            if (jumpAction.action.WasPressedThisFrame())
            {
                jumpQueued = true;
                bufferRemaining = jumpBufferTime;
            }
            jumpHeld = jumpAction.action.IsPressed();
        }
        else
        {
            jumpHeld = false;
        }

        if (visualSprite != null && Mathf.Abs(moveX) > 0.05f)
            visualSprite.flipX = moveX < 0f;
    }

    private void FixedUpdate()
    {
        float dt = Time.fixedDeltaTime;
        bool touchGround = groundCheck != null &&
            Physics2D.OverlapCircle(groundCheck.position, groundRadius, groundLayer) != null;

        // Ignore a lingering foot overlap when the player is moving upward.
        isGrounded = touchGround && body.linearVelocity.y <= 0.01f;

        if (isGrounded)
        {
            coyoteRemaining = coyoteTime;
            jumpInProgress = false;
        }
        else
        {
            coyoteRemaining = Mathf.Max(0f, coyoteRemaining - dt);
        }

        Vector2 velocity = body.linearVelocity;
        float targetX = moveX * moveSpeed;
        float acceleration = isGrounded ? groundAcceleration : airAcceleration;
        float deceleration = isGrounded ? groundDeceleration : airDeceleration;
        float rate = Mathf.Abs(moveX) > 0.01f ? acceleration : deceleration;
        velocity.x = Mathf.MoveTowards(velocity.x, targetX, rate * dt);

        // Grounded jumps always work, even if coyoteTime = 0.
        // A press can be consumed in the next physics step even with bufferTime = 0.
        bool wantsJump = jumpQueued || bufferRemaining > 0f;
        bool canJump = isGrounded || coyoteRemaining > 0f;
        if (wantsJump && canJump)
        {
            velocity.y = jumpSpeed;
            bufferRemaining = 0f;
            coyoteRemaining = 0f;
            isGrounded = false;
            jumpInProgress = true;
            jumpCutUsed = false;
        }
        else
        {
            bufferRemaining = Mathf.Max(0f, bufferRemaining - dt);
        }
        jumpQueued = false;

        // Releasing the jump key early produces a shorter jump.
        if (jumpInProgress && !jumpHeld && !jumpCutUsed && velocity.y > 0f)
        {
            velocity.y *= jumpCutMultiplier;
            jumpCutUsed = true;
        }

        body.linearVelocity = velocity;
    }

    private void OnDrawGizmosSelected()
    {
        if (groundCheck == null) return;
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(groundCheck.position, groundRadius);
    }
}
