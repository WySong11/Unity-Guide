using UnityEngine;

/// <summary>Optional diagnostic logger for the Day 17 player controller.</summary>
[RequireComponent(typeof(Rigidbody2D))]
public class MovementTelemetry2D : MonoBehaviour
{
    [SerializeField] private PlayerMovementPolished2D controller;
    [SerializeField, Min(0.05f)] private float interval = 0.25f;
    private Rigidbody2D body;
    private float nextLogTime;

    private void Awake() => body = GetComponent<Rigidbody2D>();

    private void Update()
    {
        if (controller == null || Time.unscaledTime < nextLogTime) return;
        nextLogTime = Time.unscaledTime + interval;
        Debug.Log($"[Move17] grounded={controller.IsGrounded}, " +
                  $"velocity={body.linearVelocity}", this);
    }
}
