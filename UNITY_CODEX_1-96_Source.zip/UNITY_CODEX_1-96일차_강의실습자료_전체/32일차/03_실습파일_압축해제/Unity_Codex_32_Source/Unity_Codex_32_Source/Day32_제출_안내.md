# 32일차 중간 평가 제출 안내

## 제출 산출물
1. 발표 자료(PPT 또는 PDF)
2. Windows 빌드 폴더(실행 파일과 `_Data` 폴더 전체)
3. Unity 프로젝트 핵심 파일(Assets, Packages, ProjectSettings)
4. 플레이 테스트 표 및 증거 파일(화면 캡처 또는 로그)
5. 다음 단계 개선 계획(Backlog)

## 권장 폴더 구조
```text
Team_01_Midterm/
├─ Presentation/
├─ Build/
│  ├─ Game.exe
│  └─ Game_Data/
├─ Project/
│  ├─ Assets/
│  ├─ Packages/
│  └─ ProjectSettings/
├─ Evidence/
└─ Evaluation/
```

## 유의 사항
- `Library`, `Temp`, `Obj`는 일반적으로 공유용 프로젝트 ZIP에서 제외할 수 있습니다.
- 게임 실행에 필요한 빌드 파일은 전체를 제출합니다.
- 환경별 출력이 다른 경우 테스트 환경(Windows, 해상도 등)을 적습니다.
- 저작권이 있는 서드파티 유료 에셋·개인 비밀키·비밀번호는 공유하지 않습니다.
- 기능이 재현되지 않았다면 PASS가 아닌 FAIL 또는 NOT RUN으로 기록합니다.
