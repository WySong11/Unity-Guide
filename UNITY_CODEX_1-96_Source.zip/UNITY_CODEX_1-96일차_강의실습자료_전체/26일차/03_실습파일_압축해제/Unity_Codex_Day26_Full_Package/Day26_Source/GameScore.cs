using System;
using UnityEngine;

/// <summary>점수 값을 관리하고 변경 이벤트를 발행합니다.</summary>
public class GameScore : MonoBehaviour
{
    public int Score { get; private set; }
    public event Action<int> ScoreChanged;

    private void Awake()
    {
        Score = 0;
    }

    public void AddScore(int amount)
    {
        if (amount <= 0) return;
        // 초급 실습용: int의 범위를 벗어나는 입력은 제한합니다.
        long total = (long)Score + amount;
        Score = (int)Math.Min(total, int.MaxValue);
        ScoreChanged?.Invoke(Score);
    }

    public void ResetScore()
    {
        Score = 0;
        ScoreChanged?.Invoke(Score);
    }
}
