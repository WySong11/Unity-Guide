Unity × Codex / 26일차: 체력바, 점수 표시
적용: Unity 6.x(6000.3 계열), Unity UI(uGUI), TextMeshPro

[파일]
- PlayerHealth.cs: 현재/최대 체력 관리, HealthChanged/Died 이벤트
- GameScore.cs: 점수 관리, ScoreChanged 이벤트
- HUDPresenter.cs: Slider + TMP_Text를 이벤트로 갱신
- HUDDebugButtons.cs: 테스트 버튼(피해, 회복, 점수, 리셋) 연결

[씬 구성]
1. 빈 GameObject 'GameSystems'를 생성하고 GameScore 부착
2. Player에 PlayerHealth 부착
3. Canvas(Screen Space - Overlay)에 HUDPanel 생성
4. Slider 이름 HPBar / Handle 제거 / Interactable 해제
5. TMP - Text 두 개를 HPText, ScoreText 이름으로 생성
6. HUDPanel에 HUDPresenter 부착 후 5개 Inspector 참조 연결
   Player Health: Player의 PlayerHealth
   Game Score: GameSystems의 GameScore
   Health Slider: HPBar의 Slider
   Health Text: HPText의 TMP_Text
   Score Text: ScoreText의 TMP_Text
7. 테스트용 빈 오브젝트에 HUDDebugButtons 부착, 데이터 참조 연결
8. Button 4개를 만들고 각각의 On Click()에 HUDDebugButtons의
   DamagePlayer / HealPlayer / EarnScore / ResetHUD를 연결
9. Play에서 초기 HP 100/100, SCORE 0을 확인

[알아둘 점]
- 체력/점수의 진짜 값은 PlayerHealth/GameScore에 있고, HUDPresenter는 화면 표시만 담당합니다.
- HUDPresenter는 OnEnable/OnDisable에서 이벤트를 등록/해제합니다.
- 최초 화면 표시는 Start에서 RefreshAll()을 수행하여 보장합니다.
- Slider가 입력용이 아닌 표시용이므로 Interactable을 해제합니다.
- PlayerHealth.Heal은 사망 이후 자동 부활시키지 않습니다. 부활은 ResetHealth를 사용합니다.
- 반복 호출 Update 폴링 없이 이벤트가 발생할 때에만 UI가 변경됩니다.

[검증]
- 데미지 25 -> HP 75/100
- 회복 10 -> HP 85/100
- 점수 +100 두 번 -> SCORE 200
- 데미지를 반복하면 HP 0에 머물고 음수가 되지 않음
- HUDPanel을 끄고 다시 켠 후 값이 최신으로 표시되는지 확인
- ResetHUD -> HP 100/100, SCORE 0

[Unity 공식 문서]
https://docs.unity3d.com/6000.3/Documentation/Manual/UIE-Comparison.html
https://docs.unity3d.com/ScriptReference/UI.Slider.html
https://docs.unity3d.com/ScriptReference/UI.Slider.SetValueWithoutNotify.html
https://docs.unity3d.com/ScriptReference/UI.Image-fillAmount.html
