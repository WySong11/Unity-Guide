using UnityEngine;

/// <summary>실습용 버튼 이벤트를 연결하기 위한 테스트 컴포넌트입니다.</summary>
public class HUDDebugButtons : MonoBehaviour
{
    [SerializeField] private PlayerHealth playerHealth;
    [SerializeField] private GameScore gameScore;

    public void DamagePlayer()
    {
        if (playerHealth != null) playerHealth.TakeDamage(25);
    }

    public void HealPlayer()
    {
        if (playerHealth != null) playerHealth.Heal(10);
    }

    public void EarnScore()
    {
        if (gameScore != null) gameScore.AddScore(100);
    }

    public void ResetHUD()
    {
        if (playerHealth != null) playerHealth.ResetHealth();
        if (gameScore != null) gameScore.ResetScore();
    }
}
