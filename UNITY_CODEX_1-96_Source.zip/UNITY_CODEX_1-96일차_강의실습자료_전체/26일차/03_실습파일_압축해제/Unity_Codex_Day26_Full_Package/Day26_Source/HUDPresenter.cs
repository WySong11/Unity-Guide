using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>게임 데이터를 읽어 UI에 표현합니다. 데이터 자체는 변경하지 않습니다.</summary>
public class HUDPresenter : MonoBehaviour
{
    [Header("Data Sources")]
    [SerializeField] private PlayerHealth playerHealth;
    [SerializeField] private GameScore gameScore;

    [Header("HUD Elements")]
    [SerializeField] private Slider healthSlider;
    [SerializeField] private TMP_Text healthText;
    [SerializeField] private TMP_Text scoreText;

    private bool started;

    private void OnEnable()
    {
        if (playerHealth != null)
            playerHealth.HealthChanged += UpdateHealth;

        if (gameScore != null)
            gameScore.ScoreChanged += UpdateScore;

        // 비활성화 후 다시 열렸을 때 최신 값으로 복구합니다.
        if (started) RefreshAll();
    }

    private void Start()
    {
        started = true;
        if (healthSlider != null) healthSlider.interactable = false;
        RefreshAll(); // 시작할 때 변경 이벤트가 없어도 UI를 초기화
    }

    private void OnDisable()
    {
        if (playerHealth != null)
            playerHealth.HealthChanged -= UpdateHealth;

        if (gameScore != null)
            gameScore.ScoreChanged -= UpdateScore;
    }

    private void RefreshAll()
    {
        if (playerHealth != null)
            UpdateHealth(playerHealth.CurrentHealth, playerHealth.MaxHealth);

        if (gameScore != null)
            UpdateScore(gameScore.Score);
    }

    private void UpdateHealth(int current, int maximum)
    {
        if (healthSlider != null)
        {
            healthSlider.minValue = 0;
            healthSlider.maxValue = Mathf.Max(1, maximum);
            healthSlider.SetValueWithoutNotify(current);
        }

        if (healthText != null)
            healthText.text = $"HP {current} / {maximum}";
    }

    private void UpdateScore(int score)
    {
        if (scoreText != null)
            scoreText.text = $"SCORE  {score:N0}";
    }
}
