using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

/// <summary>새 Day37 실습 씬을 생성합니다. 기존 씬을 덮어쓰지 않습니다.</summary>
public static class Day37SceneBuilderEditor
{
    private const string Root = "Assets/Unity_Codex/Day37";

    [MenuItem("Tools/Unity Codex/Day37/Create Movement Lab")]
    public static void CreateMovementLab()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
            return;

        EnsureFolder("Assets/Unity_Codex");
        EnsureFolder(Root);
        EnsureFolder(Root + "/Scenes");
        EnsureFolder(Root + "/Materials");

        EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
        ground.name = "Ground";
        ground.transform.position = new Vector3(0f, -0.25f, 0f);
        ground.transform.localScale = new Vector3(18f, 0.5f, 18f);
        SetMaterial(ground, "Ground_Mat", new Color(0.2f, 0.27f, 0.39f));

        for (int i = 0; i < 3; i++)
        {
            GameObject wall = GameObject.CreatePrimitive(PrimitiveType.Cube);
            wall.name = "Obstacle_0" + (i + 1);
            wall.transform.position = new Vector3(-3f + i * 3f, 0.6f, 2f + i);
            wall.transform.localScale = new Vector3(1.4f, 1.2f, 1.2f);
            SetMaterial(wall, "Obstacle_Mat", new Color(0.9f, 0.53f, 0.24f));
        }

        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Player_Day37";
        player.transform.position = new Vector3(0f, 1.05f, -4f);
        CapsuleCollider oldCollider = player.GetComponent<CapsuleCollider>();
        if (oldCollider != null) Object.DestroyImmediate(oldCollider);
        CharacterController cc = player.AddComponent<CharacterController>();
        cc.center = Vector3.zero;
        cc.height = 2f;
        cc.radius = 0.45f;
        cc.stepOffset = 0.3f;
        cc.slopeLimit = 45f;
        cc.skinWidth = 0.08f;
        player.AddComponent<Day37CharacterMotor3D>();
        player.AddComponent<Day37PlayerMovementProbe>();
        SetMaterial(player, "Player_Mat", new Color(0.17f, 0.68f, 0.86f));

        GameObject camObj = new GameObject("Main Camera");
        camObj.tag = "MainCamera";
        camObj.AddComponent<Camera>();
        camObj.AddComponent<AudioListener>();
        Day37ThirdPersonCamera3D cameraFollow = camObj.AddComponent<Day37ThirdPersonCamera3D>();
        cameraFollow.SetTarget(player.transform);
        camObj.transform.position = player.transform.position + new Vector3(0f, 5f, -7f);
        camObj.transform.LookAt(player.transform.position + Vector3.up * 1.2f);

        GameObject sunObj = new GameObject("Directional Light");
        Light sun = sunObj.AddComponent<Light>();
        sun.type = LightType.Directional;
        sun.intensity = 1.1f;
        sunObj.transform.rotation = Quaternion.Euler(50f, -35f, 0f);

        string savePath = AssetDatabase.GenerateUniqueAssetPath(Root + "/Scenes/Day37_PlayerMovement.unity");
        EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene(), savePath);
        Selection.activeGameObject = player;
        EditorGUIUtility.PingObject(player);
        Debug.Log($"[Day37] New scene created: {savePath}\nNext: Assign Move/Jump InputActionReferences on Player_Day37. No actions were wired automatically.");
    }

    private static void EnsureFolder(string path)
    {
        if (AssetDatabase.IsValidFolder(path)) return;
        string parent = Path.GetDirectoryName(path)?.Replace('\\', '/');
        string name = Path.GetFileName(path);
        if (!string.IsNullOrEmpty(parent) && AssetDatabase.IsValidFolder(parent))
            AssetDatabase.CreateFolder(parent, name);
    }

    private static void SetMaterial(GameObject go, string name, Color color)
    {
        string assetPath = Root + "/Materials/" + name + ".mat";
        Material material = AssetDatabase.LoadAssetAtPath<Material>(assetPath);
        if (material == null)
        {
            Shader shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
            if (shader == null) return;
            material = new Material(shader) { name = name };
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
            if (material.HasProperty("_Color")) material.SetColor("_Color", color);
            AssetDatabase.CreateAsset(material, assetPath);
        }
        go.GetComponent<Renderer>().sharedMaterial = material;
    }
}
