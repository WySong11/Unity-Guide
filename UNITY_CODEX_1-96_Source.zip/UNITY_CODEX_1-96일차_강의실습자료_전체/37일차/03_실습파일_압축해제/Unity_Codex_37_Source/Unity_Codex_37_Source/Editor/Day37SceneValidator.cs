using UnityEditor;
using UnityEngine;

/// <summary>Day37 실행 전 씬 구성 검사. 검사 결과는 Console에만 출력합니다.</summary>
public static class Day37SceneValidator
{
    [MenuItem("Tools/Unity Codex/Day37/Validate Movement Scene")]
    public static void Validate()
    {
        Day37CharacterMotor3D motor = Object.FindFirstObjectByType<Day37CharacterMotor3D>();
        Camera cam = Camera.main;
        int errors = 0;

        if (motor == null)
        {
            Debug.LogError("[Day37] Day37CharacterMotor3D 컴포넌트를 찾지 못했습니다.");
            errors++;
        }
        else
        {
            if (motor.GetComponent<CharacterController>() == null)
            {
                Debug.LogError("[Day37] Player에 CharacterController가 없습니다.");
                errors++;
            }
            if (motor.GetComponent<Rigidbody>() != null)
            {
                Debug.LogWarning("[Day37] CharacterController 예제에는 Rigidbody를 함께 사용하지 않는 것이 권장됩니다.");
            }
            if (!motor.HasInputActions)
            {
                Debug.LogError("[Day37] Move / Jump InputActionReference를 Inspector에서 연결하세요.");
                errors++;
            }
        }
        if (cam == null)
        {
            Debug.LogError("[Day37] MainCamera 태그를 가진 Camera를 찾지 못했습니다.");
            errors++;
        }
        if (Object.FindFirstObjectByType<Collider>() == null)
        {
            Debug.LogWarning("[Day37] Ground 충돌체가 없는 것 같습니다.");
        }
        Debug.Log($"[Day37] Validator finished. Errors: {errors}. Editor 검사만 수행했으며 Play Mode 통과를 의미하지 않습니다.");
    }
}
