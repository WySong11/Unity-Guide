using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// Day 37: CharacterController 기반의 3D 이동/회전/점프 예제.
/// Input System의 Move(Vector2), Jump(Button) 액션을 Inspector에 연결하세요.
/// Rigidbody는 함께 추가하지 않습니다.
/// </summary>
[RequireComponent(typeof(CharacterController))]
public class Day37CharacterMotor3D : MonoBehaviour
{
    [Header("Input System")]
    [SerializeField] private InputActionReference moveAction;
    [SerializeField] private InputActionReference jumpAction;

    [Header("Camera")]
    [SerializeField] private Transform viewCamera;
    [SerializeField] private bool cameraRelative = true;

    [Header("Movement")]
    [Min(0f)][SerializeField] private float moveSpeed = 5f;
    [Min(0f)][SerializeField] private float rotationSpeed = 600f;
    [Min(0f)][SerializeField] private float jumpHeight = 1.5f;
    [SerializeField] private float gravity = -20f;

    private CharacterController controller;
    private float verticalSpeed;
    private Vector3 planarDirection;

    public bool HasInputActions => moveAction != null && jumpAction != null;
    public bool IsGrounded => controller != null && controller.isGrounded;
    public Vector3 PlanarDirection => planarDirection;
    public float VerticalSpeed => verticalSpeed;
    public float MoveSpeed => moveSpeed;

    private void Awake()
    {
        controller = GetComponent<CharacterController>();
        if (viewCamera == null && Camera.main != null)
            viewCamera = Camera.main.transform;
    }

    private void OnEnable()
    {
        // 본 예제는 액션을 직접 소유/활성화합니다.
        // PlayerInput이 액션을 관리하는 프로젝트라면 활성화 방식을 통일하세요.
        if (moveAction != null && moveAction.action != null)
            moveAction.action.Enable();
        if (jumpAction != null && jumpAction.action != null)
            jumpAction.action.Enable();
    }

    private void OnDisable()
    {
        if (moveAction != null && moveAction.action != null)
            moveAction.action.Disable();
        if (jumpAction != null && jumpAction.action != null)
            jumpAction.action.Disable();
    }

    private void Update()
    {
        if (Time.timeScale <= 0f) return;

        Vector2 input = Vector2.zero;
        if (moveAction != null && moveAction.action != null)
            input = moveAction.action.ReadValue<Vector2>();
        input = Vector2.ClampMagnitude(input, 1f);

        planarDirection = GetPlanarDirection(input);
        if (planarDirection.sqrMagnitude > 0.0001f)
        {
            Quaternion desiredRotation = Quaternion.LookRotation(planarDirection, Vector3.up);
            transform.rotation = Quaternion.RotateTowards(
                transform.rotation, desiredRotation, rotationSpeed * Time.deltaTime);
        }

        // isGrounded는 직전 Move에서 측정된 바닥 충돌 상태입니다.
        bool grounded = controller.isGrounded;
        if (grounded && verticalSpeed < 0f)
            verticalSpeed = -2f; // 바닥에서 미세한 부유 상태를 줄이는 유지 속도

        if (grounded && jumpAction != null && jumpAction.action != null &&
            jumpAction.action.WasPressedThisFrame())
        {
            verticalSpeed = Mathf.Sqrt(jumpHeight * -2f * gravity);
        }

        verticalSpeed += gravity * Time.deltaTime;
        Vector3 velocity = planarDirection * moveSpeed + Vector3.up * verticalSpeed;
        controller.Move(velocity * Time.deltaTime);
    }

    private Vector3 GetPlanarDirection(Vector2 input)
    {
        if (!cameraRelative || viewCamera == null)
            return Vector3.ClampMagnitude(new Vector3(input.x, 0f, input.y), 1f);

        Vector3 forward = Vector3.ProjectOnPlane(viewCamera.forward, Vector3.up);
        if (forward.sqrMagnitude < 0.0001f)
            forward = Vector3.forward;
        forward.Normalize();
        Vector3 right = new Vector3(forward.z, 0f, -forward.x);
        return Vector3.ClampMagnitude(right * input.x + forward * input.y, 1f);
    }
}
