using UnityEngine;

/// <summary>
/// Day 37: 3인칭 추적용 기초 카메라. 플레이어 회전을 따라 공전하지 않으므로
/// 카메라 상대 이동과 플레이어 회전 사이의 피드백 루프를 방지합니다.
/// </summary>
[RequireComponent(typeof(Camera))]
public class Day37ThirdPersonCamera3D : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private Vector3 worldOffset = new Vector3(0f, 5f, -7f);
    [SerializeField] private Vector3 lookAtOffset = new Vector3(0f, 1.2f, 0f);
    [Min(0.01f)][SerializeField] private float smoothTime = 0.15f;
    private Vector3 followVelocity;

    public void SetTarget(Transform newTarget) => target = newTarget;

    private void LateUpdate()
    {
        if (target == null || Time.timeScale <= 0f) return;

        Vector3 destination = target.position + worldOffset;
        transform.position = Vector3.SmoothDamp(
            transform.position, destination, ref followVelocity, smoothTime);
        Vector3 aim = target.position + lookAtOffset - transform.position;
        if (aim.sqrMagnitude > 0.0001f)
            transform.rotation = Quaternion.LookRotation(aim.normalized, Vector3.up);
    }
}
