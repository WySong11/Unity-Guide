using UnityEngine;

/// <summary>F1 키가 없어도 Inspector에서 debugOverlay를 전환할 수 있습니다.</summary>
public class Day37PlayerMovementProbe : MonoBehaviour
{
    [SerializeField] private Day37CharacterMotor3D motor;
    [SerializeField] private bool debugOverlay = true;

    private void Awake()
    {
        if (motor == null)
            motor = GetComponent<Day37CharacterMotor3D>();
    }

    private void OnGUI()
    {
        if (!debugOverlay || motor == null) return;
        GUI.Box(new Rect(12, 12, 340, 112), "Day37 · 3D 이동 진단");
        GUI.Label(new Rect(26, 42, 320, 22), $"Grounded: {motor.IsGrounded}");
        GUI.Label(new Rect(26, 65, 320, 22), $"Vertical speed: {motor.VerticalSpeed:F2}");
        GUI.Label(new Rect(26, 88, 320, 22), $"Direction: {motor.PlanarDirection}");
    }
}
