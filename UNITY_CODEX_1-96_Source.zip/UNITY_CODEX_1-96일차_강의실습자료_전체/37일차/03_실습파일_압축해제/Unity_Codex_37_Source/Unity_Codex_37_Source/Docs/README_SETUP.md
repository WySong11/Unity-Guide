# 37일차 — 3D 플레이어 이동 (Unity 6.3 / URP)

## 목적
36일차 Basic 3D Level을 기반으로 **Input System + CharacterController**를 사용해 이동, 회전, 점프, 접지 판정, 카메라 추적을 실습합니다.

## 설치 절차
1. Unity Hub에서 **Unity 6.3**으로 Universal 3D(URP) 프로젝트를 엽니다.
2. **Window > Package Manager**에서 `Input System` 패키지를 확인합니다.
3. **Edit > Project Settings > Player > Active Input Handling**이 `Input System Package (New)` 또는 `Both`인지 확인합니다. 변경 시 Editor 재시작이 필요할 수 있습니다.
4. 이 압축 파일의 Runtime `.cs`, Editor `.cs`, `Day37Gameplay.inputactions`를 `Assets/Unity_Codex/Day37/` 아래에 복사하되 **Editor 스크립트는 Editor 하위 폴더**에 둡니다.
5. 상단 **Tools > Unity Codex > Day37 > Create Movement Lab** 메뉴를 실행합니다. 변경된 현재 씬은 저장을 요청하며, 새 씬은 `Assets/Unity_Codex/Day37/Scenes/`에 충돌 없는 이름으로 생성됩니다.
6. Project 창에서 `Day37Gameplay.inputactions`를 선택하고 Move(Vector2), Jump(Button) 액션이 있는지 확인합니다.
7. Hierarchy > `Player_Day37`의 `Day37CharacterMotor3D` Inspector에서 **Move Action**에 `Day37Gameplay/Gameplay/Move`, **Jump Action**에 `Day37Gameplay/Gameplay/Jump`을 지정합니다.
8. **View Camera**에 Main Camera Transform을 지정합니다. 비워도 실행 시 Camera.main을 찾지만 명시적으로 할당하는 편이 좋습니다.
9. **Tools > Unity Codex > Day37 > Validate Movement Scene** 검사 후 ▶ Play. WASD / 방향키 이동, Space 점프, Gamepad 왼쪽 스틱·남쪽 버튼을 테스트합니다.
10. 36일차 Scene을 수정하고 싶다면 새로운 씬 생성 대신 `Day37CharacterMotor3D` 등 런타임 컴포넌트만 기존 Player에 붙여 사용할 수 있습니다.

## 핵심 Inspector 설정 (추천값)
- CharacterController: Height 2, Radius 0.45, Center (0,0,0), Step Offset 0.3, Slope Limit 45, Skin Width 0.08
- Motor: Move Speed 5, Rotation Speed 600, Jump Height 1.5, Gravity -20, Camera Relative On
- Ground: Collider 존재 / Is Trigger Off
- Player: 중심 좌표 Y = 1.05, Capsule 높이 = 2 (지면과 겹치지 않게)
- 플레이어에게 **Rigidbody를 동시에 추가하지 않습니다**. 이 예제는 CharacterController로 충돌을 처리합니다.

## 이동 방식
- W/S: 카메라의 수평 forward 방향, A/D: 수평 right 방향
- 대각선 이동을 `Vector2.ClampMagnitude`로 제한하여 속도가 증가하지 않도록 합니다.
- `CharacterController.Move`에는 `속도 × Time.deltaTime`를 전달하고, 중력은 직접 누적합니다.
- `isGrounded`는 **직전 Move 결과**로 업데이트됩니다. 경사면/계단 테스트는 별도 실행 검증이 필요합니다.
- Time.timeScale == 0일 때 모터 업데이트를 실행하지 않도록 합니다.

## 주의
- 이 스크립트는 **InputActionReference의 Enable/Disable을 직접 관리**합니다. PlayerInput 컴포넌트가 같은 액션을 관리한다면 중복 소유·상태 충돌을 피하도록 구조를 통일하세요.
- `Day37PlayerMovementProbe`의 OnGUI는 수업 진단용입니다. 출시 빌드에서는 제거하거나 비활성화하세요.
- URP/Lit Shader가 없다면 Material 생성에서 Standard Shader를 대체 사용합니다. URP 프로젝트인지 확인하십시오.
- 자동 생성은 파일 생성 및 정적 구성 확인용입니다. **실제 Unity Editor 컴파일/Play Mode 검증을 대신하지 않습니다.**
