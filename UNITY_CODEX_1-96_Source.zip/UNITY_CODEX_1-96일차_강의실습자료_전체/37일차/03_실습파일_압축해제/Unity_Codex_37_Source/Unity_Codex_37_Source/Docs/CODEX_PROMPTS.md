# Day37 — Codex 실습 프롬프트

## 프롬프트 A: 구조 확인
Unity 6.3 URP 프로젝트에서 `Day37CharacterMotor3D.cs`와 Day37 씬의 연결 상태를 분석해줘. 파일 수정 전에 Move/Jump InputActionReference, CharacterController, Main Camera, Ground Collider가 연결되었는지 확인하는 체크리스트를 작성하고, 확인하지 못한 항목은 미확인으로 표시해줘. 사용하지 않은 API는 추정하지 마.

## 프롬프트 B: 이동 오류 진단
증상: WASD를 눌러도 플레이어가 이동하지 않는다. Unity Console 로그, Player Inspector 스크린샷, Input Actions의 Move 액션 바인딩을 근거로 재현 조건과 원인 후보를 우선순위로 정리해줘. 확신할 수 없으면 설정 확인을 먼저 제안하고, 최소 수정 후 git diff로 보여줘. 기존 씬을 덮어쓰지 마.

## 프롬프트 C: 점프 오류 진단
증상: Space 키로 점프가 되지 않는다. `CharacterController.isGrounded`, Jump 액션, Ground Collider, 높이/중력 설정을 확인해줘. 원인 추정과 실제 확인 결과를 구분하고 최소 수정 패치를 제안해줘. 플레이 테스트를 실행하지 않았다면 PASS라고 쓰지 마.

## 프롬프트 D: 카메라 방향 이동 검증
현재 카메라가 월드 +X 방향을 볼 때 W 키를 누르면 플레이어가 어느 방향으로 이동해야 하는지 수식으로 설명해줘. 카메라 forward/right를 XZ 평면에 투영했는지, diagonal 입력을 정규화했는지, 회전/이동 방향이 일치하는지 검토해줘.

## 프롬프트 E: 최종 회귀 테스트
Day37 플레이어가 평지 이동, 대각선 이동, 회전, 점프, 장애물 충돌, 경사면, 일시정지·재개를 수행할 때 확인해야 할 테스트 목록을 작성해줘. 실제 수행된 검증과 미수행 검증을 구분하고, 실패 시 Console 정보/재현 단계를 포함한 보고서를 작성해줘.
