# Day37 강사용 운영안

총 120분 = 도입 10 + 핵심 개념 20 + Input/수평 이동 25 + 회전·카메라 20 + 점프·충돌 25 + Codex 점검/정리 20.

## 평가(100점)
- WASD/방향키/게임패드 입력 20
- 월드/카메라 상대 이동 및 대각선 속도 20
- 이동 방향 회전과 카메라 추적 20
- 점프·중력·접지·벽 충돌 25
- 재현/검증 기록 및 Codex 프롬프트 품질 15

## 모범 답안
1. 아니오. `CharacterController.Move()`는 입력된 motion만큼 충돌을 고려해 이동하며 중력 가속도는 직접 계산합니다.
2. Move 입력 x → X, Move 입력 y → Z, 높이 Y는 점프·중력이 담당합니다.
3. 대각선(1,1) 입력의 크기 √2를 최대 1로 제한해 동일 이동 속도를 유지하기 위해서입니다.
4. 마지막 CharacterController.Move 또는 SimpleMove 호출에서 얻은 바닥 접촉 상태입니다.
5. Input을 읽고 `Time.deltaTime`을 곱하는 `Update()`입니다. Rigidbody 물리 힘 변경과 구분합니다.

## 안전한 수업 운영
- 바인딩이 연결되지 않으면 입력이 없거나 점프가 발생하지 않습니다. Inspector 참조를 먼저 확인합니다.
- 수강생의 기존 게임 씬은 별도로 저장하고 Day37 독립 씬에서 테스트합니다.
- 결과를 설명할 때 자동 검증/직접 실행 검증을 구분합니다.

## 참고 공식 문서
- https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/charactercontroller/move
- https://docs.unity3d.com/kr/6000.0/ScriptReference/CharacterController-isGrounded.html
- https://learn.unity.com/course/input-system-video-series/unity-version?version=6.3
