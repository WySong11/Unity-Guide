using UnityEngine;

/// <summary>파티클 종료 콜백으로 자신을 풀에 반환합니다.</summary>
[RequireComponent(typeof(ParticleSystem))]
public class PooledParticleEffect2D : MonoBehaviour
{
    private ParticleSystem particle;
    private Day29ParticleEffectPool2D owner;
    private bool isInUse;

    private void Awake()
    {
        particle = GetComponent<ParticleSystem>();
        var main = particle.main;
        main.loop = false;
        main.stopAction = ParticleSystemStopAction.Callback;
    }

    public void Bind(Day29ParticleEffectPool2D pool) => owner = pool;

    public void PlayAt(Vector3 position)
    {
        transform.position = position;
        isInUse = true;
        particle.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
        particle.Clear(true);
        particle.Play(true);
    }

    private void OnParticleSystemStopped()
    {
        if (!isInUse) return; // 중복 반환 방지
        isInUse = false;
        if (owner != null) owner.Return(this);
    }
}
