using UnityEngine;

/// <summary>
/// 기존 Attack/Hit/Die/Collect 이벤트가 이 메서드를 호출하도록 연결하세요.
/// 실제 전투 로직이나 HP 계산은 여기서 처리하지 않습니다.
/// </summary>
public class Day29CombatFxBridge2D : MonoBehaviour
{
    [SerializeField] private Day29AudioManager audioManager;
    [SerializeField] private Day29ParticleEffectPool2D hitEffectPool;
    [SerializeField] private Day29ParticleEffectPool2D deathEffectPool;

    public void OnAttack()
    {
        audioManager?.PlaySfx(Day29AudioManager.Cue.Attack);
    }

    public void OnHit(Vector3 hitPoint)
    {
        audioManager?.PlaySfx(Day29AudioManager.Cue.Hit);
        hitEffectPool?.TryPlay(hitPoint);
    }

    public void OnDeath(Vector3 deathPoint)
    {
        audioManager?.PlaySfx(Day29AudioManager.Cue.Death);
        deathEffectPool?.TryPlay(deathPoint);
    }

    public void OnCollect()
    {
        audioManager?.PlaySfx(Day29AudioManager.Cue.Collect);
    }
}
