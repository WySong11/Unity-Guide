using UnityEngine;

/// <summary>
/// 29일차: 효과음·UI 사운드·BGM을 분리하는 기초 오디오 관리자.
/// </summary>
public class Day29AudioManager : MonoBehaviour
{
    public enum Cue { Attack, Hit, Death, Collect }

    [Header("Sources (different AudioSource components)")]
    [SerializeField] private AudioSource sfxSource;
    [SerializeField] private AudioSource uiSource;
    [SerializeField] private AudioSource bgmSource;

    [Header("Audio Clips")]
    [SerializeField] private AudioClip attackClip;
    [SerializeField] private AudioClip hitClip;
    [SerializeField] private AudioClip deathClip;
    [SerializeField] private AudioClip collectClip;
    [SerializeField] private AudioClip clickClip;
    [SerializeField] private AudioClip bgmClip;

    private void Awake()
    {
        if (sfxSource == null || uiSource == null)
            Debug.LogWarning("[Day29Audio] SFX/UI AudioSource를 Inspector에 연결하세요.", this);

        if (sfxSource != null)
        {
            sfxSource.playOnAwake = false;
            sfxSource.spatialBlend = 0f; // UI와 가까운 2D 효과음
        }

        if (uiSource != null)
        {
            uiSource.playOnAwake = false;
            uiSource.spatialBlend = 0f;
            uiSource.ignoreListenerPause = true; // 일시정지 메뉴 클릭음 허용
        }

        if (bgmSource != null)
        {
            bgmSource.loop = true;
            bgmSource.spatialBlend = 0f;
            bgmSource.playOnAwake = false;
        }
    }

    public void PlaySfx(Cue cue, float volume = 1f)
    {
        if (sfxSource == null || AudioListener.pause) return;

        AudioClip clip = cue switch
        {
            Cue.Attack => attackClip,
            Cue.Hit => hitClip,
            Cue.Death => deathClip,
            Cue.Collect => collectClip,
            _ => null
        };
        if (clip != null)
            sfxSource.PlayOneShot(clip, Mathf.Clamp01(volume));
    }

    public void PlayUiClick()
    {
        if (uiSource != null && clickClip != null)
            uiSource.PlayOneShot(clickClip);
    }

    public void PlayBgm()
    {
        if (bgmSource == null || bgmClip == null) return;
        bgmSource.clip = bgmClip;
        if (!bgmSource.isPlaying) bgmSource.Play();
    }

    public void StopBgm()
    {
        if (bgmSource != null) bgmSource.Stop();
    }

    /// <summary>
    /// 28일차 GameFlowController의 Pause/Resume 진입점에서 호출.
    /// Time.timeScale = 0만으로 오디오 전체가 멈추는 것은 아닙니다.
    /// </summary>
    public void SetPaused(bool paused)
    {
        AudioListener.pause = paused;
    }
}
