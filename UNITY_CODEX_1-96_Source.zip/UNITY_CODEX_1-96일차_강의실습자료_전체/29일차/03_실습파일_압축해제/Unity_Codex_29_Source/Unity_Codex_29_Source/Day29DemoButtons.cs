using UnityEngine;

/// <summary>UI Button OnClick()과 Inspector에서 연결하는 수업용 테스트.</summary>
public class Day29DemoButtons : MonoBehaviour
{
    [SerializeField] private Day29CombatFxBridge2D combatFx;
    [SerializeField] private Day29AudioManager audioManager;
    [SerializeField] private Transform effectSpawnPoint;
    private bool paused;

    private Vector3 EffectPoint => effectSpawnPoint != null
        ? effectSpawnPoint.position : transform.position;

    public void TestAttack() => combatFx?.OnAttack();
    public void TestHit() => combatFx?.OnHit(EffectPoint);
    public void TestDeath() => combatFx?.OnDeath(EffectPoint);
    public void TestCollect() => combatFx?.OnCollect();
    public void TestUiClick() => audioManager?.PlayUiClick();

    public void TogglePauseForDemo()
    {
        paused = !paused;
        Time.timeScale = paused ? 0f : 1f;
        audioManager?.SetPaused(paused);
    }

    private void OnDisable()
    {
        // 실습 오브젝트가 꺼져도 다음 테스트가 정지 상태로 시작하지 않도록 복원.
        if (!paused) return;
        paused = false;
        Time.timeScale = 1f;
        if (audioManager != null) audioManager.SetPaused(false);
    }
}
