using System.Collections.Generic;
using UnityEngine;

/// <summary>24일차 Object Pool 복습: Queue를 활용한 간단한 파티클 풀.</summary>
public class Day29ParticleEffectPool2D : MonoBehaviour
{
    [SerializeField] private PooledParticleEffect2D effectPrefab;
    [SerializeField, Min(0)] private int preloadCount = 8;
    [SerializeField, Min(1)] private int maxCount = 24;

    private readonly Queue<PooledParticleEffect2D> available = new();
    private readonly HashSet<PooledParticleEffect2D> active = new();
    private int createdCount;

    private void Awake()
    {
        if (effectPrefab == null)
        {
            Debug.LogError("[Day29EffectPool] effectPrefab 연결 필요", this);
            enabled = false;
            return;
        }

        for (int i = 0; i < Mathf.Min(preloadCount, maxCount); i++)
            available.Enqueue(CreateOne()); // 미리 생성만 하고 활성화하지 않음
    }

    private PooledParticleEffect2D CreateOne()
    {
        var fx = Instantiate(effectPrefab, transform);
        fx.Bind(this);
        fx.gameObject.SetActive(false);
        createdCount++;
        return fx;
    }

    public bool TryPlay(Vector3 position)
    {
        if (effectPrefab == null || !enabled) return false;
        PooledParticleEffect2D fx;

        if (available.Count > 0) fx = available.Dequeue();
        else if (createdCount < maxCount) fx = CreateOne();
        else return false; // 무한 Instantiate 방지

        active.Add(fx);
        fx.gameObject.SetActive(true);
        fx.PlayAt(position);
        return true;
    }

    public void Return(PooledParticleEffect2D fx)
    {
        if (fx == null || !active.Remove(fx)) return;
        fx.gameObject.SetActive(false);
        available.Enqueue(fx);
    }

    public int CreatedCount => createdCount;
    public int AvailableCount => available.Count;
    public int ActiveCount => active.Count;
}
