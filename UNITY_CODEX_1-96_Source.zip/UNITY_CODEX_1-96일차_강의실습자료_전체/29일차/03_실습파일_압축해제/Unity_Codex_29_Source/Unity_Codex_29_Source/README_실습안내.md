# Unity × Codex — 29일차 효과음과 이펙트 실습

- Unity 기준: Unity 6 (6000.x / 강의자료 표기 Unity 6.3)
- 렌더 파이프라인: URP 2D 예제 기준이지만 기본 Particle System은 다른 파이프라인에서도 사용 가능
- 별도 외부 패키지 없이 동작하는 uGUI Button 연결 방식

## 파일 구성
- `Day29AudioManager.cs` — SFX / UI 클릭 / BGM 분리와 `AudioListener.pause` 연동
- `PooledParticleEffect2D.cs` — 재생 시작과 `OnParticleSystemStopped()` 반납
- `Day29ParticleEffectPool2D.cs` — 미리 생성(Prewarm), Get/Return, 수량 제한
- `Day29CombatFxBridge2D.cs` — 기존 게임 이벤트와 사운드/파티클 연결
- `Day29DemoButtons.cs` — 공격·피격·사망·획득·UI·일시정지 테스트

## Scene과 Inspector 연결
1. 빈 GameObject `Day29Systems`를 만들고 `Day29AudioManager`, `Day29CombatFxBridge2D`, `Day29DemoButtons`를 부착합니다.
2. 다른 AudioSource 3개를 준비합니다: `SfxSource`, `UiSource`, `BgmSource`. `Play On Awake` 해제; SFX/UI는 Spatial Blend 0, BGM은 Loop 켬. 각각 `Day29AudioManager` 슬롯에 연결합니다.
3. 공격·피격·사망·획득·클릭 AudioClip을 AudioManager에 연결합니다. 저작권을 확인한 샘플을 사용하세요.
4. `GameObject > Effects > Particle System`으로 파티클을 만들고 루프 해제, 0.4~0.8초 정도의 짧은 지속 시간, Shape/Emission/Color over Lifetime 등을 조정합니다. Prefab으로 저장하고 `PooledParticleEffect2D`를 추가합니다.
5. `HitFxPool` 및 `DeathFxPool` 빈 오브젝트 각각에 `Day29ParticleEffectPool2D`를 추가한 후 해당 이펙트 Prefab을 연결합니다. 기본 Preload 8 / Max 24.
6. `Day29CombatFxBridge2D`의 audioManager, hitEffectPool, deathEffectPool을 연결합니다.
7. Canvas 아래 버튼 6개를 만들고 `Day29DemoButtons`의 `TestAttack`, `TestHit`, `TestDeath`, `TestCollect`, `TestUiClick`, `TogglePauseForDemo`를 연결합니다.
8. `Day29DemoButtons`에 `combatFx`, `audioManager`, `effectSpawnPoint`를 연결합니다. 2D 카메라 앞에서 잘 보이는 위치에 SpawnPoint를 둡니다.

## 28일차와 연동할 때
- 28일차 GameFlowController가 이미 `Time.timeScale`을 관리한다면 `Day29DemoButtons.TogglePauseForDemo`는 테스트에서만 사용하세요.
- 실제 Pause/Resume 이벤트에서는 `Day29AudioManager.SetPaused(true/false)`만 추가로 호출하고, timeScale 중복 제어는 하지 않습니다.
- UI 사운드를 일시정지 중에도 재생하려면 `UiSource`는 `SfxSource`와 **다른 컴포넌트**여야 합니다. `ignoreListenerPause`는 코드로 설정합니다.
- 씬 종료/재시작 전 `Time.timeScale=1`과 `AudioListener.pause=false`를 복원하세요.

## 테스트 체크리스트
- [ ] 버튼 눌렀을 때 올바른 AudioClip만 들린다.
- [ ] SFX가 연속 재생되어도 앞의 소리가 불필요하게 끊기지 않는다.
- [ ] 피격 이펙트가 지정한 위치에 나타난다.
- [ ] 최초 Play 시 기본 8개가 비활성 상태로 미리 생성된다.
- [ ] 파티클 종료 후 `AvailableCount`가 다시 증가한다.
- [ ] 일시정지 시 일반 SFX/BGM은 멈추고 UI 클릭음은 들린다.
- [ ] 재개 시 음성과 시간이 함께 복원된다.
- [ ] 최대 수량에 도달하면 인스턴스가 무한정 생성되지 않는다.

## 자주 묻는 문제
- **파티클이 재생되지 않음:** Prefab 연결, Prefab 오브젝트의 ParticleSystem 존재 여부, Game view 카메라/Sort Layer, UI 위치를 확인하세요.
- **풀이 미리 생성되지 않음:** 풀 GameObject 활성 여부, Awake 실행, effectPrefab 지정, Preload 값과 Max 값을 확인하세요.
- **UI 클릭음까지 멈춤:** `uiSource`를 별도로 연결하고 `ignoreListenerPause=true`인지 확인하세요.
- **Loop가 켜져 파티클이 돌아오지 않음:** `main.loop=false` 및 `main.stopAction=Callback`이 필요합니다.
- **일시정지 후 사운드가 영원히 멈춤:** Resume/씬 전환에서 `AudioListener.pause=false`인지 확인하세요.

## 학습 범위와 주의
- 소스는 2D uGUI 학습 예제이며 3D 위치 음향은 Spatial Blend, 거리 감쇠 등을 추가로 설계해야 합니다.
- Script 클래스명과 파일명은 반드시 동일하게 유지하세요.
- 소스는 정적 리뷰를 바탕으로 작성했으며 Unity Editor에서 자동 컴파일/실행 검증을 수행한 것은 아닙니다.

## API 참조 (Unity 공식 문서)
- https://docs.unity3d.com/6000.0/Documentation/ScriptReference/AudioSource.PlayOneShot.html
- https://docs.unity3d.com/6000.0/Documentation/ScriptReference/AudioListener-pause.html
- https://docs.unity3d.com/6000.0/Documentation/ScriptReference/AudioSource-ignoreListenerPause.html
- https://docs.unity3d.com/6000.0/Documentation/ScriptReference/MonoBehaviour.OnParticleSystemStopped.html
- https://docs.unity3d.com/6000.0/Documentation/ScriptReference/ParticleSystem.MainModule-stopAction.html
