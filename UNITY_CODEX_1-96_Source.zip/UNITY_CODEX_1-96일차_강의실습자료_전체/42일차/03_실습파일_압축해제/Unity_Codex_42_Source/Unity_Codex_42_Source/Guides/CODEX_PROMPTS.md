# Codex 프롬프트 — 42일차

## A. 구현 프롬프트

Unity 6.3 URP 프로젝트입니다. 기존 38일차 Orbit Camera, 40일차 Character Motor, 41일차 공격 모듈의 책임을 유지해 주세요. 먼저 코드·씬·Input Actions·프리팹 구조를 **읽기 전용으로 조사**하고 현재 구조와 충돌 가능성을 보고하세요.

그 후 다음 기능을 **독립 컴포넌트**로 추가해 주세요.
1. 카메라 중앙 Raycast → Aim Point → Muzzle 2차 Raycast, 명중 거리 및 LayerMask 필터
2. Rigidbody Projectile, 충돌 시 IDay42Damageable, 수명 종료 시 반환
3. ObjectPool 사전 생성(최초 N개 동시 Get, 모두 Release), 중복 반환 방지, 속도/Owner 충돌 상태 초기화
4. 마우스 왼쪽 Raycast·오른쪽 Projectile. 기존 입력과 중복 구독 금지
5. 테스트 씬은 기존 씬을 덮어쓰지 않는 새로운 경로에 생성

코드를 변경하기 전에 수정 대상 파일, 새 파일 목록, 실행 테스트 계획을 보여 주세요. 수정 후에는 실제로 수행한 컴파일/Play Mode 테스트와 미수행 항목을 분리해 알려 주세요.

## B. 오류 재현·수정 프롬프트

현상: [재현된 증상]
Unity 버전: 6000.3.x / 플랫폼: Editor Windows
재현 절차: [카메라 좌표 / Muzzle 좌표 / LayerMask / 입력 순서 / FPS]
기대 결과: [예: 엄폐물 Wall이 먼저 명중하여 타깃 HP 유지]
실제 결과: [예: 타깃 HP 감소]
Console 및 Stack Trace: [로그]

Camera Ray, Muzzle Ray, Physics.Raycast, Rigidbody ContinuousDynamic, Collider.IsTrigger, ObjectPool Release, Physics.IgnoreCollision 순서로 원인을 조사해 주세요. 원인이 입증된 최소 범위만 수정하고, R01~R06·A01~A06·P01~P06 회귀 테스트를 보고하세요. 실행하지 못한 검증을 성공했다고 작성하지 마세요.

## C. 최종 검증 프롬프트

Day42 실습 프로젝트의 코드/Inspector 연결/씬/Prefab/Input System 설정을 점검해 주세요. Console 컴파일 오류, 빈 Camera/Muzzle 참조, Target+Wall LayerMask, Prewarm 12, 중복 Release, 미명중 수명 만료, Owner 자기 충돌, Pause 차단을 검사합니다. 가능한 자동 검증은 실행하고, Play Mode에서만 확인 가능한 항목은 수동 테스트 단계로 분리해 표를 만드세요. 변경 내용은 git diff로 요약하세요.
