# 42일차 학생 워크시트 — Raycast와 Projectile

**학습 시간: 120분** / Unity 6.3 URP / Input System

## 도입(10분)
- [ ] 41일차 즉시 사격과 발사체의 차이를 2문장으로 설명할 수 있다.
- [ ] Raycast와 Projectile에서 충돌 판정이 발생하는 시점을 구분한다.

## 개념(20분)
1. `Physics.Raycast()`의 다섯 가지 핵심 인수는 무엇인가요?
2. `RaycastHit.point`와 `RaycastHit.normal`의 차이는 무엇인가요?
3. 카메라가 타깃을 볼 수 있지만 총구 앞에 벽이 있는 경우, 타깃이 맞으면 안 되는 이유는 무엇인가요?
4. `Rigidbody.linearVelocity`를 풀 재사용마다 초기화해야 하는 이유를 설명하세요.

## 실습 A(25분): Raycast
- [ ] Camera 중앙 Ray를 생성한다.
- [ ] LayerMask에 Target과 Wall이 포함되도록 설정한다.
- [ ] 마우스 왼쪽 클릭 → 타깃 HP 100→80 확인한다.
- [ ] 카메라와 Muzzle을 다른 위치에 놓고 총구 벽 차폐를 재현한다.

## 실습 B(25분): Projectile
- [ ] Sphere Prefab에 Rigidbody / SphereCollider / Projectile을 추가한다.
- [ ] 마우스 오른쪽 클릭 → 발사체가 이동하는지 확인한다.
- [ ] 충돌 시 HP 100→85, 미명중 3초 후 자동 반환을 확인한다.
- [ ] 속도를 25→80으로 변경하여 Discrete/ContinuousDynamic 비교한다.

## 실습 C(20분): Object Pool과 디버깅
- [ ] Prewarm 12개가 생성되어 있는지 확인한다.
- [ ] 충돌과 수명 만료가 겹쳐도 반환이 한 번만 일어나는지 확인한다.
- [ ] 발사체 반환 후 다시 꺼냈을 때 속도·Owner IgnoreCollision이 복원되는지 확인한다.
- [ ] `TEST_CHECKLIST.csv` 기록을 작성한다.

## 제출
- 씬·스크립트·Prefab 또는 씬 빌더 코드
- 캡처 4장 이상 / 문제 재현 절차 / Codex 수정 프롬프트 / diff

### 확장 문제
- RaycastHit.normal을 이용해 피격 이펙트를 표면 방향으로 회전시키기
- 아군/적군 팀 분리 및 아군 오사 방지
- 실제 발사체 이동 간 Sweep 테스트로 고속 관통 보완
