# Unity × Codex 42일차 — Raycast와 Projectile

- **대상 버전:** Unity 6.3 (6000.3), Universal 3D/URP
- **필수 패키지:** Input System (com.unity.inputsystem)
- **학습 시간:** 120분
- **실습 프로젝트:** 41일차 전투 시스템과 독립적으로 먼저 검증한 후 통합

## 1. 설치

1. Unity Hub에서 기존 Unity 6.3 URP 프로젝트를 실행합니다.
2. `Window > Package Manager`에서 **Input System** 패키지를 확인합니다.
3. Project Settings > Player > Active Input Handling을 `Input System Package` 또는 `Both`로 설정한 후 에디터를 재시작합니다(변경을 요구하는 경우).
4. 이 압축 파일의 `Runtime/*.cs`를 `Assets/Day42/Scripts`에 복사합니다.
5. `Editor/*.cs`는 **반드시** `Assets/Day42/Editor`에 복사합니다. Editor 스크립트는 빌드에 포함되지 않아야 합니다.
6. Unity Console에서 C# 컴파일 오류가 없는지 확인합니다.

## 2. 씬 자동 생성

1. **Tools > Unity Codex > Day42 > Create Raycast Projectile Scene**를 실행합니다.
2. 저장하지 않은 씬이 있으면 Unity의 저장 확인창에 응답합니다.
3. 새로운 씬과 Projectile Prefab이 `Assets/Day42_Demo/`에 **고유 파일명**으로 생성됩니다.
4. 자동 생성된 `Day42_CombatLab` 씬을 열고 Hierarchy에서 Player_Root, Main Camera, Target_1~3, Wall_Cover, Projectile Pool을 확인합니다.
5. `Tools > Unity Codex > Day42 > Validate Current Scene`를 실행합니다.

## 3. 실행 및 조작

- **마우스 왼쪽 클릭:** 화면 중앙 기반 Raycast 사격 (기본 20 HP 데미지)
- **마우스 오른쪽 클릭:** Rigidbody Projectile 발사 (기본 15 HP 데미지)
- Scene View에서 **Gizmos**를 활성화한 상태로 Play Mode를 테스트합니다.
- Target은 초기 HP 100이며 Inspector 우클릭 **Reset Health** 메뉴로 초기화할 수 있습니다.

## 4. 구조 설명

- **Day42AimUtility:** Camera.ViewportPointToRay를 통해 화면 중앙 조준점 생성
- **Day42RaycastWeapon:** 카메라 조준점 → 총구 2차 Raycast → 첫 충돌 대상으로 데미지
- **Day42ProjectileWeapon:** 총구에서 발사체 대여 → velocity 설정
- **Day42Projectile:** Rigidbody 이동 → 충돌/수명 처리 → 풀 반환
- **Day42ProjectilePool:** `UnityEngine.Pool.ObjectPool<T>` 기반 사전 생성/반환
- **Day42TargetHealth:** IDay42Damageable 구현, HP 감소
- **Day42DemoInput:** Input System 마우스 테스트 전용
- **Day42SceneBuilderEditor:** 독립 실습 씬과 Projectile Prefab 생성

## 5. Inspector 필수 연결

씬 자동 생성 시 스크립트 간 참조는 자동 연결됩니다. 기존 41일차 씬에 추가한다면 아래 항목을 수동 연결하세요.

| Component | 항목 | 연결 대상 |
|---|---|---|
| Day42RaycastWeapon | Aim Camera | 3인칭 카메라 |
| Day42RaycastWeapon | Muzzle | 플레이어 자식 총구 Transform |
| Day42RaycastWeapon | Hit Mask | Wall + Target 포함, Player 제외 |
| Day42ProjectileWeapon | Projectile Pool | Day42ProjectilePool |
| Day42ProjectilePool | Prefab | Rigidbody + Collider + Day42Projectile |
| Day42DemoInput | Weapons | Raycast / Projectile Weapon |

**중요:** 41일차 공격 입력 컴포넌트와 Day42DemoInput을 동시에 활성화하면 마우스 클릭의 다중 처리 문제가 발생할 수 있습니다. 통합 시 입력 진입점은 하나만 남깁니다.

## 6. Raycast와 Projectile 동작상의 차이

- **Raycast:** 발사 순간의 광선과 처음 충돌한 Collider로 피해를 계산합니다. 광선은 물리 탄체가 아닙니다.
- **Projectile:** 씬에 탄체가 존재하고 Rigidbody 물리 업데이트에 따라 움직입니다. 탄속, 충돌 모드, 중력, 장애물, 수명이 영향을 줍니다.
- **Camera / Muzzle:** 카메라에서 계산한 Aim Point까지 총구 기준으로 2차 Raycast해 가까운 벽 관통을 방지합니다.
- **Owner 충돌:** 실습 코드는 발사자 Collider를 Physics.IgnoreCollision으로 일시 무시하고, 풀 반환 시 복원합니다.
- **Prewarm:** N개를 동시에 Get한 뒤 Release해야 N개 객체가 실제로 만들어집니다.
- **Pool maxSize 주의:** `ObjectPool<T>`의 `maxSize`는 **풀에 보관하는 비활성 객체의 최대 수**이며 모든 동시 활성 인스턴스의 강제 상한은 아닙니다.

## 7. 알려진 전제와 확장

- 예제는 학습용 3D Physics를 가정합니다. **2D Physics와 호환되지 않습니다.**
- Projectile Collider는 일반 충돌을 기본으로 합니다. `Is Trigger`를 선택하면 OnTriggerEnter로 처리합니다.
- 아주 빠른 탄이나 매우 얇은 Collider는 CCD를 사용해도 충돌이 누락될 수 있습니다. 필요하면 이전 위치→현재 위치 Raycast 또는 SphereCast로 보강하세요.
- 실제 게임에서는 일시정지, UI 포인터 입력, 타깃 팀·아군 오사, 네트워크 권한, 발사 이펙트 처리를 별도 연동해야 합니다.
- Unity Editor 실행 및 게임 플레이 검증은 **사전에 수행되었다고 주장하지 않습니다.** 수업 시간에 실제 환경에서 검증해야 합니다.

## 8. 추천 제출물

1. 실행 씬 또는 씬 자동 생성 코드, 모든 C# 소스
2. Raycast HP 100→80, Projectile HP 100→85 화면 캡처
3. Wall 차폐 비교, Prewarm=12, 3초 Timeout 화면 캡처
4. `TEST_CHECKLIST.csv`의 Pass/Fail 기록
5. Codex 프롬프트·분석 결과와 `git diff` (수정했다면)

## 9. 공식 API 참고

- Physics.Raycast: https://docs.unity.com/en-us/engine/6000.3/script-reference/unityengine/physics/raycast
- UnityEngine.Pool.ObjectPool<T>.Get: https://docs.unity.com/en-us/engine/6000.3/script-reference/unityengine/pool/objectpool1/get
- Rigidbody.collisionDetectionMode: https://docs.unity3d.com/ScriptReference/Rigidbody-collisionDetectionMode.html
