#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class Day42SceneBuilderEditor
{
    private const string Folder = "Assets/Day42_Demo";

    [MenuItem("Tools/Unity Codex/Day42/Create Raycast Projectile Scene")]
    public static void Build()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        if (!AssetDatabase.IsValidFolder(Folder))
            AssetDatabase.CreateFolder("Assets", "Day42_Demo");
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        MakeCube("Ground", new Vector3(0f,-0.5f,8f), new Vector3(18f,1f,35f));
        MakeCube("Wall_Cover", new Vector3(1.2f,1.25f,7f), new Vector3(2f,2.5f,0.8f));

        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Player_Root";
        player.transform.position = new Vector3(0f,1f,0f);
        player.layer = 2; // Ignore Raycast
        GameObject muzzle = new GameObject("Muzzle");
        muzzle.transform.SetParent(player.transform, false);
        muzzle.transform.localPosition = new Vector3(0.35f,0.4f,1.0f);

        GameObject cameraGO = new GameObject("Main Camera");
        cameraGO.tag = "MainCamera";
        Camera camera = cameraGO.AddComponent<Camera>();
        cameraGO.AddComponent<AudioListener>();
        cameraGO.transform.position = new Vector3(0f,2.5f,-5f);
        cameraGO.transform.LookAt(new Vector3(0f,1f,11f));
        GameObject sun = new GameObject("Directional Light");
        Light light = sun.AddComponent<Light>();
        light.type = LightType.Directional;
        sun.transform.rotation = Quaternion.Euler(45f,-30f,0f);

        for (int i=0; i<3; i++)
        {
            GameObject dummy=GameObject.CreatePrimitive(PrimitiveType.Cube);
            dummy.name=$"Target_{i+1}";
            dummy.transform.position=new Vector3((i-1)*3f,1f,13f);
            dummy.transform.localScale=new Vector3(1.2f,2f,1f);
            dummy.AddComponent<Day42TargetHealth>();
        }
        string prefabPath = AssetDatabase.GenerateUniqueAssetPath(Folder + "/Day42_Projectile.prefab");
        GameObject temp = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        temp.name = "Day42_Projectile";
        temp.transform.localScale = Vector3.one*0.3f;
        Rigidbody rb = temp.AddComponent<Rigidbody>();
        rb.useGravity = false;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        temp.AddComponent<Day42Projectile>();
        GameObject prefab = PrefabUtility.SaveAsPrefabAsset(temp,prefabPath);
        Object.DestroyImmediate(temp);

        GameObject poolGO = new GameObject("Projectile Pool");
        Day42ProjectilePool pool = poolGO.AddComponent<Day42ProjectilePool>();
        SetObject(pool,"prefab",prefab.GetComponent<Day42Projectile>());
        Day42RaycastWeapon hitscan = player.AddComponent<Day42RaycastWeapon>();
        SetObject(hitscan,"aimCamera",camera); SetObject(hitscan,"muzzle",muzzle.transform);
        Day42ProjectileWeapon launcher = player.AddComponent<Day42ProjectileWeapon>();
        SetObject(launcher,"aimCamera",camera); SetObject(launcher,"muzzle",muzzle.transform);
        SetObject(launcher,"projectilePool",pool);
        Day42DemoInput controls = player.AddComponent<Day42DemoInput>();
        SetObject(controls,"raycastWeapon",hitscan);
        SetObject(controls,"projectileWeapon",launcher);

        string scenePath=AssetDatabase.GenerateUniqueAssetPath(Folder+"/Day42_CombatLab.unity");
        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene, scenePath);
        AssetDatabase.SaveAssets();
        Debug.Log("[Day42] 생성 완료: "+scenePath+" (마우스 왼쪽 Raycast, 오른쪽 Projectile)");
    }

    private static GameObject MakeCube(string name,Vector3 pos,Vector3 scale)
    {
        GameObject go=GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name=name; go.transform.position=pos; go.transform.localScale=scale;
        return go;
    }

    private static void SetObject(Object target,string propertyName,Object value)
    {
        SerializedObject so=new SerializedObject(target);
        SerializedProperty prop=so.FindProperty(propertyName);
        if (prop!=null) {prop.objectReferenceValue=value; so.ApplyModifiedPropertiesWithoutUndo();}
    }
}
#endif
