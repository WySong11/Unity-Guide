#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

public static class Day42SceneValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day42/Validate Current Scene")]
    private static void Validate()
    {
        var camera=Camera.main;
        var gun=Object.FindFirstObjectByType<Day42RaycastWeapon>();
        var launcher=Object.FindFirstObjectByType<Day42ProjectileWeapon>();
        var pool=Object.FindFirstObjectByType<Day42ProjectilePool>();
        var input=Object.FindFirstObjectByType<Day42DemoInput>();
        var targets=Object.FindObjectsByType<Day42TargetHealth>(FindObjectsSortMode.None);
        Debug.Log($"[Day42 검사] Camera={camera!=null}, RaycastWeapon={gun!=null}, " +
                  $"ProjectileWeapon={launcher!=null}, Pool={pool!=null}, " +
                  $"Input={input!=null}, Targets={targets.Length}. " +
                  "Inspector의 참조와 HitMask/Trigger 상태는 수동 확인하세요.");
    }
}
#endif
