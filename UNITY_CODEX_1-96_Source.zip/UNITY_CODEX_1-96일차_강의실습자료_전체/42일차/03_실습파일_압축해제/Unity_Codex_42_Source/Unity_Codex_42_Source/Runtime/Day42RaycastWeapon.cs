using UnityEngine;

public class Day42RaycastWeapon : MonoBehaviour
{
    [SerializeField] private Camera aimCamera;
    [SerializeField] private Transform muzzle;
    [SerializeField] private LayerMask hitMask = ~0;
    [SerializeField, Min(1f)] private float range = 60f;
    [SerializeField, Min(1)] private int damage = 20;
    [SerializeField, Min(0.01f)] private float fireInterval = 0.2f;
    private float nextFireTime;

    public bool TryFire()
    {
        if (Time.timeScale == 0f || Time.time < nextFireTime ||
            aimCamera == null || muzzle == null) return false;
        nextFireTime = Time.time + fireInterval;

        Vector3 aimPoint = Day42AimUtility.GetAimPoint(aimCamera, range, hitMask);
        Vector3 delta = aimPoint - muzzle.position;
        if (delta.sqrMagnitude < 0.0001f) return false;
        Vector3 direction = delta.normalized;
        // 총구부터 별도 Ray를 발사하여 가까운 벽 관통을 방지
        float distance = Mathf.Min(range, delta.magnitude);
        bool hitSomething = Physics.Raycast(muzzle.position, direction,
            out RaycastHit hit, distance, hitMask, QueryTriggerInteraction.Ignore);
        Vector3 end = hitSomething ? hit.point : muzzle.position + direction * distance;
        Debug.DrawLine(muzzle.position, end, hitSomething ? Color.red : Color.cyan, 1.5f);
        if (hitSomething)
        {
            IDay42Damageable target = Day42DamageLookup.Find(hit.collider);
            target?.TakeDamage(damage, gameObject, hit.point);
            Debug.Log($"[Day42 Raycast] {hit.collider.name}, distance={hit.distance:F1}", this);
        }
        return true;
    }
}
