using UnityEngine;
using UnityEngine.InputSystem;

// Input System 패키지 사용. 마우스 왼쪽=Raycast, 오른쪽=Projectile
public class Day42DemoInput : MonoBehaviour
{
    [SerializeField] private Day42RaycastWeapon raycastWeapon;
    [SerializeField] private Day42ProjectileWeapon projectileWeapon;

    private void Update()
    {
        if (Time.timeScale == 0f || Mouse.current == null) return;
        if (Mouse.current.leftButton.wasPressedThisFrame) raycastWeapon?.TryFire();
        if (Mouse.current.rightButton.wasPressedThisFrame) projectileWeapon?.TryFire();
    }
}
