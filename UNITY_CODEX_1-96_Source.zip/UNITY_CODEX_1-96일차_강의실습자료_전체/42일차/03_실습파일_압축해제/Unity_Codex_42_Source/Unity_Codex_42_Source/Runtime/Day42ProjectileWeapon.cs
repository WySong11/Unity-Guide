using UnityEngine;

public class Day42ProjectileWeapon : MonoBehaviour
{
    [SerializeField] private Camera aimCamera;
    [SerializeField] private Transform muzzle;
    [SerializeField] private Day42ProjectilePool projectilePool;
    [SerializeField] private LayerMask hitMask = ~0;
    [SerializeField, Min(1f)] private float range = 60f;
    [SerializeField, Min(1f)] private float projectileSpeed = 25f;
    [SerializeField, Min(1)] private int damage = 15;
    [SerializeField, Min(0.01f)] private float fireInterval = 0.35f;
    private float nextFireTime;

    public bool TryFire()
    {
        if (Time.timeScale == 0f || Time.time < nextFireTime ||
            aimCamera == null || muzzle == null || projectilePool == null) return false;
        Vector3 point = Day42AimUtility.GetAimPoint(aimCamera, range, hitMask);
        Vector3 delta = point - muzzle.position;
        if (delta.sqrMagnitude < 0.0001f) return false;
        Day42Projectile projectile = projectilePool.Rent();
        if (projectile == null) return false;
        nextFireTime = Time.time + fireInterval;
        projectile.Launch(muzzle.position, delta.normalized, projectileSpeed,
            damage, gameObject);
        return true;
    }
}
