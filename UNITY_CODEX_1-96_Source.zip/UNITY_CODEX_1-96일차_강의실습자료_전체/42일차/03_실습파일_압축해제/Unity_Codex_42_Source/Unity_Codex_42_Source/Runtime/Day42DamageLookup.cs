using UnityEngine;

public static class Day42DamageLookup
{
    public static IDay42Damageable Find(Collider collider)
    {
        if (collider == null) return null;
        // 인터페이스 구현이 자식 Collider가 아닌 부모에 있어도 검색
        var components = collider.GetComponentsInParent<MonoBehaviour>(true);
        foreach (MonoBehaviour component in components)
        {
            if (component is IDay42Damageable target) return target;
        }
        return null;
    }
}
