using UnityEngine;

public static class Day42AimUtility
{
    public static Vector3 GetAimPoint(Camera camera, float range, LayerMask mask)
    {
        if (camera == null) return Vector3.zero;
        Ray ray = camera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0f));
        if (Physics.Raycast(ray, out RaycastHit hit, range, mask,
                            QueryTriggerInteraction.Ignore))
            return hit.point;
        return ray.GetPoint(range);
    }
}
