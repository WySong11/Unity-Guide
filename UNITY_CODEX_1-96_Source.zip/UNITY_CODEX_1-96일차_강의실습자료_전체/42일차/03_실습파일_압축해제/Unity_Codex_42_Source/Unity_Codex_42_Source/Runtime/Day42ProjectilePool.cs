using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

public class Day42ProjectilePool : MonoBehaviour
{
    [SerializeField] private Day42Projectile prefab;
    [SerializeField, Min(0)] private int prewarmCount = 12;
    [SerializeField, Min(1)] private int maxInactive = 48;
    private ObjectPool<Day42Projectile> pool;
    private readonly HashSet<Day42Projectile> inactive = new HashSet<Day42Projectile>();

    public int CountInactive => pool != null ? pool.CountInactive : 0;

    private void Awake()
    {
        if (prefab == null)
        {
            Debug.LogError("[Day42] Projectile prefab을 지정하세요.", this);
            enabled = false;
            return;
        }
        pool = new ObjectPool<Day42Projectile>(
            CreateItem, OnGet, OnRelease, OnDestroyItem,
            collectionCheck: true,
            defaultCapacity: Mathf.Max(1, prewarmCount),
            maxSize: Mathf.Max(maxInactive, prewarmCount, 1));
        // Get/Release 즉시 반복하면 한 개만 생성되므로 동시에 N개 대여
        var warming = new List<Day42Projectile>(prewarmCount);
        for (int i = 0; i < prewarmCount; i++) warming.Add(pool.Get());
        foreach (Day42Projectile item in warming) pool.Release(item);
    }

    private Day42Projectile CreateItem()
    {
        Day42Projectile item = Instantiate(prefab, transform);
        item.AttachPool(this);
        item.gameObject.SetActive(false);
        return item;
    }

    private void OnGet(Day42Projectile item)
    {
        inactive.Remove(item);
        item.gameObject.SetActive(true);
    }

    private void OnRelease(Day42Projectile item)
    {
        item.gameObject.SetActive(false);
        item.transform.SetParent(transform, false);
        inactive.Add(item);
    }

    private void OnDestroyItem(Day42Projectile item)
    {
        inactive.Remove(item);
        if (item != null) Destroy(item.gameObject);
    }

    public Day42Projectile Rent()
    {
        return pool != null ? pool.Get() : null;
    }

    public void Release(Day42Projectile projectile)
    {
        if (pool == null || projectile == null || inactive.Contains(projectile)) return;
        pool.Release(projectile);
    }

    private void OnDestroy()
    {
        pool?.Dispose();
        pool = null;
    }
}
