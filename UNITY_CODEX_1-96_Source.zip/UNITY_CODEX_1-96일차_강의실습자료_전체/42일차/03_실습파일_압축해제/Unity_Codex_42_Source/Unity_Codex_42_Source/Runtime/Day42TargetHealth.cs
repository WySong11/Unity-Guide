using UnityEngine;
using UnityEngine.Events;

public class Day42TargetHealth : MonoBehaviour, IDay42Damageable
{
    [SerializeField, Min(1)] private int maxHealth = 100;
    [SerializeField] private UnityEvent onDefeated;
    private int currentHealth;

    private void Awake() => currentHealth = maxHealth;

    public void TakeDamage(int amount, GameObject instigator, Vector3 hitPoint)
    {
        if (amount <= 0 || currentHealth <= 0) return;
        currentHealth = Mathf.Max(0, currentHealth - amount);
        Debug.Log($"[Day42] {name} HP={currentHealth}/{maxHealth}, hit={hitPoint}", this);
        if (currentHealth == 0) onDefeated?.Invoke();
    }

    [ContextMenu("Reset Health")]
    public void ResetHealth() => currentHealth = maxHealth;
}
