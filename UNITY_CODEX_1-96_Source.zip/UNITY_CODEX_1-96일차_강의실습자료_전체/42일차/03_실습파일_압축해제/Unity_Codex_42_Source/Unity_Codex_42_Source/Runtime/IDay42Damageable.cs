using UnityEngine;

// Raycast와 Projectile이 공유하는 데미지 계약
public interface IDay42Damageable
{
    void TakeDamage(int amount, GameObject instigator, Vector3 hitPoint);
}
