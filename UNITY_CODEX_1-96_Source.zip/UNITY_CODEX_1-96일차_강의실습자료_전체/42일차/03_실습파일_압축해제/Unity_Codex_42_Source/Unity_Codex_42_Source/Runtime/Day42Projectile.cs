using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Rigidbody), typeof(Collider))]
public class Day42Projectile : MonoBehaviour
{
    [SerializeField, Min(0.2f)] private float lifetime = 3f;
    private Rigidbody body;
    private Collider projectileCollider;
    private Day42ProjectilePool ownerPool;
    private GameObject instigator;
    private int damage;
    private float remaining;
    private bool flying;
    private bool returned;
    private readonly List<Collider> ignoredColliders = new List<Collider>();

    private void Awake()
    {
        body = GetComponent<Rigidbody>();
        projectileCollider = GetComponent<Collider>();
        body.useGravity = false;
        body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
    }

    public void AttachPool(Day42ProjectilePool pool) => ownerPool = pool;

    public void Launch(Vector3 position, Vector3 direction, float speed,
                       int hitDamage, GameObject owner)
    {
        RestoreCollisionRules();
        instigator = owner;
        damage = hitDamage;
        remaining = lifetime;
        returned = false;
        flying = false;
        transform.position = position;
        transform.rotation = Quaternion.LookRotation(direction.normalized);
        body.linearVelocity = Vector3.zero;
        body.angularVelocity = Vector3.zero;
        if (owner != null)
        {
            foreach (Collider c in owner.GetComponentsInChildren<Collider>(true))
            {
                if (c != projectileCollider)
                {
                    Physics.IgnoreCollision(projectileCollider, c, true);
                    ignoredColliders.Add(c);
                }
            }
        }
        flying = true;
        body.linearVelocity = direction.normalized * Mathf.Max(0f, speed);
    }

    private void Update()
    {
        if (!flying) return;
        remaining -= Time.deltaTime;
        if (remaining <= 0f) ReturnToPool();
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (!flying || returned) return;
        Vector3 point = collision.contactCount > 0
            ? collision.GetContact(0).point : transform.position;
        Hit(collision.collider, point);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (!flying || returned) return;
        Hit(other, transform.position);
    }

    private void Hit(Collider collider, Vector3 point)
    {
        if (instigator != null && collider.transform.IsChildOf(instigator.transform)) return;
        IDay42Damageable target = Day42DamageLookup.Find(collider);
        target?.TakeDamage(damage, instigator, point);
        ReturnToPool();
    }

    public void ReturnToPool()
    {
        if (returned) return; // 충돌과 수명 만료 중복 반환 방지
        returned = true;
        flying = false;
        body.linearVelocity = Vector3.zero;
        body.angularVelocity = Vector3.zero;
        RestoreCollisionRules();
        if (ownerPool != null) ownerPool.Release(this);
        else gameObject.SetActive(false);
    }

    private void RestoreCollisionRules()
    {
        if (projectileCollider == null) return;
        foreach (Collider other in ignoredColliders)
            if (other != null) Physics.IgnoreCollision(projectileCollider, other, false);
        ignoredColliders.Clear();
    }
}
