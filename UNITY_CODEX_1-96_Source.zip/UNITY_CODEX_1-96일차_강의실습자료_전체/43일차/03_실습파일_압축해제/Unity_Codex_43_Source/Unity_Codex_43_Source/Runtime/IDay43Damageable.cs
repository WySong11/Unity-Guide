/// <summary>무기가 구체적인 Health 클래스를 모르도록 하는 계약입니다.</summary>
public interface IDay43Damageable
{
    /// <returns>실제 데미지가 적용되었을 때만 true.</returns>
    bool TryReceiveDamage(Day43DamageContext context);
}
