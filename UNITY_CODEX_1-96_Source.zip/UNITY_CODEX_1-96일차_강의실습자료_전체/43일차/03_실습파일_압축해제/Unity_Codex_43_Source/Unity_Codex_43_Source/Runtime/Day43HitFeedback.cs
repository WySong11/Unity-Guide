using System.Collections;
using UnityEngine;

/// <summary>피격이 '승인'되었을 때만 효과음/파티클/컬러 피드백을 실행.</summary>
public sealed class Day43HitFeedback : MonoBehaviour
{
    [SerializeField] private Day43Health health;
    [SerializeField] private Renderer targetRenderer;
    [SerializeField] private Color hitColor = new Color(1f, 0.4f, 0.25f);
    [SerializeField, Min(0f)] private float flashDuration = 0.12f;
    [SerializeField] private AudioSource sfxSource;
    [SerializeField] private AudioClip hitClip;
    [SerializeField] private ParticleSystem hitParticles;

    private static readonly int BaseColorId = Shader.PropertyToID("_BaseColor"); // URP/Lit
    private MaterialPropertyBlock block;
    private Color defaultBaseColor = Color.white;
    private bool canTint;
    private Coroutine running;

    private void Awake()
    {
        block = new MaterialPropertyBlock();
        if (targetRenderer != null && targetRenderer.sharedMaterial != null &&
            targetRenderer.sharedMaterial.HasProperty(BaseColorId))
        {
            defaultBaseColor = targetRenderer.sharedMaterial.GetColor(BaseColorId);
            canTint = true;
        }
    }

    private void OnEnable()
    {
        if (health == null) return;
        health.Damaged += OnDamaged;
        health.ResetCompleted += OnReset;
    }

    private void OnDisable()
    {
        if (health != null)
        {
            health.Damaged -= OnDamaged;
            health.ResetCompleted -= OnReset;
        }
        if (running != null) { StopCoroutine(running); running = null; }
        RestoreColor();
    }

    private void OnDamaged(Day43DamageContext damage, int hpLeft)
    {
        if (sfxSource != null && hitClip != null) sfxSource.PlayOneShot(hitClip);
        if (hitParticles != null)
        {
            hitParticles.transform.position = damage.HitPoint;
            hitParticles.Play();
        }
        if (running != null) StopCoroutine(running);
        running = StartCoroutine(Flash());
    }

    private IEnumerator Flash()
    {
        Tint(hitColor);
        yield return new WaitForSeconds(flashDuration);
        RestoreColor();
        running = null;
    }

    private void OnReset()
    {
        if (running != null) { StopCoroutine(running); running = null; }
        RestoreColor();
    }

    private void Tint(Color value)
    {
        if (!canTint || targetRenderer == null) return;
        targetRenderer.GetPropertyBlock(block);
        block.SetColor(BaseColorId, value);
        targetRenderer.SetPropertyBlock(block);
    }

    private void RestoreColor() => Tint(defaultBaseColor);
}
