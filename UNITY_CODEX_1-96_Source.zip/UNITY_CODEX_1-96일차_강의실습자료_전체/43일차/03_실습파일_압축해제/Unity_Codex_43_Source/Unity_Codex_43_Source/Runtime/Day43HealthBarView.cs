using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>HP의 표시 담당. HP 데이터는 절대 직접 수정하지 않습니다.</summary>
public sealed class Day43HealthBarView : MonoBehaviour
{
    [SerializeField] private Day43Health health;
    [SerializeField] private Slider hpSlider;
    [SerializeField] private TMP_Text hpText;

    private void OnEnable()
    {
        if (health == null)
        {
            Debug.LogWarning("[Day43] HealthBarView: Health 참조가 없습니다.", this);
            return;
        }
        health.HealthChanged += Refresh;
        // 구독만으로는 초기 HP 이벤트를 받지 못하므로 즉시 동기화합니다.
        Refresh(health.CurrentHealth, health.MaxHealth);
    }

    private void OnDisable()
    {
        if (health != null) health.HealthChanged -= Refresh;
    }

    private void Refresh(int current, int maximum)
    {
        if (hpSlider != null)
        {
            hpSlider.minValue = 0f;
            hpSlider.maxValue = Mathf.Max(1, maximum);
            hpSlider.value = current;
        }
        if (hpText != null) hpText.text = $"{current} / {maximum}";
    }
}
