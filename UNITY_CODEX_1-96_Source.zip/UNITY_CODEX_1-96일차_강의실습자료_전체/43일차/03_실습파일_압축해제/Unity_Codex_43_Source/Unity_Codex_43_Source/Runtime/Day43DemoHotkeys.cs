using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>H: 회복 / R: 리셋. 실습 편의를 위한 테스트 입력입니다.</summary>
public sealed class Day43DemoHotkeys : MonoBehaviour
{
    [SerializeField] private Day43Health target;
    [SerializeField, Min(1)] private int healAmount = 15;

    private void Update()
    {
        if (Keyboard.current == null || Time.timeScale <= 0f || target == null) return;
        if (Keyboard.current.hKey.wasPressedThisFrame) target.Heal(healAmount);
        if (Keyboard.current.rKey.wasPressedThisFrame) target.ResetHealth();
    }
}
