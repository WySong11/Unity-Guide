using UnityEngine;

/// <summary>피격 요청 데이터. 공격 판정과 Health 계산을 분리합니다.</summary>
public readonly struct Day43DamageContext
{
    public readonly int Amount;
    public readonly GameObject Source;
    public readonly Vector3 HitPoint;

    public Day43DamageContext(int amount, GameObject source, Vector3 hitPoint)
    {
        Amount = amount;
        Source = source;
        HitPoint = hitPoint;
    }
}
