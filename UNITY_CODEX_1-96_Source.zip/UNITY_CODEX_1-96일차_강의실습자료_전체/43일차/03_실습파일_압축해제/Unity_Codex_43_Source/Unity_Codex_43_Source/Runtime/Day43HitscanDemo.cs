using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>독립 실습용 Raycast. 42일차 Weapon과 동시 사용하지 마세요.</summary>
public sealed class Day43HitscanDemo : MonoBehaviour
{
    [SerializeField] private Camera aimCamera;
    [SerializeField, Min(1)] private int damage = 20;
    [SerializeField, Min(0.1f)] private float range = 60f;
    [SerializeField, Min(0f)] private float cooldown = 0.15f;
    [SerializeField] private LayerMask hitMask = ~0;
    [SerializeField] private bool logHits = true;

    private float nextFireTime;

    private void Awake()
    {
        if (aimCamera == null) aimCamera = GetComponent<Camera>();
    }

    private void Update()
    {
        if (Time.timeScale <= 0f || Mouse.current == null) return;
        if (!Mouse.current.leftButton.wasPressedThisFrame) return;
        if (Time.time < nextFireTime) return;
        nextFireTime = Time.time + cooldown;
        Fire();
    }

    public void Fire()
    {
        if (aimCamera == null)
        {
            Debug.LogWarning("[Day43] Camera 미지정", this);
            return;
        }
        Ray ray = aimCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0f));
        if (!Physics.Raycast(ray, out RaycastHit hit, range, hitMask, QueryTriggerInteraction.Ignore))
            return;

        // child Collider에 Hit되더라도 parent Health로 전달합니다.
        var target = hit.collider.GetComponentInParent<Day43Health>();
        if (target == null) return;
        bool accepted = target.TryReceiveDamage(new Day43DamageContext(damage, gameObject, hit.point));
        if (logHits) Debug.Log($"[Day43] {target.name}: accepted={accepted}, HP={target.CurrentHealth}", target);
    }
}
