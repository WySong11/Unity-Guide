using System;
using UnityEngine;

[DisallowMultipleComponent]
public sealed class Day43Health : MonoBehaviour, IDay43Damageable
{
    [Header("체력 설정")]
    [SerializeField, Min(1)] private int maxHealth = 100;
    [SerializeField, Min(0)] private int startingHealth = 100;
    [SerializeField, Min(0f)] private float invulnerabilitySeconds = 0.35f;
    [SerializeField] private bool rejectSelfDamage = true;
    [SerializeField] private bool debugLog;

    public event Action<int, int> HealthChanged;
    public event Action<Day43DamageContext, int> Damaged;
    public event Action Died;
    public event Action ResetCompleted;

    public int MaxHealth => maxHealth;
    public int CurrentHealth => currentHealth;
    public bool IsDead => isDead;
    public bool IsInvulnerable => !isDead && Time.time < invulnerableUntil;

    private int currentHealth;
    private float invulnerableUntil;
    private bool isDead;

    private void Awake()
    {
        maxHealth = Mathf.Max(1, maxHealth);
        currentHealth = Mathf.Clamp(startingHealth, 0, maxHealth);
        isDead = currentHealth == 0;
        invulnerableUntil = 0f;
    }

    private void OnValidate()
    {
        maxHealth = Mathf.Max(1, maxHealth);
        startingHealth = Mathf.Clamp(startingHealth, 0, maxHealth);
        invulnerabilitySeconds = Mathf.Max(0f, invulnerabilitySeconds);
    }

    public bool TryReceiveDamage(Day43DamageContext context)
    {
        if (!isActiveAndEnabled || Time.timeScale <= 0f || context.Amount <= 0 || isDead)
            return false;
        if (IsInvulnerable) return false;
        if (rejectSelfDamage && context.Source != null &&
            context.Source.transform.root == transform.root)
            return false;

        // 유효한 피해만 HP 계산, 무적 시간, 이벤트 처리로 진행합니다.
        currentHealth = Mathf.Max(0, currentHealth - context.Amount);
        invulnerableUntil = Time.time + invulnerabilitySeconds;

        HealthChanged?.Invoke(currentHealth, maxHealth);
        Damaged?.Invoke(context, currentHealth);
        if (debugLog) Debug.Log($"[Day43] {name} HP {currentHealth}/{maxHealth}", this);

        if (currentHealth == 0) DieOnce();
        return true;
    }

    public bool Heal(int amount)
    {
        if (amount <= 0 || isDead) return false;
        int newValue = Mathf.Min(maxHealth, currentHealth + amount);
        if (newValue == currentHealth) return false;
        currentHealth = newValue;
        HealthChanged?.Invoke(currentHealth, maxHealth);
        return true;
    }

    public void ResetHealth()
    {
        currentHealth = maxHealth;
        isDead = false;
        invulnerableUntil = 0f;
        HealthChanged?.Invoke(currentHealth, maxHealth);
        ResetCompleted?.Invoke();
    }

    private void DieOnce()
    {
        if (isDead) return;
        isDead = true;
        Died?.Invoke();
        if (debugLog) Debug.Log($"[Day43] {name} Died (once)", this);
    }
}
