using UnityEngine;

/// <summary>사망 이벤트가 몇 번 실행되는지 검증합니다.</summary>
public sealed class Day43DeathReporter : MonoBehaviour
{
    [SerializeField] private Day43Health health;
    private int diedCount;

    private void OnEnable()
    {
        if (health != null)
        {
            health.Died += OnDied;
            health.ResetCompleted += OnReset;
        }
    }

    private void OnDisable()
    {
        if (health != null)
        {
            health.Died -= OnDied;
            health.ResetCompleted -= OnReset;
        }
    }

    private void OnDied()
    {
        diedCount++;
        Debug.Log($"[Day43] Died Count = {diedCount}", this);
    }

    private void OnReset()
    {
        diedCount = 0;
        Debug.Log("[Day43] Reset 상태 복구", this);
    }
}
