#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class Day43PracticeSceneBuilder
{
    [MenuItem("Tools/Unity Codex/Day43/Create Health Lab Scene")]
    public static void Build()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        string folder = "Assets/Day43";
        if (!AssetDatabase.IsValidFolder(folder)) AssetDatabase.CreateFolder("Assets", "Day43");
        if (!AssetDatabase.IsValidFolder(folder + "/Scenes")) AssetDatabase.CreateFolder(folder, "Scenes");

        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Ground";
        ground.transform.localScale = new Vector3(2f, 1f, 2f);

        GameObject target = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        target.name = "Target_Health100";
        target.transform.position = new Vector3(0f, 1f, 5f);
        Day43Health hp = target.AddComponent<Day43Health>();
        var flash = target.AddComponent<Day43HitFeedback>();
        var reporter = target.AddComponent<Day43DeathReporter>();
        var camera = Camera.main;
        if (camera == null)
        {
            var cameraGo = new GameObject("Main Camera");
            cameraGo.tag = "MainCamera";
            camera = cameraGo.AddComponent<Camera>();
        }
        camera.transform.position = new Vector3(0f, 2.1f, -6f);
        camera.transform.LookAt(target.transform.position);
        camera.gameObject.AddComponent<Day43HitscanDemo>();
        camera.gameObject.AddComponent<Day43DemoHotkeys>();

        // Serialized private Inspector 필드는 SerializedObject로 할당합니다.
        void SetRef(Component owner, string property, UnityEngine.Object value)
        {
            var so = new SerializedObject(owner);
            var prop = so.FindProperty(property);
            if (prop == null) return;
            prop.objectReferenceValue = value;
            so.ApplyModifiedPropertiesWithoutUndo();
        }
        SetRef(flash, "health", hp);
        SetRef(flash, "targetRenderer", target.GetComponent<Renderer>());
        SetRef(reporter, "health", hp);
        SetRef(camera.GetComponent<Day43HitscanDemo>(), "aimCamera", camera);
        SetRef(camera.GetComponent<Day43DemoHotkeys>(), "target", hp);

        string path = AssetDatabase.GenerateUniqueAssetPath(folder + "/Scenes/Day43_HealthLab.unity");
        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene, path);
        AssetDatabase.Refresh();
        Debug.Log($"[Day43] Scene saved: {path}. HUD(Slider/TMP)는 README를 따라 수동 연결하세요.");
    }
}
#endif
