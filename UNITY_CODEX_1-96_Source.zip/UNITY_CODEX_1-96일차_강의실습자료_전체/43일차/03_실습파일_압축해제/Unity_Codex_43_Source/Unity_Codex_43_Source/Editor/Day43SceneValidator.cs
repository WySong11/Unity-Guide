#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

public static class Day43SceneValidator
{
    [MenuItem("Tools/Unity Codex/Day43/Validate Active Scene")]
    private static void Validate()
    {
        var targets = Object.FindObjectsByType<Day43Health>(FindObjectsSortMode.None);
        var cameras = Object.FindObjectsByType<Day43HitscanDemo>(FindObjectsSortMode.None);
        var huds = Object.FindObjectsByType<Day43HealthBarView>(FindObjectsSortMode.None);
        Debug.Log($"[Day43] Health={targets.Length} / HitscanDemo={cameras.Length} / HUD={huds.Length}");
        if (targets.Length == 0) Debug.LogWarning("[Day43] Health 컴포넌트를 찾지 못했습니다.");
        if (cameras.Length == 0) Debug.LogWarning("[Day43] Hitscan Demo를 찾지 못했습니다.");
        if (huds.Length == 0) Debug.LogWarning("[Day43] HUD가 없습니다. Slider/TMP 만들기 실습을 수행하세요.");
    }
}
#endif
