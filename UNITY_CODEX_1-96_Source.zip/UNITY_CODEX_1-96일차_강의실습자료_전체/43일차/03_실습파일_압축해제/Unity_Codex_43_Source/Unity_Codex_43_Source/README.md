# Unity × Codex — 43일차 피격·체력 시스템

**대상:** Unity 6.3 (6000.3), Universal Render Pipeline (URP), 3D 기본 실습
**수업:** 120분 / 44장 PPT
**목표:** 42일차 Raycast·Projectile 명중 → HP/무적/사망 → HUD/피격 피드백 → 회귀 테스트

## 1. 필요한 Unity 패키지

- Unity 6.3 + 3D URP (권장)
- **Input System** (`com.unity.inputsystem`) — 데모 좌클릭/H/R 입력
- **TextMeshPro** (보통 프로젝트에 포함) — 체력 수치 표시
- Unity UI (`com.unity.ugui`) — Slider
- Editor 전용 코드(`Editor/`)는 `Assets/Editor` 또는 `Assets/Day43/Editor`에 두세요.

## 2. 설치

1. `Runtime/*.cs` → `Assets/Day43/Runtime/`
2. `Editor/*.cs` → `Assets/Day43/Editor/`
3. Unity 컴파일이 완료되면 메뉴 `Tools → Unity Codex → Day43 → Create Health Lab Scene`을 실행합니다.
4. 씬 생성 전 다른 씬의 미저장 변경은 저장 확인을 받습니다. **생성된 씬은 기존 이름을 덮어쓰지 않고 고유 이름으로 저장**합니다.
5. 씬의 `Target_Health100`, Main Camera 및 `Day43HitscanDemo`가 Inspector에 있는지 확인합니다.
6. 플레이 모드에서 **마우스 좌클릭**으로 사격, **H**로 15 HP 회복, **R**로 체력 초기화합니다.

> 자동 씬에는 타깃/카메라/평면·기본 검사 컴포넌트만 포함됩니다. HUD UI는 다음 단계에서 직접 생성합니다.

## 3. HUD 구현 (Canvas / Slider / TMP)

1. `Hierarchy → UI → Canvas` 생성, 자식으로 `Slider`와 TextMeshPro - Text(UI) 생성
2. Canvas 자식(빈 GameObject)에 `Day43HealthBarView` 추가
3. View Inspector에서 `Health = Target_Health100`, `HP Slider`, `HP Text`를 각각 드래그
4. Play Mode에서 시작 **100/100**, 첫 타격 **80/100**, HUD 비활성→재활성 시 수치 동기화를 확인
5. `OnEnable()`에서 구독 후 즉시 `Refresh()`를 호출하는지 확인

## 4. 피격 연출

- `Target_Health100`에 추가된 `Day43HitFeedback`의 Health와 Renderer는 씬 생성 도구가 연결합니다.
- `AudioSource`, `AudioClip`, `ParticleSystem`은 선택적으로 Inspector 연결합니다.
- URP/Lit의 `_BaseColor`를 `MaterialPropertyBlock`으로 임시 변경하는 예제입니다. **동일 Renderer에 다른 색상 PropertyBlock 시스템을 함께 쓰면 복원 규칙을 통합하세요.**
- 피해가 실제로 승인되어 `Damaged` 이벤트가 발생한 경우에만 Flash/SFX가 재생됩니다.

## 5. 42일차와 연결 (중요)

42일차 `Day42RaycastWeapon`, `Day42Projectile`는 `IDay42Damageable`을 통해 데미지를 전달합니다. 43일차의 별도 인터페이스는 호환되지 않습니다. 다음 중 하나만 선택하세요.

- **A안 권장 — 어댑터:** 42일차 `IDay42Damageable.cs`가 **이미 프로젝트에 있는 경우만**, `OptionalIntegration/Day43LegacyDay42Adapter.cs.txt`를 `.cs`로 바꾸고 `Assets/Day43/Runtime`으로 이동한 뒤 `Target_Health100`에 추가합니다. 기존 `Day42TargetHealth`가 같은 대상에 있으면 제거하거나 비활성화해 **HP 소유자를 1개로 제한**합니다.
- **B안 — Weapon 변경:** 42일차 `Day42DamageLookup.Find` 부분에서 직접 `GetComponentInParent<Day43Health>()` 후 `TryReceiveDamage()`를 호출하게 변경합니다. 이 경우 기존 코드에 최소 diff만 적용합니다.

**주의:** 43일차 데모 `Day43HitscanDemo`와 42일차 Weapon을 한 씬에서 **동시에 좌클릭 구독시키지 마세요.** 한 발에 데미지가 2번 들어갈 수 있습니다. 실제 Projectile은 발사체 충돌 위치에서 동일한 어댑터를 사용하면 됩니다.

## 6. 클래스 역할

| C# 파일 | 역할 |
|---|---|
| `Day43DamageContext.cs` | 피해량, 공격자, HitPoint 데이터 |
| `IDay43Damageable.cs` | 피격 계약 |
| `Day43Health.cs` | HP, 무적 시간, 사망, 회복, 초기화, 이벤트 |
| `Day43HealthBarView.cs` | Slider 및 TMP Text 초기·이벤트 갱신 |
| `Day43HitFeedback.cs` | 피격 Flash, SFX, 파티클 |
| `Day43HitscanDemo.cs` | 카메라 중심 Raycast 독립 데모 |
| `Day43DemoHotkeys.cs` | H 회복, R 초기화 |
| `Day43DeathReporter.cs` | Died 1회 검사 |
| `Day43PracticeSceneBuilder.cs` | Editor 실습 씬 신규 저장 |
| `Day43SceneValidator.cs` | 씬 구성 점검 |

## 7. 수업 권장 시간 배분

- 도입 10분 — 42일차 공격 이벤트 복습
- 개념 20분 — 역할 분리, 무적, 이벤트
- 실습 A 25분 — Health 구현, 피해/회복
- 실습 B 25분 — HUD, Flash, 사망
- 실습 C 20분 — 기존 무기와 결합
- 검증 20분 — H/I/U 테스트 체크리스트, Codex 보고

## 8. 검증 범위와 유의사항

- `CurrentHealth`는 0~MaxHealth 범위에 있어야 합니다.
- 무적 시간(`Time.time`)은 게임 시간 기준이므로 일시정지 중 경과하지 않습니다.
- `ResetHealth()`는 HP와 사망 플래그 및 무적 타이머를 복원합니다.
- `Heal()`은 **사망 상태에서 자동 부활시키지 않습니다**.
- `HealthChanged`는 OnEnable 후 바로 호출되는 것이 아니므로 HUD가 초기 동기화를 수행합니다.
- `Died`는 사망 상태 진입 1회에만 발행됩니다.
- 자동 생성 씬에 실습 코드 배치까지만 수행합니다. **Unity 컴파일, Play Mode, 실제 디바이스 테스트를 자동으로 실행한 것은 아닙니다.**

## 9. 공식 API 근거

- [Unity 6.3 Rigidbody.AddForce](https://docs.unity.com/en-us/engine/6000.3/script-reference/unityengine/rigidbody/addforce)
- [Unity 6.3 Renderer.GetPropertyBlock](https://docs.unity.com/en-us/engine/6000.3/script-reference/unityengine/renderer/getpropertyblock)
- [Unity MaterialPropertyBlock](https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/materialpropertyblock)
