#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

// Unity 6 Universal 3D 템플릿에서만 사용하세요. Editor 폴더에 배치합니다.
public static class Day34SceneBuilderEditor
{
    private const string RootPath = "Assets/UnityCodexDay34";

    [MenuItem("Tools/Unity Codex/Day34/Create URP Practice Scene")]
    private static void CreateScene()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
            return;

        if (Shader.Find("Universal Render Pipeline/Lit") == null)
        {
            EditorUtility.DisplayDialog("Day34 URP 확인",
                "URP/Lit Shader를 찾을 수 없습니다. Universal 3D 템플릿과 URP 설정을 확인하세요.", "확인");
            return;
        }
        if (AssetDatabase.LoadAssetAtPath<SceneAsset>(
            RootPath + "/Scenes/Day34_URP_Practice.unity") != null)
        {
            EditorUtility.DisplayDialog("Day34 Scene 생성 중단",
                "같은 이름의 Scene이 존재합니다. 기존 씬을 보호하기 위해 중단했습니다. 백업 후 이름을 변경하세요.", "확인");
            return;
        }

        EnsureFolder("Assets", "UnityCodexDay34");
        EnsureFolder(RootPath, "Materials");
        EnsureFolder(RootPath, "Scenes");
        EnsureFolder(RootPath, "Settings");

        // 새 씬 생성. 현재 씬을 덮어쓰지 않으며 별도 경로에 저장합니다.
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        var environment = new GameObject("Environment").transform;
        var props = new GameObject("Props").transform;

        CreatePrimitive(PrimitiveType.Plane, "Ground", Vector3.zero,
            new Vector3(4f, 1f, 4f), ColorFromRgb(0.34f, 0.50f, 0.58f), environment);
        CreatePrimitive(PrimitiveType.Cube, "Platform", new Vector3(0, 0.35f, 0),
            new Vector3(6, .7f, 5), ColorFromRgb(.23f, .36f, .58f), environment);
        CreatePrimitive(PrimitiveType.Cube, "BlueCube", new Vector3(-2, 1.35f, .35f),
            new Vector3(1.2f, 1.2f, 1.2f), ColorFromRgb(.10f, .55f, .95f), props);
        CreatePrimitive(PrimitiveType.Sphere, "AmberSphere", new Vector3(0, 1.45f, .35f),
            Vector3.one * 1.55f, ColorFromRgb(.98f, .62f, .14f), props);
        CreatePrimitive(PrimitiveType.Capsule, "TealCapsule", new Vector3(2.2f, 1.55f, .35f),
            Vector3.one * 1.25f, ColorFromRgb(.08f, .70f, .63f), props);

        GameObject lightObject = new GameObject("Directional Light");
        var light = lightObject.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.15f;
        light.shadows = LightShadows.Soft;
        lightObject.transform.rotation = Quaternion.Euler(45f, -30f, 0f);

        GameObject cameraObject = new GameObject("Main Camera");
        cameraObject.tag = "MainCamera";
        var camera = cameraObject.AddComponent<Camera>();
        camera.transform.position = new Vector3(0f, 6.5f, -12f);
        camera.transform.LookAt(new Vector3(0f, 1f, 0f));
        camera.fieldOfView = 55f;
        camera.nearClipPlane = .1f;
        camera.farClipPlane = 300f;
        cameraObject.AddComponent<AudioListener>();
        var cameraData = cameraObject.GetComponent<UniversalAdditionalCameraData>();
        if (cameraData == null) cameraData = cameraObject.AddComponent<UniversalAdditionalCameraData>();
        cameraData.renderPostProcessing = true;

        // 볼륨 프로파일은 프로젝트 파일로 저장하므로 씬 재오픈 시에도 유지됩니다.
        var volumeObject = new GameObject("Global Volume");
        var volume = volumeObject.AddComponent<Volume>();
        volume.isGlobal = true;
        var profile = ScriptableObject.CreateInstance<VolumeProfile>();
        string profilePath = RootPath + "/Settings/Day34VolumeProfile.asset";
        AssetDatabase.CreateAsset(profile, profilePath);
        Bloom bloom = profile.Add<Bloom>(true);
        bloom.intensity.Override(.25f);
        bloom.threshold.Override(.95f);
        ColorAdjustments color = profile.Add<ColorAdjustments>(true);
        color.postExposure.Override(.10f);
        volume.sharedProfile = profile;

        EditorSceneManager.MarkSceneDirty(scene);
        string path = RootPath + "/Scenes/Day34_URP_Practice.unity";
        EditorSceneManager.SaveScene(scene, path);
        AssetDatabase.SaveAssets();
        Debug.Log("[Day34] Scene saved: " + path);
        if (GraphicsSettings.currentRenderPipeline == null)
            Debug.LogWarning("[Day34] URP Asset assignment is not active. Check Graphics / Quality.");
        Selection.activeGameObject = cameraObject;
    }

    private static GameObject CreatePrimitive(PrimitiveType type, string name, Vector3 pos,
        Vector3 scale, Color color, Transform parent)
    {
        var go = GameObject.CreatePrimitive(type);
        go.name = name;
        go.transform.SetParent(parent);
        go.transform.position = pos;
        go.transform.localScale = scale;
        string materialPath = RootPath + "/Materials/M_" + name + ".mat";
        var mat = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        mat.SetColor("_BaseColor", color);
        AssetDatabase.CreateAsset(mat, materialPath);
        go.GetComponent<Renderer>().sharedMaterial = mat;
        return go;
    }

    private static Color ColorFromRgb(float r, float g, float b) => new Color(r, g, b, 1f);

    private static void EnsureFolder(string parent, string name)
    {
        string path = parent + "/" + name;
        if (!AssetDatabase.IsValidFolder(path)) AssetDatabase.CreateFolder(parent, name);
    }
}
#endif
