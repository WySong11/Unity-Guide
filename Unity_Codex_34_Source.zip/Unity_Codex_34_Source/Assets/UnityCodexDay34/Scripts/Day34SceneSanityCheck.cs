using UnityEngine;
using UnityEngine.Rendering;

// 플레이 시작 시 주요 씬 구성 요소를 검사합니다.
public class Day34SceneSanityCheck : MonoBehaviour
{
    [SerializeField] private string groundName = "Ground";
    [SerializeField] private bool checkOnStart = true;

    private void Start()
    {
        if (checkOnStart) ValidateScene();
    }

    [ContextMenu("Validate Day34 Scene")]
    public void ValidateScene()
    {
        bool ok = true;
        if (Camera.main == null) { Debug.LogError("[Day34] Main Camera 없음"); ok = false; }
        if (GameObject.Find(groundName) == null) { Debug.LogError("[Day34] Ground 없음"); ok = false; }
        if (GraphicsSettings.currentRenderPipeline == null)
        {
            Debug.LogWarning("[Day34] 활성 SRP Asset 없음. Graphics/Quality 설정 확인");
            ok = false;
        }

        Light[] lights = FindObjectsByType<Light>(FindObjectsSortMode.None);
        bool hasDirectional = false;
        foreach (Light light in lights)
            if (light != null && light.enabled && light.type == LightType.Directional)
                hasDirectional = true;
        if (!hasDirectional) { Debug.LogWarning("[Day34] Directional Light 없음"); ok = false; }
        if (ok) Debug.Log("[Day34] 기본 씬 구성 검사 통과");
    }
}
