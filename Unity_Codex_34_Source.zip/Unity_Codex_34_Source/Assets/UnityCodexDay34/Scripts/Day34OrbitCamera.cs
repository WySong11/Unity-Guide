using UnityEngine;

// 입력 패키지와 무관하게 자동 회전으로 카메라 구도를 비교합니다.
public class Day34OrbitCamera : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField, Min(1f)] private float radius = 12f;
    [SerializeField] private float height = 6f;
    [SerializeField] private float angularSpeed = 10f;
    [SerializeField] private bool autoOrbit;
    private float angleDegrees = 180f;

    private void LateUpdate()
    {
        if (target == null) return;
        if (autoOrbit) angleDegrees += angularSpeed * Time.deltaTime;
        float rad = angleDegrees * Mathf.Deg2Rad;
        Vector3 offset = new Vector3(Mathf.Sin(rad) * radius, height, Mathf.Cos(rad) * radius);
        transform.position = target.position + offset;
        transform.LookAt(target.position);
    }

    [ContextMenu("Reset Orbit")]
    private void ResetOrbit() => angleDegrees = 180f;
}
