using UnityEngine;

// Directional Light가 회전하면 그림자 방향이 바뀝니다.
[RequireComponent(typeof(Light))]
public class Day34LightRotator : MonoBehaviour
{
    [SerializeField] private bool animateLight;
    [SerializeField, Range(0f, 30f)] private float degreesPerSecond = 5f;

    private void Update()
    {
        if (animateLight)
            transform.Rotate(Vector3.up, degreesPerSecond * Time.deltaTime, Space.World);
    }
}
