# 34일차 Codex 실습 프롬프트

## 1. 시작 전 점검
Unity 6.3, Universal 3D(URP) 프로젝트입니다. 수정 전 다음 사항만 확인해 주세요: 현재 에디터/URP 패키지 버전, 활성 렌더 파이프라인 에셋(Graphics/Quality), Console 오류, 현재 Git 작업 상태. 정상인 설정은 변경하지 마세요.

## 2. 씬 자동 생성
`Assets/UnityCodexDay34` 경로에 독립된 데모 씬을 생성하려고 합니다. 기존 씬/에셋은 삭제하거나 덮어쓰지 마세요. Ground Plane, Platform, Cube, Sphere, Capsule, URP/Lit 재질, Directional Light, Perspective Camera, Global Volume(Bloom, Color Adjustments)을 구성하는 **Editor 전용 C# 도구**를 작성해 주세요. 씬 이름은 `Day34_URP_Practice.unity`입니다. 생성 전 사용자 변경사항 보호, 재실행 시 덮어쓰기 방지, 생성 파일 목록 보고가 필요합니다.

## 3. 오류 분석
게임 실행 시 [증상]이 있습니다. Console 원문과 재현 순서를 분석하여 가능한 원인을 나열한 후, 가장 작은 수정만 적용하세요. URP Asset·Shader·Camera Post Processing·Volume Profile·Layer Mask를 우선 점검하고, 수정 전/후 차이와 검증 결과를 보고하세요. 실제 검증을 수행하지 못했다면 '미검증'이라고 명시하세요.

## 4. 검증 보고
Unity 컴파일 오류, Scene Hierarchy, URP Asset/Renderer, Material, Camera, Light, Global Volume, 빌드 씬 목록을 체크리스트와 대조하세요. Pass/Fail/미검증으로 분류하고 로그/스크린샷을 근거로 첨부하세요.
