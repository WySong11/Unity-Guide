[Unity Codex 34일차 | URP 기반 3D Scene 만들기]
수업 목표: Unity 6.3 Universal 3D 템플릿에서 바닥, Primitive, URP/Lit, 광원, 카메라, Global Volume을 가진 3D 장면을 구성합니다.

1. Unity Hub > New project > Universal 3D > Unity 6.3 계열로 프로젝트를 생성합니다.
2. Assets/UnityCodexDay34 폴더를 Unity 프로젝트 Assets 아래로 복사합니다.
3. Project Settings > Graphics 및 Quality에서 URP Asset 설정을 확인합니다.
4. Unity 컴파일 오류가 없는지 Console을 확인합니다.
5. 상단 메뉴 Tools > Unity Codex > Day34 > Create URP Practice Scene을 선택합니다.
   - 열려 있는 Scene에 변경사항이 있으면 저장 여부를 확인합니다.
   - 기존 Assets/UnityCodexDay34/Scenes/Day34_URP_Practice.unity가 있으면 덮어쓰지 않습니다.
6. 생성된 씬을 Scene / Game View에서 확인하고 Ground, Platform, BlueCube, AmberSphere, TealCapsule 배치를 확인합니다.
7. Ground/Platform/Props와 Material, Main Camera, Directional Light, Global Volume의 참조를 확인합니다.
8. Volume Profile의 Bloom, Color Adjustments를 켜거나 끄며 Game View 결과를 비교합니다.
9. 빈 GameObject에 Day34SceneSanityCheck를 부착한 다음 Play Mode에서 Console 결과를 확인합니다.
10. 선택 실습: Main Camera에 Day34OrbitCamera를 부착하고 Target에 Props/AmberSphere를 지정합니다.
    선택 실습: Directional Light에 Day34LightRotator를 부착하고 Animate Light를 켭니다.

[폴더]
Assets/UnityCodexDay34/Editor/Day34SceneBuilderEditor.cs : Editor 전용 씬 생성 메뉴
Assets/UnityCodexDay34/Scripts/Day34SceneSanityCheck.cs : 씬 검증
Assets/UnityCodexDay34/Scripts/Day34OrbitCamera.cs : 입력 없이 자동 카메라 오비트
Assets/UnityCodexDay34/Scripts/Day34LightRotator.cs : 광원 회전 실습
Docs/ : 학생 워크시트, 검증 체크리스트, Codex 프롬프트, 강사용 정답

주의: 에디터 자동 생성기는 'Universal 3D / Universal RP'를 이미 설치한 프로젝트를 전제로 합니다.
     카메라, 재질, 볼륨 설정이 에디터 버전 및 프로젝트 기본값에 따라 달라 보일 수 있으므로 Inspector에서 재검증하세요.
     자동 생성한 Scene의 실제 Unity 컴파일과 실행 검증은 사용자의 Unity Editor에서 진행해야 합니다.
