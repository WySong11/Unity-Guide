# 강사용 진행 가이드 | 66일차 개발 계획 / 작업 분할 프롬프트

## 목표
학습자가 AGENTS.md 규칙을 유지하며 기능 요청을 WBS와 검증 가능한 Task로 나눌 수 있다.

## 준비물
- Unity 6.3 프로젝트 또는 읽기 전용 예제 구조
- VS Code Codex 확장(사용 가능한 경우) / `AGENTS.md` (있으면 기존 것 보존)
- Git 변경 확인 방법 및 샘플 테스트 기록
- `PlanningTemplate/` 출력물. Codex 플랜 모드나 파일 네이밍은 환경별로 달라질 수 있음

## 시연 1 | 25분
기존 인벤토리·UI·저장 코드 위치를 알 수 없다는 점을 강조. 먼저 P0로 현행 구조/미결정을 찾는다.

## 시연 2 | 30분
WBS를 칠판에 쓰고 선행관계 확인: T01→T02→T03→T04→T05.
실제 T05의 의존성은 T03,T04. 순환이 없어야 하며 T02 변경만 허용.

## 시연 3 | 40분
P1로 계획만 생성 후 대상 파일·AC를 사람이 검토.
P2로 승인된 T02만 구현한 뒤 diff 확인. 실제 Unity Editor가 없다면 정적 리뷰 결과만 표기.
P3/P4로 AC 검증과 다음 작업 인계.

## 시연 4 | 25분
테스트 매트릭스 QA01~QA12와 RUBRIC_100 평가.
실패 주입: 미승인 장비 기능 추가 요청 → CR 문서로 영향 분석 후 새 Task로 분리.

## 강사가 확인해야 할 흔한 오류
- 계획 요청에서 이미 코드/씬을 고쳐버림
- Unity 명령을 실행하지 않고 PASS로 기록
- AGENTS.md와 PLANS.md의 역할이 혼합됨
- 작업 카드의 허용 경로가 실제 프로젝트와 다름
- 기본 코드의 Unity 버전·어셋 참조를 확인하지 않음
- 사용자의 미커밋 변경·.meta 파일을 덮어씀

## 평가
RUBRIC_100.csv: 요구 분석 20, WBS 25, 프롬프트 25, 테스트 20, 발표 10.

## 공식 참고 링크 (교육 자료 작성 기준)
- https://developers.openai.com/cookbook/examples/codex/iterating-development-workflows-with-codex
- https://developers.openai.com/blog/run-long-horizon-tasks-with-codex
- https://developers.openai.com/cookbook/articles/codex_exec_plans

> 프로젝트에 맞는 실행 권한·도구·버전을 확인해야 합니다. 정식 Unity 빌드·Play Mode는 수업 환경에서 검증하세요.
