# TeacherReference | 선택형 코드 예제

- `Day66ItemData`와 `Day66ItemCatalog`는 T02 데이터/ID 검사 예시입니다.
- `Day66InventoryModel`과 `Day66InventoryDiagnostic`는 T03 스택 경계 테스트를 이해하기 위한 **독립 참고 구현**입니다.
- Day66InventoryDiagnostic 예제는 `potion_small` ItemData를 가진 Catalog 에셋을 Inspector로 연결해야 합니다.
- 스택 5와 12슬롯은 수업 샘플이며 실제 프로젝트에 맞춰 변경하세요.
- 기존 프로젝트의 같은 이름/유사 기능이 있다면 자동으로 병합하지 마세요.
- 실제 Unity 6.3 Editor 컴파일/Play Mode 실행 여부는 수업 환경에서 별도 검증해야 합니다.
