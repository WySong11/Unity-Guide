using UnityEngine;

[CreateAssetMenu(fileName = "Day66Item", menuName = "Day66/Item Data")]
public sealed class Day66ItemData : ScriptableObject
{
    [SerializeField] private string itemId = "potion_small";
    [SerializeField] private string displayName = "Potion";
    [SerializeField, Min(1)] private int maxStack = 5;

    public string ItemId => itemId;
    public string DisplayName => displayName;
    public int MaxStack => Mathf.Max(1, maxStack);
}
