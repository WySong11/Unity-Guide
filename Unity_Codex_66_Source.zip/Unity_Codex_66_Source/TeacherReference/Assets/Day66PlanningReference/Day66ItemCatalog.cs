using System;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Day66ItemCatalog", menuName = "Day66/Item Catalog")]
public sealed class Day66ItemCatalog : ScriptableObject
{
    [SerializeField] private List<Day66ItemData> items = new();

    public bool TryFind(string id, out Day66ItemData item)
    {
        item = null;
        if (string.IsNullOrWhiteSpace(id)) return false;
        foreach (var candidate in items)
        {
            if (candidate != null && string.Equals(candidate.ItemId, id, StringComparison.Ordinal))
            {
                item = candidate;
                return true;
            }
        }
        return false;
    }

    public bool Validate(out string error)
    {
        var ids = new HashSet<string>(StringComparer.Ordinal);
        foreach (var candidate in items)
        {
            if (candidate == null) { error = "Null item entry."; return false; }
            if (string.IsNullOrWhiteSpace(candidate.ItemId))
            { error = "Empty ItemId."; return false; }
            if (!ids.Add(candidate.ItemId))
            { error = $"Duplicate ItemId: {candidate.ItemId}"; return false; }
        }
        error = string.Empty;
        return true;
    }
}
