using UnityEngine;

// Read-only IMGUI diagnostic; NOT a production inventory UI.
public sealed class Day66InventoryDiagnostic : MonoBehaviour
{
    [SerializeField] private Day66ItemCatalog catalog;
    private readonly Day66InventoryModel model = new();
    private string result = "No test run";

    private void OnGUI()
    {
        if (GUI.Button(new Rect(10, 10, 260, 42), "Test: Add 4 + 3 Potions"))
        {
            if (catalog == null)
            { result = "Catalog missing"; return; }
            if (!catalog.Validate(out var reason))
            { result = reason; return; }
            if (!catalog.TryFind("potion_small", out var data))
            { result = "potion_small ID not found"; return; }
            model.slots.Clear();
            int left = model.Add(data.ItemId, 4, data.MaxStack);
            left += model.Add(data.ItemId, 3, data.MaxStack);
            result = $"Slots={model.slots.Count}; Left={left}";
        }
        GUI.Label(new Rect(10, 55, 420, 28), result);
    }
}
