using System;
using System.Collections.Generic;

// Runtime slot state is separate from ScriptableObject shared configuration.
[Serializable]
public sealed class Day66InventorySlot
{
    public string itemId;
    public int amount;
}

[Serializable]
public sealed class Day66InventoryModel
{
    public List<Day66InventorySlot> slots = new();
    public int capacity = 12;

    // Returns how many could NOT be accepted. No loss when slots are full.
    public int Add(string itemId, int amount, int maxStack)
    {
        if (string.IsNullOrWhiteSpace(itemId) || amount <= 0 || maxStack <= 0)
            return amount;
        int remaining = amount;
        foreach (var slot in slots)
        {
            if (slot == null || slot.itemId != itemId || slot.amount >= maxStack) continue;
            int added = Math.Min(remaining, maxStack - slot.amount);
            slot.amount += added;
            remaining -= added;
            if (remaining == 0) return 0;
        }
        int limit = Math.Max(0, capacity);
        while (remaining > 0 && slots.Count < limit)
        {
            int added = Math.Min(remaining, maxStack);
            slots.Add(new Day66InventorySlot { itemId = itemId, amount = added });
            remaining -= added;
        }
        return remaining;
    }
}
