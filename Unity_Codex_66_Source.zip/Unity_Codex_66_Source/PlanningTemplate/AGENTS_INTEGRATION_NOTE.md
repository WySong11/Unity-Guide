# 기존 AGENTS.md와 이 실습 템플릿 연동

`AGENTS.md`는 Codex에서 사용하는 지속 지침 파일입니다. 아래는 기존 AGENTS를 보존하면서 **필요한 경우에만** 연결할 수 있는 예문입니다.

```md
## Task planning conventions (when feature scope is broad)
- Use PROJECT_BRIEF.md to record outcome, scope, and unresolved questions.
- Use PLANS.md and TASKS/*.md only if the project has adopted them.
- Before implementing a Task, verify dependencies, accepted file scope and AC.
- Preserve current uncommitted changes and use minimal diffs.
- Report actually executed tests and mark unavailable checks NOT RUN.
- Do not start the next Task or commit/push without the requested authorization.
```

- 실제 파일 위치에 맞춰 경로를 수정하세요.
- 이 내용은 권한을 늘리지 않습니다. 설치된 Codex와 실행 환경의 정책이 적용됩니다.
- AGENTS.md, PROJECT_BRIEF.md, PLANS.md 사이에 동일 규칙을 반복 작성하지 마세요.
