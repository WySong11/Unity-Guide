# Task Handoff | {TaskID}

- 상태: DONE / BLOCKED / CANCELLED
- 승인된 목표·범위:
- 수정 파일:
- 하지 않은 작업(범위 밖):

## Acceptance Criteria
| AC | Expected | Actual | Status | Evidence |
|---|---|---|---|---|
| AC1 |  |  | NOT RUN |  |
| AC2 |  |  | NOT RUN |  |

## Validation
- Git status / diff:
- Static review:
- Unity compile:
- Unity Play Mode:

## Risks / Remaining Issues
-

## Next Task Preconditions
-

## Approval / Commit
- 사람 검토 필요 여부:
- 커밋/푸시: NOT REQUESTED
