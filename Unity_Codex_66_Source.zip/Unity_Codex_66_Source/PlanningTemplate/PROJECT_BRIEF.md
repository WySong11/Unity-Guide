# PROJECT_BRIEF | 3D Inventory & Save

## 사용자 목표
기존 Unity 6.3 URP 프로젝트에서 월드 아이템을 얻으면 12칸 인벤토리에 표시되고 JSON으로 저장·로드한다.

## 사용자 시나리오
- R01: 아이템 1개를 획득하면 해당 아이템 수량이 정확히 1 증가한다.
- R02: maxStack=5 아이템을 4개 가진 상태에서 3개를 얻으면 기존 슬롯 5개, 새 슬롯 2개로 구성된다.
- R03: 아이템을 획득한 뒤 저장·로드하면 ID, 수량, 슬롯이 복원된다.
- R04: 슬롯 부족 또는 무효 ID는 데이터 손실·잘못된 상태 변경 없이 실패를 알린다.

## In Scope
- ScriptableObject `ItemData`와 안정적인 문자열 ID
- 12개 슬롯, 스택 병합·초과 수량 보고
- Pickup / Inventory UI의 갱신 이벤트
- JSON DTO Save/Load, 경계 값·무효 ID 검증

## Out of Scope
- 서버 동기화, 아이템 거래, 드롭 아이템 생성, 장비 시스템, 상점
- 기존 전투·Player 이동·Enemy FSM 리팩터링, 패키지 업그레이드

## 프로젝트 제약
- Unity 6.3 / URP / New Input System 가정. 실제 프로젝트 버전을 먼저 확인할 것.
- 참조 방식과 정확한 경로는 탐색 후 확정할 것. 여기서 제시한 `Assets/Scripts/Inventory/`는 **예시 경로**다.
- `AGENTS.md` 및 해당 프로젝트 규칙 우선. 사용자 변경·.meta GUID·Prefab 연결 보존.

## 위험 및 미결정
- 기존 아이템/인벤토리 시스템 존재 여부 **미확인**
- UI Toolkit / uGUI 선택 **미결정**
- JSON 세이브 스키마/파일 버전 **미결정**
- 스택 수량 5는 실습 예시이며, 실제 게임 요구 확인 필요

## Done When
R01~R04가 테스트 입력/출력 또는 Play Mode 기록으로 확인되고, 기존 이동·전투가 회귀하지 않으며, 실행하지 못한 검사는 NOT RUN으로 보고한다.
