# 통합 테스트 계획서 | WAVE GUARD

- 프로젝트/버전: 
- Unity 버전/패키지: 
- Git 브랜치/커밋: 
- 테스트 환경(Editor/Windows/Android): 
- 테스트 데이터 초기화 방식: 
- 담당자/날짜: 

| TC ID | 우선순위 | 선행 조건 | 실행 절차 | 예상 결과 | 상태(PASS/FAIL/BLOCKED/NOT RUN) | 증거 |
|---|---|---|---|---|---|---|
| TC-001 | P0 | Title 진입 | Start 클릭 | Stage 진입 및 HUD 표시 | NOT RUN | |
| TC-002 | P0 | Stage/Enemy 존재 | 적과 전투 | HP/사망 이벤트 정상 | NOT RUN | |
| TC-003 | P0 | Stage 정의 완료 | 1~3 Wave 진행 | 순차 스폰, 적 0명 시 완료 | NOT RUN | |
| TC-004 | P0 | Fighting | Pause→Resume→Move | 이동 입력 정상 복귀 | NOT RUN | |
| TC-005 | P0 | Clear 상태 | Restart | timeScale=1, 새 Stage | NOT RUN | |
| TC-006 | P0 | Stage Clear | 종료→재실행→Load | 진행도 유지 | NOT RUN | |
| TC-007 | P1 | Skill 장착 | 2회 연속 시도 | 쿨다운 중 재발동 차단 | NOT RUN | |
| TC-008 | P1 | HP 감소 | 회복 아이템 획득 | 최대 HP 제한 | NOT RUN | |
| TC-009 | P1 | AudioMixer 연결 | 음량 변경→재실행 | 설정 유지 | NOT RUN | |
| TC-010 | P0 | GameOver | ReturnToTitle | UI/입력/timeScale 초기화 | NOT RUN | |

추가 경계값 테스트: 
리스크/제외 범위: 
