# 92일차 통합 테스트 결과 보고서

- 테스트 대상: 
- Unity 버전/빌드 환경: 
- Git commit: 
- 실행자: 
- 테스트 일시: 

## 결과 집계

| Total | PASS | FAIL | BLOCKED | NOT RUN |
|---:|---:|---:|---:|---:|
| 0 | 0 | 0 | 0 | 0 |

- 실행률 = (PASS + FAIL + BLOCKED) / Total (실행률 정의는 팀 기준을 기록)
- 실행 완료 통과율 = PASS / (PASS + FAIL), BLOCKED 별도 표시

## 시스템별 결과

| 시스템 | 케이스 ID | 결과 | 증거 링크 | 관련 BUG |
|---|---|---|---|---|
| Player/UI | | | | |
| Enemy/Wave | | | | |
| Skill/Item | | | | |
| Save/Audio | | | | |
| Windows/Android | | | | |

## 남은 결함 / 위험 / 미검증

- 

## 최종 결론

- Go / No-Go: 
- 판단 근거 및 차단 사유: 
- 승인/보류 담당자: 
