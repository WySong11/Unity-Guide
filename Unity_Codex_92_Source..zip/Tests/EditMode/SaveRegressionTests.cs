using NUnit.Framework;

// Requires SaveData and SaveDataCodec from WAVE GUARD day 90.
public class SaveRegressionTests
{
    [Test]
    public void Rejects_Negative_Stage_Progress()
    {
        string json = "{\"schemaVersion\":1,\"highestClearedStage\":-1}";
        Assert.IsFalse(SaveDataCodec.TryDeserialize(json, out _));
    }

    [Test]
    public void Rejects_Unknown_Schema()
    {
        string json = "{\"schemaVersion\":999}";
        Assert.IsFalse(SaveDataCodec.TryDeserialize(json, out _));
    }

    [Test]
    public void Rejects_Empty_Json()
    {
        Assert.IsFalse(SaveDataCodec.TryDeserialize(string.Empty, out _));
    }

    [Test]
    public void RoundTrip_Preserves_Stage_Progress()
    {
        var input = new SaveData { highestClearedStage = 3, totalCoins = 10 };
        string json = SaveDataCodec.Serialize(input);
        bool ok = SaveDataCodec.TryDeserialize(json, out SaveData result);
        Assert.IsTrue(ok);
        Assert.AreEqual(3, result.highestClearedStage);
        Assert.AreEqual(10, result.totalCoins);
    }
}
