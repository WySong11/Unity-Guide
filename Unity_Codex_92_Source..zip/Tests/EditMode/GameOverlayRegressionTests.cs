using NUnit.Framework;

// Requires StageRunState and GameUiRules from WAVE GUARD days 87-88.
public class GameOverlayRegressionTests
{
    [TestCase(StageRunState.Clear, true, GameOverlay.Clear)]
    [TestCase(StageRunState.GameOver, true, GameOverlay.GameOver)]
    [TestCase(StageRunState.Fighting, true, GameOverlay.Pause)]
    [TestCase(StageRunState.Fighting, false, GameOverlay.None)]
    [TestCase(StageRunState.Spawning, true, GameOverlay.Pause)]
    [TestCase(StageRunState.Idle, true, GameOverlay.None)]
    public void Overlay_Respects_State_Priority(
        StageRunState state, bool paused, GameOverlay expected)
    {
        Assert.AreEqual(expected, GameUiRules.SelectOverlay(state, paused));
    }

    [Test]
    public void CanPause_OnlyInPlayingStates()
    {
        Assert.IsTrue(GameUiRules.CanPause(StageRunState.Spawning));
        Assert.IsTrue(GameUiRules.CanPause(StageRunState.Fighting));
        Assert.IsFalse(GameUiRules.CanPause(StageRunState.GameOver));
        Assert.IsFalse(GameUiRules.CanPause(StageRunState.Clear));
        Assert.IsFalse(GameUiRules.CanPause(StageRunState.Idle));
    }
}
