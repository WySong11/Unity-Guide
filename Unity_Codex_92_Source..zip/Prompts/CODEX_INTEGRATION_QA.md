# Codex 통합 테스트 프롬프트 3종

## 1. 읽기 전용 통합 진단

```text
WAVE GUARD Unity 6.3 프로젝트를 읽기 전용으로 조사해줘.
대상: PlayerHealth, EnemyHealth, StageWaveController, StageUIController,
StageClearSaveBridge, SkillCooldown, AudioSettingsController 및 관련 테스트.

1. 이벤트 구독/해제, 상태 우선순위, Time.timeScale, 씬 전환,
   Save/Load 경계의 통합 결함 가능성 확인
2. 각 finding에 파일/메서드/재현 단계/영향도 제시
3. P0/P1 우선 정렬, 확실한 근거와 가설 구분
4. 어떠한 소스도 수정하지 말 것
5. 확인하지 못한 부분은 '미검증'으로 표시
```

## 2. 실패 재현 → 최소 수정

```text
BUG-004를 다음 순서로 처리해줘.
증상: Pause→Resume 후 이동이 가끔 멈춤.
1. 실행 환경, 관련 상태·이벤트 경로 조사
2. 재현 가능한 테스트 또는 단계별 수동 시나리오 작성
3. 수정 전 실패 증거 확보 (미재현이면 원인 단정 금지)
4. Player/Input/UI 관련 최소 변경만 수행
5. public API, SerializeField 이름, Scene 참조 유지
6. EditMode/PlayMode 관련 테스트 재실행
7. 변경 파일·Git diff·남은 위험 보고
8. 테스트를 실제 실행 못하면 '미실행'으로 기록
```

## 3. 독립 회귀 검증

```text
현재 Git diff와 TEST_PLAN.md를 기준으로 독립 검증해줘.
- BUG-004 재현 단계 변경 후에도 정확히 수행되는지 확인
- TC-001~TC-010 중 영향받는 항목 재실행
- EditMode/PlayMode 결과 XML 확인 (없으면 미실행)
- 이벤트 중복 등록, Time.timeScale, 씬 복귀 점검
- 컴파일 오류, NullReference, 저장 데이터 손상 위험 조사
- 파일 경로·라인·심각도 중심으로 발견사항 보고
- 새로운 수정은 하지 말고 검증 보고서만 작성
- 실패/미실행/차단을 PASS로 기록하지 말 것
```
