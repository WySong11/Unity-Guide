# 92일차 | 통합 테스트 및 버그 수정 실습 자료

- 목표: 85~91일차 WAVE GUARD 코드의 연결부를 진단하고, 수정 전후의 검증 증거를 남긴다.
- 권장 환경: Unity 6.3 (6000.3), Unity Test Framework, VS Code + Codex, Git.
- 포함된 코드는 테스트 예제이며 **실제 Unity 에디터 컴파일/테스트 실행은 수행하지 않았다.**

## 사전 준비

1. 87일차 `StageWaveController`, `StageRunState`, `WaveRules`를 프로젝트에 통합한다.
2. 88일차 `GameUiRules`, `GameOverlay`, `StageUIController`를 통합한다.
3. 90일차 `SaveData`, `SaveDataCodec`, `GameSaveService`가 정상적으로 존재하는지 확인한다.
4. `Tests/EditMode` 테스트 Assembly Definition을 만든다. 테스트 Assembly는 런타임 코드가 있는 Assembly를 참조해야 하며 Unity Test Framework/NUnit 테스트 참조가 필요하다.
5. `Tests/EditMode/*.cs`를 해당 테스트 Assembly 폴더에 복사한다.
6. Unity Test Runner에서 EditMode 테스트 실행. 씬 간 연결과 기기·파일 저장은 수동 PlayMode/빌드 테스트 시나리오로 수행한다.

## 실습 운영 시 주의

- 테스트 예제의 클래스 및 enum이 이미 프로젝트에 있다면 **동일 이름을 중복 정의하지 않는다.**
- 실제 의도적 버그는 강사/수강생의 실습용 브랜치에서만 삽입한다. 제공된 C# 파일은 오류를 새로 주입하지 않는다.
- 프리팹 및 씬의 SerializeField 명칭을 임의로 변경하지 않는다.
- `Time.timeScale=0`의 영향은 입력·물리·UI·오디오에 동일하지 않을 수 있으므로 별도 검증한다.
- `GameUiRules` 테스트는 게임 상태 정책을 고정하는 단위 테스트이다. 실제 Pause / Resume 통합 동작을 자동으로 증명하지 않는다.
- `SaveDataCodec` 테스트는 저장 파일의 **내용 검증 규칙**만 다룬다. 디스크 쓰기와 재로드는 별도 시나리오다.

## 제공 파일

- `Tests/EditMode/GameOverlayRegressionTests.cs`: 결과 오버레이 우선순위 회귀 테스트
- `Tests/EditMode/SaveRegressionTests.cs`: JSON 저장 데이터 스키마/범위 검증
- `Templates/TEST_PLAN.md`: 통합 테스트 케이스 기록 양식
- `Templates/BUG_REPORT.md`: 오류 재현/분류/수정/재검증 양식
- `Templates/TEST_RESULTS.md`: 테스트 결과·Go/No-Go 양식
- `Templates/SMOKE_TEST_CHECKLIST.csv`: 10개 핵심 시나리오
- `Prompts/CODEX_INTEGRATION_QA.md`: 읽기 전용 진단/최소 수정/독립 검증 3종 프롬프트

## 평가(100점)

테스트 계획 20 · 버그 재현 25 · 수정 품질 20 · 회귀 테스트 25 · Git/보고서 10.

공식 문서 참고
- https://docs.unity.com/en-us/engine/6000.3/manual/programming-environment/test-framework-introduction/running-tests
- https://docs.unity.com/en-us/engine/6000.3/manual/programming-environment/test-framework-introduction/running-tests/run-tests-from-command-line
- https://developers.openai.com/blog/custom-code-review-rules-for-codex
