# AI subsystem instructions

Scope: only files inside `Assets/Scripts/AI/` and its descendants.

- Follow project root `AGENTS.md` and applicable coding/asset rules.
- Separate AI perception, NavMesh movement, FSM decisions, attack actions.
- Document state transitions (Patrol/Chase/Attack/Return/Dead) when editing behavior.
- Avoid unconditional `NavMeshAgent.SetDestination()` in every Update without measuring cost.
- Do not silently alter player movement, input bindings, or unrelated UI scripts.
- Dead state must block future damage-causing attacks and stop movement as appropriate.
- Distinguish code review from actual baked NavMesh/Play Mode behavior.
