#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEngine;

/// <summary>Read-only AGENTS.md document presence check for class use.</summary>
public static class Day65RulesAuditEditor
{
    private static readonly string[] RuleFiles =
    {
        "AGENTS.md", "READ.md", "UNITY_CS_CODING_RULES.md",
        "UNITY_ASSET_RULES.md", "FILE.md", "GIT.md",
        "BUILD.md", "UNITY_TOOLING.md", "HISTORY.md",
        "REVIEW_NOTES.md"
    };

    [MenuItem("Tools/Unity Codex/Day65/Check Rules Docs")]
    private static void CheckRules()
    {
        string root = Directory.GetCurrentDirectory();
        int found = 0;
        foreach (string name in RuleFiles)
        {
            string absolute = Path.Combine(root, name);
            bool exists = File.Exists(absolute);
            if (exists) found++;
            if (exists) Debug.Log($"[Day65 Rules] FOUND: {name}");
            else Debug.LogWarning($"[Day65 Rules] MISSING: {name}");
        }
        Debug.Log($"[Day65 Rules] {found}/{RuleFiles.Length} docs present. " +
                  "Presence check only: it does not prove Codex has read or obeyed them.");
    }
}
#endif
