using UnityEngine;

/// <summary>Subscribes to a gameplay event using a symmetric lifecycle.</summary>
public sealed class Day65HealthPresenter : MonoBehaviour
{
    [SerializeField] private Day65Health health;
    private string label = "No health assigned";

    private void OnEnable()
    {
        if (health == null) return;
        health.Changed += OnHealthChanged;
        OnHealthChanged(health.CurrentHp, health.MaxHp);
    }

    private void OnDisable()
    {
        if (health != null) health.Changed -= OnHealthChanged;
    }

    private void OnHealthChanged(int current, int max)
    {
        label = $"HP: {current} / {max}";
    }

    private void OnGUI()
    {
        GUILayout.BeginArea(new Rect(15, 15, 240, 60), GUI.skin.box);
        GUILayout.Label(label);
        GUILayout.EndArea();
    }
}
