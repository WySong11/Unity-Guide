using UnityEngine;

/// <summary>Simple UI buttons; no Input System package dependency in the lab.</summary>
public sealed class Day65DemoControls : MonoBehaviour
{
    [SerializeField] private Day65Health health;
    private void OnGUI()
    {
        if (health == null) return;
        GUILayout.BeginArea(new Rect(15, 85, 240, 145), GUI.skin.box);
        if (GUILayout.Button("Damage 20")) health.Damage(20);
        if (GUILayout.Button("Heal 10")) health.Heal(10);
        if (GUILayout.Button("Reset")) health.ResetToFull();
        GUILayout.EndArea();
    }
}
