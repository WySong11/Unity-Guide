using System;
using UnityEngine;

/// <summary>Small independent C# example for reviewing Day65 project rules.</summary>
public sealed class Day65Health : MonoBehaviour
{
    [SerializeField, Min(1)] private int maxHp = 100;

    public event Action<int, int> Changed;
    public event Action Died;

    public int MaxHp => Mathf.Max(1, maxHp);
    public int CurrentHp { get; private set; }
    public bool IsAlive => CurrentHp > 0;

    private void Awake() => CurrentHp = MaxHp;

    public void Damage(int amount)
    {
        if (amount <= 0 || !IsAlive) return;
        CurrentHp = Mathf.Max(0, CurrentHp - amount);
        Changed?.Invoke(CurrentHp, MaxHp);
        if (!IsAlive) Died?.Invoke();
    }

    public bool Heal(int amount)
    {
        if (amount <= 0 || !IsAlive || CurrentHp >= MaxHp) return false;
        CurrentHp = Mathf.Min(MaxHp, CurrentHp + amount);
        Changed?.Invoke(CurrentHp, MaxHp);
        return true;
    }

    public void ResetToFull()
    {
        CurrentHp = MaxHp;
        Changed?.Invoke(CurrentHp, MaxHp);
    }
}
