# READ.md — 프로젝트 시작 안내

1. `AGENTS.md`에서 개발 대상, 수정 범위, 적용할 상세 규칙 문서를 확인합니다.
2. Unity 버전 `6000.3.x` 및 URP/New Input System 설정을 현재 `ProjectSettings`, `Packages/manifest.json`과 대조합니다. 프로젝트 버전이 다르면 추측하지 말고 확인합니다.
3. Git 상태와 대상 파일의 기존 변경 사항을 먼저 확인합니다.
4. C# 작업은 `UNITY_CS_CODING_RULES.md`, Asset 작업은 `UNITY_ASSET_RULES.md`, Git 작업은 `GIT.md`, 실행 검증은 `BUILD.md`를 따릅니다.
5. Unity 도구는 `UNITY_TOOLING.md`를 참조합니다.
6. 작업 완료 후 변경 파일·검증 증거·미실행 테스트·남은 위험을 명시합니다.

이 문서는 시작 위치입니다. 다른 문서를 항상 한꺼번에 읽을 필요는 없습니다.
