# UNITY_ASSET_RULES.md — Unity 에셋 안전

- Unity Scene, Prefab, Animation, ScriptableObject, Material, AudioMixer, Package manifest는 기본적으로 사용자 데이터로 취급합니다.
- Unity 파일 이동·삭제 시 `.meta` 파일과 GUID 참조 관계를 유지합니다. 외부 텍스트 편집이 필요할 때는 원본 백업과 참조 검사를 먼저 수행합니다.
- Prefab 수정 전 Base/Variant/Instance와 Override 영향 범위를 확인합니다.
- 의도하지 않은 씬 오브젝트 변경, ProjectSettings 변경, 패키지 업그레이드를 수행하지 않습니다.
- Asset Database 갱신이 필요한 작업은 가능하면 Unity Editor 또는 연결된 공식 툴을 이용합니다.
- 임시 테스트 씬/Prefab은 별도 폴더에 생성하고, 기존 폴더에 덮어쓰지 않습니다.
- 코드 변경만 요청된 경우 `.unity`, `.prefab`, `.asset`, `.meta` 수정이 필요한지 설명하고 확인합니다.
- 빌드 출력·`Library`, `Temp`, `obj` 등 생성물은 소스처럼 편집하지 않습니다.
