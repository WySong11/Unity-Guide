# HISTORY.md — 변경 이력

기록은 사용자 요청 또는 프로젝트 규칙에서 요구한 경우에만 추가합니다. 이 파일은 정책을 중복 정의하지 않습니다.

| 날짜 | 변경 내용 | 변경 파일 | 검증 결과 | 미해결 사항 |
|---|---|---|---|---|
| YYYY-MM-DD | 예: Health 이벤트 대칭 처리 | Assets/.../Day65Health.cs | Static PASS / Editor NOT RUN | Play Mode 확인 필요 |
