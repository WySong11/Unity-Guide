# UNITY_CS_CODING_RULES.md — Unity C# 규칙

## API·프로젝트 기반
- 목표 프로젝트의 `ProjectVersion.txt`와 설치 패키지를 기준으로 API 호환성을 확인합니다. 예제는 Unity 6.3 / URP / New Input System을 가정합니다.
- Unity 6 `Rigidbody.linearVelocity` 사용 시, 2D/3D 컴포넌트를 구분하고 기존 프로젝트 기준을 확인합니다.
- Input System 기존 Action 및 이벤트 바인딩을 임의로 교체하지 않습니다.

## 데이터·컴포넌트
- Inspector에 노출할 설정값은 가능하면 `[SerializeField] private`로 선언합니다. 직렬화 데이터와 런타임 상태를 분리합니다.
- 한 MonoBehaviour의 책임은 작게 유지합니다. 입력, 이동, 체력, AI, UI를 무리하게 한 클래스로 합치지 않습니다.
- 스크립트 파일명과 public 타입명을 맞춥니다. 신규 데모 클래스는 명시된 접두사를 사용합니다.
- 이벤트 구독과 해제는 `OnEnable`/`OnDisable` 같은 대칭 생명주기로 관리합니다.
- 매 프레임 `Find*`, 반복적인 `GetComponent` 호출이 필요한지 검토하고 필요한 참조는 캐시합니다.
- `Update`, `FixedUpdate`, Coroutine, async 요청은 현재 상태·취소·비활성화 시점을 고려합니다.
- `OnDisable`/`OnDestroy` 시 남은 Coroutine, 예약 작업, 이벤트, Object Pool 반환 등 누수를 점검합니다.

## 검증
- 수정한 코드의 null 경로, 범위값, 중복 호출, 이벤트 구독, 풀 재사용 초기화를 검토합니다.
- Unity Editor가 없으면 `compile/play mode: NOT RUN`으로 보고하고 프로젝트 사용자에게 재현 절차를 제공합니다.
- 오류를 숨기는 빈 catch는 사용하지 않습니다. 오류 정보와 사용자 영향 범위를 기록합니다.
