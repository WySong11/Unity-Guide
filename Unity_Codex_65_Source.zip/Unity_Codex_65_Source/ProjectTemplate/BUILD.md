# BUILD.md — 검증 및 보고

## 테스트 구분
| 테스트 수준 | 증거 예시 | 미수행 시 |
|---|---|---|
| Static | 변경 diff, 검사 스크립트 | NOT RUN |
| Unity Compile | Unity Editor Console, 로그 | NOT RUN 또는 BLOCKED |
| Play Mode | 직접 시연, 녹화, 상태 로그 | NOT RUN 또는 BLOCKED |
| Build | Unity 빌드 결과, 로그, 산출물 | NOT RUN 또는 BLOCKED |
| Device | 기기별 동작 로그와 버전 | NOT RUN 또는 BLOCKED |

## Unity 6.3 프로젝트 확인
- 실제 버전은 `ProjectSettings/ProjectVersion.txt`로 확인합니다.
- 씬 빌드는 프로젝트의 Build Profiles/Scene List 등 현재 Unity 버전의 구성을 확인합니다.
- C# 컴파일 오류, MissingReferenceException, 중복 이벤트, 게임 상태 초기화 등을 확인합니다.
- 빌드를 실행하지 못했다면 파일 존재 여부만으로 PASS로 표시하지 않습니다.

## 완료 보고 포맷
```text
Files changed: <paths>
Static checks: PASS/FAIL/NOT RUN + evidence
Unity compilation: PASS/FAIL/NOT RUN/BLOCKED + evidence
Play Mode: PASS/FAIL/NOT RUN/BLOCKED + evidence
Build/device: PASS/FAIL/NOT RUN/BLOCKED + evidence
Remaining risks: <concrete items>
```
