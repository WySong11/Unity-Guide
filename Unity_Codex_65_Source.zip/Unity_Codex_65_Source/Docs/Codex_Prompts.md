# VS Code Codex 실습 프롬프트

## P1 — 적용 규칙 경로 확인
프로젝트 현재 경로를 확인하고, 내가 지정한 대상 `Assets/Day65_RulesLab/Runtime/Day65Health.cs`에 적용되는 AGENTS.md와 작업별 관련 상세 규칙 문서의 실제 파일 경로를 나열해줘. 없는 파일은 없다고 보고하고 추측하지 마. 파일 변경은 하지 마.

## P2 — Health 규칙 리뷰
Day65Health/Day65HealthPresenter를 읽고 UNITY_CS_CODING_RULES.md와 AGENTS.md에 비추어 규칙 준수 여부·Null 경로·이벤트 구독/해제·HP 범위를 점검해줘. 수정 전에는 최소 diff 계획부터 제시해줘.

## P3 — AI 하위 규칙
`Assets/Scripts/AI/` 안의 파일을 대상으로 루트 AGENTS.md와 중첩 AGENTS.md 중 어떤 규칙이 적용되는지 설명해줘. AI 폴더 밖 Player 스크립트에는 하위 규칙을 적용하지 마. 실제 파일 수정은 하지 마.

## P4 — 검증 수준 보고
실제로 실행한 `git status`/`git diff --check`/Unity Editor 컴파일/Play Mode를 각각 표로 정리해줘. 실행할 수 없는 항목은 이유와 함께 NOT RUN 또는 BLOCKED라고 써줘. PASS를 추측하지 마.

## P5 — Unity 에셋 안전
기존 씬·Prefab·.meta·Packages를 건드리지 않고 대상 스크립트만 수정할 방법을 제안해줘. 파일 변경 전 영향받는 GUID 참조와 사용자 변경 여부를 확인해줘.

## P6 — 범위·Git 점검
이번 과제의 변경 파일 목록과 `git diff`를 검토해줘. 사용자 작업을 보존하고 요청받지 않은 commit, push, reset, clean은 실행하지 마.

## P7 — 규칙 충돌 분석
루트 AGENTS.md, 하위 AGENTS.md, GIT.md, FILE.md 지침이 충돌한다면 실제 적용 범위와 지시 우선순위를 설명해줘. 안전 권한을 AGENTS.md로 변경할 수 있다는 주장은 하지 마.

## 최종 보고 문구
`Changed files / Rule sources / Checks run / PASS-FAIL-NOT RUN-BLOCKED / Remaining risks` 형식으로 결과를 제출해줘.
