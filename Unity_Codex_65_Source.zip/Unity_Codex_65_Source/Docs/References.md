# 공식 참고 자료

- Codex repository AGENTS.md specification (OpenAI Codex source): https://github.com/openai/codex/blob/main/codex-rs/protocol/src/prompts/base_instructions/default.md
- OpenAI Cookbook, Iterating development workflows with Codex: https://developers.openai.com/cookbook/examples/codex/iterating-development-workflows-with-codex
- Codex AGENTS.md discovery implementation: https://github.com/openai/codex/blob/main/codex-rs/core/src/agents_md.rs
- Unity Scripting API: https://docs.unity3d.com/ScriptReference/

실제 기능과 CLI/MCP 명령 구문은 설치한 Codex/Unity 버전의 공식 문서 및 도움말과 대조합니다.
