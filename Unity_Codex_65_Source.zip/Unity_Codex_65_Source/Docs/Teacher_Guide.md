# 강사용 진행 가이드 (120분)

| 시간 | 활동 | 피드백 포인트 |
|---|---|---|
| 0~20 | AGENTS.md 개념·스코프 | 루트/하위/사용자 지시/실제 권한을 구분 |
| 20~55 | 루트 AGENTS와 FILE/GIT/BUILD 등 문서 분리 | 단일 기준, 관련 시점에만 읽게 지시 |
| 55~95 | Codex P1~P7, Health 수정/리뷰, AI 중첩 규칙 | git status/diff와 실제 로그 확인 |
| 95~120 | T01~T12, 미실행 검증 표기, 발표 | 사실 기반 평가, 안전한 문서 병합 |

## 시연 팁
- 원래 Unity 프로젝트에서 기존 AGENTS.md를 덮어쓰지 마세요. 템플릿 비교 → 변경 의도 → 병합 순서를 시연합니다.
- Codex에 `이 프로젝트에서 해당 코드에 적용되는 규칙 파일을 모두 설명해줘`라고 요청하고, 실제 출력된 경로를 확인합니다.
- `Day65DemoControls`와 `Day65HealthPresenter`를 같은 GameObject에 부착한 뒤 `Day65Health` 참조를 Inspector에 연결합니다.
- Unity Editor 메뉴 `Tools > Unity Codex > Day65 > Check Rules Docs`는 파일 존재 여부만 검사합니다. 규칙 준수와 테스트 성공을 보장하지 않습니다.
- 샌드박스가 read-only라면 Code 변경/테스트를 우회하지 말고 BLOCKED로 기록합니다.

## 채점
목적·범위 25 / 문서 분리·연결 25 / Unity C# 규칙 실습 20 / 안전·테스트 15 / Codex 결과·발표 15 = 100점.
