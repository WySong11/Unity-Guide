# Unity × Codex — 65일차 AGENTS.md 프로젝트 규칙

**대상:** Unity 6.3·URP·New Input System 프로젝트 / 120분 수업 / 44장 강의자료.

## 설치하기 전에
1. 원래 프로젝트를 Git에 백업하거나 작업 브랜치를 만듭니다. 변경 중인 사용자 파일은 보존합니다.
2. `ProjectTemplate/AGENTS.md`는 **참고 템플릿**입니다. 기존 프로젝트 루트에 `AGENTS.md`가 이미 있으면 덮어쓰지 말고 차이와 우선순위를 검토한 후 필요한 조항만 병합하세요.
3. `READ.md`, `GIT.md`, `FILE.md` 등 규칙 문서도 동일하게 **기존 문서 보존 후 선택 병합**합니다.
4. `ProjectTemplate/Assets/Day65_RulesLab/`만 Unity 프로젝트의 `Assets/` 안으로 복사하면 별도 C# 샘플을 사용할 수 있습니다. 다른 코드와 이름이 충돌하지 않도록 `Day65` 접두사를 사용했습니다.
5. `Assets/Scripts/AI/AGENTS.md`는 AI 전용 하위 규칙의 **배치 예시**입니다. 실제 프로젝트의 AI 경로를 확인한 후 적용하세요.
6. VS Code Codex를 프로젝트 루트에서 실행하고 `Docs/Codex_Prompts.md`의 P1~P7을 사용하세요. AGENTS.md 적용 여부는 실제 Codex 결과·diff·로그로 확인합니다.

## 자료 구성
- `ProjectTemplate/AGENTS.md`: 루트 작업 지침과 규칙 인덱스
- `ProjectTemplate/READ.md`: 빠른 온보딩
- `ProjectTemplate/UNITY_CS_CODING_RULES.md`: Unity C# 규칙
- `ProjectTemplate/UNITY_ASSET_RULES.md`: Asset/Prefab/Scene/.meta 규칙
- `ProjectTemplate/FILE.md`: 파일 추가·이동·삭제 원칙
- `ProjectTemplate/GIT.md`: 브랜치·커밋·Push 안전 원칙
- `ProjectTemplate/BUILD.md`: Editor 컴파일·Play Mode·빌드 증거
- `ProjectTemplate/UNITY_TOOLING.md`: Unity CLI/MCP 시작 시 한 번 점검, 오류 시 재확인
- `ProjectTemplate/HISTORY.md`: 변경 이력 서식
- `ProjectTemplate/REVIEW_NOTES.md`: 코드 리뷰 기록 서식
- `ProjectTemplate/Assets/Scripts/AI/AGENTS.md`: 하위 폴더 범위 지침 예시
- `ProjectTemplate/Assets/Day65_RulesLab`: Unity 6 테스트 컴포넌트 및 정적 문서 점검 메뉴
- `Docs`: 교강사 안내·학생 활동지·Codex 프롬프트·테스트표·평가표·공식 참고자료

## 실습 시간 배분
00~20 AGENTS.md 개념 및 범위 / 20~55 규칙 문서 작성 / 55~95 Codex 리팩터링 / 95~120 테스트·발표·평가.

## 주의 사항
- `AGENTS.md`는 프로젝트 지침이지 샌드박스·승인·네트워크 권한 설정 파일이 아닙니다.
- Codex가 다른 `.md`를 **항상 자동으로 읽는다고 가정하면 안 됩니다**. 루트 AGENTS에 작업별로 읽을 문서를 안내하고 실제 수행 내역을 확인하세요.
- Windows/VS Code, Unity Editor, Git, Unity CLI/MCP 설치 상태에 따라 실행 가능한 도구가 다릅니다. 실습 자료에서는 CLI/MCP 연결을 **보장하지 않습니다**.
- 강의 자료는 실제 Unity Editor에서 컴파일·Play Mode 실행된 결과가 아닙니다. 실행 검증 후에만 PASS를 기록하세요.
