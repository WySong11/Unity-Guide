// WAVE GUARD - Day 88. Requires StageRunState from Day 87.
public enum GameOverlay { None, Pause, Clear, GameOver }

public static class GameUiRules
{
    public static bool CanPause(StageRunState state) =>
        state == StageRunState.Spawning || state == StageRunState.Fighting;

    public static GameOverlay SelectOverlay(StageRunState state, bool paused)
    {
        if (state == StageRunState.Clear) return GameOverlay.Clear;
        if (state == StageRunState.GameOver) return GameOverlay.GameOver;
        return paused && CanPause(state) ? GameOverlay.Pause : GameOverlay.None;
    }
}
