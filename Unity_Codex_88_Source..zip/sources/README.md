# Day 88 · WAVE GUARD UI와 게임 루프

## Unity/프로젝트 조건
- Unity 6.3 LTS, URP 2D, Input System, uGUI, TextMeshPro
- 85일차 `PlayerHealth`(HealthChanged, Died, MaxHealth, CurrentHealth), `PlayerMotor2D`(SetHorizontal)
- 87일차 `StageWaveController`(State, StateChanged, WaveStarted, AliveChanged), `StageHUD` 및 `StageRunState`
- 위 스크립트는 프로젝트에 이미 있어야 합니다. 동일 클래스 중복 추가 금지.

## 씬 생성
1. `Title`과 `Stage_01` 두 씬을 만들고 `File > Build Profiles > Scene List`에 등록합니다.
2. Title Canvas: TitlePanel, StartButton, QuitButton, EventSystem을 추가합니다.
3. Stage Canvas: HudRoot(HpText/WaveText/AliveText/StatusText/PauseButton), PausePanel, ClearPanel, GameOverPanel. 결과/일시정지 패널은 처음에 비활성화합니다.
4. Canvas Scaler는 Scale With Screen Size (예: 1920×1080), Anchors는 각 UI에 맞춰 설정합니다.
5. EventSystem에는 `InputSystemUIInputModule`을 사용하고 Pointer/Click/Submit/Cancel 등 UI Action이 설정돼 있는지 확인합니다. **중요**: gameplayInput.DeactivateInput()이 UI 입력까지 끄지 않도록 UI 입력 액션과 플레이어 입력을 독립적으로 구성합니다.

## 컴포넌트 연결
1. Title의 빈 오브젝트 `TitleSystem`에 `TitleMenuController` 부착. `gameSceneName = Stage_01`.
2. StartButton → `TitleMenuController.StartGame`, QuitButton → `QuitGame`.
3. Stage의 빈 오브젝트 `UIController`에 `StageUIController` 부착.
4. `stage`: 전일차 StageWaveController; `gameplayInput`: 85일차 PlayerInput; `playerMotor`: 플레이어 이동 컨트롤러(선택).
5. `hudRoot`/`pausePanel`/`clearPanel`/`gameOverPanel`은 Canvas 하위 패널을 Inspector에서 연결.
6. PauseButton → `TogglePause`, ResumeButton → `Resume`, RestartButton → `RestartStage`, TitleButton → `ReturnToTitle`.
7. 기존 `StageHUD`(WaveStarted/AliveChanged/StateChanged)와 `PlayerHpView`(HealthChanged)를 HudRoot 내부에 연결.

## 실습 포인트
- Title → Stage는 씬 전환이며 StageWaveController.Start()가 웨이브를 시작합니다.
- Pause는 `Time.timeScale = 0`을 사용하지만 Update와 UI 입력은 계속 처리됩니다. 게임플레이 입력은 분리해 꺼둡니다.
- Clear/GameOver는 `StageWaveController.StateChanged`에서 수신합니다. Pause와 결과는 동시에 보이지 않습니다.
- Restart 또는 Title 이동 전 `Time.timeScale = 1f`를 복구해야 합니다.
- Android Back 키는 단말/입력 설정에 따라 다를 수 있으므로 실제 기기 확인이 필요합니다. Pause 버튼을 함께 제공합니다.
- `SceneManager.LoadScene()`은 단순 실습용. 규모가 커지면 LoadSceneAsync + 로딩 패널로 확장합니다.

## 테스트
EditMode Test Assembly에서 `GameUiRulesTests` 실행; StageRunState가 들어 있는 Assembly를 참조하도록 설정합니다.
PlayMode에서 Title → 시작 → HUD 갱신 → Pause/Resume → 3 Wave Clear → Restart → Player Die → GameOver → Title을 검증합니다.

## 주의
- 게임 루프 제어와 UI 표시를 동일 책임으로 뭉치지 않습니다. 87일차 StageWaveController는 웨이브 상태를, StageUIController는 패널/버튼/일시정지를 맡습니다.
- GameUiRulesTests는 순수 상태 정책을 검증합니다. UI Button 연결과 씬 재시작은 PlayMode 수동/자동 테스트로 별도 검증합니다.
- 본 예제는 PC 중심이며 모바일 Safe Area/해상도 대응은 프로젝트에 맞게 확장합니다.
