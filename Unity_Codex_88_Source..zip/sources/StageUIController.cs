using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

// The EventSystem's InputSystemUIInputModule must remain enabled while
// gameplayInput is deactivated. Use an independent UI input-actions setup.
public class StageUIController : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private StageWaveController stage;
    [SerializeField] private PlayerInput gameplayInput;
    [SerializeField] private PlayerMotor2D playerMotor;

    [Header("Panels")]
    [SerializeField] private GameObject hudRoot;
    [SerializeField] private GameObject pausePanel;
    [SerializeField] private GameObject clearPanel;
    [SerializeField] private GameObject gameOverPanel;

    [Header("Scenes")]
    [SerializeField] private string titleSceneName = "Title";

    private bool isPaused;
    private bool isResult;
    private bool navigating;

    private void Awake()
    {
        Time.timeScale = 1f;
        RefreshPanels();
    }

    private void OnEnable()
    {
        if (stage != null) stage.StateChanged += OnStageStateChanged;
    }

    private void Start()
    {
        if (stage == null)
        {
            Debug.LogError("[StageUI] StageWaveController reference is missing.", this);
            return;
        }
        OnStageStateChanged(stage.State); // Also handles an already-changed state.
    }

    private void Update()
    {
        if (Keyboard.current != null && Keyboard.current.escapeKey.wasPressedThisFrame)
            TogglePause();
    }

    private void OnStageStateChanged(StageRunState state)
    {
        if (!isResult && (state == StageRunState.Clear || state == StageRunState.GameOver))
        {
            isResult = true;
            isPaused = false;
            gameplayInput?.DeactivateInput();
            playerMotor?.SetHorizontal(0f);
            Time.timeScale = 0f;
        }
        RefreshPanels();
    }

    public void TogglePause()
    {
        if (stage == null || isResult || !GameUiRules.CanPause(stage.State)) return;
        SetPaused(!isPaused);
    }

    public void Resume()
    {
        if (isResult) return;
        SetPaused(false);
    }

    private void SetPaused(bool paused)
    {
        isPaused = paused;
        if (paused)
        {
            playerMotor?.SetHorizontal(0f);
            gameplayInput?.DeactivateInput();
        }
        else
        {
            gameplayInput?.ActivateInput();
        }
        Time.timeScale = paused ? 0f : 1f;
        RefreshPanels();
    }

    private void RefreshPanels()
    {
        var overlay = GameUiRules.SelectOverlay(
            stage != null ? stage.State : StageRunState.Idle, isPaused);
        if (hudRoot != null) hudRoot.SetActive(!isResult);
        if (pausePanel != null) pausePanel.SetActive(overlay == GameOverlay.Pause);
        if (clearPanel != null) clearPanel.SetActive(overlay == GameOverlay.Clear);
        if (gameOverPanel != null) gameOverPanel.SetActive(overlay == GameOverlay.GameOver);
    }

    public void RestartStage()
    {
        if (navigating) return;
        navigating = true;
        Time.timeScale = 1f; // Restore before changing scenes.
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    public void ReturnToTitle()
    {
        if (navigating) return;
        navigating = true;
        Time.timeScale = 1f;
        SceneManager.LoadScene(titleSceneName);
    }

    private void OnDisable()
    {
        if (stage != null) stage.StateChanged -= OnStageStateChanged;
    }

    private void OnDestroy()
    {
        Time.timeScale = 1f; // Safety when this controller is destroyed.
    }
}
