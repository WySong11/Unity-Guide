using NUnit.Framework;

public class GameUiRulesTests
{
    [TestCase(StageRunState.Idle, false)]
    [TestCase(StageRunState.Spawning, true)]
    [TestCase(StageRunState.Fighting, true)]
    [TestCase(StageRunState.Clear, false)]
    [TestCase(StageRunState.GameOver, false)]
    public void CanPause_OnlyDuringGameplay(StageRunState state, bool expected)
    {
        Assert.AreEqual(expected, GameUiRules.CanPause(state));
    }

    [Test]
    public void GameOver_HasPriorityOverPause()
    {
        var result = GameUiRules.SelectOverlay(StageRunState.GameOver, true);
        Assert.AreEqual(GameOverlay.GameOver, result);
    }

    [Test]
    public void Clear_HasPriorityOverPause()
    {
        var result = GameUiRules.SelectOverlay(StageRunState.Clear, true);
        Assert.AreEqual(GameOverlay.Clear, result);
    }

    [Test]
    public void Fighting_Paused_ShowsPause()
    {
        var result = GameUiRules.SelectOverlay(StageRunState.Fighting, true);
        Assert.AreEqual(GameOverlay.Pause, result);
    }
}
