# Unity × Codex — 33일차 좌표계와 Vector3

권장 환경: Unity 6.3 (6000.3 계열), 3D URP, Input System 패키지.

## 시작하기
1. Unity Hub → 새 프로젝트 → **Universal 3D** 생성 (또는 기존 3D 프로젝트 사용).
2. `Assets/Day33/Scripts` 폴더에 `Scripts/*.cs`를 복사합니다.
3. Hierarchy에 빈 GameObject `Day33Demos`를 만든 후 실습별 스크립트를 추가합니다.
4. `Day33WorldLocalMover.cs`는 **Input System 패키지**가 필요합니다. Package Manager에서 `Input System`이 설치되어 있는지 확인하세요.
5. Edit → Project Settings → Player → Active Input Handling은 `Input System Package (New)` 또는 `Both`로 맞춘 후 요구되면 Editor를 재시작합니다.

## 예제별 설정
- **Vector3Explorer**: Cube에 부착 → Component 톱니 메뉴의 `Print Vector3 Values` 실행 → Scene에서 Cube를 선택하면 Gizmos 표시.
- **WorldLocalMover**: Cube에 부착 → Y 회전을 45°로 설정 → `Movement Space`를 `World`/`Self`로 바꾸어 Play Mode에서 WASD 비교.
- **TargetDistance**: Cube A에 부착 → Target에 Cube B 연결 → 컴포넌트 메뉴 `Print Target Distance` 실행 → Scene Gizmos 확인.
- **MoveTowards**: Cube A에 부착 → Target에 Cube B 연결 → Play 후 일정한 속도로 접근하는지 확인.
- **CoordinateConverter**: 회전시킨 Cube에 부착 → `Print Converted Coordinates` 실행 → `TransformPoint`와 `TransformDirection` 결과 비교.
- **SpawnOffsetDemo**: 빈 SpawnOrigin과 임의 Prefab 연결 → 컴포넌트 메뉴의 `Spawn At Local Offset` 실행.

## 핵심 개념
- `transform.position`: 월드 좌표, `transform.localPosition`: 부모 기준 로컬 좌표.
- `Vector3`는 x, y, z 세 개의 float를 가진 값 형식이며 **위치·방향·오프셋**을 표현할 수 있습니다.
- 방향 벡터는 `(목표 위치 - 현재 위치)`이고, `.normalized`는 길이 1의 방향 벡터입니다.
- `TransformPoint`는 **위치**를 로컬 → 월드로 변환하며 스케일 영향을 받습니다.
- `TransformDirection`은 **방향**을 로컬 → 월드로 변환하며 위치 이동·스케일을 적용하지 않습니다.
- 이 프로젝트의 Transform 기반 이동은 좌표 학습용입니다. Rigidbody가 있는 물리 게임에서는 이동 방식이 달라질 수 있습니다.

## 반드시 확인할 테스트
1. 같은 W 입력에 대해 World 모드는 월드 +Z, Self 모드는 오브젝트 전방으로 이동하는가?
2. 부모 Transform을 회전/이동하면 자식의 world `position`이 변해도 `localPosition`은 유지되는가?
3. `Vector3.Distance(A,B)`와 `(B.position - A.position).magnitude`가 일치하는가?
4. `MoveTowards`가 프레임 속도와 무관하게 일정 속도로 접근하는가?
5. `TransformPoint` 후 `InverseTransformPoint`가 원래 로컬 좌표를 복원하는가?
6. target/prefab 참조가 없을 때 예외 대신 경고가 표시되는가?

## 공식 문서
- https://docs.unity3d.com/ScriptReference/Vector3.html
- https://docs.unity3d.com/ScriptReference/Transform-position.html
- https://docs.unity3d.com/ScriptReference/Transform-localPosition.html
- https://docs.unity3d.com/ScriptReference/Transform.Translate.html
- https://docs.unity3d.com/ScriptReference/Transform.TransformPoint.html
- https://docs.unity3d.com/ScriptReference/Transform.TransformDirection.html
