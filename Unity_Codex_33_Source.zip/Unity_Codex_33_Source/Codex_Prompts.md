# 33일차 Codex 실습 프롬프트

## Prompt 1 — 기존 코드 분석
Unity 6.3 3D 프로젝트에서 좌표계 개념을 학습 중입니다. 현재 프로젝트의 이동 코드에서 `transform.position`, `localPosition`, `Translate`, `Space.World`, `Space.Self` 사용 부분을 찾아 월드/로컬 좌표계 혼동 위험을 분석해 주세요. 먼저 파일과 영향 범위를 정리하고, 아직 코드는 수정하지 마세요.

## Prompt 2 — 월드/로컬 이동 구현
`Day33WorldLocalMover.cs`를 참고하여 WASD 이동 샘플을 작성/점검해 주세요. Unity Input System의 `Keyboard.current`를 사용하고, 이동 벡터 정규화, `Time.deltaTime`, `Space.World`/`Space.Self` 비교 기능을 넣어 주세요. 기존 이동 시스템을 덮어쓰지 말고 새 데모 스크립트로 구현하세요.

## Prompt 3 — 좌표 변환 기능
로컬 스폰 오프셋 `(0, 0, 1.5)`를 월드 위치로 변환해 Prefab을 생성하는 샘플을 작성해 주세요. `TransformPoint`와 `TransformDirection`의 역할을 혼동하지 않도록 설명하고, 누락된 Inspector 참조를 방어 처리하세요.

## Prompt 4 — 검증 보고
다음 항목의 테스트를 제안하고 가능한 항목만 실제 수행해 주세요: 컴파일, Inspector 참조, World/Self 이동 차이, 대각선 속도, Distance 계산, TransformPoint 역변환. 실행하지 못한 테스트는 **미검증**으로 표시해 주세요. 수정한 파일 목록, `git diff`, 재현/검증 단계도 보고하세요.
