# 33일차 강사용 정답 및 평가 참고

## 43번 슬라이드 퀴즈 정답
1. 부모가 존재하고 부모의 위치·회전·스케일 등이 월드 공간에 영향을 미칠 때 `position`과 `localPosition`이 달라질 수 있습니다.
2. `B - A = (3, 0, 4)`.
3. `(3, 0, 4).normalized`의 길이는 `1`이며 결과는 대략 `(0.6, 0, 0.8)`입니다.
4. World는 씬 +Z 기준으로, Self는 오브젝트의 회전된 로컬 +Z를 따라 이동합니다. Y=45°일 때 경로가 달라집니다.
5. `Transform.TransformPoint(localPoint)`입니다. 역변환은 `InverseTransformPoint()`입니다.

## 워크시트 채점 가이드 (100점)
- A 월드/로컬 20점: 부모-자식 설정 10, 위치 변화 관찰/기록 10
- B Vector3 30점: 차벡터 10, 거리 10, 단위방향과 dt 설명 10
- C 이동 30점: World/Self 10, 대각선 정규화 10, MoveTowards 10
- D 검증/제출 20점: 캡처 10, 에러 및 Codex 검증 보고 10

## 주의 사항
- `Transform.position`과 `localPosition`을 구분하고, Inspector가 부모 기준 위치를 보여줄 수 있음을 설명합니다.
- `Vector3.forward`와 `transform.forward` 차이를 Y 회전 사례로 시연합니다.
- `TransformPoint`는 position 변환이므로 scale의 영향을 받는 반면, `TransformDirection`은 scale과 position을 무시하고 회전을 적용합니다.
- 물리 충돌이 중요한 Rigidbody 기반 캐릭터는 `transform.Translate` 예제와 다르게 이동을 설계해야 합니다.
