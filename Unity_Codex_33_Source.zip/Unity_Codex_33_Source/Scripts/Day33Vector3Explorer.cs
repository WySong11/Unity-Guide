using UnityEngine;

/// <summary>
/// 33일차: Vector3 구성 요소와 오브젝트의 월드/로컬 위치를 관찰합니다.
/// </summary>
public class Day33Vector3Explorer : MonoBehaviour
{
    [SerializeField] private Vector3 exampleVector = new Vector3(3f, 2f, 4f);
    [SerializeField, Min(0.1f)] private float axisLength = 2f;

    [ContextMenu("Print Vector3 Values")]
    private void PrintValues()
    {
        Debug.Log($"[Day33] example = {exampleVector}, length = {exampleVector.magnitude:F2}", this);
        Debug.Log($"[Day33] world = {transform.position}, local = {transform.localPosition}", this);
        Debug.Log($"[Day33] forward = {transform.forward}", this);
    }

    private void OnDrawGizmosSelected()
    {
        Vector3 origin = transform.position;
        Gizmos.color = Color.red;
        Gizmos.DrawLine(origin, origin + Vector3.right * axisLength);
        Gizmos.color = Color.green;
        Gizmos.DrawLine(origin, origin + Vector3.up * axisLength);
        Gizmos.color = Color.blue;
        Gizmos.DrawLine(origin, origin + Vector3.forward * axisLength);
        Gizmos.color = Color.yellow;
        Gizmos.DrawSphere(origin + exampleVector, 0.1f);
    }
}
