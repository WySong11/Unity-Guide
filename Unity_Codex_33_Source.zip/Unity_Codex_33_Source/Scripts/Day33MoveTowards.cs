using UnityEngine;

/// <summary>
/// 33일차: 프레임 시간에 독립적인 일정 속도 이동을 실습합니다.
/// 물리 충돌을 처리하는 실제 캐릭터에는 Rigidbody 이동 방식이 더 적합할 수 있습니다.
/// </summary>
public class Day33MoveTowards : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField, Min(0f)] private float moveSpeed = 3f;
    [SerializeField, Min(0f)] private float stopDistance = 0.15f;

    private void Update()
    {
        if (target == null) return;
        float distance = Vector3.Distance(transform.position, target.position);
        if (distance <= stopDistance) return;

        transform.position = Vector3.MoveTowards(
            transform.position,
            target.position,
            moveSpeed * Time.deltaTime);
    }
}
