using UnityEngine;

/// <summary>
/// 33일차: 로컬 점과 월드 점의 변환 및 방향 벡터 변환을 비교합니다.
/// </summary>
public class Day33CoordinateConverter : MonoBehaviour
{
    [SerializeField] private Vector3 localPoint = new Vector3(0f, 0f, 2f);
    [SerializeField] private Vector3 localDirection = Vector3.forward;

    [ContextMenu("Print Converted Coordinates")]
    private void PrintConversions()
    {
        Vector3 worldPoint = transform.TransformPoint(localPoint);
        Vector3 restoredLocalPoint = transform.InverseTransformPoint(worldPoint);
        Vector3 worldDirection = transform.TransformDirection(localDirection);

        Debug.Log($"[Day33] localPoint {localPoint} -> worldPoint {worldPoint}", this);
        Debug.Log($"[Day33] inverse -> localPoint {restoredLocalPoint}", this);
        Debug.Log($"[Day33] direction {localDirection} -> world {worldDirection}", this);
    }

    private void OnDrawGizmosSelected()
    {
        Vector3 worldPoint = transform.TransformPoint(localPoint);
        Gizmos.color = Color.magenta;
        Gizmos.DrawSphere(worldPoint, 0.15f);
        Gizmos.DrawLine(transform.position, worldPoint);
        Gizmos.color = Color.blue;
        Gizmos.DrawLine(transform.position,
                        transform.position + transform.TransformDirection(localDirection) * 2f);
    }
}
