using UnityEngine;

/// <summary>
/// 33일차: 부모(발사 지점)의 로컬 오프셋을 월드 스폰 위치로 바꿉니다.
/// </summary>
public class Day33SpawnOffsetDemo : MonoBehaviour
{
    [SerializeField] private Transform spawnOrigin;
    [SerializeField] private GameObject prefab;
    [SerializeField] private Vector3 localOffset = new Vector3(0f, 0f, 1.5f);

    [ContextMenu("Spawn At Local Offset")]
    public void Spawn()
    {
        if (spawnOrigin == null || prefab == null)
        {
            Debug.LogWarning("[Day33] SpawnOrigin / Prefab 연결을 확인하세요.", this);
            return;
        }

        Vector3 worldPosition = spawnOrigin.TransformPoint(localOffset);
        Instantiate(prefab, worldPosition, spawnOrigin.rotation);
    }
}
