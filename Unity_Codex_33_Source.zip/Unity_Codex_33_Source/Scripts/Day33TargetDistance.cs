using UnityEngine;

/// <summary>
/// 33일차: 위치 차이, 거리, 단위 방향 벡터를 계산합니다.
/// </summary>
public class Day33TargetDistance : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField, Min(0f)] private float detectRadius = 5f;

    [ContextMenu("Print Target Distance")]
    private void PrintTargetData()
    {
        if (target == null)
        {
            Debug.LogWarning("[Day33] Target이 지정되지 않았습니다.", this);
            return;
        }

        Vector3 toTarget = target.position - transform.position;
        float distance = toTarget.magnitude;
        Vector3 direction = distance > 0.0001f ? toTarget / distance : Vector3.zero;
        Debug.Log($"[Day33] distance={distance:F2}, direction={direction}, " +
                  $"inRange={distance <= detectRadius}", this);
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, detectRadius);
        if (target == null) return;
        Gizmos.color = Color.cyan;
        Gizmos.DrawLine(transform.position, target.position);
    }
}
