using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// 33일차: 같은 WASD 입력을 월드 축/오브젝트 로컬 축에서 비교합니다.
/// Input System 패키지와 Active Input Handling 설정이 필요합니다.
/// </summary>
public class Day33WorldLocalMover : MonoBehaviour
{
    [SerializeField, Min(0f)] private float moveSpeed = 4f;
    [SerializeField] private Space movementSpace = Space.World;

    private void Update()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null) return;

        float x = (keyboard.dKey.isPressed ? 1f : 0f)
                - (keyboard.aKey.isPressed ? 1f : 0f);
        float z = (keyboard.wKey.isPressed ? 1f : 0f)
                - (keyboard.sKey.isPressed ? 1f : 0f);

        Vector3 inputDirection = new Vector3(x, 0f, z);
        if (inputDirection.sqrMagnitude > 1f)
            inputDirection.Normalize();  // 대각선 이동 속도 보정

        transform.Translate(inputDirection * moveSpeed * Time.deltaTime, movementSpace);
    }

    public void SetWorldSpace() => movementSpace = Space.World;
    public void SetLocalSpace() => movementSpace = Space.Self;
}
