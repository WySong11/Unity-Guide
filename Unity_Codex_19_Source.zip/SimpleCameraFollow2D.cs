using UnityEngine;

/// <summary>
/// 수업용 독립 카메라 추적 예제입니다.
/// Cinemachine을 사용하는 동안에는 이 컴포넌트를 비활성화하세요.
/// </summary>
[DisallowMultipleComponent]
[RequireComponent(typeof(Camera))]
public sealed class SimpleCameraFollow2D : MonoBehaviour
{
    [Header("Tracking")]
    [SerializeField] private Transform target;
    [SerializeField] private Vector2 xyOffset = new Vector2(0f, 1f);
    [SerializeField, Min(0.01f)] private float smoothTime = 0.25f;
    [SerializeField] private float cameraZ = -10f;

    [Header("Optional Rectangle Bounds")]
    [SerializeField] private bool useBounds;
    [SerializeField] private Vector2 boundsMin = new Vector2(-15f, -5f);
    [SerializeField] private Vector2 boundsMax = new Vector2(15f, 8f);

    private Camera attachedCamera;
    private Vector3 velocity;

    private void Awake()
    {
        attachedCamera = GetComponent<Camera>();
    }

    private void LateUpdate()
    {
        if (target == null) return;

        Vector3 desired = new Vector3(
            target.position.x + xyOffset.x,
            target.position.y + xyOffset.y,
            cameraZ);

        // 화면 전체가 범위 내에 들어오도록 카메라 중심을 제한합니다.
        if (useBounds && attachedCamera != null && attachedCamera.orthographic)
        {
            float halfHeight = attachedCamera.orthographicSize;
            float halfWidth = halfHeight * attachedCamera.aspect;
            desired.x = ClampOrCenter(desired.x,
                boundsMin.x + halfWidth, boundsMax.x - halfWidth,
                (boundsMin.x + boundsMax.x) * 0.5f);
            desired.y = ClampOrCenter(desired.y,
                boundsMin.y + halfHeight, boundsMax.y - halfHeight,
                (boundsMin.y + boundsMax.y) * 0.5f);
        }

        transform.position = Vector3.SmoothDamp(
            transform.position, desired, ref velocity, smoothTime);
    }

    private static float ClampOrCenter(float value, float low, float high, float center)
    {
        return low <= high ? Mathf.Clamp(value, low, high) : center;
    }

    private void OnDrawGizmosSelected()
    {
        if (!useBounds) return;
        Gizmos.color = Color.cyan;
        Vector3 center = (Vector3)(boundsMin + boundsMax) * 0.5f;
        center.z = 0f;
        Vector3 size = (Vector3)(boundsMax - boundsMin);
        Gizmos.DrawWireCube(center, size);
    }
}
