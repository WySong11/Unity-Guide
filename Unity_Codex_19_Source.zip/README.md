# Unity × Codex — 19일차 2D 카메라 추적 실습

**대상:** Unity 6000.3 계열 / Cinemachine 3.1.x (6000.3 공식 패키지 릴리스 예: 3.1.7)

## 실습 A — Cinemachine (권장)
1. 18일차 프로젝트의 Player 이동/점프를 먼저 확인합니다.
2. Window > Package Manager에서 Unity Registry의 Cinemachine 설치 상태를 확인합니다.
3. GameObject > Cinemachine > Targeted Cameras > 2D Camera를 생성합니다. (메뉴 문구는 설치 버전에 따라 다를 수 있습니다.)
4. Main Camera에 Cinemachine Brain이 있는지 확인합니다.
5. Cinemachine Camera의 Tracking Target에 Player Transform을 지정합니다.
6. Position Control = Position Composer. Damping X/Y, Screen Position, Dead Zone을 게임 장면을 보면서 조정합니다.
7. 빈 오브젝트 `CameraBounds`에 PolygonCollider2D를 추가하고 맵 경계로 편집합니다. Is Trigger를 켜고, 필요한 물리 설정을 확인합니다.
8. Cinemachine Camera의 Add Extension에서 Cinemachine Confiner 2D를 추가하고 Bounding Shape 2D에 CameraBounds를 지정합니다.
9. 캐릭터를 좌우 경계·점프 영역으로 이동해 빈 배경 노출 여부를 테스트합니다.

## 실습 B — 수동 C# 카메라 (비교 학습)
**주의:** Cinemachine과 수동 추적을 동시에 구동하지 않습니다.
1. 실습 A의 Cinemachine Camera를 비활성화하고 Main Camera의 Cinemachine Brain도 비활성화합니다.
2. `SimpleCameraFollow2D`를 Main Camera에 추가하고 target = Player를 설정합니다.
3. Main Camera의 Projection을 Orthographic으로 설정합니다.
4. Camera Z=-10, smoothTime=0.25에서 시작하여 추적 감각을 비교합니다.
5. 경계를 사용하려면 useBounds를 체크하고 boundsMin/Max로 사각형 영역을 지정합니다. (직접 구현 예제는 복잡한 폴리곤 맵 경계에 적합하지 않습니다.)

## 파일 설명
- `SimpleCameraFollow2D.cs`: 비교 학습용 직접 추적/사각형 경계
- `CameraTargetOffset2D.cs`: 선택적 앵커 위치 설정
- `CameraBoundsGizmo2D.cs`: Scene 뷰 경계 시각화 보조
- `CameraTestMatrix.csv`: 테스트 결과 작성
- `CodexPrompts.md`: 분석·검증용 프롬프트

## 공식 문서
- https://docs.unity.com/en-us/engine/6000.3/manual/packages-list/packages-all/pack-safe/com-unity-cinemachine
- https://docs.unity.cn/Packages/com.unity.cinemachine@3.1/manual/CinemachinePositionComposer.html
- https://docs.unity.cn/Packages/com.unity.cinemachine@3.1/manual/CinemachineConfiner2D.html

> Inspector 설명 이미지는 이해를 돕는 모식도입니다. Unity 설치 버전별 구성은 다를 수 있습니다. 실제 Unity 에디터 컴파일과 Play Mode 테스트는 수강생 환경에서 진행해야 합니다.
