using UnityEngine;

/// <summary>
/// 부모 Player의 몸통 위쪽을 따라 움직이는 카메라 앵커입니다.
/// Player 자식에 붙여서 Tracking Target으로 지정할 수 있습니다.
/// </summary>
public sealed class CameraTargetOffset2D : MonoBehaviour
{
    [SerializeField] private Vector2 localOffset = new Vector2(0f, 0.75f);

    private void Reset() => transform.localPosition = (Vector3)localOffset;

    private void OnValidate()
    {
        // Play Mode에서는 기존 위치를 강제 변경하지 않습니다.
        if (!Application.isPlaying)
            transform.localPosition = (Vector3)localOffset;
    }
}
