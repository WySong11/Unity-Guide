using UnityEngine;

/// <summary>
/// 맵 경계를 Scene 뷰에서 시각적으로 확인하는 선택 예제입니다.
/// 실제 Cinemachine Confiner 2D 경계는 PolygonCollider2D를 사용하세요.
/// </summary>
public sealed class CameraBoundsGizmo2D : MonoBehaviour
{
    [SerializeField] private Vector2 size = new Vector2(30f, 12f);
    [SerializeField] private Color color = Color.green;

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = color;
        Gizmos.DrawWireCube(transform.position, new Vector3(size.x, size.y, 0f));
    }
}
