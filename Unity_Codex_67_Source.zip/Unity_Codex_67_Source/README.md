# Unity × Codex | 67일차 Git Diff 기반 코드 리뷰

**주의: `Candidate/`는 리뷰 연습을 위한 의도적 결함 코드입니다. 실제 Unity 프로젝트에 그대로 복사하지 마세요.**

## 120분 진행
- 00~25분: `git status`, `git diff`, `--cached`, `main...HEAD`, Hunk 표기 분석
- 25~55분: `PracticeDiff/Before`와 `Candidate`의 Unity C# 코드 비교
- 55~95분: Codex `/review` 또는 `Course/Codex_Review_Prompts.md` 실습
- 95~120분: Finding F01~F04 검증, QA01~QA12 기록, 리뷰 보고서 제출

## 소스 설명
- `PracticeDiff/Before/Assets/Scripts/Day67ReviewLab/`: 기준 동작
- `PracticeDiff/Candidate/Assets/Scripts/Day67ReviewLab/`: 코드 리뷰 대상(의도적 회귀)
- `PracticeDiff/review_changes.patch`: 두 트리의 변경을 담은 **실제 Git 패치**
- `PracticeDiff/setup_lab.ps1`: Windows PowerShell에서 Git 학습 리포지토리 생성
- `PracticeDiff/setup_lab.sh`: bash/macOS/Linux에서 Git 학습 리포지토리 생성
- `Course/`: 학생 워크시트, Codex 프롬프트, 리뷰 보고 양식, QA 매트릭스, 평가표
- `Teacher/ANSWER_KEY.md`: 강사용 정답(수강생에게 처음부터 공개하지 않음)

## Windows에서 시작 (Git for Windows 설치 필요)
1. 압축 해제 후 PowerShell에서 `PracticeDiff` 폴더로 이동합니다.
2. `./setup_lab.ps1`을 실행합니다. 실행 정책에 막히면 파일 내용을 검토한 후, **해당 세션 범위에서만** 허용하거나 아래 수동 명령을 사용합니다.
3. 새로 만들어진 `LabWorkspace`로 이동해 `git status --short`, `git diff --stat`, `git diff`를 실행합니다.
4. 변경을 확인한 후 `git add -A; git diff --cached`로 스테이징 리뷰를 비교할 수 있습니다. 실습 시 Git 스테이징은 승인·커밋과 다릅니다.
5. 기존 프로젝트가 아닌 **이 연습 폴더에서만** 작업하세요.

## PowerShell 없이 수동으로 진행
1. 새 빈 폴더를 만들고 `Before/Assets`를 복사합니다.
2. 해당 폴더에서 `git init`, `git add .`, `git -c user.name='ReviewLab' -c user.email='review@example.invalid' commit -m 'baseline'`으로 기준 버전을 만듭니다.
3. `Candidate/Assets`로 파일을 덮어쓰고 `git diff`로 확인합니다.
4. `git diff --cached`는 스테이징 이전에는 비어 있는 것이 정상입니다.
5. `git status --short`는 Git이 아직 추적하지 않는 신규 파일을 확인하는 데에도 사용합니다.

## Unity에 적용 시
- `Day67` 클래스명으로 기존 코드와 충돌하지 않도록 작성했지만, **동일 프로젝트에 Before/Candidate를 동시에 설치하면 타입 중복**이 발생합니다.
- 필요한 경우 별도 복사 프로젝트에 **한 버전만** 넣으세요. 이 과제의 중심은 Unity 런타임 구현이 아니라 Git Diff 리뷰입니다.
- 실제 Unity Editor 컴파일/Play Mode/Android 테스트는 제공 환경에서 실행하지 않았으며 반드시 별도 확인해야 합니다.

## 검증 결과 표기
- PASS: 실제 실행한 검사에만 사용
- FAIL: 실제로 실패를 확인한 검사
- BLOCKED: 접근 권한·의존 환경 부족
- NOT RUN: 검사를 수행하지 않음
