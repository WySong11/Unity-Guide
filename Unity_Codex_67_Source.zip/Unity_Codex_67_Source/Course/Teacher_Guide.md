# 67일차 강사용 진행 가이드 (120분)

## 사전 준비
- Git for Windows와 VS Code 확인, 실습은 복사한 ReviewLab 폴더에서만 합니다.
- 이전 65일차 AGENTS.md와 66일차 작업 카드(T03)를 상기시킵니다.
- `Teacher/ANSWER_KEY.md`는 첫 60분 동안 수강생에게 보여주지 않습니다.

## 1교시 (25분): Git Diff
- working tree / index / HEAD / branch 개념, git status, git diff, --cached.
- `git diff main...HEAD`에서 main은 실제 기준 브랜치명으로 교체할 것.
- Untracked 신규 파일은 기본 git diff에 나타나지 않는다는 점 강조.

## 2교시 (30분): 4종 결함 찾기
- Inventory 4+3 스택, HUD 재활성화, Pool 중복 반환, 음수 JSON 저장 데이터를 학생이 추론.
- 코드 변경 없이 file:line과 Trigger/Expected/Actual를 작성하도록 함.

## 3교시 (40분): Codex 리뷰
- /review 또는 텍스트 P1 실행. Codex가 제시한 Finding을 학생의 근거와 비교.
- Code Review Rules는 실제 중요한 불변식에 집중. 단순 서식은 CI가 더 적합.

## 4교시 (25분): 발표·검증
- 검증표 QA01~QA12, 강사 정답 비교. 코드 수정은 승인받은 경우에만.
- 자체 확인하지 못한 Unity Editor·Play Mode 검사는 NOT RUN으로 기록.

## 품질 및 안전
- 제공된 Candidate에는 의도적 결함이 있으므로 실제 앱에 붙이지 않습니다.
- `git diff --check`는 단순 공백 검사이지 테스트가 아닙니다.
- 코드 리뷰 자동화는 사람의 최종 코드/테스트 확인을 대체하지 않습니다.
