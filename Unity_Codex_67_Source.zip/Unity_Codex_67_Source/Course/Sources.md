# 공식 참고 링크
- Git Diff 문서: https://git-scm.com/docs/git-diff
- Git Status 문서: https://git-scm.com/docs/git-status
- Codex 코드 리뷰: https://learn.chatgpt.com/docs/code-review
- Codex AGENTS.md: https://learn.chatgpt.com/docs/agent-configuration/agents-md
- OpenAI Codex 리뷰 규칙: https://developers.openai.com/blog/custom-code-review-rules-for-codex

2026-10-27 기준 강의 내용을 작성했습니다. UI 명칭이나 메뉴는 제품 업데이트에 따라 달라질 수 있습니다.
