# AGENTS.md에 추가할 리뷰 규칙 예제

> 기존 프로젝트의 AGENTS.md를 덮어쓰지 말고 `## Code Review Rules` 하위에 **프로젝트에 맞는 것만** 합칩니다.

## Code Review Rules

### Inventory total count invariant
- 동일 아이템의 Stack 분할·병합 전후 합계가 보존되어야 합니다.
- 최대 스택 초과 시 실제 추가량만 차감하고 잔여 개수를 반환·다음 슬롯에 반영합니다.
- 리뷰에서 `4 + 3, maxStack=5` 경계값을 확인합니다.

### Event lifecycle symmetry
- `OnEnable` 또는 Awake에서 구독한 이벤트는 대응하는 수명주기에 반드시 해제해야 합니다.
- 재활성화 후 핸들러가 중복 실행되지 않는지 확인합니다.

### Object Pool ownership
- 재사용 오브젝트는 활성화할 때 내부 상태를 초기화하고 동일 대여 주기 내 중복 반환을 막습니다.
- 충돌·타이머 종료가 겹칠 때도 Release 콜백이 1회만 발생해야 합니다.

### Save validation before mutation
- JSON을 파싱한 뒤 **모든 슬롯 유효성을 검사하고 나서** 실제 게임 상태에 반영합니다.
- 손상·음수 수량·중복 슬롯·지원하지 않는 ID는 상태를 부분 변경하지 않은 채 거부합니다.

### Review output contract
- 결함만 우선순위 P0~P3, 경로:줄, 재현 입력, 기대/실제 결과, 최소 수정안, 테스트로 보고합니다.
- 실제 실행하지 않은 테스트는 NOT RUN으로 명시합니다.
- 읽기 전용 리뷰에서는 코드 수정·커밋·푸시를 수행하지 않습니다.
