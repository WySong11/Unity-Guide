using System;
using UnityEngine;

public sealed class Day67PooledProjectile : MonoBehaviour
{
    private Action<Day67PooledProjectile> release;
    private bool isReturning;

    public void Activate(Action<Day67PooledProjectile> returnCallback)
    {
        release = returnCallback;
        isReturning = false;
        gameObject.SetActive(true);
    }

    public void ReturnToPool()
    {
        if (isReturning) return;
        isReturning = true;
        release?.Invoke(this);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Enemy")) ReturnToPool();
    }
}
