using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public sealed class Day67SaveData
{
    public Day67ItemSlot[] slots;
}

public static class Day67SaveLoader
{
    // Validate everything first. Applying malformed JSON must not mutate the current inventory.
    public static bool TryLoad(string json, Day67Inventory inventory, out string error)
    {
        error = null;
        if (inventory == null || string.IsNullOrWhiteSpace(json))
        {
            error = "Missing inventory or JSON";
            return false;
        }
        Day67SaveData data;
        try { data = JsonUtility.FromJson<Day67SaveData>(json); }
        catch (Exception e) { error = e.Message; return false; }
        if (data == null || data.slots == null || data.slots.Length > 12)
        {
            error = "Invalid save schema";
            return false;
        }
        List<Day67ItemSlot> validated = new();
        foreach (Day67ItemSlot slot in data.slots)
        {
            if (slot == null || string.IsNullOrWhiteSpace(slot.itemId) ||
                slot.count <= 0 || slot.maxStack <= 0 || slot.count > slot.maxStack)
            {
                error = "Invalid slot";
                return false;
            }
            validated.Add(new Day67ItemSlot(slot.itemId, slot.count, slot.maxStack));
        }
        inventory.ReplaceAll(validated);
        return true;
    }
}
