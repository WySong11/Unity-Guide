using System;
using UnityEngine;

public sealed class Day67Health : MonoBehaviour
{
    [SerializeField, Min(1)] private int maxHealth = 100;
    public event Action<int> OnChanged;
    public int Current { get; private set; }
    private void Awake() { Current = maxHealth; }
    public void Damage(int amount)
    {
        if (amount <= 0) return;
        Current = Mathf.Max(0, Current - amount);
        OnChanged?.Invoke(Current);
    }
}
