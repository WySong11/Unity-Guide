$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$target = Join-Path $root 'LabWorkspace'
if (Test-Path $target) { throw 'LabWorkspace already exists; existing work is preserved. Use another folder or rename it manually.' }
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git executable not found on PATH.' }
New-Item -ItemType Directory -Path $target | Out-Null
Copy-Item -Path (Join-Path $root 'Before\Assets') -Destination $target -Recurse
Push-Location $target
try {
    git init
    if ($LASTEXITCODE -ne 0) { throw 'git init failed' }
    git add -- Assets
    if ($LASTEXITCODE -ne 0) { throw 'git add failed' }
    git -c user.name='ReviewLab' -c user.email='review@example.invalid' commit -m 'Training baseline'
    if ($LASTEXITCODE -ne 0) { throw 'baseline commit failed' }
    $from = Join-Path $root 'Candidate\Assets\Scripts\Day67ReviewLab'
    $to = Join-Path $target 'Assets\Scripts\Day67ReviewLab'
    Get-ChildItem -Path $from -File | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination $to -Force }
    Write-Output '--- git status --short ---'
    git status --short
    Write-Output '--- git diff --stat ---'
    git diff --stat
    Write-Output '--- git diff --check ---'
    git diff --check
    Write-Output 'LabWorkspace is ready; no commit or push performed for Candidate.'
} finally { Pop-Location }
