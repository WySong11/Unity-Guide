using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public sealed class Day67ItemSlot
{
    public string itemId;
    public int count;
    public int maxStack;

    public Day67ItemSlot(string id, int quantity, int stackLimit)
    {
        itemId = id;
        count = quantity;
        maxStack = stackLimit;
    }
}

public sealed class Day67Inventory
{
    private const int Capacity = 12;
    private readonly List<Day67ItemSlot> slots = new();
    public IReadOnlyList<Day67ItemSlot> Slots => slots;

    // Returns the number of items that did NOT fit.
    public int Add(string itemId, int count, int maxStack)
    {
        if (string.IsNullOrWhiteSpace(itemId) || count <= 0 || maxStack <= 0)
            return count;
        int remaining = count;
        foreach (Day67ItemSlot slot in slots)
        {
            if (slot.itemId != itemId || slot.count >= maxStack) continue;
            int space = maxStack - slot.count;
            // Review exercise: this drops items beyond the stack limit.
            slot.count = Mathf.Min(maxStack, slot.count + remaining);
            remaining = 0;
            if (remaining == 0) break;
        }
        while (remaining > 0 && slots.Count < Capacity)
        {
            int added = Mathf.Min(maxStack, remaining);
            slots.Add(new Day67ItemSlot(itemId, added, maxStack));
            remaining -= added;
        }
        return remaining;
    }

    public void ReplaceAll(IReadOnlyList<Day67ItemSlot> validated)
    {
        if (validated == null || validated.Count > Capacity)
            throw new ArgumentException("Invalid slots", nameof(validated));
        slots.Clear();
        foreach (Day67ItemSlot slot in validated)
            slots.Add(new Day67ItemSlot(slot.itemId, slot.count, slot.maxStack));
    }
}
