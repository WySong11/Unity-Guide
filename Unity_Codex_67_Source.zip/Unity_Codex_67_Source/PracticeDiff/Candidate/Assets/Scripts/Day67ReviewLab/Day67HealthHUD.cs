using UnityEngine;

public sealed class Day67HealthHUD : MonoBehaviour
{
    [SerializeField] private Day67Health health;
    public int UpdateCount { get; private set; }
    private void OnEnable()
    {
        if (health != null) health.OnChanged += UpdateHUD;
    }
    private void OnDisable()
    {
        // Review exercise: the event is never unsubscribed.
    }
    private void UpdateHUD(int current)
    {
        UpdateCount++;
        Debug.Log($"[Day67] HP={current}, HUD calls={UpdateCount}");
    }
}
