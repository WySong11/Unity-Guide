#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
DEST="$ROOT/LabWorkspace"
if [ -e "$DEST" ]; then echo 'LabWorkspace exists; preserve existing user work.' >&2; exit 1; fi
command -v git >/dev/null || { echo 'git missing' >&2; exit 1; }
mkdir "$DEST"
cp -R "$ROOT/Before/Assets" "$DEST/"
cd "$DEST"
git init
git add -- Assets
git -c user.name='ReviewLab' -c user.email='review@example.invalid' commit -m 'Training baseline'
cp -R "$ROOT/Candidate/Assets/." "$DEST/Assets/"
git status --short
git diff --stat
git diff --check
printf '%s\n' 'LabWorkspace ready; Candidate is unstaged and uncommitted.'
