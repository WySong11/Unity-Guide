# 강사용 정답 · 수강생에게 초기 공개 금지

> 아래 Finding은 **코드에서 확인 가능한 정적 분석 결과**입니다. 제공 환경에서 Unity Play Mode를 수행한 결과가 아닙니다.

## F01 [P1] Inventory 스택 수량 소실
- 파일: `Day67Inventory.cs`의 `Add()` 내 기존 스택 병합.
- Before: `added=min(space,remaining); slot.count+=added; remaining-=added;`
- Candidate: `slot.count=min(maxStack,slot.count+remaining); remaining=0;`
- 입력: Potion count 4, maxStack 5, 3개 추가.
- 기대: 5개·2개 = 총 7개. Candidate: 5개만 남음.
- 수정: 실제 추가량만 남은 수량에서 빼고 다음 슬롯으로 분산.

## F02 [P2] HUD 이벤트 중복 구독
- 파일: `Day67HealthHUD.cs`, `OnDisable`의 `-=` 누락.
- 입력: HUD를 비활성화하고 다시 활성화, 건강 이벤트 호출.
- 기대: 1회 변경 이벤트당 UI 1회 갱신. Candidate: 활성화할 때마다 구독 누적 가능.
- 수정: 대칭적으로 `health.OnChanged -= UpdateHUD;` 호출.

## F03 [P2] 발사체 Pool 중복 반환
- 파일: `Day67PooledProjectile.cs`, `ReturnToPool` 보호 조건 삭제.
- 입력: 충돌과 수명 만료의 같은 프레임 중복 호출(또는 두 번 명시 호출).
- 기대: 반환 콜백 1회. Candidate: 조건이 없으므로 2회 호출 가능.
- 수정: `if (isReturning) return;` 복구, Activate 때 false로 초기화.

## F04 [P1] SaveLoader의 부분 상태 변경
- 파일: `Day67SaveLoader.cs`, `TryLoad` JSON 데이터 순차 적용 변경.
- 입력: 첫 슬롯 정상, 두 번째 슬롯 count=-1인 JSON.
- 기대: 전체 거부하며 기존 Inventory 상태 변경하지 않음.
- Candidate: `ReplaceAll(empty)`로 기존 내용 삭제, 첫 슬롯 추가 후 실패.
- 수정: 모든 항목을 별도 List에 사전 검증 후 마지막 한 번 `ReplaceAll`.

## 추가 관찰
- Source Candidate를 Unity에 단독 설치할 때 .meta 재생성/씬 참조는 별도 확인 필요.
- 기존 `Before`와 `Candidate` 코드를 한 Unity 프로젝트에 동시에 넣으면 클래스명이 중복되므로 안 됩니다.
- `git diff --check` 통과와 Unity 컴파일 통과는 다른 검사입니다.
- 실제 줄 번호는 `Review.diff` 또는 Git LabWorkspace에서 확인하여 보고하십시오.
