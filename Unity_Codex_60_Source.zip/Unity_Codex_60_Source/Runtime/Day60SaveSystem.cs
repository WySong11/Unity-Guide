using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public sealed class Day60SavedSlot
{
    public int index;
    public string itemId;
    public int quantity;
}

[Serializable]
public sealed class Day60SaveData
{
    public int version = 1;
    public string equippedItemId;
    public Day60SavedSlot[] slots;
}

public sealed class Day60SaveSystem : MonoBehaviour
{
    [SerializeField] private Day60Inventory inventory;
    [SerializeField] private Day60EquipmentController equipment;
    [SerializeField] private Day60DataCatalog catalog;
    private string SavePath => Path.Combine(Application.persistentDataPath, "day60_inventory.json");

    private void Awake()
    {
        if (inventory == null) inventory = GetComponent<Day60Inventory>();
        if (equipment == null) equipment = GetComponent<Day60EquipmentController>();
    }

    public bool Save(out string message)
    {
        if (inventory == null || equipment == null) { message = "참조 누락"; return false; }
        try
        {
            var entries = new List<Day60SavedSlot>();
            for (int i = 0; i < inventory.Capacity; i++)
            {
                var slot = inventory.GetSlot(i);
                if (slot == null || slot.IsEmpty) continue;
                entries.Add(new Day60SavedSlot { index = i, itemId = slot.Item.ItemId, quantity = slot.Quantity });
            }
            var dto = new Day60SaveData { slots = entries.ToArray(),
                equippedItemId = equipment.Equipped != null ? equipment.Equipped.ItemId : "" };
            File.WriteAllText(SavePath, JsonUtility.ToJson(dto, true));
            message = "저장 완료: " + SavePath;
            return true;
        }
        catch (Exception e) { message = "저장 실패: " + e.Message; return false; }
    }

    public bool Load(out string message)
    {
        if (inventory == null || equipment == null || catalog == null || !File.Exists(SavePath))
        { message = "필수 참조 또는 저장 파일 누락"; return false; }
        try
        {
            var dto = JsonUtility.FromJson<Day60SaveData>(File.ReadAllText(SavePath));
            if (dto == null || dto.version != 1 || dto.slots == null)
            { message = "저장 버전/형식 오류"; return false; }
            var items = new Day60ItemData[inventory.Capacity];
            var quantities = new int[inventory.Capacity];
            var seen = new HashSet<int>();
            foreach (var saved in dto.slots)
            {
                if (saved == null || saved.index < 0 || saved.index >= inventory.Capacity || !seen.Add(saved.index))
                { message = "중복/범위 오류 슬롯"; return false; }
                var item = catalog.FindItem(saved.itemId);
                if (item == null || saved.quantity < 1 || saved.quantity > item.MaxStack)
                { message = "존재하지 않는 ID 또는 수량 오류"; return false; }
                items[saved.index] = item;
                quantities[saved.index] = saved.quantity;
            }
            Day60ItemData equipped = null;
            if (!string.IsNullOrEmpty(dto.equippedItemId))
            {
                equipped = catalog.FindItem(dto.equippedItemId);
                if (equipped == null || equipped.Kind != Day60ItemKind.Equipment)
                { message = "장비 ID 오류"; return false; }
            }
            // 모든 ID·수량 검증 후 상태를 변경합니다.
            if (!inventory.ReplaceAll(items, quantities))
            { message = "Inventory 교체 실패"; return false; }
            equipment.ApplyLoadedEquipment(equipped);
            message = "불러오기 완료";
            return true;
        }
        catch (Exception e) { message = "로드 실패: " + e.Message; return false; }
    }
}
