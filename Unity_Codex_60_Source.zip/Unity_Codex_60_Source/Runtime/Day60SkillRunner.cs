using System.Collections.Generic;
using UnityEngine;

public sealed class Day60SkillRunner : MonoBehaviour
{
    [SerializeField] private Day60Stats caster;
    private readonly Dictionary<string, float> nextReady = new Dictionary<string, float>();
    private void Awake() { if (caster == null) caster = GetComponent<Day60Stats>(); }

    public float Remaining(Day60SkillData skill)
    {
        if (skill == null || string.IsNullOrWhiteSpace(skill.SkillId)) return 0f;
        return nextReady.TryGetValue(skill.SkillId, out float when)
            ? Mathf.Max(0f, when - Time.time) : 0f;
    }

    public bool TryCast(Day60SkillData skill, Day60Stats selected, out string reason)
    {
        if (skill == null || string.IsNullOrWhiteSpace(skill.SkillId) || caster == null)
        { reason = "스킬/시전자 참조 누락"; return false; }
        if (Remaining(skill) > 0f) { reason = "쿨타임 중"; return false; }
        if (!caster.HasMana(skill.ManaCost)) { reason = "마나 부족"; return false; }
        if (!Day60EffectEngine.CanApplyAll(skill.Effects, caster, selected))
        { reason = "대상 또는 효과 조건 미충족"; return false; }
        if (!caster.TrySpendMana(skill.ManaCost)) { reason = "마나 소모 실패"; return false; }
        Day60EffectEngine.ApplyAll(skill.Effects, caster, selected);
        nextReady[skill.SkillId] = Time.time + Mathf.Max(0f, skill.Cooldown);
        reason = "시전 성공";
        return true;
    }
}
