using UnityEngine;

public enum Day60ItemKind { Consumable, Equipment }

[CreateAssetMenu(menuName = "Unity Codex/Day60/Item Data", fileName = "Day60_Item")]
public sealed class Day60ItemData : ScriptableObject
{
    [SerializeField] private string itemId;
    [SerializeField] private string displayName;
    [SerializeField] private Day60ItemKind kind;
    [Min(1)] [SerializeField] private int maxStack = 1;
    [SerializeField] private Day60EffectDefinition[] effects = new Day60EffectDefinition[0];
    [Min(0)] [SerializeField] private int equipAttackBonus;

    public string ItemId => itemId;
    public string DisplayName => displayName;
    public Day60ItemKind Kind => kind;
    public int MaxStack => Mathf.Max(1, maxStack);
    public Day60EffectDefinition[] Effects => effects;
    public int EquipAttackBonus => equipAttackBonus;
}
