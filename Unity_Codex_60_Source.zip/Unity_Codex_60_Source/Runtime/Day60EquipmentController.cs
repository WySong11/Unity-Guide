using UnityEngine;

public sealed class Day60EquipmentController : MonoBehaviour
{
    [SerializeField] private Day60Inventory inventory;
    [SerializeField] private Day60Stats stats;
    [SerializeField] private Day60ItemData equipped;
    public Day60ItemData Equipped => equipped;

    private void Awake()
    {
        if (inventory == null) inventory = GetComponent<Day60Inventory>();
        if (stats == null) stats = GetComponent<Day60Stats>();
        if (stats != null) stats.SetEquipmentAttackBonus(equipped != null ? equipped.EquipAttackBonus : 0);
    }

    public bool TryEquipFromSlot(int slotIndex, out string reason)
    {
        if (inventory == null || stats == null) { reason = "필수 컴포넌트 누락"; return false; }
        var slot = inventory.GetSlot(slotIndex);
        if (slot == null || slot.IsEmpty || slot.Item.Kind != Day60ItemKind.Equipment || slot.Item.MaxStack != 1)
        { reason = "장비 슬롯을 선택하세요"; return false; }
        var candidate = slot.Item;
        if (!inventory.TryRemoveAt(slotIndex, 1)) { reason = "슬롯 수량 오류"; return false; }
        if (equipped != null && inventory.Add(equipped, 1) != 1)
        {
            inventory.Add(candidate, 1);
            reason = "이전 장비를 가방에 넣을 공간 부족";
            return false;
        }
        equipped = candidate;
        stats.SetEquipmentAttackBonus(candidate.EquipAttackBonus);
        reason = "장비 착용 성공";
        return true;
    }

    public bool TryUnequip(out string reason)
    {
        if (equipped == null || inventory == null || stats == null)
        { reason = "해제할 장비 없음"; return false; }
        if (inventory.Add(equipped, 1) != 1)
        { reason = "가방 공간 부족"; return false; }
        equipped = null;
        stats.SetEquipmentAttackBonus(0);
        reason = "장비 해제 완료";
        return true;
    }

    public void ApplyLoadedEquipment(Day60ItemData item)
    {
        if (item != null && item.Kind != Day60ItemKind.Equipment) return;
        equipped = item;
        if (stats == null) stats = GetComponent<Day60Stats>();
        if (stats != null) stats.SetEquipmentAttackBonus(item != null ? item.EquipAttackBonus : 0);
    }
}
