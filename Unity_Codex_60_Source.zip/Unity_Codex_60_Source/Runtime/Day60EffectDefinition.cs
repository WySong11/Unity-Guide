using System;
using UnityEngine;

public enum Day60EffectType { Heal, RestoreMana, Damage, AttackBuff }
public enum Day60EffectTarget { Self, Selected }

[Serializable]
public struct Day60EffectDefinition
{
    public Day60EffectType type;
    public Day60EffectTarget target;
    [Min(0f)] public float amount;
    [Min(0f)] public float duration;
}
