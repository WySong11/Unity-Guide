using UnityEngine;

public sealed class Day60DemoHUD : MonoBehaviour
{
    [SerializeField] private Day60Stats player;
    [SerializeField] private Day60Stats target;
    [SerializeField] private Day60SkillRunner runner;
    [SerializeField] private Day60Inventory inventory;
    [SerializeField] private Day60EquipmentController equipment;
    [SerializeField] private Day60SaveSystem saveSystem;
    [SerializeField] private Day60SkillData[] skills;
    [SerializeField] private Day60ItemData[] starterItems;
    private string status = "Day60 실습 준비";
    private Vector2 scroll;

    private void OnGUI()
    {
        GUILayout.BeginArea(new Rect(12, 12, 395, Screen.height - 25), GUI.skin.box);
        scroll = GUILayout.BeginScrollView(scroll);
        GUILayout.Label("DAY 60 · Skill / Item Data Lab");
        if (player != null) GUILayout.Label($"Player HP {player.Hp}/{player.MaxHp}  Mana {player.Mana}/{player.MaxMana}  Attack {player.AttackPower:0.0}");
        if (target != null) GUILayout.Label($"Target HP {target.Hp}/{target.MaxHp}");
        GUILayout.Label(status);
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Damage Player -40") && player != null)
            status = player.TryDamage(40) ? "플레이어 HP -40" : "피격 불가";
        if (GUILayout.Button("Damage Target -20") && target != null)
            status = target.TryDamage(20) ? "타깃 HP -20" : "피격 불가";
        GUILayout.EndHorizontal();
        GUILayout.Space(6);
        GUILayout.Label("스킬: 마나 / 쿨타임 / 대상 조건");
        if (skills != null)
            for (int i = 0; i < skills.Length; i++)
            {
                var skill = skills[i];
                if (skill == null) continue;
                if (GUILayout.Button($"{skill.DisplayName} (CD {runner.Remaining(skill):0.0}s)"))
                {
                    bool ok = runner.TryCast(skill, target, out var reason);
                    status = (ok ? "성공: " : "거절: ") + reason;
                }
            }
        GUILayout.Space(6);
        GUILayout.Label("인벤토리: 아이템 추가 / 사용 / 장착");
        if (starterItems != null)
            foreach (var item in starterItems)
            {
                if (item == null) continue;
                if (GUILayout.Button("Add: " + item.DisplayName))
                    status = "획득 수량: " + inventory.Add(item, 1);
            }
        if (inventory != null)
            for (int i = 0; i < inventory.Capacity; i++)
            {
                var slot = inventory.GetSlot(i);
                if (slot == null || slot.IsEmpty) continue;
                GUILayout.BeginHorizontal();
                GUILayout.Label($"[{i}] {slot.Item.DisplayName} ×{slot.Quantity}", GUILayout.Width(200));
                int index = i;
                if (GUILayout.Button("Use / Equip"))
                {
                    bool ok;
                    string reason;
                    if (slot.Item.Kind == Day60ItemKind.Equipment)
                        ok = equipment.TryEquipFromSlot(index, out reason);
                    else
                        ok = inventory.TryUse(index, player, target, out reason);
                    status = (ok ? "성공: " : "거절: ") + reason;
                }
                GUILayout.EndHorizontal();
            }
        GUILayout.Label("장착: " + (equipment != null && equipment.Equipped != null ? equipment.Equipped.DisplayName : "없음"));
        if (GUILayout.Button("Unequip"))
        {
            bool ok = equipment.TryUnequip(out var reason);
            status = (ok ? "성공: " : "거절: ") + reason;
        }
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Save")) saveSystem.Save(out status);
        if (GUILayout.Button("Load")) saveSystem.Load(out status);
        GUILayout.EndHorizontal();
        GUILayout.EndScrollView();
        GUILayout.EndArea();
    }
}
