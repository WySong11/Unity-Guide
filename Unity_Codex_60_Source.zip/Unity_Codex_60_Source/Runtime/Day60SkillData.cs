using UnityEngine;

[CreateAssetMenu(menuName = "Unity Codex/Day60/Skill Data", fileName = "Day60_Skill")]
public sealed class Day60SkillData : ScriptableObject
{
    [SerializeField] private string skillId;
    [SerializeField] private string displayName;
    [Min(0)] [SerializeField] private int manaCost;
    [Min(0f)] [SerializeField] private float cooldown;
    [SerializeField] private Day60EffectDefinition[] effects = new Day60EffectDefinition[0];

    public string SkillId => skillId;
    public string DisplayName => displayName;
    public int ManaCost => manaCost;
    public float Cooldown => cooldown;
    // 강의 실습에서는 반환 배열을 읽기 전용으로 취급합니다.
    public Day60EffectDefinition[] Effects => effects;
}
