using System;
using UnityEngine;

[CreateAssetMenu(menuName = "Unity Codex/Day60/Data Catalog", fileName = "Day60_Catalog")]
public sealed class Day60DataCatalog : ScriptableObject
{
    [SerializeField] private Day60SkillData[] skills;
    [SerializeField] private Day60ItemData[] items;
    public Day60SkillData[] Skills => skills;
    public Day60ItemData[] Items => items;

    public Day60ItemData FindItem(string id)
    {
        if (string.IsNullOrWhiteSpace(id) || items == null) return null;
        foreach (var item in items)
            if (item != null && string.Equals(item.ItemId, id, StringComparison.Ordinal)) return item;
        return null;
    }

    public bool Validate(out string reason)
    {
        var ids = new System.Collections.Generic.HashSet<string>(StringComparer.Ordinal);
        if (items == null || skills == null) { reason = "Catalog 배열 누락"; return false; }
        foreach (var item in items)
        {
            if (item == null || string.IsNullOrWhiteSpace(item.ItemId) || !ids.Add("i:" + item.ItemId))
            { reason = "아이템 ID 중복/누락"; return false; }
            if (item.Kind == Day60ItemKind.Equipment && item.MaxStack != 1)
            { reason = "장비는 MaxStack 1 권장"; return false; }
            if (item.Kind == Day60ItemKind.Consumable && !CheckEffects(item.Effects))
            { reason = "아이템 효과 누락/수치 오류"; return false; }
        }
        foreach (var skill in skills)
        {
            if (skill == null || string.IsNullOrWhiteSpace(skill.SkillId) || !ids.Add("s:" + skill.SkillId))
            { reason = "스킬 ID 중복/누락"; return false; }
            if (!CheckEffects(skill.Effects)) { reason = "스킬 효과 누락/수치 오류"; return false; }
        }
        reason = "Catalog 정상";
        return true;
    }

    private static bool CheckEffects(Day60EffectDefinition[] effects)
    {
        if (effects == null || effects.Length == 0) return false;
        foreach (var e in effects)
        {
            if (e.amount <= 0f) return false;
            if (e.type == Day60EffectType.AttackBuff && e.duration <= 0f) return false;
        }
        return true;
    }
}
