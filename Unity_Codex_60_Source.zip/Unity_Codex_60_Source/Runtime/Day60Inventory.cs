using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public sealed class Day60InventoryEntry
{
    [SerializeField] private Day60ItemData item;
    [SerializeField] private int quantity;
    public Day60ItemData Item => item;
    public int Quantity => quantity;
    public bool IsEmpty => item == null || quantity <= 0;
    public Day60InventoryEntry() { }
    public Day60InventoryEntry(Day60ItemData itemData, int count) { Set(itemData, count); }
    internal void Set(Day60ItemData data, int count)
    {
        item = count > 0 ? data : null;
        quantity = count > 0 ? count : 0;
    }
}

public sealed class Day60Inventory : MonoBehaviour
{
    [Range(1, 48)] [SerializeField] private int capacity = 12;
    [SerializeField] private List<Day60InventoryEntry> slots = new List<Day60InventoryEntry>();
    public event Action Changed;
    public int Capacity => capacity;

    private void Awake() => EnsureSlots();

    private void EnsureSlots()
    {
        while (slots.Count < capacity) slots.Add(new Day60InventoryEntry());
        if (slots.Count > capacity) slots.RemoveRange(capacity, slots.Count - capacity);
        for (int i = 0; i < slots.Count; i++)
            if (slots[i] == null) slots[i] = new Day60InventoryEntry();
    }

    public Day60InventoryEntry GetSlot(int index)
    {
        EnsureSlots();
        return index >= 0 && index < slots.Count ? slots[index] : null;
    }

    public int Add(Day60ItemData item, int count)
    {
        EnsureSlots();
        if (item == null || count <= 0) return 0;
        int remaining = count;
        foreach (var slot in slots)
        {
            if (remaining <= 0) break;
            if (slot.IsEmpty || slot.Item != item) continue;
            int added = Mathf.Min(remaining, item.MaxStack - slot.Quantity);
            if (added <= 0) continue;
            slot.Set(item, slot.Quantity + added);
            remaining -= added;
        }
        foreach (var slot in slots)
        {
            if (remaining <= 0) break;
            if (!slot.IsEmpty) continue;
            int added = Mathf.Min(remaining, item.MaxStack);
            slot.Set(item, added);
            remaining -= added;
        }
        if (remaining < count) Changed?.Invoke();
        return count - remaining;
    }

    public bool TryRemoveAt(int slotIndex, int count)
    {
        var slot = GetSlot(slotIndex);
        if (slot == null || slot.IsEmpty || count <= 0 || slot.Quantity < count) return false;
        slot.Set(slot.Item, slot.Quantity - count);
        Changed?.Invoke();
        return true;
    }

    public bool TryUse(int slotIndex, Day60Stats self, Day60Stats target, out string reason)
    {
        var slot = GetSlot(slotIndex);
        if (slot == null || slot.IsEmpty) { reason = "빈 슬롯"; return false; }
        if (slot.Item.Kind != Day60ItemKind.Consumable) { reason = "장비는 장착 메뉴 사용"; return false; }
        if (!Day60EffectEngine.CanApplyAll(slot.Item.Effects, self, target))
        { reason = "대상 또는 효과 적용 조건 미충족"; return false; }
        // 동기 함수이므로 효과·수량을 동일 호출에서 처리합니다.
        if (!Day60EffectEngine.ApplyAll(slot.Item.Effects, self, target))
        { reason = "효과 적용 실패"; return false; }
        TryRemoveAt(slotIndex, 1);
        reason = "아이템 효과 적용 완료";
        return true;
    }

    public bool ReplaceAll(Day60ItemData[] items, int[] quantities)
    {
        if (items == null || quantities == null || items.Length != capacity || quantities.Length != capacity)
            return false;
        for (int i = 0; i < capacity; i++)
        {
            if (items[i] == null && quantities[i] == 0) continue;
            if (items[i] == null || quantities[i] < 1 || quantities[i] > items[i].MaxStack) return false;
        }
        EnsureSlots();
        for (int i = 0; i < capacity; i++) slots[i].Set(items[i], quantities[i]);
        Changed?.Invoke();
        return true;
    }
}
