using UnityEngine;

public static class Day60EffectEngine
{
    public static bool CanApply(Day60EffectDefinition effect, Day60Stats self, Day60Stats selected)
    {
        Day60Stats recipient = effect.target == Day60EffectTarget.Self ? self : selected;
        if (recipient == null || !recipient.IsAlive || effect.amount <= 0f) return false;
        switch (effect.type)
        {
            case Day60EffectType.Heal: return recipient.CanHeal;
            case Day60EffectType.RestoreMana: return recipient.CanRestoreMana;
            case Day60EffectType.Damage: return recipient.IsAlive;
            case Day60EffectType.AttackBuff: return effect.duration > 0f;
            default: return false;
        }
    }

    // 일괄 사용 정책: 모든 효과가 유효해야 시작할 수 있습니다.
    public static bool CanApplyAll(Day60EffectDefinition[] effects, Day60Stats self, Day60Stats selected)
    {
        if (effects == null || effects.Length == 0) return false;
        foreach (var effect in effects)
            if (!CanApply(effect, self, selected)) return false;
        return true;
    }

    public static bool ApplyAll(Day60EffectDefinition[] effects, Day60Stats self, Day60Stats selected)
    {
        if (!CanApplyAll(effects, self, selected)) return false;
        foreach (var effect in effects)
        {
            Day60Stats recipient = effect.target == Day60EffectTarget.Self ? self : selected;
            int amount = Mathf.Max(1, Mathf.RoundToInt(effect.amount));
            switch (effect.type)
            {
                case Day60EffectType.Heal: recipient.TryHeal(amount); break;
                case Day60EffectType.RestoreMana: recipient.TryRestoreMana(amount); break;
                case Day60EffectType.Damage: recipient.TryDamage(amount); break;
                case Day60EffectType.AttackBuff:
                    recipient.ApplyAttackBuff(effect.amount, effect.duration); break;
            }
        }
        return true;
    }
}
