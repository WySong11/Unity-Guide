using System;
using UnityEngine;

public sealed class Day60Stats : MonoBehaviour
{
    [Min(1)] [SerializeField] private int maxHp = 100;
    [Min(1)] [SerializeField] private int maxMana = 100;
    [Min(0)] [SerializeField] private int baseAttack = 10;

    [SerializeField] private int hp = 100;
    [SerializeField] private int mana = 100;
    private float timedAttackBonus;
    private float bonusExpiry;
    private int equipmentAttackBonus;

    public event Action Changed;
    public int Hp => hp;
    public int Mana => mana;
    public int MaxHp => maxHp;
    public int MaxMana => maxMana;
    public bool IsAlive => hp > 0;
    public bool CanHeal => IsAlive && hp < maxHp;
    public bool CanRestoreMana => IsAlive && mana < maxMana;
    public float AttackPower => baseAttack + equipmentAttackBonus + (Time.time < bonusExpiry ? timedAttackBonus : 0f);
    public int EquipmentBonus => equipmentAttackBonus;

    private void Awake()
    {
        hp = Mathf.Clamp(hp, 0, maxHp);
        mana = Mathf.Clamp(mana, 0, maxMana);
    }

    private void Update()
    {
        if (timedAttackBonus <= 0f || Time.time < bonusExpiry) return;
        timedAttackBonus = 0f;
        Changed?.Invoke();
    }

    public bool HasMana(int cost) => IsAlive && cost >= 0 && mana >= cost;

    public bool TrySpendMana(int cost)
    {
        if (!HasMana(cost)) return false;
        mana -= cost;
        Changed?.Invoke();
        return true;
    }

    public bool TryHeal(int amount)
    {
        if (!CanHeal || amount <= 0) return false;
        hp += Mathf.Min(maxHp - hp, amount);
        Changed?.Invoke();
        return true;
    }

    public bool TryRestoreMana(int amount)
    {
        if (!CanRestoreMana || amount <= 0) return false;
        mana += Mathf.Min(maxMana - mana, amount);
        Changed?.Invoke();
        return true;
    }

    public bool TryDamage(int damage)
    {
        if (!IsAlive || damage <= 0) return false;
        hp = Mathf.Max(0, hp - damage);
        Changed?.Invoke();
        return true;
    }

    public bool ApplyAttackBuff(float amount, float duration)
    {
        if (!IsAlive || amount <= 0f || duration <= 0f) return false;
        // 실습 정책: 버프가 중복되면 누적하지 않고 '가장 최근 효과'로 교체합니다.
        timedAttackBonus = amount;
        bonusExpiry = Time.time + duration;
        Changed?.Invoke();
        return true;
    }

    public void SetEquipmentAttackBonus(int bonus)
    {
        equipmentAttackBonus = Mathf.Max(0, bonus);
        Changed?.Invoke();
    }
}
