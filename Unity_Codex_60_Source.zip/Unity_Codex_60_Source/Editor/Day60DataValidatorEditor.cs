#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

public static class Day60DataValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day60/Validate Data Assets")]
    private static void Validate()
    {
        string[] ids = AssetDatabase.FindAssets("t:Day60DataCatalog");
        if (ids.Length == 0)
        {
            EditorUtility.DisplayDialog("Day60 Validation", "Day60DataCatalog 에셋을 찾지 못했습니다.", "OK");
            return;
        }
        int passed = 0;
        int failed = 0;
        foreach (string guid in ids)
        {
            var catalog = AssetDatabase.LoadAssetAtPath<Day60DataCatalog>(AssetDatabase.GUIDToAssetPath(guid));
            string reason = "Catalog 파일을 읽을 수 없습니다";
            bool valid = catalog != null && catalog.Validate(out reason);
            if (valid)
            {
                passed++;
                Debug.Log($"[Day60] PASS {catalog.name} : {reason}");
            }
            else
            {
                failed++;
                Debug.LogError($"[Day60] FAIL {catalog?.name} : {reason}");
            }
        }
        EditorUtility.DisplayDialog("Day60 Validation", $"Catalog PASS {passed}, FAIL {failed}\n세부 결과는 Console을 확인하세요.", "OK");
    }
}
#endif
