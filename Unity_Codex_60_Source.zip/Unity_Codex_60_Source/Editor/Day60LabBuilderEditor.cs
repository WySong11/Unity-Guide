#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class Day60LabBuilderEditor
{
    private const string Menu = "Tools/Unity Codex/Day60/Create Skill Item Data Lab";

    [MenuItem(Menu)]
    private static void Build()
    {
        // 현재 씬에 저장되지 않은 변경 내용이 있으면 저장 여부를 먼저 묻습니다.
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;

        string rootName = "Day60_DataExpansion_Lab";
        int suffix = 2;
        while (AssetDatabase.IsValidFolder("Assets/" + rootName))
            rootName = "Day60_DataExpansion_Lab_" + suffix++;
        AssetDatabase.CreateFolder("Assets", rootName);
        string root = "Assets/" + rootName;
        AssetDatabase.CreateFolder(root, "Data");
        AssetDatabase.CreateFolder(root, "Scenes");
        string dataFolder = root + "/Data";

        Day60SkillData fireball = CreateSkill(dataFolder, "Skill_Fireball", "skill_fireball", "Fireball", 10, 2f,
            Day60EffectType.Damage, Day60EffectTarget.Selected, 20f, 0f);
        Day60SkillData heal = CreateSkill(dataFolder, "Skill_Heal", "skill_heal", "Heal", 15, 5f,
            Day60EffectType.Heal, Day60EffectTarget.Self, 30f, 0f);
        Day60SkillData battleCry = CreateSkill(dataFolder, "Skill_BattleCry", "skill_battlecry", "Battle Cry", 20, 8f,
            Day60EffectType.AttackBuff, Day60EffectTarget.Self, 10f, 5f);

        Day60ItemData potion = CreateItem(dataFolder, "Item_HpPotion", "item_hp_potion", "HP Potion",
            Day60ItemKind.Consumable, 5, 0, Day60EffectType.Heal, Day60EffectTarget.Self, 30f, 0f);
        Day60ItemData ether = CreateItem(dataFolder, "Item_Ether", "item_ether", "Ether",
            Day60ItemKind.Consumable, 5, 0, Day60EffectType.RestoreMana, Day60EffectTarget.Self, 25f, 0f);
        Day60ItemData rune = CreateItem(dataFolder, "Item_AttackRune", "item_attack_rune", "Attack Rune",
            Day60ItemKind.Consumable, 3, 0, Day60EffectType.AttackBuff, Day60EffectTarget.Self, 5f, 6f);
        Day60ItemData sword = CreateItem(dataFolder, "Item_TrainingSword", "item_training_sword", "Training Sword",
            Day60ItemKind.Equipment, 1, 8, Day60EffectType.AttackBuff, Day60EffectTarget.Self, 0f, 0f);

        Day60DataCatalog catalog = ScriptableObject.CreateInstance<Day60DataCatalog>();
        AssetDatabase.CreateAsset(catalog, dataFolder + "/Day60_Catalog.asset");
        SerializedObject cs = new SerializedObject(catalog);
        SetObjectArray(cs.FindProperty("skills"), new Object[] { fireball, heal, battleCry });
        SetObjectArray(cs.FindProperty("items"), new Object[] { potion, ether, rune, sword });
        cs.ApplyModifiedPropertiesWithoutUndo();

        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
        floor.name = "Floor";
        floor.transform.position = new Vector3(1.5f, -0.5f, 0f);
        floor.transform.localScale = new Vector3(9f, 1f, 6f);

        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Player_Day60";
        player.transform.position = new Vector3(-1.5f, 1f, 0f);
        Day60Stats playerStats = player.AddComponent<Day60Stats>();
        Day60Inventory inventory = player.AddComponent<Day60Inventory>();
        Day60SkillRunner runner = player.AddComponent<Day60SkillRunner>();
        Day60EquipmentController equipment = player.AddComponent<Day60EquipmentController>();
        Day60SaveSystem save = player.AddComponent<Day60SaveSystem>();
        Day60DemoHUD hud = player.AddComponent<Day60DemoHUD>();

        GameObject target = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        target.name = "Target_Day60";
        target.transform.position = new Vector3(2f, 1f, 0f);
        target.transform.localScale = new Vector3(1.3f, 1.3f, 1.3f);
        Day60Stats targetStats = target.AddComponent<Day60Stats>();

        SerializedObject e = new SerializedObject(equipment);
        e.FindProperty("inventory").objectReferenceValue = inventory;
        e.FindProperty("stats").objectReferenceValue = playerStats;
        e.ApplyModifiedPropertiesWithoutUndo();
        SerializedObject ss = new SerializedObject(save);
        ss.FindProperty("inventory").objectReferenceValue = inventory;
        ss.FindProperty("equipment").objectReferenceValue = equipment;
        ss.FindProperty("catalog").objectReferenceValue = catalog;
        ss.ApplyModifiedPropertiesWithoutUndo();
        SerializedObject hs = new SerializedObject(hud);
        hs.FindProperty("player").objectReferenceValue = playerStats;
        hs.FindProperty("target").objectReferenceValue = targetStats;
        hs.FindProperty("runner").objectReferenceValue = runner;
        hs.FindProperty("inventory").objectReferenceValue = inventory;
        hs.FindProperty("equipment").objectReferenceValue = equipment;
        hs.FindProperty("saveSystem").objectReferenceValue = save;
        SetObjectArray(hs.FindProperty("skills"), new Object[] { fireball, heal, battleCry });
        SetObjectArray(hs.FindProperty("starterItems"), new Object[] { potion, ether, rune, sword });
        hs.ApplyModifiedPropertiesWithoutUndo();

        Camera camera = Camera.main;
        if (camera != null)
        {
            camera.transform.position = new Vector3(0f, 5f, -9f);
            camera.transform.LookAt(new Vector3(0f, 1.0f, 0f));
        }
        EditorSceneManager.SaveScene(scene, root + "/Scenes/Day60_SkillItemDataLab.unity");
        EditorUtility.SetDirty(catalog);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        EditorUtility.DisplayDialog("Day60 Lab", "새 폴더에 Skill 3종·Item 4종·Scene이 생성되었습니다.\n" + root, "OK");
    }

    private static Day60SkillData CreateSkill(string folder, string assetName, string id, string name, int mana, float cd,
        Day60EffectType type, Day60EffectTarget target, float amount, float duration)
    {
        var asset = ScriptableObject.CreateInstance<Day60SkillData>();
        AssetDatabase.CreateAsset(asset, folder + "/" + assetName + ".asset");
        var so = new SerializedObject(asset);
        so.FindProperty("skillId").stringValue = id;
        so.FindProperty("displayName").stringValue = name;
        so.FindProperty("manaCost").intValue = mana;
        so.FindProperty("cooldown").floatValue = cd;
        SetEffect(so.FindProperty("effects"), type, target, amount, duration);
        so.ApplyModifiedPropertiesWithoutUndo();
        return asset;
    }

    private static Day60ItemData CreateItem(string folder, string assetName, string id, string name,
        Day60ItemKind kind, int stack, int equipBonus, Day60EffectType type,
        Day60EffectTarget target, float amount, float duration)
    {
        var asset = ScriptableObject.CreateInstance<Day60ItemData>();
        AssetDatabase.CreateAsset(asset, folder + "/" + assetName + ".asset");
        var so = new SerializedObject(asset);
        so.FindProperty("itemId").stringValue = id;
        so.FindProperty("displayName").stringValue = name;
        so.FindProperty("kind").enumValueIndex = (int)kind;
        so.FindProperty("maxStack").intValue = stack;
        so.FindProperty("equipAttackBonus").intValue = equipBonus;
        if (kind == Day60ItemKind.Consumable)
            SetEffect(so.FindProperty("effects"), type, target, amount, duration);
        else
            so.FindProperty("effects").arraySize = 0;
        so.ApplyModifiedPropertiesWithoutUndo();
        return asset;
    }

    private static void SetEffect(SerializedProperty array, Day60EffectType type,
        Day60EffectTarget target, float amount, float duration)
    {
        array.arraySize = 1;
        var effect = array.GetArrayElementAtIndex(0);
        effect.FindPropertyRelative("type").enumValueIndex = (int)type;
        effect.FindPropertyRelative("target").enumValueIndex = (int)target;
        effect.FindPropertyRelative("amount").floatValue = amount;
        effect.FindPropertyRelative("duration").floatValue = duration;
    }

    private static void SetObjectArray(SerializedProperty array, Object[] assets)
    {
        array.arraySize = assets.Length;
        for (int i = 0; i < assets.Length; i++)
            array.GetArrayElementAtIndex(i).objectReferenceValue = assets[i];
    }
}
#endif
