# UNITY × CODEX | 60일차 — 스킬/아이템 데이터 확장

- 기준: Unity 6.3, 3D 프로젝트, 120분 수업
- 목표: **SkillData/ItemData(ScriptableObject) 정의와 런타임 상태를 분리하고 공통 EffectEngine을 실습**합니다.
- 58~59일차를 직접 수정하지 않습니다. 새 접두사 `Day60`으로 충돌을 방지합니다.
- 의존성: Unity 기본 기능, `UnityEditor`(Editor 폴더의 도구에서만 사용). New Input System 패키지 없어도 GUI 버튼으로 실습 가능.

## 설치

1. Unity 6.3 프로젝트를 백업 또는 Git 커밋합니다.
2. 압축 해제한 `Runtime`, `Editor` 폴더를 프로젝트의 `Assets/Day60_SkillItemData/` 아래 복사합니다.
3. Console의 스크립트 컴파일 오류를 먼저 확인합니다.
4. 메뉴 **Tools > Unity Codex > Day60 > Create Skill Item Data Lab**을 선택합니다.
5. 기존 씬의 변경 사항 저장 여부가 나오면 선택합니다. 확인 후 신규 폴더(`Assets/Day60_DataExpansion_Lab[_숫자]`)에 SO 데이터 8개(스킬 3·아이템 4·Catalog 1)와 Scene이 생성됩니다.
6. 열린 `Day60_SkillItemDataLab` 씬에서 Play를 누릅니다. 화면 왼쪽 IMGUI 패널 버튼으로 실습합니다.
7. 메뉴 **Tools > Unity Codex > Day60 > Validate Data Assets**로 ID, 종류, 수치 조건을 검증합니다.

## 실습 조작

- **Damage Player -40**: HP를 낮춰 Heal / HP Potion 테스트
- **Damage Target -20**: 타깃 체력 변화 확인
- **Fireball / Heal / Battle Cry**: ManaCost, Cooldown, Effect 조건 확인
- **Add HP Potion / Ether / Attack Rune / Training Sword**: 인벤토리 스택에 1개씩 추가
- **Use / Equip**: 소비 아이템 효과 적용 또는 장비 장착
- **Unequip**: 장착 보너스를 0으로 하고 인벤토리에 반환(빈 칸 필요)
- **Save / Load**: `Application.persistentDataPath/day60_inventory.json`에 장비·슬롯을 문자열 ID로 저장/복원

## 기본 데이터

| 종류 | ID | 소비·쿨타임 | 효과 |
|---|---|---|---|
| Fireball (Skill) | skill_fireball | Mana 10 / CD 2s | Selected HP -20 |
| Heal (Skill) | skill_heal | Mana 15 / CD 5s | Self HP +30 |
| Battle Cry (Skill) | skill_battlecry | Mana 20 / CD 8s | Self Attack +10 / 5s |
| HP Potion (Item) | item_hp_potion | MaxStack 5 | Self HP +30 |
| Ether (Item) | item_ether | MaxStack 5 | Self Mana +25 |
| Attack Rune (Item) | item_attack_rune | MaxStack 3 | Self Attack +5 / 6s |
| Training Sword (Item) | item_training_sword | MaxStack 1 | Equipped Attack +8 |

## 데이터와 실행 상태의 차이

- SO의 `ManaCost`, `Effects[]`, `MaxStack`, `EquipAttackBonus`는 에셋 설정입니다.
- `Day60Stats`의 HP/Mana 및 공격 버프 만료시각, `Day60SkillRunner`의 스킬 ID별 다음 시전 시각, `Day60Inventory`의 슬롯/수량은 개별 런타임 상태입니다.
- 하나의 EffectEngine을 사용하지만 Skill의 **마나/쿨타임**, Item의 **수량**, Equipment의 **패시브**는 각 컨트롤러에서 처리합니다.
- 실습 버프는 최신 사용 효과로 **교체/갱신**되며 누적되지 않습니다. 장비 보너스는 별도 가산합니다.
- 복합 효과는 **모든 효과에 대한 사용 가능 판정이 통과해야 사용**하는 수업용 정책입니다. 실제 제품에서는 회복량 0 또는 중간 실패에 대한 더 강한 트랜잭션 설계가 필요할 수 있습니다.

## 주의

- 플레이어 HP가 가득 찬 상태에서는 Heal/HP Potion이 실패하는 것이 정상입니다.
- 타깃 HP가 0이면 Damage 대상이 유효하지 않아 Fireball을 거절합니다.
- 쿨타임 계산은 `Time.time`이므로 `Time.timeScale = 0` 동안 시간이 흐르지 않습니다.
- 장비는 `EquipAttackBonus`를 사용하며 해당 보너스를 SO의 Effects에서 반복 적용하지 않습니다.
- Load는 **Inventory 슬롯·장비 ID**만 복원합니다. HP·Mana·진행 중인 버프/쿨타임은 저장 대상이 아닙니다.
- 변경된 SO 자체를 빌드 런타임의 영구 저장 장소로 사용하지 않습니다.
- 이 자료는 Unity Editor의 실제 컴파일/Play Mode 결과를 주장하지 않습니다. 첨부 체크리스트로 각자 실행 검증하세요.

## 폴더 구성

- `Runtime`: 독립 실행 C# 예제 11개
- `Editor`: 실습 폴더·에셋·씬 자동 생성 및 데이터 검사 2개
- `Docs`: 학생 워크시트, 강사 노트, 평가표, 테스트 매트릭스, Codex 프롬프트

## 공식 참고

- ScriptableObject: https://docs.unity3d.com/kr/current/Manual/class-ScriptableObject.html
- JSON 직렬화: https://docs.unity3d.com/kr/current/Manual/json-serialization.html
