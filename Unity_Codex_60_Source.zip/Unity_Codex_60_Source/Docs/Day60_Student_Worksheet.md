# 60일차 학생 실습 워크시트 (120분)

**이름:** ____________    **날짜:** ____________

### 1교시 · 데이터 에셋 생성 (0~25분)

- [ ] 새 실습 폴더를 생성했다. 기존 프로젝트 스크립트는 변경하지 않았다.
- [ ] SkillData 3종, ItemData 4종, Catalog 1종 생성했다.
- [ ] `skill_fireball`, `item_hp_potion` 등 ID 중복이 없는지 확인했다.
- [ ] 효과 Type, Target, Amount, Duration의 차이를 설명할 수 있다.

### 2교시 · 공통 효과 적용 (25~60분)

- [ ] Fireball: 대상 HP 20 감소, Mana 10 감소, CD 2초
- [ ] Heal: 플레이어가 상처를 입은 상태에서 HP 30 회복
- [ ] Full HP일 때 Heal 거절·Mana 보존
- [ ] HP Potion과 Heal이 같은 효과(Heal)를 사용하는 것을 확인
- [ ] Attack Rune: 6초 동안 공격력 +5 적용 후 복귀

### 3교시 · 장비/저장 (60~100분)

- [ ] Training Sword 장착 시 공격력 +8
- [ ] 장비 해제 시 +8 보너스 해제
- [ ] 인벤토리 수량·장비를 Save 한 뒤 변경하고 Load로 복원
- [ ] JSON에 `itemId`, `quantity`, `index`, `equippedItemId`가 있는지 확인

### 4교시 · 회귀 검증 (100~120분)

- [ ] T01~T12 각각 PASS/FAIL 기재
- [ ] SO 에셋 원본과 Play Mode 후 값 비교
- [ ] Codex 코드 검토 결과의 diff와 재검증 근거 기록

**오류 상황 / 재현 단계:**

1. 
2. 
3. 

**실습 스크린샷 이름:** `Day60_01_Data.png`, `Day60_02_Skill.png`, `Day60_03_Inventory.png`, `Day60_04_Save.png`

**종합 소감 / 개선안:**
