# Codex 지시 프롬프트 — Day60

## P1. 코드 설계 리뷰

```
Unity 6.3, C# Day60 Skill/Item Data 확장 실습을 검토해줘.
1) ScriptableObject 원본 데이터와 플레이어별 HP/Mana/SkillCooldown/Inventory의 런타임 상태가 섞였는지 검사.
2) SkillData와 ItemData가 공통 EffectDefinition/EffectEngine을 사용하는지 점검.
3) 모든 Effect가 적용 가능한지 선검사 후 자원·수량이 소비되는지 확인.
4) Equipment 보너스가 반복 장착 시 중복 증가하지 않는지 검증.
5) JsonUtility DTO의 아이템 ID, 슬롯 중복, 수량 범위 검증을 확인.
6) 수정 전에 결함 증거를 제시하고 최소 diff로 고친 뒤 T01~T12 회귀 계획을 작성.
수정하지 않은 부분은 명시하고, 실제 Unity Play Mode를 실행하지 않았다면 PASS라고 단정하지 마.
```

## P2. 데이터 밸런스 확장

```
현재 Day60SkillData와 Day60ItemData 에셋에 기반하여
Rare/Normal Rarity, EquipSlot, MagicAttack 효과를 추가하는 설계를 제안해줘.
기존 에셋 ID를 변경하지 말고 직렬화 호환성·저장 버전 변경을 설명해줘.
새로운 MonoBehaviour가 불필요하게 늘어나지 않도록 책임 경계를 유지해줘.
```

## P3. 실행 테스트 지시

```
Unity Editor가 실제 연결되어 있다면 Day60_SkillItemDataLab 씬을 열고
Console 컴파일 오류 0개 확인 → T01~T12 순서대로 실행해줘.
각 항목의 실제 결과 값(HP/Mana/Attack/Count/JSON)을 표에 기록하고,
실행 불가 항목은 NOT RUN으로 표시해줘. 실패한 테스트만 최소 수정 후 재시험해줘.
```
