# 강사용 진행 가이드 — Day60

## 학습 연결

57일차 ScriptableObject 기본 데이터 → 58일차 스킬·쿨타임 → 59일차 인벤토리 → 60일차 데이터·효과의 공통화와 장비/저장 확장.

## 강의 도입 질문

1. Heal Skill과 Potion이 같은 회복 효과를 갖는데 왜 코드가 두 군데 필요할까?
2. SkillData의 `cooldown`과 스킬 사용 후 `remainingCooldown`의 저장 위치가 달라야 하는 이유는?
3. 아이템 SO 자체를 JSON으로 직렬화하면 왜 식별/복원하기 어려운가?

## 120분 권장 진행

- 0~25분: SO 구성·효과 타입·실행 상태 분리
- 25~60분: 공통 Engine·마나/쿨타임·포션 소비 규칙
- 60~100분: 장비 교체·ID Catalog·JSON Save/Load
- 100~120분: 12개 케이스 확인·Codex 리뷰

## 예상 오류

- `CanHeal == false`에서 Potion이 소모된다면 Item.TryUse의 사전 검사부터 확인
- Fireball이 안 나가면 target HP가 0인지, 쿨타임인지, Mana 부족인지 확인
- 버프가 5초 뒤 사라지지 않으면 Time.time과 timeScale 확인
- Equipment +8이 중첩되면 Add가 아니라 Set으로 변경했는지 확인
- 로드 실패면 중복 slotIndex, 알려지지 않은 ItemId, MaxStack 초과 여부 확인
- `UnityEditor` 타입을 Runtime 폴더에서 쓰면 빌드 오류가 발생할 수 있음

## 평가 시 유의

PPT/압축 파일의 정적 구조 검사는 실행 검증과 다릅니다. Unity Editor 컴파일, Play Mode, 실제 JSON 저장 위치를 학생 PC에서 확인해야 합니다.

## 심화 과제

- Buff 중복 시 갱신·가산·최대치 우선 정책을 ScriptableObject로 분리
- Item Rarity/EquipSlot과 복합 EffectCondition 도입
- 저장 버전 마이그레이션, 플레이어별 인벤토리 분리
- New Input System과 UI Toolkit/TMP UI로 데모 GUI 대체
