#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using UnityEngine.AI;

public static class Day51SceneValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day51/Validate Current Scene")]
    public static void Validate()
    {
        var brains = UnityEngine.Object.FindObjectsByType<Day51EnemyBrain>(FindObjectsSortMode.None);
        if (brains.Length == 0) Debug.LogError("[Day51] Day51EnemyBrain 없음");
        foreach (var brain in brains)
        {
            bool ok = true;
            NavMeshAgent nav = brain.GetComponent<NavMeshAgent>();
            if (nav == null || !nav.isOnNavMesh) { Debug.LogWarning("[Day51] NavMeshAgent가 Bake된 Mesh 위에 없습니다.", brain); ok = false; }
            if (brain.GetComponent<Day50EnemyPerception>() == null) { Debug.LogError("[Day51] Perception 없음", brain); ok = false; }
            if (brain.GetComponent<Day51EnemyAttack>() == null) { Debug.LogError("[Day51] Attack 없음", brain); ok = false; }
            if (brain.GetComponent<Day51EnemyHealth>() == null) { Debug.LogError("[Day51] Health 없음", brain); ok = false; }
            if (brain.GetComponent<Day50EnemyBrain>() != null) { Debug.LogError("[Day51] Day50EnemyBrain과 동시 부착 금지", brain); ok = false; }
            if (ok) Debug.Log("[Day51] 기본 컴포넌트 검사 통과. Play Mode 테스트는 별도 수행하세요.", brain);
        }
    }
}
#endif
