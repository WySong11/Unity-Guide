#if UNITY_EDITOR
using System;
using Unity.AI.Navigation;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.SceneManagement;

public static class Day51SceneBuilderEditor
{
    private const string Root = "Assets/UnityCodexDay51";
    [MenuItem("Tools/Unity Codex/Day51/Create Attack Return Dead Lab")]
    public static void CreateLab()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        Folder(Root);
        Folder(Root + "/Scenes");
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        GameObject lab = new GameObject("Day51_AttackReturnDead_Lab");
        GameObject navRoot = new GameObject("NavigationGeometry");
        navRoot.transform.SetParent(lab.transform);
        Cube("Ground", new Vector3(0, -0.25f, 0), new Vector3(25, .5f, 25), navRoot.transform);
        Cube("Wall_Left", new Vector3(-4, 1, 0), new Vector3(1, 2, 6), navRoot.transform);
        Cube("Wall_Right", new Vector3(4, 1, 0), new Vector3(1, 2, 6), navRoot.transform);
        GameObject waypoints = new GameObject("PatrolPoints");
        waypoints.transform.SetParent(lab.transform);
        Vector3[] positions = { new Vector3(-8,0,-8), new Vector3(-8,0,8), new Vector3(8,0,8), new Vector3(8,0,-8) };
        Transform[] points = new Transform[positions.Length];
        for (int i = 0; i < positions.Length; i++)
        {
            GameObject p = new GameObject($"WP_{i:00}");
            p.transform.SetParent(waypoints.transform); p.transform.position = positions[i]; points[i] = p.transform;
        }
        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Player_Test"; player.transform.SetParent(lab.transform);
        player.transform.position = new Vector3(0, 1, 8);
        UnityEngine.Object.DestroyImmediate(player.GetComponent<CapsuleCollider>());
        player.AddComponent<CharacterController>(); player.AddComponent<Day50PlayerMover>(); player.AddComponent<Day51PlayerHealth>();
        GameObject enemy = new GameObject("Enemy_AttackReturnDead");
        enemy.transform.SetParent(lab.transform); enemy.transform.position = positions[0];
        GameObject visual = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        visual.name = "Visual"; visual.transform.SetParent(enemy.transform, false); visual.transform.localPosition = Vector3.up;
        UnityEngine.Object.DestroyImmediate(visual.GetComponent<CapsuleCollider>());
        NavMeshAgent agent = enemy.AddComponent<NavMeshAgent>();
        agent.radius = .45f; agent.height = 2f; agent.speed = 2f; agent.angularSpeed = 560f;
        enemy.AddComponent<Day50EnemyNavigation>();
        Day50EnemyPerception sensor = enemy.AddComponent<Day50EnemyPerception>(); sensor.Configure(player.transform);
        Day50PatrolRoute route = enemy.AddComponent<Day50PatrolRoute>(); route.Configure(points);
        enemy.AddComponent<Day51EnemyAttack>();
        Day51EnemyHealth health = enemy.AddComponent<Day51EnemyHealth>();
        enemy.AddComponent<Day51EnemyBrain>();
        enemy.AddComponent<Day51EnemyAnimatorBridge>();
        enemy.AddComponent<Day51AIDiagnostics>();
        Day51LabControls debug = enemy.AddComponent<Day51LabControls>();
        SerializedObject serialized = new SerializedObject(debug);
        serialized.FindProperty("enemy").objectReferenceValue = health;
        serialized.ApplyModifiedPropertiesWithoutUndo();
        GameObject cam = new GameObject("Main Camera"); cam.tag = "MainCamera";
        cam.AddComponent<Camera>(); cam.AddComponent<AudioListener>();
        cam.AddComponent<Day50FollowCamera>().Configure(player.transform);
        cam.transform.position = new Vector3(0, 12, -12);
        GameObject light = new GameObject("Directional Light");
        light.AddComponent<Light>().type = LightType.Directional;
        light.transform.rotation = Quaternion.Euler(50, -30, 0);
        NavMeshSurface surface = navRoot.AddComponent<NavMeshSurface>();
        surface.collectObjects = CollectObjects.Children;
        surface.useGeometry = NavMeshCollectGeometry.PhysicsColliders;
        string path = AssetDatabase.GenerateUniqueAssetPath(Root + "/Scenes/Day51_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".unity");
        EditorSceneManager.SaveScene(scene, path);
        surface.BuildNavMesh();
        EditorSceneManager.SaveScene(scene, path);
        Selection.activeGameObject = enemy;
        Debug.Log("[Day51] Scene ready: " + path + " | WASD Player, 1 Damage, 2 Kill, F1 HUD");
    }
    private static void Folder(string full)
    {
        if (AssetDatabase.IsValidFolder(full)) return;
        string parent = full.Substring(0, full.LastIndexOf('/'));
        string name = full.Substring(full.LastIndexOf('/') + 1);
        AssetDatabase.CreateFolder(parent, name);
    }
    private static GameObject Cube(string name, Vector3 pos, Vector3 scale, Transform parent)
    {
        GameObject o = GameObject.CreatePrimitive(PrimitiveType.Cube);
        o.name = name; o.transform.SetParent(parent); o.transform.position = pos; o.transform.localScale = scale;
        return o;
    }
}
#endif
