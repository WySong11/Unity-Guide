# Unity × Codex 51일차 — Attack · Return · Dead 구현

- **기준 환경:** Unity 6.3 / URP (Universal 3D) / Input System / AI Navigation (NavMeshSurface)
- **선행:** 49일차 FSM, 50일차 Patrol/Chase. 소스의 `Dependencies_Day50`에는 필요한 Day50 보조 컴포넌트 5개가 포함됩니다.
- **교육 목표:** Attack, Return, Dead의 상태 전환과 전투·체력·NavMesh 상태를 안전하게 통합합니다.

## 설치 방법

1. 새 Unity 6.3 URP 프로젝트 또는 50일차 프로젝트를 엽니다.
2. **Window > Package Manager**에서 `AI Navigation`, `Input System` 설치 여부를 확인합니다.
3. `Runtime`과 `Editor`를 각각 `Assets/UnityCodexDay51/Runtime`, `Assets/UnityCodexDay51/Editor`에 복사합니다.
4. **기존 프로젝트에 Day50 컴포넌트가 있으면** `Dependencies_Day50` 폴더는 중복 복사하지 않습니다. 그렇지 않으면 `Dependencies_Day50`의 5개 `.cs` 파일을 `Runtime` 아래로 복사합니다.
5. `Tools > Unity Codex > Day51 > Create Attack Return Dead Lab`을 실행합니다. 수정한 기존 씬은 저장 여부를 먼저 묻고, 새로운 고유 씬 파일을 생성합니다.
6. 자동 생성된 Lab에서 `NavMeshSurface`가 Bake되었는지 확인합니다. AI Navigation이 설치되지 않으면 Editor 코드가 컴파일되지 않으므로 패키지를 먼저 설치하세요.
7. Play Mode: **WASD 플레이어 이동**, **1=Enemy 25 데미지**, **2=즉시 사망**, **F1=AI HUD 표시 전환**.
8. `Tools > Unity Codex > Day51 > Validate Current Scene`으로 필수 컴포넌트를 점검합니다.

## 이전 수업 프로젝트에 통합할 때

- 기존 Enemy에 붙어 있는 **`Day50EnemyBrain`을 제거하거나 비활성화**하고 `Day51EnemyBrain`만 사용하세요. 두 Brain이 동시에 상태와 NavMeshAgent를 수정하면 충돌합니다.
- `Day50EnemyNavigation`, `Day50EnemyPerception`, `Day50PatrolRoute`는 그대로 재사용합니다.
- Enemy에 `Day51EnemyAttack`, `Day51EnemyHealth`, `Day51EnemyBrain`을 추가합니다.
- Player 루트에 `Day51PlayerHealth`를 추가하거나 기존 PlayerHealth를 `IDay51Damageable`로 감싸는 어댑터를 작성합니다.
- `Day51EnemyAnimatorBridge`는 **Animator와 Animator Controller가 있어야** 시각적인 Attack / Die를 표시합니다. 제공하는 자동 생성 Lab에서는 캐릭터 Capsule만 있으므로 Animator를 별도로 연결하세요.
- 공격 피해는 기본적으로 **공격 시작 → Windup 경과 → 거리·방향 확인 → 1회 피해** 경로에서 발생합니다. Animation Event로 피해를 구현한다면 **기본 코루틴 피해 경로를 비활성화**하여 이중 데미지를 방지하세요.

## 구성

`Runtime` (9개): `Day51EnemyState`, `IDay51Damageable`, `Day51EnemyHealth`, `Day51PlayerHealth`, `Day51EnemyAttack`, `Day51EnemyBrain`, `Day51EnemyAnimatorBridge`, `Day51AIDiagnostics`, `Day51LabControls`.

`Editor` (2개): 실습 씬 생성, 씬 검사.

`Dependencies_Day50` (5개): `Day50EnemyNavigation`, `Day50EnemyPerception`, `Day50PatrolRoute`, `Day50PlayerMover`, `Day50FollowCamera`.

`Docs`: Codex 프롬프트, 학생 워크시트, 강사용 체크, 16항목 테스트 매트릭스.

## 알려진 조건 및 주의 사항

- Unity Editor에서 실제 컴파일/Play Mode 자동 검증을 수행한 결과물은 아닙니다. 환경·패키지·씬에 맞춘 검증이 필요합니다.
- `Day51EnemyBrain`은 테스트를 위해 Patrol/Chase의 핵심 이동 코드를 재구성했습니다. 50일차 고급 Path Recovery/Waypoint Error 처리 로직은 프로젝트 상황에 맞춰 옮겨 주세요.
- 테스트용 Enemy 사망 후 GameObject는 즉시 삭제하지 않습니다. Dead 상태의 Animator/이펙트 연동을 실습하기 위한 의도입니다.
- `Day51LabControls`는 강의 데모 전용입니다. 실제 게임에서는 별도 Input/Combat 시스템으로 교체하세요.

## 관련 공식 문서

- NavMeshAgent: https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/ai/navmeshagent
- SetDestination: https://docs.unity.com/en-us/engine/6000.6/script-reference/unityengine/ai/navmeshagent/setdestination
- Animation Events: Unity Manual의 Animation Events 항목 참조.
