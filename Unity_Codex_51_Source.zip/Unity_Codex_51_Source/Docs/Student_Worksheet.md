# 51일차 학생 실습 워크시트 (120분)

## A. 설계 (20분)
- [ ] 50일차 Patrol·Chase·Return 흐름을 직접 설명할 수 있다.
- [ ] Attack 진입/유지/이탈 조건을 기록했다.
- [ ] Dead가 모든 상태보다 우선하는 이유를 설명했다.

**질문:** 공격 범위에 들어왔지만 벽이 사이에 있다면 어떤 상태로 있어야 하는가? 이유를 적으세요.

## B. 실습 (55분)
- [ ] Scene Builder 실행 및 NavMesh Bake 확인
- [ ] Enemy에 Day51EnemyBrain만 부착됨 확인
- [ ] EnemyAttack Range 1.8 / Interval 1.2 / Windup 0.3 적용
- [ ] PlayerHealth의 피해 로그 확인
- [ ] EnemyHealth의 Died 이벤트 처리 확인
- [ ] Return 중 재탐지 처리 확인

## C. 검증 (45분)
- [ ] `Test_Checklist.csv` 16개 케이스 실행
- [ ] 1번 키로 Enemy 체력 감소, 2번 키로 즉시 사망 확인
- [ ] F1 Debug HUD에서 State와 Attack CD 확인
- [ ] Codex에 로그를 제공해 최소 수정·회귀 검증 지시

### 제출물
1. Scene 화면과 Inspector 캡처 (3장 이상)
2. FSM 전이표 (1장)
3. 테스트 결과 CSV
4. Codex 수정 요청·변경 diff·재검증 요약
