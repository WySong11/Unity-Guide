# 강사용 해설 / 관찰 기준

- 공격 시작 조건: Target 활성/생존, AttackRange 이내, LOS 유효, Attack CD 0.
- 피해 처리 타이밍: Windup 경과 후 Target 활성/생존·거리·방향을 재확인해 한 번만 적용.
- Attack → Chase: LOS가 확보된 상태에서 ExitPadding 이상 멀어졌을 때.
- Attack → Return: LOS 상실 시간이 LostDelay 이상 누적될 때. 잠깐 시야 상실에서는 공격 취소만 하고 LostTimer 유지.
- Return → Chase: 재탐지 성공 시.
- Return → Patrol: 정상 도착·안전한 대체 종료 시.
- Any → Dead: EnemyHealth Died 이벤트, 공격 중단 및 Agent.Stop, 재전이 차단.
- 이벤트 구독: OnEnable, OnDisable에서 쌍으로 관리.
- 대표 버그: AnimationEvent와 Coroutine에서 동시 데미지 처리, Attack에서 Agent.isStopped 해제 누락, Dead 후 공격 Coroutine 잔존, Return에서 경로 없음·무한 대기.

**평가 배점:** Attack 30 / Return 20 / Dead·HP 25 / 구조 15 / Codex 검증 10 = 100점.

본 자료의 자동 Lab은 재사용 예제이며 50일차의 고급 경로 복구 알고리즘을 완전히 대체하는 상용 AI는 아닙니다.
