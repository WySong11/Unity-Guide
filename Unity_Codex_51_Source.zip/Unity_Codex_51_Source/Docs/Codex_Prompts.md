# Codex 실습 프롬프트

## 1차: 구조 분석과 전이표

```text
Unity 6.3, AI Navigation/NavMeshAgent 프로젝트입니다.
현재 Day50 Enemy AI 관련 C# 소스를 먼저 읽고 Patrol/Chase/Return 전이를 설명해 주세요.
이번에는 Attack, Return, Dead를 확장할 계획입니다.
수정 전에 상태 전이표, 컴포넌트별 책임, 위험한 중복 로직, Inspector 연결 계획을 먼저 작성하세요.
기존 파일을 임의로 삭제하거나 Day50EnemyBrain과 Day51EnemyBrain을 동시에 붙이지 마세요.
```

## 2차: 구현

```text
Enemy Attack/Return/Dead를 추가해 주세요.
Attack: 사거리/LOS/선딜레이/쿨다운/피해 1회/타깃 상실 시 공격 취소.
Return: 가까운 Waypoint 복귀, 재탐지 시 Chase, 경로 실패와 타임아웃 보호.
Dead: HP=0이면 이벤트 1회, 공격 코루틴 취소, NavMesh Stop/ResetPath, 이후 상태 전이 금지.
Input/Navigation/Health/Animation 책임을 분리하고 SerializeField 의존성을 검사해 주세요.
수정 파일별 diff, 기본 테스트, Unity Editor에서 수동 확인할 항목을 보고하세요.
```

## 3차: 오류 검증

```text
오류를 수정하기 전에 재현 절차와 증거 로그를 정리하세요.
증상: [Console/현상을 붙여넣기]
현재 상태: [State/HP/isStopped/pathStatus/Attack CD/LostTimer]
가설을 우선순위로 정하고 최소 수정만 적용하세요.
수정 후 Attack/Return/Dead뿐 아니라 Patrol/Chase 회귀 테스트를 진행하세요.
실행하지 못한 테스트는 PASS라고 쓰지 말고 NOT RUN으로 표기하세요.
```
