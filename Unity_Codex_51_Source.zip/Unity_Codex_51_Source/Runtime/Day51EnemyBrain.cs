using System;
using UnityEngine;

/// <summary>Day50 Navigation / Perception / PatrolRoute를 재사용하고 Attack·Return·Dead로 확장.</summary>
[RequireComponent(typeof(Day50EnemyNavigation), typeof(Day50EnemyPerception), typeof(Day50PatrolRoute))]
[RequireComponent(typeof(Day51EnemyAttack), typeof(Day51EnemyHealth))]
public sealed class Day51EnemyBrain : MonoBehaviour
{
    [SerializeField] private Day50EnemyNavigation navigation;
    [SerializeField] private Day50EnemyPerception perception;
    [SerializeField] private Day50PatrolRoute route;
    [SerializeField] private Day51EnemyAttack attack;
    [SerializeField] private Day51EnemyHealth health;
    [SerializeField, Min(0.1f)] private float repathInterval = 0.25f;
    [SerializeField, Min(0.1f)] private float lostTargetDelay = 1.5f;
    [SerializeField, Min(0f)] private float attackExitPadding = 0.5f;
    [SerializeField, Min(0.2f)] private float returnTimeout = 5f;

    public Day51EnemyState State { get; private set; } = Day51EnemyState.Patrol;
    public event Action<Day51EnemyState> StateChanged;
    public float LostTimer => lostTimer;
    public Day50EnemyNavigation Navigation => navigation;
    public Day50EnemyPerception Perception => perception;
    public Day51EnemyAttack Attack => attack;

    private float lostTimer, repathTimer, patrolWait, returnTimer;
    private bool waiting;
    private Vector3 lastSeenPosition, returnPosition;

    private void Awake()
    {
        if (!navigation) navigation = GetComponent<Day50EnemyNavigation>();
        if (!perception) perception = GetComponent<Day50EnemyPerception>();
        if (!route) route = GetComponent<Day50PatrolRoute>();
        if (!attack) attack = GetComponent<Day51EnemyAttack>();
        if (!health) health = GetComponent<Day51EnemyHealth>();
    }
    private void OnEnable()
    {
        if (health != null) health.Died += EnterDead;
    }
    private void OnDisable()
    {
        if (health != null) health.Died -= EnterDead;
        if (attack != null) attack.CancelAttack();
        if (navigation != null && navigation.Ready) navigation.Stop();
    }
    private void Start() => BeginPatrol();
    private void Update()
    {
        if (State == Day51EnemyState.Dead || navigation == null || !navigation.Ready) return;
        if (State == Day51EnemyState.Patrol || State == Day51EnemyState.Return)
        {
            if (perception.CanAcquire()) { BeginChase(); return; }
        }
        switch (State)
        {
            case Day51EnemyState.Patrol: UpdatePatrol(); break;
            case Day51EnemyState.Chase: UpdateChase(); break;
            case Day51EnemyState.Attack: UpdateAttack(); break;
            case Day51EnemyState.Return: UpdateReturn(); break;
        }
    }
    private void SetState(Day51EnemyState next)
    {
        if (State == Day51EnemyState.Dead || State == next) return;
        State = next;
        StateChanged?.Invoke(State);
        Debug.Log($"[Day51] Enemy State: {State}", this);
    }
    private void BeginPatrol()
    {
        if (!route || !route.HasPoints) { Debug.LogWarning("[Day51] Patrol Waypoints missing", this); return; }
        navigation.SetPatrolMode();
        waiting = false; patrolWait = 0f;
        SetState(Day51EnemyState.Patrol);
        navigation.TryGo(route.CurrentPoint);
    }
    private void UpdatePatrol()
    {
        if (!route || !route.HasPoints) return;
        if (!waiting)
        {
            if (!navigation.Agent.pathPending && !navigation.Agent.hasPath)
                navigation.TryGo(route.CurrentPoint);
            if (navigation.HasArrived() || Vector3.Distance(transform.position, route.CurrentPoint) < 0.35f)
            {
                waiting = true;
                patrolWait = route.WaitAtPoint;
                navigation.Stop();
            }
        }
        else if ((patrolWait -= Time.deltaTime) <= 0f)
        {
            route.Advance(); waiting = false;
            navigation.SetPatrolMode();
            navigation.TryGo(route.CurrentPoint);
        }
    }
    private void BeginChase()
    {
        if (perception.Target == null) return;
        lostTimer = 0f; repathTimer = 0f;
        lastSeenPosition = perception.Target.position;
        navigation.SetChaseMode(attack.AttackRange);
        SetState(Day51EnemyState.Chase);
    }
    private void UpdateChase()
    {
        if (CheckLostTarget()) return;
        if (perception.CanKeepSight() && perception.DistanceToTarget <= attack.AttackRange)
        {
            EnterAttack(); return;
        }
        repathTimer -= Time.deltaTime;
        if (repathTimer <= 0f)
        {
            navigation.SetChaseMode(attack.AttackRange);
            navigation.TryGo(lastSeenPosition);
            repathTimer = repathInterval;
        }
    }
    private void EnterAttack()
    {
        navigation.Stop();
        SetState(Day51EnemyState.Attack);
    }
    private void UpdateAttack()
    {
        if (CheckLostTarget()) return;
        Transform target = perception.Target;
        if (target == null) return;
        if (!perception.CanKeepSight())
        {
            attack.CancelAttack();
            return;  // LostTimer는 유지; 재시야 확보 또는 Return을 기다림
        }
        if (perception.DistanceToTarget > attack.AttackRange + attackExitPadding)
        {
            attack.CancelAttack();
            BeginChase(); return;
        }
        Vector3 forward = target.position - transform.position;
        forward.y = 0f;
        if (forward.sqrMagnitude > 0.0001f)
        {
            Quaternion desired = Quaternion.LookRotation(forward);
            transform.rotation = Quaternion.RotateTowards(transform.rotation, desired, 360f * Time.deltaTime);
        }
        attack.TryAttack(target);
    }
    private bool CheckLostTarget()
    {
        if (perception.Target == null || !perception.Target.gameObject.activeInHierarchy)
        { BeginReturn(); return true; }
        Day51PlayerHealth playerHealth = perception.Target.GetComponentInParent<Day51PlayerHealth>();
        if (playerHealth != null && playerHealth.IsDead)
        { BeginReturn(); return true; }
        if (perception.CanKeepSight())
        {
            lostTimer = 0f; lastSeenPosition = perception.Target.position;
            return false;
        }
        lostTimer += Time.deltaTime;
        if (lostTimer < lostTargetDelay) return false;
        BeginReturn(); return true;
    }
    private void BeginReturn()
    {
        attack.CancelAttack();
        if (route != null && route.HasPoints)
        {
            route.SelectClosest(transform.position);
            returnPosition = route.CurrentPoint;
        }
        else returnPosition = transform.position;
        navigation.SetPatrolMode();
        returnTimer = 0f;
        SetState(Day51EnemyState.Return);
        navigation.TryGo(returnPosition);
    }
    private void UpdateReturn()
    {
        returnTimer += Time.deltaTime;
        bool closeEnough = Vector3.Distance(transform.position, returnPosition) <= 0.45f;
        if (closeEnough || navigation.HasArrived()) { BeginPatrol(); return; }
        if (returnTimer >= returnTimeout)
        {
            Debug.LogWarning("[Day51] Return timeout, retry / patrol", this);
            BeginPatrol();
        }
    }
    public void EnterDead()
    {
        if (State == Day51EnemyState.Dead) return;
        if (attack != null) attack.CancelAttack();
        if (navigation != null && navigation.Ready) navigation.Stop();
        State = Day51EnemyState.Dead;
        StateChanged?.Invoke(State);
        Debug.Log("[Day51] Enemy Dead: AI permanently stopped", this);
    }
}
