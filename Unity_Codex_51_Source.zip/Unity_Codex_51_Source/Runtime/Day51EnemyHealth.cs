using System;
using UnityEngine;

public sealed class Day51EnemyHealth : MonoBehaviour, IDay51Damageable
{
    [SerializeField, Min(1)] private int maxHealth = 100;
    public int CurrentHealth { get; private set; }
    public bool IsDead => CurrentHealth <= 0;
    public event Action<int, int> HealthChanged;
    public event Action Died;

    private void Awake() => CurrentHealth = Mathf.Max(1, maxHealth);
    private void Start() => HealthChanged?.Invoke(CurrentHealth, maxHealth);

    public void TakeDamage(int damage)
    {
        if (damage <= 0 || IsDead) return;
        CurrentHealth = Mathf.Max(0, CurrentHealth - damage);
        HealthChanged?.Invoke(CurrentHealth, maxHealth);
        Debug.Log($"[Day51] Enemy HP {CurrentHealth}/{maxHealth}", this);
        if (CurrentHealth == 0) Died?.Invoke();
    }
    public void RestoreFull()
    {
        CurrentHealth = Mathf.Max(1, maxHealth);
        HealthChanged?.Invoke(CurrentHealth, maxHealth);
    }
}
