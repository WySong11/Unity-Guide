using UnityEngine;

/// <summary>Animator 파라미터: Float Speed, Trigger Attack, Trigger Die (모두 선택).</summary>
public sealed class Day51EnemyAnimatorBridge : MonoBehaviour
{
    [SerializeField] private Day51EnemyBrain brain;
    [SerializeField] private Animator animator;
    [SerializeField] private string speedParameter = "Speed";
    [SerializeField] private string dieTrigger = "Die";
    private void Awake()
    {
        if (brain == null) brain = GetComponent<Day51EnemyBrain>();
        if (animator == null) animator = GetComponentInChildren<Animator>();
    }
    private void OnEnable() { if (brain != null) brain.StateChanged += OnStateChanged; }
    private void OnDisable() { if (brain != null) brain.StateChanged -= OnStateChanged; }
    private void Update()
    {
        if (animator == null || brain == null || brain.Navigation == null) return;
        float speed = brain.Navigation.Ready ? brain.Navigation.Agent.velocity.magnitude : 0f;
        if (!string.IsNullOrEmpty(speedParameter)) animator.SetFloat(speedParameter, speed, 0.1f, Time.deltaTime);
    }
    private void OnStateChanged(Day51EnemyState state)
    {
        if (animator == null) return;
        if (state == Day51EnemyState.Dead && !string.IsNullOrEmpty(dieTrigger)) animator.SetTrigger(dieTrigger);
    }
}
