using System;
using UnityEngine;

public sealed class Day51PlayerHealth : MonoBehaviour, IDay51Damageable
{
    [SerializeField, Min(1)] private int maxHealth = 100;
    public int CurrentHealth { get; private set; }
    public bool IsDead => CurrentHealth <= 0;
    public event Action<int, int> HealthChanged;
    public event Action Died;
    private void Awake() => CurrentHealth = Mathf.Max(1, maxHealth);
    private void Start() => HealthChanged?.Invoke(CurrentHealth, maxHealth);
    public void TakeDamage(int amount)
    {
        if (IsDead || amount <= 0) return;
        CurrentHealth = Mathf.Max(0, CurrentHealth - amount);
        HealthChanged?.Invoke(CurrentHealth, maxHealth);
        Debug.Log($"[Day51] Player HP {CurrentHealth}/{maxHealth}", this);
        if (IsDead) Died?.Invoke();
    }
}
