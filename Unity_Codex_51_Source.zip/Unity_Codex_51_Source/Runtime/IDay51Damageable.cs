public interface IDay51Damageable
{
    bool IsDead { get; }
    void TakeDamage(int damage);
}
