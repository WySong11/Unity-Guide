using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>Editor 데모: 1 = Enemy 피격 / 2 = Enemy 즉시 사망. 빌드 입력과 별도 실습용.</summary>
public sealed class Day51LabControls : MonoBehaviour
{
    [SerializeField] private Day51EnemyHealth enemy;
    [SerializeField, Min(1)] private int testDamage = 25;
    private void Update()
    {
        if (Keyboard.current == null || enemy == null) return;
        if (Keyboard.current.digit1Key.wasPressedThisFrame) enemy.TakeDamage(testDamage);
        if (Keyboard.current.digit2Key.wasPressedThisFrame) enemy.TakeDamage(int.MaxValue);
    }
}
