public enum Day51EnemyState
{
    Patrol,
    Chase,
    Attack,
    Return,
    Dead
}
