using System.Collections;
using UnityEngine;

/// <summary>Cooldown은 공격 시작 시간에, Damage는 Windup 후에 적용. 한 번의 공격에 한 번만 적용.</summary>
public sealed class Day51EnemyAttack : MonoBehaviour
{
    [SerializeField, Min(0.1f)] private float attackRange = 1.8f;
    [SerializeField, Min(0.1f)] private float attackInterval = 1.2f;
    [SerializeField, Min(0f)] private float windupSeconds = 0.3f;
    [SerializeField, Min(1)] private int damage = 15;
    [SerializeField, Range(1f, 180f)] private float hitAngle = 100f;
    [SerializeField] private Animator animator;

    private Coroutine activeAttack;
    private float nextAttackTime;
    public float AttackRange => attackRange;
    public float CooldownRemaining => Mathf.Max(0f, nextAttackTime - Time.time);
    public bool IsAttacking => activeAttack != null;
    public event System.Action Attacked;

    public void TryAttack(Transform target)
    {
        if (!isActiveAndEnabled || activeAttack != null || Time.time < nextAttackTime || target == null) return;
        nextAttackTime = Time.time + attackInterval;
        activeAttack = StartCoroutine(AttackOnce(target));
    }

    private IEnumerator AttackOnce(Transform target)
    {
        if (animator != null) animator.SetTrigger("Attack");
        if (windupSeconds > 0f) yield return new WaitForSeconds(windupSeconds);
        if (target != null && target.gameObject.activeInHierarchy && WithinHitRange(target))
        {
            IDay51Damageable receiver = FindDamageable(target);
            if (receiver != null && !receiver.IsDead)
            {
                receiver.TakeDamage(damage);
                Attacked?.Invoke();
            }
        }
        activeAttack = null;
    }

    private bool WithinHitRange(Transform target)
    {
        Vector3 delta = target.position - transform.position;
        delta.y = 0f;
        if (delta.sqrMagnitude > attackRange * attackRange) return false;
        return delta.sqrMagnitude < 0.001f || Vector3.Angle(transform.forward, delta) <= hitAngle * 0.5f;
    }
    private static IDay51Damageable FindDamageable(Transform t)
    {
        foreach (MonoBehaviour mb in t.GetComponentsInParent<MonoBehaviour>())
            if (mb is IDay51Damageable receiver) return receiver;
        return null;
    }
    public void CancelAttack()
    {
        if (activeAttack == null) return;
        StopCoroutine(activeAttack);
        activeAttack = null;
    }
    private void OnDisable() => CancelAttack();
}
