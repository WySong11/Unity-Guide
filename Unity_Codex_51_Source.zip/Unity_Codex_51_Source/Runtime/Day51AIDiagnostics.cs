using UnityEngine;
using UnityEngine.InputSystem;

public sealed class Day51AIDiagnostics : MonoBehaviour
{
    [SerializeField] private Day51EnemyBrain brain;
    [SerializeField] private Day51EnemyHealth health;
    [SerializeField] private bool show = true;
    private GUIStyle style;
    private void Awake()
    {
        if (!brain) brain = GetComponent<Day51EnemyBrain>();
        if (!health) health = GetComponent<Day51EnemyHealth>();
    }
    private void Update()
    {
        if (Keyboard.current != null && Keyboard.current.f1Key.wasPressedThisFrame) show = !show;
    }
    private void OnGUI()
    {
        if (!show || brain == null) return;
        if (style == null) style = new GUIStyle(GUI.skin.box) { fontSize = 17, alignment = TextAnchor.UpperLeft };
        string nav = brain.Navigation != null && brain.Navigation.Ready
            ? $"path={brain.Navigation.Agent.pathStatus}, stop={brain.Navigation.Agent.isStopped}" : "NO NAVMESH";
        string text = $"[Day51 AI]\nState: {brain.State}\nHP: {(health ? health.CurrentHealth : 0)}\n" +
            $"Target dist: {(brain.Perception != null ? brain.Perception.DistanceToTarget : -1f):0.00}\n" +
            $"Lost: {brain.LostTimer:0.0}\nAttack CD: {(brain.Attack != null ? brain.Attack.CooldownRemaining : 0f):0.0}\n{nav}";
        GUI.Box(new Rect(20, 20, 430, 175), text, style);
    }
}
