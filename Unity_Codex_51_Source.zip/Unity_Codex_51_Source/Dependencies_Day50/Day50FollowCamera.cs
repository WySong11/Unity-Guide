using UnityEngine;

public sealed class Day50FollowCamera : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField] private Vector3 offset = new Vector3(0f, 12f, -13f);
    [SerializeField, Min(0.01f)] private float smoothTime = 0.14f;
    private Vector3 velocity;
    public void Configure(Transform value) => target = value;
    private void LateUpdate()
    {
        if (target == null) return;
        transform.position = Vector3.SmoothDamp(transform.position,
            target.position + offset, ref velocity, smoothTime);
        transform.LookAt(target.position + Vector3.up * 0.8f);
    }
}
