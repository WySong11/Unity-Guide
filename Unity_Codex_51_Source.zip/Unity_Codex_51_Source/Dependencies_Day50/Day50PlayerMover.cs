using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>Input System 패키지를 사용하는 학습 전용 플레이어 이동 예제.</summary>
[RequireComponent(typeof(CharacterController))]
public sealed class Day50PlayerMover : MonoBehaviour
{
    [SerializeField, Min(0f)] private float speed = 5f;
    [SerializeField] private float gravity = -18f;
    private CharacterController motor;
    private float verticalSpeed;
    private void Awake() => motor = GetComponent<CharacterController>();
    private void Update()
    {
        Keyboard keyboard = Keyboard.current;
        if (keyboard == null) return;
        Vector2 input = Vector2.zero;
        if (keyboard.wKey.isPressed) input.y++;
        if (keyboard.sKey.isPressed) input.y--;
        if (keyboard.dKey.isPressed) input.x++;
        if (keyboard.aKey.isPressed) input.x--;
        input = Vector2.ClampMagnitude(input, 1f);
        Vector3 horizontal = new Vector3(input.x, 0f, input.y) * speed;
        if (motor.isGrounded && verticalSpeed < 0f) verticalSpeed = -1f;
        verticalSpeed += gravity * Time.deltaTime;
        motor.Move((horizontal + Vector3.up * verticalSpeed) * Time.deltaTime);
        if (horizontal.sqrMagnitude > 0.01f) transform.forward = horizontal.normalized;
    }
}
