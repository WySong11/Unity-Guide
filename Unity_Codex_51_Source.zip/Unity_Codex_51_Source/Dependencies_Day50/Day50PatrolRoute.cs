using UnityEngine;

/// <summary>월드 좌표의 Waypoint 배열을 순환 관리합니다.</summary>
public sealed class Day50PatrolRoute : MonoBehaviour
{
    [SerializeField] private Transform[] waypoints;
    [SerializeField, Min(0f)] private float waitAtPoint = 0.75f;
    private int currentIndex;

    public bool HasPoints => waypoints != null && waypoints.Length > 0;
    public float WaitAtPoint => waitAtPoint;
    public int CurrentIndex => currentIndex;
    public int Count => waypoints == null ? 0 : waypoints.Length;

    public Vector3 CurrentPoint => HasPoints && waypoints[currentIndex] != null
        ? waypoints[currentIndex].position : transform.position;

    public void Configure(Transform[] points)
    {
        waypoints = points;
        currentIndex = 0;
    }

    public void Advance()
    {
        if (HasPoints) currentIndex = (currentIndex + 1) % waypoints.Length;
    }

    public void SelectClosest(Vector3 from)
    {
        if (!HasPoints) return;
        float best = float.PositiveInfinity;
        for (int i = 0; i < waypoints.Length; i++)
        {
            if (waypoints[i] == null) continue;
            float sqr = (waypoints[i].position - from).sqrMagnitude;
            if (sqr < best) { best = sqr; currentIndex = i; }
        }
    }

    public void OnDrawGizmosSelected()
    {
        if (!HasPoints) return;
        Gizmos.color = new Color(0.2f, 0.75f, 1f);
        for (int i = 0; i < waypoints.Length; i++)
        {
            Transform a = waypoints[i];
            if (a == null) continue;
            Gizmos.DrawSphere(a.position + Vector3.up * 0.15f, 0.20f);
            Transform b = waypoints[(i + 1) % waypoints.Length];
            if (b != null && Count > 1) Gizmos.DrawLine(a.position, b.position);
        }
    }
}
