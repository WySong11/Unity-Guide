using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
public sealed class Day50EnemyNavigation : MonoBehaviour
{
    [SerializeField, Min(0.1f)] private float patrolSpeed = 2.0f;
    [SerializeField, Min(0.1f)] private float chaseSpeed = 4.5f;
    [SerializeField, Min(0.01f)] private float arriveTolerance = 0.2f;
    private NavMeshAgent agent;
    public NavMeshAgent Agent => agent != null ? agent : (agent = GetComponent<NavMeshAgent>());
    public bool Ready => Agent != null && Agent.enabled && Agent.isOnNavMesh;
    public bool IsMoving => Ready && !Agent.isStopped && Agent.velocity.sqrMagnitude > 0.02f;

    public void SetPatrolMode()
    {
        if (!Ready) return;
        Agent.speed = patrolSpeed;
        Agent.stoppingDistance = 0.25f;
        Agent.autoBraking = false;
        Agent.isStopped = false;
    }
    public void SetChaseMode(float stopDistance)
    {
        if (!Ready) return;
        Agent.speed = chaseSpeed;
        Agent.stoppingDistance = Mathf.Max(0.1f, stopDistance);
        Agent.autoBraking = true;
        Agent.isStopped = false;
    }
    public bool TryGo(Vector3 position)
    {
        return Ready && Agent.SetDestination(position);
    }
    public void Stop()
    {
        if (!Ready) return;
        Agent.isStopped = true;
        Agent.ResetPath();
    }
    public bool HasArrived()
    {
        if (!Ready || Agent.pathPending || !Agent.hasPath) return false;
        if (Agent.pathStatus != NavMeshPathStatus.PathComplete) return false;
        if (float.IsInfinity(Agent.remainingDistance)) return false;
        float allowed = Agent.stoppingDistance + arriveTolerance;
        return Agent.remainingDistance <= allowed && Agent.velocity.sqrMagnitude < 0.09f;
    }
    public bool PathFailed()
    {
        return Ready && !Agent.pathPending && Agent.hasPath &&
            Agent.pathStatus != NavMeshPathStatus.PathComplete;
    }
}
