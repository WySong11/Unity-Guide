using UnityEngine;

/// <summary>
/// 거리 + 수평 시야각 + 장애물 검사를 분리합니다.
/// RaycastNonAlloc 결과에서 자기 자신과 Target의 Collider는 제외합니다.
/// </summary>
public sealed class Day50EnemyPerception : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField, Min(0.1f)] private float detectionRadius = 7f;
    [SerializeField, Min(0.1f)] private float loseRadius = 11f;
    [SerializeField, Range(1f, 360f)] private float viewAngle = 120f;
    [SerializeField, Min(0f)] private float eyeHeight = 1.2f;
    [SerializeField, Min(0f)] private float targetHeight = 1.0f;
    [SerializeField] private LayerMask obstacleMask = ~0;

    private readonly RaycastHit[] rayHits = new RaycastHit[48];
    public Transform Target => target;
    public float DetectionRadius => detectionRadius;
    public float LoseRadius => loseRadius;

    public void Configure(Transform newTarget) => target = newTarget;

    public float DistanceToTarget => target == null
        ? float.PositiveInfinity : Vector3.Distance(transform.position, target.position);

    public bool CanAcquire()
    {
        if (target == null || DistanceToTarget > detectionRadius) return false;
        Vector3 direction = target.position - transform.position;
        direction.y = 0f;
        if (direction.sqrMagnitude > 0.0001f &&
            Vector3.Angle(transform.forward, direction) > viewAngle * 0.5f)
            return false;
        return HasLineOfSight();
    }

    public bool CanKeepSight()
    {
        return target != null && DistanceToTarget <= loseRadius && HasLineOfSight();
    }

    private bool HasLineOfSight()
    {
        if (target == null) return false;
        Vector3 origin = transform.position + Vector3.up * eyeHeight;
        Vector3 point = target.position + Vector3.up * targetHeight;
        Vector3 delta = point - origin;
        float length = delta.magnitude;
        if (length < 0.001f) return true;

        int hitCount = Physics.RaycastNonAlloc(origin, delta / length, rayHits,
            length, obstacleMask, QueryTriggerInteraction.Ignore);
        // 48개 이상 Hit가 동시에 발생하면 판정이 불완전할 수 있으므로 탐지하지 않습니다.
        if (hitCount == rayHits.Length) return false;
        for (int i = 0; i < hitCount; i++)
        {
            Collider collider = rayHits[i].collider;
            if (collider == null) continue;
            Transform hit = collider.transform;
            if (hit == transform || hit.IsChildOf(transform)) continue;
            if (hit == target || hit.IsChildOf(target)) continue;
            return false; // 장애물로 시야가 가려졌음
        }
        return true;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, detectionRadius);
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, loseRadius);
        float half = viewAngle * 0.5f;
        Vector3 origin = transform.position + Vector3.up * eyeHeight;
        Gizmos.color = Color.cyan;
        Gizmos.DrawLine(origin, origin + Quaternion.Euler(0f, half, 0f) * transform.forward * detectionRadius);
        Gizmos.DrawLine(origin, origin + Quaternion.Euler(0f, -half, 0f) * transform.forward * detectionRadius);
    }
}
