﻿using UnityEngine;
using UnityEngine.UIElements;

// UI Document가 있는 GameObject에 추가하는 컴포넌트입니다.
public class MainMenuUI : MonoBehaviour
{
    [SerializeField] private UIDocument uiDocument;

    private Button startButton;
    private Button settingsButton;
    private Button quitButton;
    private Button closeSettingsButton;
    private TextField nameField;
    private Toggle soundToggle;
    private Label statusLabel;
    private VisualElement settingsPanel;

    private void OnEnable()
    {
        // UI Document가 자동으로 할당되지 않았다면 같은 오브젝트에서 찾습니다.
        if (uiDocument == null)
            uiDocument = GetComponent<UIDocument>();

        if (uiDocument == null)
        {
            Debug.LogError("[MainMenuUI] UIDocument 컴포넌트가 없습니다.");
            return;
        }

        // UI Toolkit의 계층 구조 최상위 요소를 가져옵니다.
        VisualElement root = uiDocument.rootVisualElement;
        startButton = root.Q<Button>("startButton");
        settingsButton = root.Q<Button>("settingsButton");
        quitButton = root.Q<Button>("quitButton");
        closeSettingsButton = root.Q<Button>("closeSettingsButton");
        nameField = root.Q<TextField>("nameField");
        soundToggle = root.Q<Toggle>("soundToggle");
        statusLabel = root.Q<Label>("statusLabel");
        settingsPanel = root.Q<VisualElement>("settingsPanel");

        // UXML의 name과 코드 문자열이 다르면 null을 반환합니다.
        if (startButton == null || settingsButton == null || quitButton == null ||
            closeSettingsButton == null || nameField == null || soundToggle == null ||
            statusLabel == null || settingsPanel == null)
        {
            Debug.LogError("[MainMenuUI] UXML 요소의 name을 확인하세요.");
            return;
        }

        startButton.clicked += OnStartClicked;
        settingsButton.clicked += OnSettingsClicked;
        quitButton.clicked += OnQuitClicked;
        closeSettingsButton.clicked += OnCloseSettingsClicked;
        nameField.RegisterValueChangedCallback(OnNameChanged);
        soundToggle.RegisterValueChangedCallback(OnSoundChanged);
    }

    private void OnDisable()
    {
        // 재활성화할 때 중복 실행되지 않도록 모든 이벤트를 해제합니다.
        if (startButton != null) startButton.clicked -= OnStartClicked;
        if (settingsButton != null) settingsButton.clicked -= OnSettingsClicked;
        if (quitButton != null) quitButton.clicked -= OnQuitClicked;
        if (closeSettingsButton != null) closeSettingsButton.clicked -= OnCloseSettingsClicked;
        if (nameField != null) nameField.UnregisterValueChangedCallback(OnNameChanged);
        if (soundToggle != null) soundToggle.UnregisterValueChangedCallback(OnSoundChanged);
    }

    private void OnStartClicked()
    {
        string playerName = string.IsNullOrWhiteSpace(nameField.value)
            ? "Player" : nameField.value.Trim();

        // 이 기본 실습에서는 씬을 바꾸지 않고 상태 메시지를 갱신합니다.
        statusLabel.text = $"{playerName} 님, 게임 시작 버튼을 눌렀습니다!";
        Debug.Log($"[MainMenuUI] 시작 클릭 - 플레이어: {playerName}");
    }

    private void OnSettingsClicked()
    {
        settingsPanel.style.display = DisplayStyle.Flex;
        statusLabel.text = "설정 패널을 열었습니다.";
    }

    private void OnCloseSettingsClicked()
    {
        settingsPanel.style.display = DisplayStyle.None;
        statusLabel.text = "설정 패널을 닫았습니다.";
    }

    private void OnNameChanged(ChangeEvent<string> evt)
    {
        statusLabel.text = $"플레이어 이름: {evt.newValue}";
    }

    private void OnSoundChanged(ChangeEvent<bool> evt)
    {
        statusLabel.text = evt.newValue ? "사운드: ON" : "사운드: OFF";
    }

    private void OnQuitClicked()
    {
        Debug.Log("[MainMenuUI] 게임 종료 요청");
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}
