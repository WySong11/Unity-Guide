Unity 6 UI Toolkit - 실습 예제

Unity Project Assets/ 아래에 아래처럼 파일을 배치하세요.
Assets/UI/MainMenu.uxml
Assets/UI/MainMenu.uss
Assets/Scripts/MainMenuUI.cs

1. Unity에서 GameObject > UI Toolkit > UI Document
2. Inspector의 Source Asset에 MainMenu.uxml 연결
3. Panel Settings 필드 확인
4. 동일한 UIDocument GameObject에 MainMenuUI 스크립트 추가
5. Play 버튼 -> Game View에서 테스트

버튼 동작
- 시작: 상태 텍스트 갱신 + Console 로그
- 설정: 설정 패널 보이기
- 닫기: 설정 패널 숨기기
- 종료: Editor Play 종료 / 빌드 Application.Quit

참고: Unity UI Toolkit의 별도 Canvas GameObject는 필요하지 않습니다.
SceneChange_Optional.txt의 코드는 추가 씬 전환 예제입니다.

코딩 파일 포맷: C# UTF-8 BOM; UXML/USS UTF-8 no BOM; LF 줄바꿈.
