using UnityEngine;

/// <summary>
/// Day55MonsterUnit 실습용 Raycast 공격 어댑터.
/// 기존 Day55 WaveSpawner/Pool 코드를 수정하지 않고 전투 기능을 연결합니다.
/// </summary>
[DisallowMultipleComponent]
public sealed class Day56CombatRaycaster : MonoBehaviour
{
    [SerializeField] private Camera aimCamera;
    [SerializeField] private Transform muzzle;
    [SerializeField] private LayerMask hitLayers = ~0;
    [SerializeField, Min(0.1f)] private float range = 60f;
    [SerializeField, Min(0.1f)] private float damage = 20f;
    [SerializeField, Min(0f)] private float shotCooldown = 0.2f;

    public int Shots { get; private set; }
    public int RayHits { get; private set; }
    public int EnemyHits { get; private set; }
    public string LastResult { get; private set; } = "Not fired";

    private float nextShotTime;

    public bool TryFire()
    {
        if (Time.timeScale <= 0f)
        {
            LastResult = "Paused";
            return false;
        }
        if (Time.time < nextShotTime) return false;
        if (aimCamera == null)
        {
            Debug.LogWarning("[Day56] Aim Camera is not assigned.", this);
            LastResult = "Missing camera";
            return false;
        }

        nextShotTime = Time.time + shotCooldown;
        Shots++;
        Ray ray = aimCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0f));
        if (!Physics.Raycast(ray, out RaycastHit hit, range, hitLayers,
                QueryTriggerInteraction.Ignore))
        {
            LastResult = "No collider hit";
            return false;
        }

        RayHits++;
        // Ray의 첫 충돌체(벽/지형)를 무시하지 않으므로 벽 관통을 막습니다.
        var monster = hit.collider.GetComponentInParent<Day55MonsterUnit>();
        if (monster == null || monster.IsDead)
        {
            LastResult = "Hit non-enemy: " + hit.collider.name;
            return false;
        }

        EnemyHits++;
        monster.TakeDamage(damage);
        LastResult = "Hit " + monster.name + " (HP " + monster.HP.ToString("F0") + ")";
        return true;
    }

    private void OnDrawGizmosSelected()
    {
        if (aimCamera == null) return;
        var ray = aimCamera.ViewportPointToRay(new Vector3(0.5f, 0.5f, 0f));
        Gizmos.color = Color.yellow;
        Gizmos.DrawRay(ray.origin, ray.direction * range);
        if (muzzle != null)
        {
            Gizmos.color = Color.cyan;
            Gizmos.DrawWireSphere(muzzle.position, 0.12f);
        }
    }
}
