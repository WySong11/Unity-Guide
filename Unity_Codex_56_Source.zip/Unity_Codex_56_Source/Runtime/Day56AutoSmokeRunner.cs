using System.Collections;
using UnityEngine;

/// <summary>
/// Play Mode 통합 Smoke Test. 몬스터를 강제로 피해 처리하므로 명중 정확도는 별도 테스트해야 합니다.
/// 실시간 Timeout을 사용하며 Scene/Prefab 원본을 수정하지 않습니다.
/// </summary>
[DisallowMultipleComponent]
public sealed class Day56AutoSmokeRunner : MonoBehaviour
{
    [SerializeField] private Day55WaveSpawner spawner;
    [SerializeField] private Day55MonsterPool pool;
    [SerializeField] private Day56IntegrationObserver observer;
    [SerializeField, Min(1f)] private float timeoutSeconds = 40f;
    [SerializeField, Min(1f)] private float damagePerFrame = 99999f;

    public bool Running => routine != null;
    public string Result { get; private set; } = "Not started";

    private Coroutine routine;
    private float savedTimeScale = 1f;

    public void RunSmokeTest()
    {
        if (routine != null) return;
        if (spawner == null || pool == null || observer == null)
        {
            Result = "FAIL: Missing references";
            Debug.LogError("[Day56] Missing Spawner / Pool / Observer", this);
            return;
        }
        savedTimeScale = Time.timeScale;
        Time.timeScale = 1f;
        observer.ResetStatistics();
        routine = StartCoroutine(RunSequence());
    }

    public void StopTest()
    {
        if (routine != null) StopCoroutine(routine);
        routine = null;
        if (spawner != null) spawner.StopRun();
        Time.timeScale = savedTimeScale;
        Result = "Stopped by user";
    }

    private void OnDisable()
    {
        if (routine != null) StopTest();
    }

    private IEnumerator RunSequence()
    {
        Result = "Running: complete waves";
        spawner.RestartRun();
        float deadline = Time.realtimeSinceStartup + timeoutSeconds;
        bool passed = true;
        string failure = "";

        while (spawner.State != Day55WaveState.Completed)
        {
            if (spawner.State == Day55WaveState.Failed)
            {
                passed = false;
                failure = "Spawner entered Failed";
                break;
            }
            if (Time.realtimeSinceStartup >= deadline)
            {
                passed = false;
                failure = "Timed out while completing waves";
                break;
            }
            // 빠른 사망 이벤트·Return·중복 집계를 검증하는 전용 경로입니다.
            pool.DamageAll(damagePerFrame);
            yield return null;
        }

        if (passed && observer.InvariantFailures > 0)
        {
            passed = false;
            failure = "Observer detected invalid counters";
        }
        if (passed && observer.ObservedRunCompletions != 1)
        {
            passed = false;
            failure = "RunCompleted event count was not one";
        }
        if (passed && pool.CountActive != 0)
        {
            passed = false;
            failure = "Active monster remains after completion";
        }
        if (passed)
        {
            Result = "PASS: wave completion / return";
            spawner.RestartRun();
            deadline = Time.realtimeSinceStartup + Mathf.Min(10f, timeoutSeconds);
            while (spawner.Spawned == 0 && Time.realtimeSinceStartup < deadline)
                yield return null;
            if (spawner.Spawned == 0)
            {
                passed = false;
                failure = "Restart did not begin spawning";
            }
            spawner.StopRun();
            if (pool.CountActive != 0)
            {
                passed = false;
                failure = "StopRun left active monsters";
            }
        }
        else spawner.StopRun();

        Result = passed ? "PASS: Complete + Restart + Stop" : "FAIL: " + failure;
        Debug.Log("[Day56 Smoke] " + Result, this);
        Time.timeScale = savedTimeScale;
        routine = null;
    }
}
