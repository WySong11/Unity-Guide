using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

/// <summary>입력 전용. Mouse Left Click 및 Space로 Raycast 공격.</summary>
[DisallowMultipleComponent]
public sealed class Day56CombatInput : MonoBehaviour
{
    [SerializeField] private Day56CombatRaycaster weapon;
    [SerializeField] private bool keyboardSpaceAlsoFires = true;

    private void Update()
    {
        if (weapon == null || Time.timeScale <= 0f) return;
#if ENABLE_INPUT_SYSTEM
        bool pressed = Mouse.current != null && Mouse.current.leftButton.wasPressedThisFrame;
        if (keyboardSpaceAlsoFires && Keyboard.current != null)
            pressed |= Keyboard.current.spaceKey.wasPressedThisFrame;
        if (pressed) weapon.TryFire();
#else
        // Legacy Input Manager가 활성화된 프로젝트용 대체 경로.
        bool pressed = Input.GetMouseButtonDown(0)
            || (keyboardSpaceAlsoFires && Input.GetKeyDown(KeyCode.Space));
        if (pressed) weapon.TryFire();
#endif
    }
}
