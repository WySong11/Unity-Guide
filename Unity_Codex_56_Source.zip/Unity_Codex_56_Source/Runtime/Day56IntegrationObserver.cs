using System;
using UnityEngine;

/// <summary>Day55 공개 속성·이벤트를 읽는 비침습 통합 진단 컴포넌트.</summary>
[DisallowMultipleComponent]
public sealed class Day56IntegrationObserver : MonoBehaviour
{
    [SerializeField] private Day55WaveSpawner spawner;
    [SerializeField] private Day55MonsterPool pool;
    [SerializeField] private bool checkEveryFrame = true;
    [SerializeField] private bool verboseEventLog;

    public int ObservedUnitKills { get; private set; }
    public int ObservedWaveStarts { get; private set; }
    public int ObservedWaveClears { get; private set; }
    public int ObservedRunCompletions { get; private set; }
    public int InvariantFailures { get; private set; }
    public string LastEvent { get; private set; } = "None";

    private bool warned;

    private void OnEnable()
    {
        if (spawner != null)
        {
            spawner.StateChanged += HandleState;
            spawner.WaveStarted += HandleWave;
            spawner.WaveCleared += HandleWaveClear;
            spawner.RunCompleted += HandleRunCompleted;
        }
        if (pool != null) pool.UnitKilled += HandleKilled;
    }

    private void OnDisable()
    {
        if (spawner != null)
        {
            spawner.StateChanged -= HandleState;
            spawner.WaveStarted -= HandleWave;
            spawner.WaveCleared -= HandleWaveClear;
            spawner.RunCompleted -= HandleRunCompleted;
        }
        if (pool != null) pool.UnitKilled -= HandleKilled;
    }

    private void LateUpdate()
    {
        if (checkEveryFrame) CheckInvariants();
    }

    public bool CheckInvariants()
    {
        if (spawner == null || pool == null)
        {
            if (!warned) Debug.LogWarning("[Day56] Observer needs Spawner and Pool.", this);
            warned = true;
            return false;
        }
        warned = false;
        bool valid = pool.CountActive >= 0 && pool.CountInactive >= 0
            && pool.CountAll >= pool.CountActive + pool.CountInactive
            && spawner.Alive == pool.CountActive
            && spawner.Spawned >= 0
            && spawner.Killed >= 0 && spawner.Killed <= spawner.Spawned;

        // maxAlive는 Wave가 활성 중일 때에만 검사합니다.
        if (spawner.WaveNumber > 0 && spawner.CurrentPlan.maxAlive > 0
            && spawner.State != Day55WaveState.Idle
            && spawner.State != Day55WaveState.Completed)
            valid &= spawner.Alive <= spawner.CurrentPlan.maxAlive;

        if (!valid && !warned)
        {
            InvariantFailures++;
            Debug.LogError($"[Day56] Invariant failed: W{spawner.WaveNumber} {spawner.State}, "
                + $"Spawned={spawner.Spawned}, Killed={spawner.Killed}, "
                + $"Alive={spawner.Alive}, Pool A/I/All={pool.CountActive}/{pool.CountInactive}/{pool.CountAll}", this);
        }
        warned = !valid;
        return valid;
    }

    public void ResetStatistics()
    {
        ObservedUnitKills = ObservedWaveStarts = ObservedWaveClears = 0;
        ObservedRunCompletions = InvariantFailures = 0;
        LastEvent = "Reset";
        warned = false;
    }

    private void HandleState(Day55WaveState state) => Record("State = " + state);
    private void HandleWave(int index, Day55WavePlan plan)
    {
        ObservedWaveStarts++;
        Record("Wave " + index + " started");
    }
    private void HandleWaveClear(int index)
    {
        ObservedWaveClears++;
        Record("Wave " + index + " cleared");
    }
    private void HandleKilled(Day55MonsterUnit unit)
    {
        ObservedUnitKills++;
        Record("Monster died");
    }
    private void HandleRunCompleted()
    {
        ObservedRunCompletions++;
        Record("All waves completed");
    }
    private void Record(string message)
    {
        LastEvent = message;
        if (verboseEventLog) Debug.Log("[Day56 Observer] " + message, this);
    }
}
