using UnityEngine;

/// <summary>임시 IMGUI 계측 HUD. 배포용 HUD는 uGUI/TMP로 교체 가능합니다.</summary>
[DisallowMultipleComponent]
public sealed class Day56IntegrationHUD : MonoBehaviour
{
    [SerializeField] private Day55WaveSpawner spawner;
    [SerializeField] private Day55MonsterPool pool;
    [SerializeField] private Day56IntegrationObserver observer;
    [SerializeField] private Day56AutoSmokeRunner smokeRunner;
    [SerializeField] private Day56CombatRaycaster raycaster;
    [SerializeField] private bool showHUD = true;

    private void OnGUI()
    {
        if (!showHUD || spawner == null || pool == null) return;
        GUILayout.BeginArea(new Rect(14, 14, 370, 318), GUI.skin.box);
        GUILayout.Label("DAY56 | COMBAT / SPAWN INTEGRATION");
        GUILayout.Label($"Wave: {spawner.WaveNumber}   State: {spawner.State}");
        GUILayout.Label($"Spawned: {spawner.Spawned}  Killed: {spawner.Killed}  Alive: {spawner.Alive}");
        GUILayout.Label($"Pool: Active={pool.CountActive}, Inactive={pool.CountInactive}, All={pool.CountAll}");
        if (observer != null)
            GUILayout.Label($"Events: Death={observer.ObservedUnitKills}, Clear={observer.ObservedWaveClears}   Issues={observer.InvariantFailures}");
        if (raycaster != null)
            GUILayout.Label($"Shots={raycaster.Shots}, EnemyHits={raycaster.EnemyHits} | {raycaster.LastResult}");
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Start")) spawner.StartRun();
        if (GUILayout.Button("Restart")) spawner.RestartRun();
        if (GUILayout.Button("Stop")) spawner.StopRun();
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Fire") && raycaster != null) raycaster.TryFire();
        if (GUILayout.Button("Defeat One")) pool.DamageOne(99999f);
        if (GUILayout.Button("Defeat All")) pool.DamageAll(99999f);
        GUILayout.EndHorizontal();
        if (smokeRunner != null)
        {
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Smoke Test")) smokeRunner.RunSmokeTest();
            if (GUILayout.Button("Stop Test")) smokeRunner.StopTest();
            GUILayout.EndHorizontal();
            GUILayout.Label("Smoke: " + smokeRunner.Result);
        }
        GUILayout.EndArea();
    }
}
