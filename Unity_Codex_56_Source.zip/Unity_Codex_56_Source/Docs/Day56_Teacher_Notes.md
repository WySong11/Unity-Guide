# 교강사용 운영 가이드 (120분)

| 구간 | 진행 | 지도 포인트 |
|---|---|---|
| 0~20분 | 통합 데이터 흐름 | Hit ≠ Damage ≠ Kill ≠ Return 구분 |
| 20~45분 | Observer·HUD 연결 | Counter 불변식·이벤트 구독 해제 |
| 45~95분 | T01~T12 시연 | Spawn/AI/Combat/Pool/Pause/Restart |
| 95~120분 | Codex 수정·보고 | diff 및 재현 증거 중심 평가 |

## 강사용 설명
- *Day55 자동 Smoke Test의 DamageAll은 공격의 Raycast 정확도를 보장하지 않음.*
- `WaveCompleted`를 지나치게 빨리 가정하면 아직 생성되지 않은 적이 남을 수 있음.
- `maxAlive`는 동시에 활성화할 몬스터 수이고, `ObjectPool<T>.maxSize`는 비활성 객체 보관 상한임.
- NavMesh 없이 만든 독립 Lab에서는 `Day55MonsterUnit`의 비-NavMesh 단순 이동 대체 경로가 사용됨.
- 41~55일차에서 작성한 실제 전투/AI 시스템과 결합할 때는 Day56 TestHarness가 관측만 하도록 하고 기존 Brain과 Spawner를 중복 실행하지 않게 함.
