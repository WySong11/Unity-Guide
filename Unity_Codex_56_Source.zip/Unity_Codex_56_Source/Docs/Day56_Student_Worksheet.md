# 56일차 학생 워크시트 — 전투/스폰 통합 테스트

**목표:** 공격 명중 → HP 감소 → 사망 → Pool 반환 → Wave Clear의 연동을 검사한다.

1. Day55 씬 원본을 백업하거나 Day56 새 Lab을 생성한다.
2. Observer를 켜고 **Spawned / Killed / Alive / Pool.CountActive** 변화를 설명한다.
3. Play Mode에서 `Start`와 수동 `Fire`, `Defeat One`을 사용해 전투·이벤트를 구분한다.
4. 몬스터가 전부 죽어도 생성 목표를 채우기 전에는 Clear가 아니어야 하는 이유를 작성한다.
5. Pool.Get으로 재사용된 몬스터의 MaxHP/HP, IsDead, Target 상태를 확인한다.
6. Restart를 연달아 3회 수행한 뒤 이전 Coroutine/활성 적이 잔존하는지 확인한다.
7. Time.timeScale=0 동안 WaveSpawner의 Scaled Spawn 루프가 멈추는지 확인한다.
8. Console·Observer·Profiler 캡처를 첨부해 테스트 결과표를 완성한다.

## 기술 질문
- `Died`와 `UnitKilled` 중 어느 이벤트를 HUD가 구독하는 것이 좋을까? 그 이유는?
- `Killed == Spawned`인데도 `Alive > 0`이 되는 상황이 가능한가? 어떤 버그를 의심할까?
- `maxAlive`와 ObjectPool의 `maxSize`는 왜 다른가?
- `WaitForSeconds`와 `WaitForSecondsRealtime`은 일시정지 중 어떻게 다르게 동작하는가?

## 제출물
- 테스트용 씬 및 Inspector 스크린샷
- T01~T12 테스트 결과 및 실패 로그
- 수정 전후 `git diff` 또는 코드 비교
- Profiler CPU/GC Alloc 캡처와 개선 근거
