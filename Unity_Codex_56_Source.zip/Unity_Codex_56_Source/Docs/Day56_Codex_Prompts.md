# 56일차 Codex 검증 프롬프트

## 1. 분석/구현 범위 고정
> Unity 6.3 프로젝트에서 Day55WaveSpawner, Day55MonsterPool, Day55MonsterUnit의 실제 시그니처를 먼저 확인해줘. 56일차에서는 Raycast 공격과 통합 계측만 추가하고 기존 WaveConfig, Prefab, Scene의 원본은 수정하지 마. 분석 결과로 시스템 의존성, 이벤트 흐름, 불변식 및 위험도를 먼저 보고해줘.

## 2. 수동/자동 통합 테스트
> Day56 통합 씬에서 Raycast → TakeDamage → Died → Pool.Return → UnitKilled → WaveCleared 순서를 검증해줘. T01~T12 테스트별 예상 결과를 정리하고, 실제 실행된 테스트와 실행하지 못한 테스트를 구분해줘. Unity 실행이 불가능한 환경에서는 성공했다고 주장하지 말고 그 이유와 재현 절차를 제출해줘.

## 3. 결함 재현 및 최소 수정
> 다음 실패 로그/스크린샷을 바탕으로 첫 번째 깨진 불변식을 추적해줘. Spawned/Killed/Alive/CountActive, WaveState, RaycastHit, UnitKilled 횟수를 비교하고 수정 후보를 설명해줘. 기존 코드의 변경 범위를 최소화하고, 파일별 diff와 회귀 테스트 결과를 제출해줘.

## 4. 회귀 검증
> 수정 후 T01~T12를 다시 실행하고, 실패 케이스의 재현 여부를 우선 확인해줘. Restart 3회 반복, Pause/Resume, 빠른 연속 처치, 500회 Pool 반환 테스트를 포함해줘. Profiler CPU/GC Alloc과 객관적 테스트 결과를 첨부해줘.
