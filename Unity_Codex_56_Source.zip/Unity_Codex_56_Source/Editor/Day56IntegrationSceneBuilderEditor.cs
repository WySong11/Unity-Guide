#if UNITY_EDITOR
using System;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Day55 런타임이 설치된 프로젝트에서 독립적인 56일차 테스트 씬을 새로 생성합니다.</summary>
public static class Day56IntegrationSceneBuilderEditor
{
    [MenuItem("Tools/Unity Codex/Day56/Create Integration Lab")]
    public static void CreateLab()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        const string baseFolder = "Assets/Day56_IntegrationLab";
        if (!AssetDatabase.IsValidFolder(baseFolder))
            AssetDatabase.CreateFolder("Assets", "Day56_IntegrationLab");
        string timestamp = DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");
        string folder = baseFolder + "/Lab_" + timestamp;
        AssetDatabase.CreateFolder(baseFolder, "Lab_" + timestamp);

        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
        floor.name = "Ground";
        floor.transform.localScale = new Vector3(5, 1, 5);

        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "PlayerTarget";
        player.transform.position = new Vector3(0, 1, -5);
        player.transform.localScale = Vector3.one;

        var mainCamera = Camera.main;
        if (mainCamera == null)
        {
            var go = new GameObject("Main Camera");
            go.tag = "MainCamera";
            mainCamera = go.AddComponent<Camera>();
            go.AddComponent<AudioListener>();
        }
        mainCamera.transform.position = new Vector3(0, 9, -16);
        mainCamera.transform.LookAt(new Vector3(0, 1, 4));
        mainCamera.farClipPlane = 150f;

        GameObject prototype = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        prototype.name = "Day56TestMonster";
        prototype.transform.position = new Vector3(0, 1, 0);
        prototype.AddComponent<Day55MonsterUnit>();
        // Capsule Collider는 Primitive에 기본 포함되어 Raycast 테스트가 가능합니다.
        string prefabPath = folder + "/Day56TestMonster.prefab";
        var prefab = PrefabUtility.SaveAsPrefabAsset(prototype, prefabPath);
        UnityEngine.Object.DestroyImmediate(prototype);

        var waveConfig = ScriptableObject.CreateInstance<Day55WaveConfig>();
        AssetDatabase.CreateAsset(waveConfig, folder + "/Day56_WaveConfig.asset");

        var pointRoot = new GameObject("SpawnPoints");
        var points = new Transform[3];
        var positions = new[]
        {
            new Vector3(-4, 1, 5), new Vector3(4, 1, 5), new Vector3(0, 1, 9)
        };
        for (int i = 0; i < points.Length; i++)
        {
            var point = new GameObject("SpawnPoint_" + (i + 1));
            point.transform.SetParent(pointRoot.transform);
            point.transform.position = positions[i];
            points[i] = point.transform;
        }

        var pool = new GameObject("MonsterPool").AddComponent<Day55MonsterPool>();
        SetRef(pool, "monsterPrefab", prefab.GetComponent<Day55MonsterUnit>());
        var director = new GameObject("DifficultyDirector").AddComponent<Day55DifficultyDirector>();
        var spawner = new GameObject("WaveSpawner").AddComponent<Day55WaveSpawner>();
        SetRef(spawner, "waveConfig", waveConfig);
        SetRef(spawner, "difficultyDirector", director);
        SetRef(spawner, "monsterPool", pool);
        SetRef(spawner, "playerTarget", player.transform);
        SetArray(spawner, "spawnPoints", points);
        SetBool(spawner, "useNavMeshPositionCheck", false); // 기본 연습장에는 NavMesh를 Bake하지 않습니다.
        SetBool(spawner, "startAutomatically", false); // 버튼으로 시작하게 해 재현성을 높입니다.

        var weapon = player.AddComponent<Day56CombatRaycaster>();
        SetRef(weapon, "aimCamera", mainCamera);
        var input = player.AddComponent<Day56CombatInput>();
        SetRef(input, "weapon", weapon);

        var harness = new GameObject("TestHarness");
        var observer = harness.AddComponent<Day56IntegrationObserver>();
        SetRef(observer, "spawner", spawner);
        SetRef(observer, "pool", pool);
        var runner = harness.AddComponent<Day56AutoSmokeRunner>();
        SetRef(runner, "spawner", spawner);
        SetRef(runner, "pool", pool);
        SetRef(runner, "observer", observer);
        var hud = harness.AddComponent<Day56IntegrationHUD>();
        SetRef(hud, "spawner", spawner);
        SetRef(hud, "pool", pool);
        SetRef(hud, "observer", observer);
        SetRef(hud, "smokeRunner", runner);
        SetRef(hud, "raycaster", weapon);

        string scenePath = folder + "/Day56_IntegrationLab.unity";
        EditorSceneManager.SaveScene(scene, scenePath);
        AssetDatabase.SaveAssets();
        Selection.activeGameObject = harness;
        Debug.Log("[Day56] Generated new lab: " + scenePath);
        EditorUtility.DisplayDialog("Day56 Integration Lab", 
            "새 테스트 씬을 생성했습니다. Play 후 Start/Smoke Test를 실행하세요.\n"
            + "수동 Raycast는 카메라 중앙의 몬스터에 조준해야 합니다.\n"
            + "현재 Scene 원본은 덮어쓰지 않았습니다.", "OK");
    }

    private static void SetRef(UnityEngine.Object target, string field, UnityEngine.Object value)
    {
        var serialized = new SerializedObject(target);
        var prop = serialized.FindProperty(field);
        if (prop != null) prop.objectReferenceValue = value;
        serialized.ApplyModifiedPropertiesWithoutUndo();
    }
    private static void SetBool(UnityEngine.Object target, string field, bool value)
    {
        var serialized = new SerializedObject(target);
        var prop = serialized.FindProperty(field);
        if (prop != null) prop.boolValue = value;
        serialized.ApplyModifiedPropertiesWithoutUndo();
    }
    private static void SetArray(UnityEngine.Object target, string field, Transform[] values)
    {
        var serialized = new SerializedObject(target);
        var prop = serialized.FindProperty(field);
        if (prop == null) return;
        prop.arraySize = values.Length;
        for (int i = 0; i < values.Length; i++)
            prop.GetArrayElementAtIndex(i).objectReferenceValue = values[i];
        serialized.ApplyModifiedPropertiesWithoutUndo();
    }
}
#endif
