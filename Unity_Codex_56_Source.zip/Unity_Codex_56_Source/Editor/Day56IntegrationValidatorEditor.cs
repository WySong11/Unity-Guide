#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

/// <summary>씬의 필수 구성과 카메라·Collider 연결을 검사하는 Editor 메뉴.</summary>
public static class Day56IntegrationValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day56/Validate Integration Lab")]
    public static void Validate()
    {
        var spawner = Object.FindFirstObjectByType<Day55WaveSpawner>();
        var pool = Object.FindFirstObjectByType<Day55MonsterPool>();
        var observer = Object.FindFirstObjectByType<Day56IntegrationObserver>();
        var weapon = Object.FindFirstObjectByType<Day56CombatRaycaster>();
        var runner = Object.FindFirstObjectByType<Day56AutoSmokeRunner>();
        bool valid = spawner && pool && observer && weapon && runner && Camera.main;
        if (valid)
            Debug.Log("[Day56 Validate] Essential components present. Now run Play Mode scenarios.");
        else
            Debug.LogError("[Day56 Validate] Missing WaveSpawner/Pool/Observer/Raycaster/Runner/MainCamera.");
    }
}
#endif
