# Unity Codex 56일차: 전투/스폰 통합 테스트

## 권장 Unity 환경
Unity 6.3 (6000.3 계열), 3D URP 또는 Universal 3D 프로젝트를 기준으로 작성했습니다. Unity 6.3 이외 버전에서도 대체로 호환되지만 API 및 패키지 버전을 먼저 확인하세요.

## 설치 방법
1. **Day55 수업 소스를 이미 설치했다면** `Runtime/*.cs`, `Editor/*.cs` 만 `Assets/Day56_IntegrationLab/Scripts/Runtime`, `.../Editor`에 복사합니다. `Dependencies_Day55_Only_If_Missing` 폴더는 복사하지 않습니다.
2. **새 프로젝트에서 단독 실습한다면** `Dependencies_Day55_Only_If_Missing/*.cs` 파일도 `Assets/Day55_Prerequisites/Runtime`에 **한 번만** 설치합니다.
3. Unity Console에 컴파일 에러가 없는지 확인합니다. Input System이 활성화되어 있으면 새 Input System을 사용하고, 아니라면 Legacy Input Manager 코드를 사용합니다. Active Input Handling을 New만 사용하는 경우 Input System 패키지가 설치돼 있어야 합니다.
4. 메뉴 **Tools → Unity Codex → Day56 → Create Integration Lab**을 누르면 새 씬/Prefab/WaveConfig를 시간스탬프 폴더에 생성합니다. 기존 씬은 저장 확인을 거치며 기존 파일을 덮어쓰지 않습니다.
5. 생성된 `Day56_IntegrationLab.unity` 씬을 Play합니다. 좌측 상단 Day56 HUD의 `Start`, `Defeat One`, `Defeat All`, `Smoke Test`로 검증합니다.
6. 수동 `Fire` 버튼 또는 좌클릭/Space 입력으로 **카메라 화면 중앙에 보이는 몬스터**를 Raycast 공격합니다. 조준점이 어긋나면 카메라 Transform을 조절합니다.

## 핵심 검증 범위
- 공격: `Physics.Raycast` → Collider → `Day55MonsterUnit.TakeDamage` → Died
- 스폰: `Day55WaveSpawner` → `Day55MonsterPool.TrySpawn` → HP 초기화
- 반환: Died → `Day55MonsterPool.Return` → `UnitKilled`
- 완료: 이번 웨이브에서 `Spawned` 목표치 충족 **및** `Alive == 0`
- 일시정지/재시작: `Time.timeScale=0` 시 Spawn 코루틴 정지; 재시작 전 시간 복원 및 ReturnAll 확인

## 소스 파일
| 파일 | 역할 |
|---|---|
| `Day56CombatRaycaster.cs` | 카메라 레이 명중/데미지 연결 |
| `Day56CombatInput.cs` | 입력 전용 (Input System / Legacy 분기) |
| `Day56IntegrationObserver.cs` | 이벤트 카운터·불변식 진단 |
| `Day56AutoSmokeRunner.cs` | 자동 웨이브 완료·재시작·Stop 스모크 테스트 |
| `Day56IntegrationHUD.cs` | IMGUI 테스트 버튼·상태 표시 |
| `Day56IntegrationSceneBuilderEditor.cs` | 테스트 씬·Prefab·WaveConfig 안전 생성 |
| `Day56IntegrationValidatorEditor.cs` | 필수 컴포넌트 구성 검사 |

## 반드시 알아야 할 한계
- 자동 Smoke Test는 `pool.DamageAll()`을 사용해 몬스터를 직접 처치합니다. **Raycast 실제 명중/입력 장치/Player Controller의 정상 동작을 대신 검증하지 않습니다.** 수동 공격 테스트를 별도로 실행하세요.
- Editor 스크립트는 `Assets` 아래 **Editor 폴더**에 배치해야 합니다.
- 독립 실습 씬에는 NavMesh를 Bake하지 않으며 Day55 AI는 기본 이동 대체 코드를 사용합니다. 52일차 NavMesh AI 통합 검증은 별도의 NavMesh Bake와 AI 브리지 연결 후 수행하세요.
- 기존 52일차 EnemyBrain, 53~55일차 Spawner나 Pool을 동일 오브젝트에 중복 부착하지 마세요. 기존 수업 시스템을 통합할 때는 컴포넌트의 API 차이를 먼저 확인하세요.
- **Unity Editor 실제 컴파일과 Play Mode 실행은 이 패키지 작성 단계에서 수행하지 않았습니다.** 수강생이 패키지를 가져와 결과를 확인해야 합니다.
