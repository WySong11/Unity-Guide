# UNITY × CODEX | 68일차 Codex 리팩토링 실습

## 목적
동작을 변경하지 않고 몬스터 전투 로직의 Health·Cooldown·Combat 책임을 분리하고, Git Diff와 모델 동등성 테스트로 결과를 검증합니다.

## 실행 준비
1. Unity 6.3의 기존 프로젝트를 **백업 또는 별도 실습 브랜치**에서 엽니다.
2. `Assets/Day68RefactorLab/` 폴더를 프로젝트 `Assets/` 하위에 복사합니다. 다른 68일차 폴더가 있으면 덮어쓰지 않습니다.
3. 상단 메뉴 `Tools > Unity Codex > Day 68 > Build Refactor Lab`을 선택합니다. 기존 동일 이름 씬이 존재하면 생성하지 않습니다.
4. 생성된 `Assets/Day68RefactorLab/Scenes/Day68_RefactorLab.unity`를 열고 Play를 실행합니다.
5. 좌측 상단 IMGUI 버튼으로 공격·피격·초기화·동등성 테스트를 실행합니다.
6. `Tools > Unity Codex > Day 68 > Validate Current Scene`으로 필수 컴포넌트 존재 여부를 확인합니다.

## Before / After 코드
- `Runtime/Before/Day68LegacyMonsterLogic.cs`: 체력과 쿨타임이 한 클래스에 섞인 기준 모델
- `Runtime/After/Day68HealthState.cs`: 체력·사망 이벤트 모델
- `Runtime/After/Day68CooldownGate.cs`: 쿨타임 모델
- `Runtime/After/Day68RefactoredMonsterLogic.cs`: 공개 메서드는 Before와 같고 내부 구현만 분리
- `Runtime/Shared`: Unity 씬 연결·점수·사망 보상·테스트 UI·동등성 검사

## 행동 계약
`ReceiveDamage(int)`: 실제 적용된 피해량 반환, 0/음수는 무시, 사망 이후 추가 피해 0, 사망 이벤트는 각 생명주기에 1회.
`TryAttack(float now)`: 공격 가능하면 데미지 수치 반환, 사망/쿨타임 중이면 0, 동일 now 재호출은 0.
`Reset()`: 최대 HP와 초기 쿨타임으로 복구; Pool의 재사용에 대응.

## 검증 구분
- **모델 자동 비교**: `Day68LogicParityRunner`의 12개 정해진 시퀀스 검사 (Unity Play Mode에서 실행해야 함)
- **Unity 통합 수동 검사**: OnEnable/OnDisable 수명, Inspector 참조, 보상 중복, 씬/Prefab 회귀, Pause·실시간 타이머
- **코드 정적 검증**: Git Diff·수정 파일 범위·AGENTS.md 준수·필드 직렬화

이 ZIP 제작 환경에서는 Unity Editor를 실행하지 않았습니다. 자동 비교 테스트의 실제 PASS는 수강생이 Play Mode에서 확인해야 합니다.
