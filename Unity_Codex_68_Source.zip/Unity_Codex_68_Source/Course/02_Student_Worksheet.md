# 학생 워크시트 — Codex 리팩토링

**이름:** __________ **프로젝트/브랜치:** __________ **날짜:** __________

## A. 리팩토링 전 행동 계약
1. Monster의 CurrentHp가 50일 때 ReceiveDamage(20) 결과는? __________
2. HP 10에서 ReceiveDamage(100)의 실제 적용 피해는? __________
3. TryAttack(0), TryAttack(0), TryAttack(1)의 기대 출력은? __________
4. 사망 후 ReceiveDamage(100)를 한 번 더 호출할 때 OnDied 횟수는? __________

## B. 책임 분해
| 원래 책임 | 이동할 클래스 | 기존 공개 계약 유지 여부 |
|---|---|---|
| HP·사망 이벤트 | | |
| 공격 쿨타임 | | |
| 전투 결과 조합 | | |
| UI·점수 | | |

## C. Codex 기록
- 분석/계획 프롬프트: __________________
- 변경 승인 범위: __________________
- 변경 파일: __________________
- `git diff --check`: PASS / FAIL / NOT RUN
- 모델 parity 결과: PASS __ / FAIL __ / NOT RUN
- Unity Scene·Prefab 검사: PASS / FAIL / NOT RUN
- 남은 리스크: __________________
