# Git Diff 리팩토링 실습

1. 실습용 브랜치에서 `git status --short`로 시작합니다.
2. 기존 코드는 `Assets/Day68RefactorLab/Runtime/Before/`, 개선 코드는 `Runtime/After/`에서 비교합니다.
3. `git diff --no-index -- <Before파일> <After파일>`은 각각의 **내용 차이**만 보여주며 종료 코드 1은 차이가 있다는 뜻입니다.
4. 단계별 실제 구현에서는 `git diff --stat`, `git diff --check`, `git diff -- Assets/Day68RefactorLab/Runtime`를 사용합니다.
5. 순수 모델 외 Unity 참조·SerializeField·Prefab GUID·수명주기 변경도 수동으로 점검합니다.
6. Legacy와 Refactored의 클래스명이 다르므로 단일 소스파일 패치와 동치라고 주장하지 않습니다. API 계약과 실행 결과를 별도 비교해야 합니다.
