# AGENTS.md 리팩토링 섹션 예제 (기존 AGENTS.md에 검토 후 병합)

## 안전한 리팩토링
- 게임플레이의 입력, 출력, 직렬화 필드, 이벤트 발생 횟수, 풀 재사용 동작을 보존합니다.
- `AGENTS.md`, `UNITY_CS_CODING_RULES.md`, `GIT.md`, `UNITY_TOOLING.md`를 작업에 맞게 검토합니다.
- 수정을 시작하기 전에 코드 호출부와 프로젝트 상태를 조사하고 계획을 제시합니다.
- 작업 승인 범위 밖 파일·Scene·Prefab·.meta를 임의 수정하지 않습니다.
- 단계별 `git diff`와 자동·수동 테스트 결과를 기록합니다.
- 수행하지 못한 Unity Editor/Play Mode 테스트는 PASS가 아니라 NOT RUN으로 표시합니다.
- 승인 없이 commit/push, 기존 사용자 변경 초기화, 강제 덮어쓰기를 하지 않습니다.
