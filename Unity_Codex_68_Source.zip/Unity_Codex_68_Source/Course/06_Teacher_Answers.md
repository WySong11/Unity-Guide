# 강사용 기대 결과

- HP=50, ReceiveDamage(20): 적용 20, HP 30
- HP=10, ReceiveDamage(100): 적용 10, HP 0
- TryAttack(0) = 10, 같은 시각 두 번째 공격 = 0, TryAttack(1) = 10
- 사망 시 OnDied는 1회 발생하며, 사망 이후 피격·공격 결과는 0
- Reset 후 HP=50, 쿨타임 최초 상태 복귀
- `Day68HealthState`: HP·사망 이벤트만 유지
- `Day68CooldownGate`: 시간 간격 상태만 유지
- `Day68RefactoredMonsterLogic`: 두 모델의 조합·외부 계약 제공
- `Day68CombatFacade`: Unity 수명주기/인스펙터·Time.time과 순수 로직 연결
- `Day68RewardListener`: OnEnable 구독 / OnDisable 해제, 사망당 보상 1회

수업 패키지에 포함된 모델 동등성 12개 항목은 실제 Unity Play Mode에서 버튼을 눌러야 결과가 생성됩니다. 단독 컴파일을 수행했다고 주장하지 않습니다.
