# 강사용 120분 수업 진행 가이드

| 시간 | 목표 | 활동 | 산출물 |
|---|---|---|---|
| 0~25분 | 기존 시스템 이해 | Legacy 코드 책임, 행동 계약·경계값 확인 | 계약 시트 |
| 25~60분 | 안전한 리팩토링 | HealthState, CooldownGate, CombatLogic 책임 분리 | 수정 코드 |
| 60~100분 | Codex 활용 | P0 계획 → T01~T03 구현 → Git Diff 리뷰 | 프롬프트 로그·Diff |
| 100~120분 | 회귀 검증 | 12개 모델 체크·씬/Prefab 수동 검증·발표 | QA 결과·보고서 |

### 시연 포인트
- 리팩토링은 새로운 공격 기능 추가가 아님
- 같은 입력에 Legacy와 After가 동일한 반환값·상태·사망 이벤트 횟수를 내야 함
- 모델 테스트와 Unity Scene/Prefab·애니메이션 테스트를 혼동하지 말 것
- 코드 변경 전 `git status`로 기존 작업을 확인하고 승인 없는 reset/commit/push 금지
- 작업 이력과 `AGENTS.md`, `UNITY_CS_CODING_RULES.md`, `GIT.md`를 먼저 확인
