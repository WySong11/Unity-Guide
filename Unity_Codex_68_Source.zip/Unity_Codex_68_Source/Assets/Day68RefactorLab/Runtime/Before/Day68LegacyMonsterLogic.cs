using System;

namespace Day68RefactorLab
{
    /// <summary>교육용 Before: 체력과 쿨타임을 함께 관리하는 동작 기준 모델.</summary>
    public sealed class Day68LegacyMonsterLogic
    {
        private readonly int maxHp;
        private readonly int attackDamage;
        private readonly float attackInterval;
        private int hp;
        private float nextAt;

        public event Action OnDied;
        public int MaxHp => maxHp;
        public int CurrentHp => hp;
        public bool IsDead => hp == 0;

        public Day68LegacyMonsterLogic(int maxHp, int attackDamage, float attackInterval)
        {
            if (maxHp <= 0) throw new ArgumentOutOfRangeException(nameof(maxHp));
            if (attackDamage <= 0) throw new ArgumentOutOfRangeException(nameof(attackDamage));
            if (float.IsNaN(attackInterval) || float.IsInfinity(attackInterval) || attackInterval <= 0f)
                throw new ArgumentOutOfRangeException(nameof(attackInterval));
            this.maxHp = maxHp;
            this.attackDamage = attackDamage;
            this.attackInterval = attackInterval;
            Reset();
        }

        public int ReceiveDamage(int damage)
        {
            if (damage <= 0 || hp == 0) return 0;
            int applied = Math.Min(hp, damage);
            hp -= applied;
            if (hp == 0) OnDied?.Invoke();
            return applied;
        }

        public int TryAttack(float now)
        {
            if (hp == 0 || float.IsNaN(now) || float.IsInfinity(now) || now < nextAt)
                return 0;
            nextAt = now + attackInterval;
            return attackDamage;
        }

        public void Reset()
        {
            hp = maxHp;
            nextAt = 0f;
        }
    }
}
