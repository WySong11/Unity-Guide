using System;

namespace Day68RefactorLab
{
    /// <summary>After: 외부 계약은 Before와 같고 내부 책임만 조합으로 나뉨.</summary>
    public sealed class Day68RefactoredMonsterLogic
    {
        private readonly Day68HealthState health;
        private readonly Day68CooldownGate cooldown;
        private readonly int attackDamage;

        public event Action OnDied;
        public int MaxHp => health.MaxHp;
        public int CurrentHp => health.CurrentHp;
        public bool IsDead => health.IsDead;

        public Day68RefactoredMonsterLogic(int maxHp, int attackDamage, float attackInterval)
        {
            if (attackDamage <= 0) throw new ArgumentOutOfRangeException(nameof(attackDamage));
            health = new Day68HealthState(maxHp);
            cooldown = new Day68CooldownGate(attackInterval);
            this.attackDamage = attackDamage;
            health.OnDied += HandleDied;
        }

        private void HandleDied() => OnDied?.Invoke();
        public int ReceiveDamage(int amount) => health.ApplyDamage(amount);

        public int TryAttack(float now)
        {
            if (health.IsDead || !cooldown.TryOpen(now)) return 0;
            return attackDamage;
        }

        public void Reset()
        {
            health.Reset();
            cooldown.Reset();
        }
    }
}
