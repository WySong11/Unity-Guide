using System;

namespace Day68RefactorLab
{
    /// <summary>After: 공격 시간 간격만 책임지는 순수 C# 클래스.</summary>
    public sealed class Day68CooldownGate
    {
        private readonly float interval;
        private float nextAt;

        public Day68CooldownGate(float interval)
        {
            if (float.IsNaN(interval) || float.IsInfinity(interval) || interval <= 0f)
                throw new ArgumentOutOfRangeException(nameof(interval));
            this.interval = interval;
            Reset();
        }

        public bool TryOpen(float now)
        {
            if (float.IsNaN(now) || float.IsInfinity(now) || now < nextAt)
                return false;
            nextAt = now + interval;
            return true;
        }

        public void Reset() => nextAt = 0f;
    }
}
