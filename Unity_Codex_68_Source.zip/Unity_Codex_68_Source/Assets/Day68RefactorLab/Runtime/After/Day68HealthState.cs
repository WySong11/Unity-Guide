using System;

namespace Day68RefactorLab
{
    /// <summary>After: 체력·사망 이벤트만 책임지는 순수 C# 상태 객체.</summary>
    public sealed class Day68HealthState
    {
        public int MaxHp { get; }
        public int CurrentHp { get; private set; }
        public bool IsDead => CurrentHp == 0;
        public event Action OnDied;

        public Day68HealthState(int maxHp)
        {
            if (maxHp <= 0) throw new ArgumentOutOfRangeException(nameof(maxHp));
            MaxHp = maxHp;
            Reset();
        }

        public int ApplyDamage(int value)
        {
            if (value <= 0 || CurrentHp == 0) return 0;
            int applied = Math.Min(CurrentHp, value);
            CurrentHp -= applied;
            if (CurrentHp == 0) OnDied?.Invoke();
            return applied;
        }

        public void Reset() => CurrentHp = MaxHp;
    }
}
