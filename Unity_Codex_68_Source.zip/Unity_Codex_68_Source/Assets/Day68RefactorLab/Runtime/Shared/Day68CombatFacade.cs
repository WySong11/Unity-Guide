using System;
using UnityEngine;

namespace Day68RefactorLab
{
    /// <summary>Unity 씬 연동 담당. 핵심 계산은 순수 C# Logic에 위임.</summary>
    public sealed class Day68CombatFacade : MonoBehaviour
    {
        [SerializeField, Min(1)] private int maxHp = 50;
        [SerializeField, Min(1)] private int attackDamage = 10;
        [SerializeField, Min(0.01f)] private float attackInterval = 1f;
        private Day68RefactoredMonsterLogic logic;

        public event Action OnDied;
        public int CurrentHp => logic?.CurrentHp ?? 0;
        public bool IsDead => logic?.IsDead ?? true;

        private void Awake()
        {
            logic = new Day68RefactoredMonsterLogic(maxHp, attackDamage, attackInterval);
            logic.OnDied += HandleDied;
        }

        private void OnEnable() { if (logic != null) logic.Reset(); }
        private void OnDestroy() { if (logic != null) logic.OnDied -= HandleDied; }
        private void HandleDied() => OnDied?.Invoke();
        public int ReceiveDamage(int damage) => logic?.ReceiveDamage(damage) ?? 0;
        public int TryAttack() => logic?.TryAttack(Time.time) ?? 0;
        public void ResetCombat() => logic?.Reset();
    }
}
