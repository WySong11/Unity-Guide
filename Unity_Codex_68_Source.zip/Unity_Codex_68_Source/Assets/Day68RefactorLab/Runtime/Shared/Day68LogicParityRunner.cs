using UnityEngine;

namespace Day68RefactorLab
{
    /// <summary>두 모델에 동일한 시퀀스를 입력해 결과와 이벤트 횟수를 비교한다.</summary>
    public sealed class Day68LogicParityRunner : MonoBehaviour
    {
        public int LastPass { get; private set; }
        public int LastFail { get; private set; }
        private Day68LegacyMonsterLogic before;
        private Day68RefactoredMonsterLogic after;
        private int beforeDeaths;
        private int afterDeaths;

        private void Check(string id, bool equal)
        {
            if (equal) { LastPass++; Debug.Log($"[Day68] PASS {id}"); }
            else { LastFail++; Debug.LogError($"[Day68] FAIL {id}"); }
        }

        [ContextMenu("Run Day68 Parity Tests")]
        public void RunParity()
        {
            LastPass = LastFail = beforeDeaths = afterDeaths = 0;
            before = new Day68LegacyMonsterLogic(50, 10, 1f);
            after = new Day68RefactoredMonsterLogic(50, 10, 1f);
            before.OnDied += () => beforeDeaths++;
            after.OnDied += () => afterDeaths++;

            Check("QA01 normal damage", before.ReceiveDamage(20) == after.ReceiveDamage(20)
                && before.CurrentHp == after.CurrentHp && after.CurrentHp == 30);
            Check("QA03 zero damage", before.ReceiveDamage(0) == after.ReceiveDamage(0)
                && before.CurrentHp == after.CurrentHp);
            Check("QA03 negative damage", before.ReceiveDamage(-7) == after.ReceiveDamage(-7)
                && before.CurrentHp == after.CurrentHp);
            Check("QA04 attack t=0", before.TryAttack(0f) == after.TryAttack(0f));
            Check("QA04 duplicate t=0", before.TryAttack(0f) == after.TryAttack(0f)
                && after.TryAttack(0f) == 0);
            Check("QA04 early t=0.5", before.TryAttack(0.5f) == after.TryAttack(0.5f));
            Check("QA04 ready t=1", before.TryAttack(1f) == after.TryAttack(1f));
            Check("QA02 lethal 200", before.ReceiveDamage(200) == after.ReceiveDamage(200)
                && before.CurrentHp == after.CurrentHp && beforeDeaths == afterDeaths
                && afterDeaths == 1);
            Check("QA06 dead attack", before.TryAttack(2f) == after.TryAttack(2f)
                && after.TryAttack(2f) == 0);
            Check("QA07 repeat death", before.ReceiveDamage(100) == after.ReceiveDamage(100)
                && beforeDeaths == 1 && afterDeaths == 1);
            before.Reset(); after.Reset();
            Check("QA05 reset HP", before.CurrentHp == after.CurrentHp && after.CurrentHp == 50);
            Check("QA05 reset cooldown", before.TryAttack(0f) == after.TryAttack(0f)
                && before.CurrentHp == after.CurrentHp);
            Debug.Log($"[Day68] MODEL PARITY: PASS {LastPass}, FAIL {LastFail}. "
                + "Unity Scene/Prefab and performance tests are NOT covered.");
        }
    }
}
