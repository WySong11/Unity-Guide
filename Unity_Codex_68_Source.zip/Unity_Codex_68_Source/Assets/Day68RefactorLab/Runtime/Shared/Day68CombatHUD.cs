using UnityEngine;

namespace Day68RefactorLab
{
    /// <summary>별도 Canvas 없이 사용 가능한 수업용 디버그 UI.</summary>
    public sealed class Day68CombatHUD : MonoBehaviour
    {
        [SerializeField] private Day68CombatFacade monster;
        [SerializeField] private Day68ScoreBank score;
        [SerializeField] private Day68LogicParityRunner parity;
        private string lastAction = "READY";

        private void OnGUI()
        {
            GUILayout.BeginArea(new Rect(15, 15, 350, 260), GUI.skin.box);
            GUILayout.Label("DAY 68 | CODEX REFACTOR LAB");
            GUILayout.Label("Monster HP: " + (monster != null ? monster.CurrentHp.ToString() : "Missing"));
            GUILayout.Label("Score: " + (score != null ? score.Score.ToString() : "Missing"));
            GUILayout.Label("Last action: " + lastAction);
            if (GUILayout.Button("Damage Monster (20)") && monster != null)
                lastAction = "Damage applied: " + monster.ReceiveDamage(20);
            if (GUILayout.Button("Try Monster Attack") && monster != null)
                lastAction = "Attack damage: " + monster.TryAttack();
            if (GUILayout.Button("Reset Monster") && monster != null)
            {
                monster.ResetCombat(); lastAction = "Monster state reset";
            }
            if (GUILayout.Button("Reset Score") && score != null) score.ResetScore();
            if (GUILayout.Button("Run Model Parity (12 checks)") && parity != null)
            {
                parity.RunParity();
                lastAction = $"Model tests PASS {parity.LastPass} / FAIL {parity.LastFail}";
            }
            GUILayout.EndArea();
        }
    }
}
