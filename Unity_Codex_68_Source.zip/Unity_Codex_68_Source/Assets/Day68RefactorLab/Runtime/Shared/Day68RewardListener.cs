using UnityEngine;

namespace Day68RefactorLab
{
    /// <summary>사망 이벤트 수신과 보상 지급은 Monster 모델 외부에 둔다.</summary>
    public sealed class Day68RewardListener : MonoBehaviour
    {
        [SerializeField] private Day68CombatFacade source;
        [SerializeField] private Day68ScoreBank score;
        [SerializeField, Min(1)] private int points = 10;
        private void OnEnable()
        {
            if (source != null) source.OnDied += GiveReward;
        }
        private void OnDisable()
        {
            if (source != null) source.OnDied -= GiveReward;
        }
        private void GiveReward()
        {
            if (score != null) score.Add(points);
        }
    }
}
