using System;
using UnityEngine;

namespace Day68RefactorLab
{
    /// <summary>UI와 게임플레이에서 재사용할 간단한 점수 모델.</summary>
    public sealed class Day68ScoreBank : MonoBehaviour
    {
        [SerializeField, Min(0)] private int score;
        public int Score => score;
        public event Action<int> OnScoreChanged;
        public void Add(int points)
        {
            if (points <= 0) return;
            score = points >= int.MaxValue - score ? int.MaxValue : score + points;
            OnScoreChanged?.Invoke(score);
        }
        public void ResetScore() { score = 0; OnScoreChanged?.Invoke(score); }
    }
}
