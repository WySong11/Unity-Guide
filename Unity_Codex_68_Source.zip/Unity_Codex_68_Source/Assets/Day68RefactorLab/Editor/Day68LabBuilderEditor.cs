#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Day68RefactorLab.Editor
{
    public static class Day68LabBuilderEditor
    {
        [MenuItem("Tools/Unity Codex/Day 68/Build Refactor Lab")]
        public static void Build()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            const string folder = "Assets/Day68RefactorLab/Scenes";
            if (!AssetDatabase.IsValidFolder("Assets/Day68RefactorLab"))
                AssetDatabase.CreateFolder("Assets", "Day68RefactorLab");
            if (!AssetDatabase.IsValidFolder(folder))
                AssetDatabase.CreateFolder("Assets/Day68RefactorLab", "Scenes");
            string scenePath = folder + "/Day68_RefactorLab.unity";
            if (File.Exists(scenePath))
            {
                EditorUtility.DisplayDialog("Day 68", "Existing scene preserved: " + scenePath,
                    "OK");
                return;
            }
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects,
                NewSceneMode.Single);
            GameObject monster = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            monster.name = "Day68_Monster";
            monster.transform.position = new Vector3(0f, 1f, 0f);
            var combat = monster.AddComponent<Day68CombatFacade>();
            var reward = monster.AddComponent<Day68RewardListener>();
            var root = new GameObject("Day68_RefactorServices");
            var bank = root.AddComponent<Day68ScoreBank>();
            var runner = root.AddComponent<Day68LogicParityRunner>();
            var hud = root.AddComponent<Day68CombatHUD>();
            SerializedObject rewardFields = new SerializedObject(reward);
            rewardFields.FindProperty("source").objectReferenceValue = combat;
            rewardFields.FindProperty("score").objectReferenceValue = bank;
            rewardFields.ApplyModifiedPropertiesWithoutUndo();
            SerializedObject hudFields = new SerializedObject(hud);
            hudFields.FindProperty("monster").objectReferenceValue = combat;
            hudFields.FindProperty("score").objectReferenceValue = bank;
            hudFields.FindProperty("parity").objectReferenceValue = runner;
            hudFields.ApplyModifiedPropertiesWithoutUndo();
            if (Camera.main != null)
            {
                Camera.main.transform.position = new Vector3(0f, 2.5f, -7f);
                Camera.main.transform.LookAt(monster.transform);
            }
            EditorSceneManager.SaveScene(scene, scenePath);
            AssetDatabase.Refresh();
            EditorUtility.DisplayDialog("Day 68", "Scene created: " + scenePath +
                "\nPress Play, then use the IMGUI buttons.", "OK");
        }
    }
}
#endif
