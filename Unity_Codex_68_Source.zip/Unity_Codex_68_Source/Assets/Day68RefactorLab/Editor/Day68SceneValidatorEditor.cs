#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace Day68RefactorLab.Editor
{
    public static class Day68SceneValidatorEditor
    {
        [MenuItem("Tools/Unity Codex/Day 68/Validate Current Scene")]
        public static void Validate()
        {
            var combat = Object.FindFirstObjectByType<Day68CombatFacade>();
            var listener = Object.FindFirstObjectByType<Day68RewardListener>();
            var bank = Object.FindFirstObjectByType<Day68ScoreBank>();
            var parity = Object.FindFirstObjectByType<Day68LogicParityRunner>();
            var hud = Object.FindFirstObjectByType<Day68CombatHUD>();
            bool ok = combat != null && listener != null && bank != null && parity != null && hud != null;
            if (!ok)
                Debug.LogWarning("[Day68] Missing expected components. Run Build Refactor Lab.");
            else
                Debug.Log("[Day68] Required components exist. Check serialized references in Inspector and run Play Mode tests.");
        }
    }
}
#endif
