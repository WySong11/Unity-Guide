using UnityEngine;

public class ScoreCounter2D : MonoBehaviour
{
    [SerializeField] private int score;
    public int Score => score;

    public void AddScore(int amount)
    {
        if (amount <= 0) return;
        score += amount;
        Debug.Log($"Score: {score}");
    }
}
