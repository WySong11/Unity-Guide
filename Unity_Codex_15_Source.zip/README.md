# 15일차 — 2D 플레이어 이동과 충돌

대상: Unity 6.3 계열 + Input System 패키지. 입력 예제는 `InputActionReference`를 직접 제어하는 방식입니다. `PlayerInput` 컴포넌트가 같은 Action Asset을 동시에 활성화/비활성화하지 않도록 다른 입력 제어 스크립트와 혼용하지 마세요.

## Unity 설정
1. 2D URP 프로젝트에서 Day15_PlayerMovement Scene을 만듭니다.
2. Player: SpriteRenderer, Rigidbody2D(Dynamic), CapsuleCollider2D, PlayerMover2D, PlayerHealth2D.
3. Rigidbody2D의 Freeze Rotation Z 체크. Gravity Scale 2.5는 시작 예시입니다.
4. Player 하위에 GroundCheck 빈 GameObject를 발 아래에 배치합니다.
5. Ground, Wall은 Ground Layer + 일반 Collider2D. PlayerMover2D의 Ground Layer에 해당 레이어 지정.
6. Input Actions: Player/Move(Value Vector2, WASD Composite), Player/Jump(Button, Space). 각 Reference를 Inspector에 연결.
7. Coin: Collider2D / Is Trigger 체크 + CoinPickup2D. ScoreCounter2D 레퍼런스 연결.
8. Hazard: 일반 Collider2D + HazardCollision2D. Player의 Tag는 Player.
9. 테스트: 이동, 점프, 공중 중복 점프 방지, 벽 충돌, 코인 수집, 위험물 피해.

## 핵심 검증
- Unity 6에서는 Rigidbody2D.linearVelocity 속성을 사용합니다.
- `FixedUpdate`에서 수평 X를 변경하면서 Y는 보존합니다.
- 점프 입력은 콜백에서 bool로 저장해 FixedUpdate에서 처리합니다. 기본 구현은 공중에서 발생한 점프 요청을 해당 FixedUpdate에서 소모합니다. 코요테 타임이나 점프 버퍼는 심화 과제입니다.
- 스크립트 동작 여부는 실제 Unity Play Mode에서 확인해야 합니다. 본 배포물은 코드·설정 예제이며 Unity 빌드 검증은 포함되지 않습니다.

공식 문서:
- https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/rigidbody2d/linearvelocity
- https://docs.unity.com/en-us/engine/6000.3/script-reference/unityengine/physicsscene2d/overlapcircle
- https://docs.unity.com/en-us/engine/6000.3/manual/packages-list/packages-all/pack-safe/com-unity-inputsystem
