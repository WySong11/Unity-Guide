using UnityEngine;

public class HazardCollision2D : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (!collision.gameObject.CompareTag("Player")) return;
        if (collision.gameObject.TryGetComponent(out PlayerHealth2D hp))
            hp.TakeDamage(1);
    }
}
