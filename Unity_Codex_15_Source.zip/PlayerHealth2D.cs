using UnityEngine;

public class PlayerHealth2D : MonoBehaviour
{
    [SerializeField, Min(1)] private int maxHealth = 3;
    private int health;

    private void Awake() { health = maxHealth; }

    public void TakeDamage(int amount)
    {
        if (amount <= 0 || health <= 0) return;
        health = Mathf.Max(0, health - amount);
        Debug.Log($"HP: {health}/{maxHealth}");
        if (health == 0) Debug.Log("Game Over");
    }
}
