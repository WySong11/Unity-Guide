using UnityEngine;

[RequireComponent(typeof(Collider2D))]
public class CoinPickup2D : MonoBehaviour
{
    [SerializeField] private int scoreValue = 10;
    [SerializeField] private ScoreCounter2D scoreCounter;
    private bool collected;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (collected || !other.CompareTag("Player")) return;
        collected = true;
        if (scoreCounter != null) scoreCounter.AddScore(scoreValue);
        gameObject.SetActive(false);
    }
}
