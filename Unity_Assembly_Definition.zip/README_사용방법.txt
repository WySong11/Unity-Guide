Unity 6.3(6000.3) Assembly Definition 실습 소스

1) ZIP 안의 Assets/AsmdefLab 폴더를 Unity 프로젝트의 Assets/ 경로에 복사하세요.
2) Unity가 import/compile을 끝내도록 하세요.
3) Hierarchy > Create Empty, 이름은 AssemblyDemo로 설정하세요.
4) HealthDemo 컴포넌트를 AssemblyDemo에 추가하세요.
5) Play 버튼을 누르고 Console에서 HP: 75 / 100 출력 확인.
6) OptionalSamples는 Unity 프로젝트의 Assets에 통째로 넣지 마세요.
   HealthTests.cs.txt는 Test Runner로 만든 test assembly 폴더에
   HealthTests.cs라는 이름으로 저장한 뒤 Demo.Core 참조를 추가하세요.
   .asmref 확장 예제도 해당 폴더를 준비한 다음에만 사용하세요.

주의:
- .asmdef 예제의 references는 읽기 쉬운 이름 기반입니다.
- C# 파일은 UTF-8 BOM, .asmdef JSON은 UTF-8 without BOM으로 저장했습니다.
- 임포트 뒤 Unity가 생성한 .meta는 Git에서 함께 버전 관리하세요.
- 동일한 assembly name의 다른 asmdef가 있으면 이름 충돌이 발생할 수 있습니다.
