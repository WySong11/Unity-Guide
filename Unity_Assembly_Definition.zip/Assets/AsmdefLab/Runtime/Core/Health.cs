﻿using System;

namespace AsmdefLab.Core
{
    // UnityEngine 없이 동작하는 순수 C# 체력 모델입니다.
    public sealed class Health
    {
        public int Maximum { get; }
        public int Current { get; private set; }

        public Health(int maximum)
        {
            if (maximum <= 0)
                throw new ArgumentOutOfRangeException(nameof(maximum));

            Maximum = maximum;
            Current = maximum;
        }

        public void Damage(int amount)
        {
            if (amount < 0)
                throw new ArgumentOutOfRangeException(nameof(amount));

            Current = Math.Max(0, Current - amount);
        }
    }
}
