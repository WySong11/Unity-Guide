﻿using AsmdefLab.Core;
using AsmdefLab.UI;
using UnityEngine;

namespace AsmdefLab.Gameplay
{
    // GameObject에 붙여 실행할 MonoBehaviour 컴포넌트입니다.
    public sealed class HealthDemo : MonoBehaviour
    {
        [SerializeField] private int maximumHealth = 100;
        [SerializeField] private int damage = 25;

        private void Start()
        {
            // 서로 다른 두 어셈블리의 코드를 사용합니다.
            var health = new Health(maximumHealth);
            health.Damage(damage);

            Debug.Log(HealthFormatter.Format(health));
        }
    }
}
