﻿using AsmdefLab.Core;

namespace AsmdefLab.UI
{
    // Health 타입을 사용하므로 Demo.Core 참조가 필요합니다.
    public static class HealthFormatter
    {
        public static string Format(Health health)
        {
            if (health == null)
                return "HP: -";

            return $"HP: {health.Current} / {health.Maximum}";
        }
    }
}
