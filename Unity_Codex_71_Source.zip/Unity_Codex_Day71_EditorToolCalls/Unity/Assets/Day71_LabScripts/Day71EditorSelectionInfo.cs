using UnityEngine;

/// <summary>Inspector에 표시되는 실습 태그 (프로젝트 데이터에 영향 없음).</summary>
public sealed class Day71EditorSelectionInfo : MonoBehaviour
{
    [SerializeField] private string labTag = "Day71-MCP";
    public string LabTag => labTag;
}
