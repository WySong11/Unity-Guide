using UnityEngine;

/// <summary>71일차: 저장된 Scene의 Cube가 Play Mode에서 회전하는지 확인.</summary>
public sealed class Day71SpinCube : MonoBehaviour
{
    [SerializeField, Min(0f)] private float speedDegreesPerSecond = 45f;

    public float SpeedDegreesPerSecond => speedDegreesPerSecond;

    private void Update()
    {
        transform.Rotate(Vector3.up, speedDegreesPerSecond * Time.deltaTime, Space.Self);
    }
}
