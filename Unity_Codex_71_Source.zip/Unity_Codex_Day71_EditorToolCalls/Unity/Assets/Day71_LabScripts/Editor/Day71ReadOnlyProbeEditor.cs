#if UNITY_EDITOR
using System.Text;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class Day71ReadOnlyProbeEditor
{
    [MenuItem("Tools/Day71/01 Read Only Scene Snapshot")]
    public static void Snapshot()
    {
        Scene scene = SceneManager.GetActiveScene();
        GameObject[] roots = scene.GetRootGameObjects();
        var report = new StringBuilder(512);
        report.AppendLine("[Day71] READ-ONLY EDITOR SNAPSHOT");
        report.AppendLine("Unity Version: " + Application.unityVersion);
        report.AppendLine("Project: " + Application.dataPath);
        report.AppendLine("Scene: " + scene.name + " / " + scene.path);
        report.AppendLine("Scene IsDirty: " + scene.isDirty);
        report.AppendLine("Root Count: " + roots.Length);
        foreach (GameObject root in roots)
            report.AppendLine(" - " + root.name + " @ " + root.transform.position);
        if (Selection.activeGameObject != null)
        {
            var selected = Selection.activeGameObject;
            report.AppendLine("Selected: " + selected.name);
            foreach (Component component in selected.GetComponents<Component>())
                report.AppendLine(" Component: " + (component == null ? "Missing" : component.GetType().Name));
        }
        else report.AppendLine("Selected: None");
        Debug.Log(report.ToString()); // 로그 출력 이외 프로젝트 데이터 수정 없음
    }
}
#endif
