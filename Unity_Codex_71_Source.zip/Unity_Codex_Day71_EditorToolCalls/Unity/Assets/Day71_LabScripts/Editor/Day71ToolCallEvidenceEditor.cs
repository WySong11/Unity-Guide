#if UNITY_EDITOR
using System;
using System.Text;
using UnityEditor;
using UnityEngine;

/// <summary>Selection의 Component 정보와 속성들을 읽기 전용으로 출력.</summary>
public static class Day71ToolCallEvidenceEditor
{
    [MenuItem("Tools/Day71/04 Inspect Selected Object (Read Only)")]
    public static void InspectSelected()
    {
        GameObject go = Selection.activeGameObject;
        if (go == null)
        {
            Debug.Log("[Day71] 선택된 GameObject가 없습니다.");
            return;
        }
        var sb = new StringBuilder("[Day71] Selected: " + go.name + Environment.NewLine);
        Transform t = go.transform;
        sb.AppendLine("localPosition=" + t.localPosition + " worldPosition=" + t.position);
        sb.AppendLine("localRotation=" + t.localEulerAngles + " localScale=" + t.localScale);
        foreach (Component c in go.GetComponents<Component>())
            sb.AppendLine("Component=" + (c == null ? "Missing Script" : c.GetType().FullName));
        Debug.Log(sb.ToString());
    }
}
#endif
