#if UNITY_EDITOR
using System;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class Day71SceneValidatorEditor
{
    [MenuItem("Tools/Day71/03 Validate Active Lab Scene (Read Only)")]
    public static void Validate()
    {
        Scene scene = SceneManager.GetActiveScene();
        bool inLab = scene.path.StartsWith("Assets/Day71_EditorToolLab/", StringComparison.Ordinal);
        if (!inLab)
        {
            Debug.LogWarning("[Day71] FAIL: 활성 Scene이 실습 폴더 밖입니다: " + scene.path);
            return;
        }
        int found = 0;
        foreach (GameObject root in scene.GetRootGameObjects())
        {
            if (root.name != "Day71_MCP_Cube") continue;
            found++;
            Vector3 actual = root.transform.position;
            bool correctPos = Vector3.Distance(actual, new Vector3(0f, 1f, 0f)) < 0.001f;
            Day71SpinCube[] spin = root.GetComponents<Day71SpinCube>();
            bool correctSpin = spin.Length == 1 && Mathf.Abs(spin[0].SpeedDegreesPerSecond - 45f) < 0.01f;
            Debug.Log("[Day71] Cube | Position: " + (correctPos ? "PASS" : "FAIL")
                + " | Spin: " + (correctSpin ? "PASS" : "FAIL") + " | Actual: " + actual);
        }
        Debug.Log("[Day71] Lab Scene: " + scene.path
            + " | Target object count: " + found + " (expected 1)"
            + " | IsDirty: " + scene.isDirty + " | Scene valid: " + scene.IsValid());
        if (found != 1) Debug.LogWarning("[Day71] FAIL: Day71_MCP_Cube는 정확히 1개여야 합니다.");
    }
}
#endif
