#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class Day71SceneBuilderEditor
{
    private const string Folder = "Assets/Day71_EditorToolLab";

    [MenuItem("Tools/Day71/02 Create Unique Lab Scene (Confirmation)")]
    public static void CreateLabScene()
    {
        if (EditorApplication.isPlayingOrWillChangePlaymode)
        {
            EditorUtility.DisplayDialog("Day71", "먼저 Play Mode를 종료하세요.", "확인");
            return;
        }

        Scene active = SceneManager.GetActiveScene();
        if (active.isDirty)
        {
            EditorUtility.DisplayDialog("Day71", "현재 Scene에 미저장 변경이 있습니다. 직접 저장하거나 취소한 뒤 다시 실행하세요. 자동으로 저장하지 않습니다.", "확인");
            return;
        }

        if (!EditorUtility.DisplayDialog("Day71 Editor Tool Lab",
            "현재 Scene을 닫고 Day71 전용 실습 Scene을 새로 만듭니다. 기존 Scene과 에셋은 덮어쓰지 않습니다. 진행할까요?",
            "Create", "Cancel")) return;

        if (!AssetDatabase.IsValidFolder(Folder))
            AssetDatabase.CreateFolder("Assets", "Day71_EditorToolLab");

        string scenePath = AssetDatabase.GenerateUniqueAssetPath(Folder + "/Day71_MCP_EditorLab.unity");
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        cube.name = "Day71_MCP_Cube";
        Undo.RegisterCreatedObjectUndo(cube, "Day71 Create Lab Cube");
        cube.transform.position = new Vector3(0f, 1f, 0f);
        cube.AddComponent<Day71SpinCube>();
        cube.AddComponent<Day71EditorSelectionInfo>();

        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (shader == null) shader = Shader.Find("Standard");
        if (shader != null)
        {
            var material = new Material(shader);
            material.name = "Day71_LabMaterial";
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", new Color(0.16f, 0.56f, 0.95f));
            else if (material.HasProperty("_Color")) material.color = new Color(0.16f, 0.56f, 0.95f);
            string matPath = AssetDatabase.GenerateUniqueAssetPath(Folder + "/Day71_LabMaterial.mat");
            AssetDatabase.CreateAsset(material, matPath);
            cube.GetComponent<Renderer>().sharedMaterial = material;
        }
        else Debug.LogWarning("[Day71] 표시용 셰이더를 찾지 못해 기본 재질을 사용합니다.");

        if (!EditorSceneManager.SaveScene(scene, scenePath))
        {
            Debug.LogError("[Day71] Scene 저장 실패: " + scenePath);
            return;
        }
        Selection.activeGameObject = cube;
        Debug.Log("[Day71] Lab scene created: " + scenePath + " | Cube: " + cube.transform.position);
    }
}
#endif
