# Tool inventory is dynamic; always inspect the installed version.
if (-not (Get-Command unity -ErrorAction SilentlyContinue)) { Write-Error 'Unity CLI not found'; exit 1 }
& unity command
& unity list
Write-Host 'IMPORTANT: Editor CLI commands and MCP tool names may differ.'
Write-Host 'Use Codex to enumerate the actual MCP tool schemas before any mutation.'
