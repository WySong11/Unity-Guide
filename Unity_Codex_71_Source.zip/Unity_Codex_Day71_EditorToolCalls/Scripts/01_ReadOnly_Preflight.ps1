# Read-only diagnostic. Run from the project root in PowerShell.
# Does not install Unity, configure MCP, create scenes, or alter settings.
$ErrorActionPreference = 'Continue'
Write-Host '===== Day71 Unity Editor Tool Preflight (READ ONLY) ====='
foreach ($cmd in @('unity','codex','git')) {
    $found = Get-Command $cmd -ErrorAction SilentlyContinue
    Write-Host "[$cmd] $(if ($found) { $found.Source } else { 'NOT FOUND' })"
}
if (Get-Command unity -ErrorAction SilentlyContinue) {
    & unity --version
    & unity status
    & unity pipeline list
    & unity command
}
if (Get-Command codex -ErrorAction SilentlyContinue) { & codex mcp list }
if (Get-Command git -ErrorAction SilentlyContinue) { & git status --short }
Write-Host '===== No configuration or project files changed by this script ====='
