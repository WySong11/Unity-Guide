# Unity Editor Tool Call Workflow

```text
사용자 요구 / AGENTS.md
         |
         v
Codex (MCP Client)
         |  tools/list → 실제 tool ID/Schema
         v
Unity CLI 내장 MCP Server (stdio)
         |
         v
Unity Pipeline (Editor connection)
         |
         v
Unity Editor ── Scene / GameObject / Transform / Component
         |
         v
실제 값 재조회 ── Console 확인 ── Scene Save ── Git Diff
```

`codex mcp list`는 서버 등록을 확인할 뿐 실제 Unity Scene 수정 검증이 아니다.
