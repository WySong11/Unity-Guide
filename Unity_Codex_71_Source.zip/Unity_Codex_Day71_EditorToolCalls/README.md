# Unity × Codex | Day 71 — Unity Editor Tool Calls

**목표:** Codex가 Unity MCP 도구를 실제로 목록 조회하고, Unity Editor에서 Scene/Hierarchy를 읽고, 승인된 실습 Scene에만 Cube를 생성·수정한 뒤 저장과 Git Diff로 결과를 확인한다.

**준비:** Unity 6.0 이상(수업 기준 Unity 6.3), `com.unity.pipeline`, Unity CLI, Codex MCP 등록, Windows PowerShell, Git.

## 시작

1. 기존 프로젝트에서 `git status` 확인하고 미커밋 변경을 보존한다.
2. ZIP의 `Unity/Assets/Day71_LabScripts`만 자기 Unity 프로젝트 `Assets/` 아래에 복사한다. 동일 이름 파일이 있으면 자동으로 덮어쓰지 않는다.
3. Unity 컴파일을 확인한다. `Tools > Day71 > 01 Read Only Scene Snapshot` 메뉴로 기본 상태를 읽는다.
4. `CODEX_PROMPTS.md`의 **P0/P1/P2를 우선 실행**하고 MCP 도구 스키마를 수집한다.
5. 강사의 승인 이후 **P3~P7**을 수행하거나, Unity 메뉴의 **02 Create Unique Lab Scene**을 시연용 대체 경로로 사용할 수 있다.
6. `03 Validate Active Lab Scene`은 실습 Scene을 검사하나 수정하지 않는다.
7. `QA_MATRIX.csv`로 검증한다. 실제 도구 호출이 없었다면 MCP 실행 항목을 PASS로 처리하지 않는다.

## 중요: 두 경로를 혼동하지 않는다

- **MCP 실습**: Codex에서 Unity MCP 도구를 실제 호출해서 씬을 만들고 수정한다.
- **Editor 메뉴 대체 시연**: 제공한 C# Editor 스크립트로 유사한 결과를 생성한다. 이것은 **MCP 도구 호출 성공 증거가 아니다**.

## 안전한 기본 범위

- 쓰기 허용: `Assets/Day71_EditorToolLab/` 내 새 Scene·Material 등으로 한정.
- 기존 Scenes, Prefabs, ProjectSettings, Packages, MCP 설정, Git 커밋은 사전 승인 없이 변경하지 않는다.
- 메뉴 도구는 활성 Scene의 미저장 변경이 있으면 생성 작업을 거절한다. 같은 이름의 Scene은 새 고유 경로를 생성한다.
- 실제 Unity 실행/컴파일/Play Mode 테스트는 이 ZIP 생성 환경에서 수행하지 않았다. **로컬 Editor 검증이 필요하다.**

## 설치된 Unity CLI 버전별 차이

- MCP 서버 `unity mcp`, 구성 `unity mcp configure codex`, 실제 Editor 연결 조회 `unity status`, 목록 `unity command`/`unity list`.
- MCP 도구 식별자와 인자 스키마는 버전에 따라 바뀔 수 있으므로 **가짜 함수명 사용 금지**.
- CLI 직접 명령과 Codex를 통한 MCP 도구 실행은 서로 다른 경로다.

## 강의 제출물

`TOOL_INVENTORY.csv`, `CALL_LOG.csv`, `QA_MATRIX.csv`, Scene/Inspector 스크린샷, Console 오류 목록, `git diff --stat`, `REVIEW_REPORT_TEMPLATE.md`.
