# 학생 실습 — Unity Editor 도구 호출 (120분)

## 목표 및 시간
|시간|실습|완료 기준|
|---|---|---|
|0~20분|CLI·Pipeline·MCP 연결 및 도구 조사|실제 도구명·스키마 4개 이상|
|20~45분|현재 Scene·Root·Component 읽기 호출|Editor 화면값과 일치|
|45~90분|승인 받은 Day71 테스트 Scene 생성·Cube 수정|Cube(0,1,0), Spin(45)|
|90~120분|씬 저장·Console·Git Diff·최종 QA|12개 QA 결과·증거|

## 단계별 과제
**1. Discover.** `AGENTS.md`를 확인하고 Unity MCP 도구 목록을 실제로 나열한다. `unity command` 출력은 참고용일 뿐 MCP 호출 증거가 아니다.

**2. Inspect.** 현재 Scene 이름·경로·Root 객체 이름·Main Camera Transform을 읽는다. 읽기 결과에 도구명/인수/응답을 기록한다.

**3. Approve.** 새 Scene의 위치가 `Assets/Day71_EditorToolLab`인지 확인하고 쓰기 작업 범위를 승인받는다.

**4. Create.** `Day71_MCP_EditorLab` Scene에서 `Day71_MCP_Cube`를 정확히 1개 만든다. 위치 `(0,1,0)`, 회전 `(0,0,0)`, 스케일 `(1,1,1)`을 설정한다. 같은 이름이 존재하면 중복 생성하지 않는다.

**5. Component.** 제공된 `Day71SpinCube` 컴포넌트를 1개만 연결한다. 인스펙터 기본 속도 `45`를 확인한다. 컴파일 오류를 기록한다.

**6. Save.** `Day71_MCP_EditorLab.unity`를 저장한 뒤 씬을 다시 조회한다. `git status`, `git diff --stat`와 실제 에셋 파일 경로를 대조한다.

**7. Play.** 허가 후 Play Mode에서 Cube 회전을 눈으로 확인한다. Play Mode를 중단하고 Scene Dirty 상태를 다시 검사한다. 자동 회전이 실패하면 코드·Console로 원인을 좁힌다.

**8. Report.** PASS/FAIL/NOT RUN을 분리하고, 미실행 호출은 절대 성공한 것으로 기록하지 않는다.

## 도전 과제
- Scene 내 Cube와 Main Camera의 World·Local Transform 차이를 조사한다.
- 두 개 Unity Editor를 열었을 때 잘못된 대상 Scene을 조작하지 않도록 프로젝트 경로를 고정해본다.
- 재실행한 Codex 프롬프트가 동일 Cube를 중복 생성하지 않는지 확인한다.
