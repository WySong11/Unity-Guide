# 공식 참고 문서 (2026-10 확인)

- Unity CLI 안내: https://docs.unity.com/en-us/unity-cli
- Unity CLI 사용법: https://docs.unity.com/en-us/unity-cli/use-unity-cli
- Unity Pipeline/CLI 비교: https://docs.unity.com/en-us/unity-production-pipeline/local-tools-cli/unity-cli-pipeline-package
- MCP 서버 전환: https://docs.unity.com/en-us/unity-cli/replace-mcp-server-unity-cli
- Unity CLI 릴리스 노트: https://docs.unity.com/en-us/unity-cli/release-notes
- Unity 공식 플러그인 확장 설정: https://github.com/Unity-Technologies/unity-agent-plugin/tree/main/skills/unity-cli

Unity CLI는 실험적 기능이 포함되어 버전별 명령·매개변수가 바뀔 수 있다.
실제 설치된 버전의 `unity --help`, `unity command`, `unity list` 및 Codex MCP 도구 스키마가 최종 기준이다.
