# 강사용 120분 진행안

- **00–20분:** 70일차 MCP 등록 상태 복습, `unity status`·`unity command`·`codex mcp list` 확인. 실제 도구 스키마의 형태를 칠판에 작성.
- **20–45분:** 도구 읽기 호출과 Inspector 비교. 값이 다르면 다른 Editor/Scene을 대상으로 하고 있지 않은지 점검.
- **45–90분:** 단계적 승인으로 Lab Scene → Cube → Transform → Script 순서. 중간에 `git status` 점검. 작성 전 파일 명 중복을 검사.
- **90–120분:** 저장과 재조회, Play Mode 승인 실습, Console 분석, 100점 평가표 제출.

## 교사 시연 플랜
1. MCP 도구를 사용한 **실제 호출**을 우선 시연.
2. 네트워크·권한·라이선스 때문에 MCP가 동작하지 않으면, Editor `Tools/Day71/02 Create Unique Lab Scene` 메뉴로 구조를 시연하면서 **MCP 미실행(진행 불가)** 로 명시한다.
3. `03 Validate Active Lab Scene`의 PASS/FAIL은 Scene 값 검사이고 MCP 연결을 검증하지 않는다.
4. 다른 수강생/프로젝트의 토큰·경로를 공유하지 않는다. 텍스트 로그에서 민감 데이터를 지운다.

## 자주하는 오개념
- `codex mcp list` 성공 ≠ Editor 도구가 호출됨.
- CLI `unity command` 성공 ≠ Codex MCP 실행 성공.
- Editor `eval`로 만든 결과 ≠ 주어진 MCP 도구의 안전성이 확인됨.
- Play Mode 회전 확인 ≠ 씬 저장이 보장됨.
