# AGENTS.md에 추가할 수 있는 Day71 실습 규칙 예시

## Unity Editor MCP tool call policy
- 사전 읽기: `AGENTS.md`, Git 변경 파일, 현재 Unity Editor/Scene/Project 식별 정보를 확인한다.
- 등록 여부와 실제 도구 응답을 구분한다. 도구 ID/매개변수는 실제 연결된 MCP 서버가 제공한 스키마를 따른다.
- 기본은 읽기 전용. 새 Scene 작성, Asset/Prefab 생성·수정, Play Mode 진입은 별도의 승인 단계로 둔다.
- 실습 쓰기 허용 범위: `Assets/Day71_EditorToolLab/` 내부의 새 자산만. 다른 경로를 변경하기 전 별도 승인.
- 기존 미커밋 변경·씬은 사용자 동의 없이 초기화, 덮어쓰기, 정리, 커밋, 푸시하지 않는다.
- 각 단계 뒤 Editor 상태를 재조회해 도구 결과와 일치하는지 확인한다.
- 테스트 결과는 PASS / FAIL / NOT RUN으로 분리하고 증거와 실제 변경 파일을 보고한다.
