# Unity Editor 도구 호출 오류 분류

| 코드 | 증상 | 확인 순서 | 주의 |
|---|---|---|---|
| E01 | Unity MCP 도구 목록 미노출 | `codex mcp list` → Unity Editor/Pipeline 실행 → Codex 세션 | 임의 도구명 생성 금지 |
| E02 | 대상 Scene이 다름 | 프로젝트 경로 → Unity version → 활성 Scene 조회 | 다른 프로젝트 변경 금지 |
| E03 | create_gameobject 실패 | 실제 도구 인수 스키마 → Scene Dirty → Console | 기존 Scene 덮어쓰기 금지 |
| E04 | 같은 이름 Cube 2개 | Hierarchy 객체 이름/경로 재조회 | 대량 삭제 금지 |
| E05 | Day71SpinCube 추가 실패 | `.cs` 파일 위치 → 컴파일 Error → MonoBehaviour 여부 | 컴파일 실패 상태에서 시도 금지 |
| E06 | Scene Save 실패 | 쓰기 권한 → 경로 → Dirty → 파일 잠금 | 다른 씬에 저장 금지 |
| E07 | Play Mode에서 회전 안 됨 | 스크립트 Enabled → Console → Time.timeScale | 저장 여부 별도 검사 |
| E08 | CLI 성공, MCP 실패 | Codex config, sandbox localhost, 토큰/세션 | 보안을 전면 해제하지 않음 |

## 오류 대응 원칙
1. **실제 도구 응답**과 Console의 원문에서 민감 정보를 제거해 기록한다.
2. 실패 단계의 바로 전 상태로 복귀하고 변경 범위를 최소화한다.
3. 동일 QA를 재실행한 결과가 없으면 FAIL/NOT RUN을 유지한다.
