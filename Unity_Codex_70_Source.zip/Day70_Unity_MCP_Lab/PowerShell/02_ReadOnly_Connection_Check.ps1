# Day70 - Reads configuration status only; does not modify files.
# Console output can contain your project paths: review before sharing.
$ErrorActionPreference = 'Continue'
Write-Host '=== Day70 CLI / Pipeline / Codex MCP: READ ONLY ==='

function Check-Command([string] $name, [string[]] $arguments) {
    $command = Get-Command $name -ErrorAction SilentlyContinue
    if (-not $command) {
        Write-Host "$name : NOT FOUND - dependent tests NOT RUN"
        return
    }
    Write-Host "`n---- $name $($arguments -join ' ') ----"
    try {
        & $name @arguments
        Write-Host "ExitCode=$LASTEXITCODE"
    } catch {
        Write-Warning "Command failed: $($_.Exception.Message)"
    }
}

Check-Command 'unity' @('pipeline', 'list')
Check-Command 'unity' @('mcp', 'configure', '--list')
Check-Command 'codex' @('mcp', 'list')
Write-Host "`nDo not count a registered MCP server as verified Editor connectivity."
Write-Host 'Run an actual read-only Editor request through Codex (P4).'
