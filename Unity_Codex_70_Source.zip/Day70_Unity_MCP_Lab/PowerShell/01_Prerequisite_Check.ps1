# Day70 - Read-only command presence check. Does not install or modify settings.
$ErrorActionPreference = 'Continue'
Write-Host '=== Day70 Unity MCP prerequisite check (READ ONLY) ==='
foreach ($name in @('unity','codex','git')) {
    $found = Get-Command $name -ErrorAction SilentlyContinue
    if ($null -eq $found) {
        Write-Host "$name : NOT FOUND"
    } else {
        Write-Host "$name : FOUND"
        Write-Host "  Path: $($found.Source)"
    }
}
Write-Host 'Unity Editor should be open in the target project.'
Write-Host 'Next steps: run 02_ReadOnly_Connection_Check.ps1 only after verifying paths.'
Write-Host 'Important: no files were modified by this script.'
