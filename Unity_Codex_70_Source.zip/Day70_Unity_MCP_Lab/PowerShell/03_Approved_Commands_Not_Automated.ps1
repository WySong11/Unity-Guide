# COMMAND REFERENCE ONLY. This file deliberately performs NO installation or settings changes.
# Copy commands ONE BY ONE, after checking the target project and requesting approval.
#
# unity auth login
# unity pipeline install
# unity pipeline list
# unity mcp configure codex --dry-run
# unity mcp configure codex
# codex mcp list
#
# Optional, separate Unity Agent Plugin:
# codex plugin marketplace add Unity-Technologies/unity-agent-plugin
# codex plugin add unity@unity-agent-plugin
# codex plugin list
Write-Host 'No actions performed. Read this file and execute approved commands manually.'
