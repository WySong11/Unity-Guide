# UNITY × CODEX | 70일차 Unity MCP 설치 및 연결 검사

대상: Unity 6.3, Windows 11, VS Code Codex, Unity CLI 및 Unity Pipeline. 다른 운영체제에서는 쉘·경로만 조정합니다.

**중요 구분:** Unity CLI 설치, Pipeline 설치, Codex MCP 서버 등록, 실제 Editor 도구 호출은 서로 다른 검사입니다.
`codex mcp list`에 서버가 표시된 사실만으로 **연결 성공을 판정하지 않습니다.**

## 빠른 진행
1. 게임 프로젝트를 Git에 저장하고 **현재 `AGENTS.md`, `~/.codex/config.toml`**의 기존 정책을 확인합니다. 실제 토큰·비밀번호를 공개 자료에 복사하지 않습니다.
2. Unity 6.x 프로젝트를 Editor에서 열고 Console 컴파일 오류를 확인합니다.
3. PowerShell에서 `01_Prerequisite_Check.ps1`을 실행하여 사용 가능 명령과 환경을 관찰합니다. 스크립트는 설치·설정 파일을 변경하지 않습니다.
4. `unity auth login`은 필요할 때만 사용합니다. `unity pipeline list`로 Pipeline이 설치돼 있는지 확인합니다. 미설치 시 **별도 승인 후** `unity pipeline install`을 실행합니다.
5. `unity command`로 Editor 명령 목록을 확인합니다. 여러 Editor가 있다면 `--project-path`를 지정합니다.
6. `unity mcp configure --list`와 `unity mcp configure codex --dry-run` 출력 내용을 검사하고, 설정 백업·승인을 마친 후 `unity mcp configure codex`를 실행합니다. Codex 설정과 localhost 네트워크 정책이 수정될 수 있습니다.
7. Codex를 새 세션으로 시작하고 `codex mcp list`를 확인합니다. `Prompts/CODEX_PROMPTS.md`의 P4 읽기 전용 프롬프트로 **실제 Editor 씬 이름**을 요청합니다.
8. 쓰기 테스트는 읽기 성공 후 별도 승인을 받고 새 테스트 씬에서만 수행합니다. QA를 PASS / FAIL / NOT RUN으로 기록합니다.

## 권장 수업 자료
- `PowerShell/01_Prerequisite_Check.ps1`: CLI·Editor·MCP 등록 여부 **읽기 전용** 환경 검사.
- `PowerShell/02_ReadOnly_Connection_Check.ps1`: Pipeline·Unity 명령 목록·Codex 등록 확인. 값의 실제 인증정보는 출력하지 않도록 구성.
- `Editor/Day70ReadOnlyEditorProbe.cs`: Unity Editor 안에서 버전/씬/Hierarchy와 manifest 의존성을 출력하는 메뉴.
- `Editor/Day70OptionalSceneLab.cs`: 메뉴에서 학생 승인을 받은 뒤 새로운 테스트 씬 파일을 생성할 수 있는 선택 과제. 자동으로 실행되지 않음.
- `Prompts/CODEX_PROMPTS.md`: P0~P9 프롬프트.
- `Docs/TROUBLESHOOTING.md`: 계층별 오류 분류.
- `QA/QA_MATRIX.csv`, `QA/RUBRIC_100.csv`, `Templates/LAB_LOG.md`: 검증 및 평가.

## 기존 프로젝트와의 관계
이 패키지는 기존 `com.unity.pipeline`, `AGENTS.md`, Codex 설정, Scene 파일을 자동으로 수정하지 않습니다. `Editor/*.cs`는 선택적으로 **Assets/Editor/** 밑에 복사할 수 있습니다. 이미 같은 파일/메뉴가 있으면 비교 후 이름을 바꾸고 별도 복사하세요. `Day70OptionalSceneLab` 메뉴는 신규 폴더에서만 씬을 만듭니다.

실습 자료는 설계 및 문서 점검까지 확인한 예제입니다. **제작 환경에서 실제 Unity Editor에 연결하여 테스트한 것은 아닙니다.** 설치한 Unity CLI의 `--help`와 문서를 수업 전에 확인하세요.
