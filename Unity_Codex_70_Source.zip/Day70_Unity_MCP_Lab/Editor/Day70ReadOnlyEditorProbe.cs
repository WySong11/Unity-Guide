#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>Unity Editor-local diagnostic; does NOT test MCP protocol connectivity.</summary>
public static class Day70ReadOnlyEditorProbe
{
    [MenuItem("Tools/Day70 MCP/Read-only Editor Report")]
    public static void PrintReport()
    {
        Scene scene = SceneManager.GetActiveScene();
        string projectRoot = Directory.GetParent(Application.dataPath)?.FullName ?? "(unknown)";
        string manifest = Path.Combine(Application.dataPath, "../Packages/manifest.json");
        bool pipelineDeclared = false;
        try
        {
            pipelineDeclared = File.Exists(manifest) &&
                File.ReadAllText(manifest).Contains("com.unity.pipeline");
        }
        catch (Exception ex)
        {
            Debug.LogWarning("[Day70] manifest read error: " + ex.GetType().Name);
        }

        int rootCount = scene.IsValid() && scene.isLoaded
            ? scene.GetRootGameObjects().Length : 0;
        Debug.Log("[Day70] UnityVersion=" + Application.unityVersion);
        Debug.Log("[Day70] ActiveScene=" + scene.name + " IsLoaded=" + scene.isLoaded);
        Debug.Log("[Day70] SceneRootCount=" + rootCount);
        Debug.Log("[Day70] PipelineListedInManifest=" + pipelineDeclared);
        Debug.Log("[Day70] EditorCompiling=" + EditorApplication.isCompiling);
        Debug.Log("[Day70] ProjectPath(local only)=" + projectRoot);
        Debug.Log("[Day70] Report obtained INSIDE Editor; not proof of MCP connection.");
    }
}
#endif
