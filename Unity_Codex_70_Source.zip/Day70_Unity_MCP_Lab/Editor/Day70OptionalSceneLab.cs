#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

/// <summary>Optional manual test scene creation. Never runs automatically.</summary>
public static class Day70OptionalSceneLab
{
    [MenuItem("Tools/Day70 MCP/Create NEW Test Scene (Confirmation Required)")]
    private static void CreateTestScene()
    {
        if (!EditorUtility.DisplayDialog("Day70 optional lab",
                "Create a NEW test scene under Assets/Day70_MCP_Lab/Scenes?\n" +
                "This changes the project. Proceed only with permission.",
                "Create new scene", "Cancel")) return;

        const string folder = "Assets/Day70_MCP_Lab/Scenes";
        const string path = folder + "/Day70_MCP_TestScene.unity";
        if (File.Exists(path))
        {
            Debug.LogWarning("[Day70] Scene already exists. No overwrite: " + path);
            return;
        }
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        Directory.CreateDirectory(folder);
        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        cube.name = "Day70_MCP_Cube";
        cube.transform.position = Vector3.zero;
        EditorSceneManager.SaveScene(scene, path);
        AssetDatabase.Refresh();
        Debug.Log("[Day70] CREATED (manual approval): " + path);
        Debug.Log("[Day70] Review Git diff and delete lab asset only after your own review.");
    }
}
#endif
