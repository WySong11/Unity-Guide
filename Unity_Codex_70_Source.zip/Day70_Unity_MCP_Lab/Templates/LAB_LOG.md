# 70일차 실습 로그 (실측값만 기입)

- 실습 날짜:
- Unity 버전:
- Windows PowerShell 버전:
- Unity CLI 실행 경로(발표용은 마스킹):
- Codex 버전·플러그인 설치 여부:
- 대상 Unity 프로젝트/Scene:
- 연결된 MCP 서버 항목 이름:
- `unity pipeline list` 결과:
- `codex mcp list` 결과:
- 실제 MCP 호출에 사용한 도구:
- 실제 Editor에서 반환된 Scene 이름:
- Editor 화면과 일치 여부:
- 설정 변경·승인·백업 경로(발표용은 마스킹):
- QA 실패/NOT RUN 항목 및 원인:
- 복구/원복 방법:
- 최종 판정: [ ] PASS [ ] FAIL [ ] NOT RUN

증거는 스크린샷·로컬 로그의 해당 부분만 첨부하며, API 키 및 개인 경로를 공개 문서에 포함하지 않습니다.
