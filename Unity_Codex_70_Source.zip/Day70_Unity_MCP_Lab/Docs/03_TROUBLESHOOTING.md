# 오류 해결: 계층별 진단

| 실패 계층 | 증상 | 우선 검사 | 조치·재검증 |
|---|---|---|---|
| CLI | `unity` command not found | Get-Command unity, 새 PowerShell | Hub/CLI 설치, PATH 확인 → `unity --help` |
| Unity Editor | Running 0 또는 잘못된 프로젝트 | `unity editors running` | 대상 프로젝트 Editor 실행, 경로 확인 |
| 인증 | auth/license 실패 | `unity auth login` 흐름/오류 메시지 | 정상 로그인·정책 확인; 토큰 공유 금지 |
| Pipeline | Installed 안 보임 | `unity pipeline list` 및 Console | 승인 후 `unity pipeline install`, 재컴파일 기다린 뒤 재검사 |
| Pipeline 접근 | 명령 목록 안 보임 | `unity command`; 여러 Editor | `--project-path` 설정, Editor 재확인 |
| MCP 등록 | `codex mcp list`에 Unity 없음 | `unity mcp configure --list`, `--dry-run` | 기존 config 백업 후 등록, Codex 새 세션 |
| localhost | CLI는 연결, Codex는 실패 | 네트워크 sandbox·proxy·firewall | 과도한 권한 부여 없이 필요한 로컬 정책만 승인 후 수정 |
| 계정/권한 | 승인 거절, readonly | 현재 approval/sandbox 정책 | 실제 권한과 작업 목적에 맞는 명시적 승인 |
| 여러 Unity Editor | 다른 Scene을 보고함 | Editor 목록 및 절대 경로 | 대상 경로 명시하고 Read 호출 재검증 |
| 설정 손상 | config.toml 파싱 실패 | 변경 전 백업과 Diff | 설정 전체 초기화 금지, 최소 항목만 수정 |

## 4단계 증거 사다리
1. `unity --help` 성공 = CLI가 실행됨.
2. `unity pipeline list` Installed = 해당 프로젝트가 Pipeline을 갖춤.
3. `codex mcp list` Unity 등록 = **구성 목록에 있음**.
4. Codex가 MCP 도구를 사용하여 실제 활성 Scene을 조회하고 Editor 정보와 일치 = **실제 연결 확인**.

## 점검 보고 규칙
실제로 관찰한 출력만 PASS. 실패는 FAIL. 테스트하지 못했으면 NOT RUN. 오류 로그에서 비밀번호·토큰·개인정보를 삭제 후 공유합니다.
