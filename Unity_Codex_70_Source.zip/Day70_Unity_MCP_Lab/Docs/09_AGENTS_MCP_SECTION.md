## Unity CLI / MCP 작업 규칙 (AGENTS.md에 검토 후 병합)

- 작업 시작 시 `AGENTS.md`, Unity 버전, 대상 프로젝트 경로, 기존 MCP 서버와 연결 상태를 확인한다.
- 기존 Unity 씬, Package Manifest, Codex config.toml, 사용자 환경설정 파일을 **승인 없이 수정하지 않는다**.
- Unity CLI·MCP 설치·등록 전에 변경 범위와 되돌리기 계획을 보고하고 승인을 요청한다.
- Unity 프로젝트가 둘 이상 열렸을 때는 절대 경로로 대상 프로젝트를 명시한다.
- MCP 서버 목록에 나타난 사실만으로 연결 성공을 보고하지 않는다.
- 먼저 Editor를 읽기 전용으로 조회하고 실제 Scene·버전 등 반환 데이터를 기록한다.
- Unity Agent Plugin과 Unity CLI MCP 서버를 구분한다.
- 사용자가 승인한 테스트 씬 외의 Unity Scene·Prefab·Asset에는 쓰지 않는다.
- 민감한 토큰, 비밀번호, 타인의 데이터, 환경 설정 전체 텍스트를 출력·커밋·외부 전송하지 않는다.
- `unity mcp configure codex`의 샌드박스 네트워크 정책 변경은 사전 승인 대상으로 기록한다.
- 도구 오류·컴파일 오류·실패한 테스트는 숨기지 않는다. PASS/FAIL/NOT RUN 및 증거를 남긴다.
