# 학생 워크시트 · 70일차

1. 본인 Unity 프로젝트 버전과 경로(공유본에서는 마스킹): ____________
2. Unity CLI 설치 여부: [ ] PASS [ ] FAIL [ ] NOT RUN / 근거: ______
3. Unity Pipeline Installed: [ ] PASS [ ] FAIL [ ] NOT RUN / 근거: ______
4. `unity command`가 응답한 Editor 프로젝트: ____________
5. `unity mcp configure codex --dry-run`의 변경점 2가지: ____________
6. 설정 백업 위치 (Git이 아닌 안전한 개인 저장 위치): ____________
7. `codex mcp list`에 Unity 서버 표시: ____________
8. MCP 도구로 실제 조회한 활성 Scene 이름: ____________
9. 에디터 화면의 실제 Scene 이름과 일치 여부: ____________
10. 가장 큰 위험 2개(샌드박스·다중 Editor·토큰 등)와 완화 방법: ____________
11. QA01~QA12 중 FAIL 또는 NOT RUN 원인과 후속 행동: ____________
12. 설치 후 실제로 수정된 파일 목록·Git Diff: ____________

제출: QA Matrix, 필요한 스크린샷(민감값 제거), LAB_LOG, Codex의 도구 호출 기록, 최종 보고서.
