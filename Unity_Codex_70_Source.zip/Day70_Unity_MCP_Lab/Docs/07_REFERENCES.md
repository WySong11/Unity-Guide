# 공식 참고 자료 (2026-10-27 확인)

- Unity CLI 소개: https://docs.unity.com/en-us/unity-cli
- Unity CLI 사용법: https://docs.unity.com/en-us/unity-cli/use-unity-cli
- Unity Pipeline 설치: https://docs.unity.com/en-us/unity-cli/unity-pipeline/unity-pipeline-package
- 인에디터 MCP 서버를 CLI로 대체: https://docs.unity.com/en-us/unity-cli/replace-mcp-server-unity-cli
- Unity CLI 고급 MCP configure 옵션: https://github.com/Unity-Technologies/unity-agent-plugin/blob/main/skills/unity-cli/references/integration-advanced.md
- Unity Agent Plugin: https://github.com/Unity-Technologies/unity-agent-plugin
- Codex CLI MCP 명령: https://learn.chatgpt.com/docs/cli/reference

Unity CLI는 실험적(Experimental) 기능으로, 설치 방법과 플래그는 변할 수 있습니다. 반드시 설치된 버전의 `--help`와 최신 공식 문서를 참조하세요.
