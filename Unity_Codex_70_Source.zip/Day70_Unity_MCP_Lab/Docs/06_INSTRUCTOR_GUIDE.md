# 강사용 진행 가이드

- 실습 시작 전에 테스트용 Unity 6.3 프로젝트와 PowerShell을 준비합니다.
- Unity CLI와 Pipeline이 이미 설치된 수강생도 있으므로 **현황 조회 후 필요한 부분만 수행**합니다.
- VS Code Codex와 Unity MCP 등록 대상 설정이 다른지 확인하고, `codex mcp list`와 VS Code 세션을 비교합니다.
- 플러그인과 MCP를 혼동하지 않도록 별도로 칠판에 표시합니다.
- `unity mcp configure codex`가 sandbox localhost 정책을 변경할 수 있다는 사실을 반드시 시연 전에 알려주세요.
- Read-only 검사를 첫 성공 기준으로 하고, 쓰기 테스트는 **교사 승인이 내려진 팀만** 새로운 테스트 씬에서 수행합니다.
- `Assets/Editor/Day70ReadOnlyEditorProbe.cs`는 Unity Editor 내에서 연결 대상 씬을 확인하는 보조용이며, MCP 연결 검증을 대신하지 않습니다.
- 테스트 로그에 API 키나 사용자 경로가 있을 수 있으므로 발표용 자료는 마스킹 후 제출하도록 합니다.
- 평가: CLI·환경 20점, Pipeline 25점, MCP 설정 25점, 도구 실호출 20점, 보안·보고 10점.

### 교사 예상 질문
Q. Unity Agent Plugin과 MCP가 같은가요? A. 아닙니다. Plugin은 Unity 지식/스킬 묶음이고, Unity CLI MCP는 실제 Editor 명령을 노출하는 연결 방식입니다.
Q. `codex mcp list`에 있으면 완료인가요? A. 아닙니다. 해당 서버를 통해 실제 Editor 읽기 호출까지 성공해야 합니다.
Q. 연결용으로 모든 네트워크를 허용해야 하나요? A. 필요한 로컬호스트 접근만 검토하며, 보안 정책 전체 해제는 권장하지 않습니다.
