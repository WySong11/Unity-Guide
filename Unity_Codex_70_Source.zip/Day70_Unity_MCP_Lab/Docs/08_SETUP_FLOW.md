# Unity CLI MCP 연결 흐름도

```mermaid
flowchart TD
 A[Unity 6 Editor 실행] --> B{CLI 실행됨?}
 B -->|아니요| C[공식 방법으로 CLI 설치]
 B -->|예| D[Pipeline 설치 여부 확인]
 C --> D
 D --> E{Pipeline Installed?}
 E -->|아니요| F[승인 후 unity pipeline install]
 E -->|예| G[unity command 목록 확인]
 F --> G
 G --> H[unity mcp configure codex --dry-run]
 H --> I[설정 백업 및 승인]
 I --> J[unity mcp configure codex]
 J --> K[codex mcp list]
 K --> L[Codex에서 Editor 읽기 호출]
 L --> M{실제 씬 정보 일치?}
 M -->|예| N[QA PASS 및 로그 제출]
 M -->|아니요| O[계층별 문제 분리 후 재검증]
```

주의: 서버 등록은 연결의 일부이며, 실제 Editor 도구 응답까지 확인해야 합니다.
