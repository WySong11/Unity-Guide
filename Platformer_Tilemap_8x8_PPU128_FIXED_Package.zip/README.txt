Unity 6 Platformer Tilemap Sprite Sheet (fixed grid)

Source art: previous generated 1254x1254 platformer atlas.
This file was rebuilt by cutting each of the 64 original art cells and resizing them to exactly 128x128px.
The source's dark background was color-keyed to alpha; small artifacts or inset gaps may remain.
This is a grid-corrected illustration set, not a verified seamlessly connecting 47-mask AutoTile set.

Texture Type: Sprite (2D and UI)
Sprite Mode: Multiple
Pixels Per Unit: 128
Mesh Type: Full Rect
Filter Mode: Point (no filter) or Bilinear for smooth art
Compression: None
Alpha Is Transparency: On
Generate Mip Maps: Off

Sprite Editor > Slice > Grid By Cell Size
Pixel Size: 128 x 128
Offset: 0, 0
Padding: 0, 0
Pivot: Center
Apply.

The main PNG has dimensions 1024x1024, with 64 slots.
The transparent PNG can be used in the 2D Tile Palette.
For a seamless fully connected Rule Tile use a specially authored Rule Tile sprite atlas.
