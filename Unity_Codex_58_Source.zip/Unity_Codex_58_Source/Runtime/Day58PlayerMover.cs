using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(CharacterController))]
public sealed class Day58PlayerMover : MonoBehaviour
{
    [Min(0f)] [SerializeField] private float moveSpeed = 4.5f;
    [SerializeField] private float gravity = -18f;
    private CharacterController character;
    private Vector3 moveInput;
    private Vector3 dashDirection;
    private float dashSpeed;
    private float dashEnd;
    private float verticalSpeed;

    public bool IsDashing => Time.time < dashEnd;
    public bool CanDash => isActiveAndEnabled && character != null && character.enabled && !IsDashing;

    private void Awake() => character = GetComponent<CharacterController>();

    public bool BeginDash(float speed, float duration)
    {
        if (!CanDash || duration <= 0f || speed <= 0f) return false;
        dashDirection = moveInput.sqrMagnitude > 0.01f ? moveInput.normalized : transform.forward;
        dashDirection.y = 0f;
        if (dashDirection.sqrMagnitude < 0.001f) dashDirection = Vector3.forward;
        dashDirection.Normalize();
        dashSpeed = speed;
        dashEnd = Time.time + duration;
        transform.rotation = Quaternion.LookRotation(dashDirection);
        return true;
    }

    private void Update()
    {
        if (character == null || !character.enabled || Time.timeScale <= 0f) return;
        var k = Keyboard.current;
        float horizontal = k == null ? 0f : (k.dKey.isPressed ? 1f : 0f) - (k.aKey.isPressed ? 1f : 0f);
        float vertical = k == null ? 0f : (k.wKey.isPressed ? 1f : 0f) - (k.sKey.isPressed ? 1f : 0f);
        moveInput = Vector3.ClampMagnitude(new Vector3(horizontal, 0f, vertical), 1f);
        Vector3 velocity = IsDashing ? dashDirection * dashSpeed : moveInput * moveSpeed;
        if (!IsDashing && moveInput.sqrMagnitude > 0.01f)
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(moveInput), 12f * Time.deltaTime);
        if (character.isGrounded && verticalSpeed < 0f) verticalSpeed = -1f;
        verticalSpeed += gravity * Time.deltaTime;
        velocity.y = verticalSpeed;
        character.Move(velocity * Time.deltaTime);
    }
}
