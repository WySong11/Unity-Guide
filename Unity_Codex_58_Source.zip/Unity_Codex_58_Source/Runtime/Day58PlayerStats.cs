using System;
using UnityEngine;

public sealed class Day58PlayerStats : MonoBehaviour
{
    [Min(1f)] [SerializeField] private float maxHealth = 100f;
    [Min(0f)] [SerializeField] private float maxMana = 100f;
    private float currentHealth;
    private float currentMana;

    public event Action Changed;
    public float Health => currentHealth;
    public float Mana => currentMana;
    public float MaxHealth => Mathf.Max(1f, maxHealth);
    public float MaxMana => Mathf.Max(0f, maxMana);
    public bool IsAlive => currentHealth > 0f;
    public bool CanHeal => IsAlive && currentHealth < MaxHealth;

    private void Awake() => ResetResources();

    public void ResetResources()
    {
        currentHealth = MaxHealth;
        currentMana = MaxMana;
        Changed?.Invoke();
    }

    public bool CanSpend(float amount) => IsAlive && amount >= 0f && currentMana >= amount;

    public bool Spend(float amount)
    {
        if (!CanSpend(amount)) return false;
        currentMana = Mathf.Max(0f, currentMana - amount);
        Changed?.Invoke();
        return true;
    }

    public bool Heal(float amount)
    {
        if (!CanHeal || amount <= 0f) return false;
        currentHealth = Mathf.Min(MaxHealth, currentHealth + amount);
        Changed?.Invoke();
        return true;
    }

    public void TakeDamage(float amount)
    {
        if (!IsAlive || amount <= 0f) return;
        currentHealth = Mathf.Max(0f, currentHealth - amount);
        Changed?.Invoke();
    }

    public void RefillMana()
    {
        currentMana = MaxMana;
        Changed?.Invoke();
    }
}
