using UnityEngine;

public sealed class Day58TargetDummy : MonoBehaviour, IDay58Damageable
{
    [Min(1f)] [SerializeField] private float maxHealth = 60f;
    [Min(0f)] [SerializeField] private float respawnDelay = 2f;
    private float health;
    private float resetAt;
    private Renderer targetRenderer;
    private Color normalColor;

    private void Awake()
    {
        health = maxHealth;
        targetRenderer = GetComponentInChildren<Renderer>();
        if (targetRenderer != null) normalColor = targetRenderer.material.color;
    }

    public void TakeDamage(float damage)
    {
        if (health <= 0f || damage <= 0f) return;
        health = Mathf.Max(0f, health - damage);
        Debug.Log($"[Day58 Dummy] {name}: {health:0}/{maxHealth:0} HP");
        if (health <= 0f)
        {
            resetAt = Time.time + respawnDelay;
            if (targetRenderer != null) targetRenderer.material.color = Color.gray;
        }
        else if (targetRenderer != null) targetRenderer.material.color = Color.yellow;
    }

    private void Update()
    {
        if (health > 0f || Time.time < resetAt) return;
        health = maxHealth;
        if (targetRenderer != null) targetRenderer.material.color = normalColor;
    }
}
