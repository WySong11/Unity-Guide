using System.Collections;
using UnityEngine;

public sealed class Day58SkillController : MonoBehaviour
{
    [SerializeField] private Day58SkillData[] skills = new Day58SkillData[3];
    [SerializeField] private Day58PlayerStats stats;
    [SerializeField] private Day58PlayerMover mover;
    [SerializeField] private Day58ProjectilePool projectilePool;
    [SerializeField] private Transform firePoint;

    private float[] cooldownEnd = new float[0];
    private Coroutine activeCast;
    private bool isCasting;
    public int SlotCount => skills != null ? skills.Length : 0;
    public bool IsCasting => isCasting;
    public Day58SkillData SkillAt(int slot) => slot >= 0 && slot < SlotCount ? skills[slot] : null;

    private void Awake()
    {
        if (stats == null) stats = GetComponent<Day58PlayerStats>();
        if (mover == null) mover = GetComponent<Day58PlayerMover>();
        cooldownEnd = new float[SlotCount];
    }

    public float Remaining(int slot)
    {
        if (slot < 0 || slot >= cooldownEnd.Length) return 0f;
        return Mathf.Max(0f, cooldownEnd[slot] - Time.time);
    }
    public bool IsReady(int slot) => slot >= 0 && slot < SlotCount && Remaining(slot) <= 0f;

    public bool TryUseSlot(int slot)
    {
        if (!isActiveAndEnabled || Time.timeScale <= 0f || isCasting || stats == null || !stats.IsAlive)
            return false;
        Day58SkillData skill = SkillAt(slot);
        if (skill == null || !IsReady(slot) || !stats.CanSpend(skill.ManaCost) || !CanExecute(skill))
            return false;
        // Validation completed: resources and cooldown are committed once at cast START.
        if (!stats.Spend(skill.ManaCost)) return false;
        cooldownEnd[slot] = Time.time + skill.Cooldown;
        Execute(skill);
        return true;
    }

    private bool CanExecute(Day58SkillData skill)
    {
        switch (skill.Kind)
        {
            case Day58SkillKind.Projectile:
                return projectilePool != null && projectilePool.IsConfigured && firePoint != null;
            case Day58SkillKind.Heal:
                return stats != null && stats.CanHeal && skill.Power > 0f;
            case Day58SkillKind.Dash:
                return mover != null && mover.CanDash;
            default:
                return false;
        }
    }

    private void Execute(Day58SkillData skill)
    {
        switch (skill.Kind)
        {
            case Day58SkillKind.Projectile:
                if (skill.CastDelay > 0f) activeCast = StartCoroutine(CastProjectile(skill));
                else Shoot(skill);
                break;
            case Day58SkillKind.Heal:
                stats.Heal(skill.Power);
                break;
            case Day58SkillKind.Dash:
                mover.BeginDash(skill.DashSpeed, skill.DashDuration);
                break;
        }
    }

    private IEnumerator CastProjectile(Day58SkillData skill)
    {
        isCasting = true;
        yield return new WaitForSeconds(skill.CastDelay);
        if (isActiveAndEnabled && stats != null && stats.IsAlive) Shoot(skill);
        isCasting = false;
        activeCast = null;
    }

    private void Shoot(Day58SkillData skill)
    {
        if (projectilePool != null && firePoint != null)
            projectilePool.Fire(skill, firePoint.position, firePoint.forward, gameObject);
    }

    private void OnDisable()
    {
        if (activeCast != null) StopCoroutine(activeCast);
        activeCast = null;
        isCasting = false;
        // No mana / cooldown refund when cast is cancelled (explicit lesson policy).
    }
}
