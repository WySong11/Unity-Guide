using UnityEngine;

// Runtime check only: does not claim a full Unity Play Mode test suite.
public sealed class Day58RuntimeAudit : MonoBehaviour
{
    [SerializeField] private Day58SkillController controller;
    [SerializeField] private Day58ProjectilePool projectilePool;
    private void Start()
    {
        if (controller == null || projectilePool == null)
            Debug.LogWarning("[Day58 Audit] Required references are missing.", this);
        else
        {
            for (int i = 0; i < controller.SlotCount; i++)
                if (controller.SkillAt(i) == null)
                    Debug.LogWarning($"[Day58 Audit] Missing SkillData in slot {i}.", this);
            Debug.Log("[Day58 Audit] References checked. Run T01~T12 manually for behavior.", this);
        }
    }
}
