using UnityEngine;

// Lightweight OnGUI HUD avoids TMP/UGUI setup for the standalone practice scene.
public sealed class Day58SkillHUD : MonoBehaviour
{
    [SerializeField] private Day58SkillController controller;
    [SerializeField] private Day58PlayerStats stats;

    private void OnGUI()
    {
        if (controller == null || stats == null) return;
        GUI.Box(new Rect(14, 14, 315, 218), "DAY 58 | SKILLS & COOLDOWN");
        GUI.Label(new Rect(28, 42, 286, 24), $"HP {stats.Health:0}/{stats.MaxHealth:0}     Mana {stats.Mana:0}/{stats.MaxMana:0}");
        for (int slot = 0; slot < Mathf.Min(3, controller.SlotCount); slot++)
        {
            Day58SkillData data = controller.SkillAt(slot);
            if (data == null) continue;
            float remain = controller.Remaining(slot);
            string status = remain > 0f ? $"{remain:0.0}s" : "READY";
            GUI.Label(new Rect(28, 70 + slot * 42, 245, 20),
                $"{slot + 1}: {data.DisplayName}  Mana {data.ManaCost:0}  [{status}]");
            if (GUI.Button(new Rect(263, 69 + slot * 42, 52, 23), "USE")) controller.TryUseSlot(slot);
            float progress = data.Cooldown > 0f ? Mathf.Clamp01(1f - remain / data.Cooldown) : 1f;
            GUI.Box(new Rect(29, 91 + slot * 42, 272, 5), GUIContent.none);
            GUI.Box(new Rect(29, 91 + slot * 42, 272 * progress, 5), GUIContent.none);
        }
        GUI.Box(new Rect(14, 240, 390, 70), "CONTROLS");
        GUI.Label(new Rect(25, 264, 365, 35), "WASD Move | 1 Fireball | 2 Heal | 3 Dash\nH Damage | M Mana | R Reset | P Pause");
    }
}
