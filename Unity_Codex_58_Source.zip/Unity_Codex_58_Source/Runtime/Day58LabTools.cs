using UnityEngine;
using UnityEngine.InputSystem;

public sealed class Day58LabTools : MonoBehaviour
{
    [SerializeField] private Day58PlayerStats stats;
    private void Awake() { if (stats == null) stats = GetComponent<Day58PlayerStats>(); }
    private void Update()
    {
        var k = Keyboard.current;
        if (k == null || stats == null) return;
        if (k.hKey.wasPressedThisFrame) stats.TakeDamage(40f);
        if (k.mKey.wasPressedThisFrame) stats.RefillMana();
        if (k.rKey.wasPressedThisFrame) stats.ResetResources();
        if (k.pKey.wasPressedThisFrame) Time.timeScale = Time.timeScale > 0f ? 0f : 1f;
    }
    private void OnDisable() { Time.timeScale = 1f; }
}
