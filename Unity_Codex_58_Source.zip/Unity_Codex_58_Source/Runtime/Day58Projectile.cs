using System;
using UnityEngine;

// Swept Raycast to reduce high-speed tunnelling. The visual prefab needs no collider.
public sealed class Day58Projectile : MonoBehaviour
{
    private Action<Day58Projectile> returnAction;
    private Vector3 direction;
    private float speed;
    private float power;
    private float lifetime;
    private float elapsed;
    private GameObject owner;
    private bool flying;

    public void BindReturn(Action<Day58Projectile> callback) => returnAction = callback;

    public void Launch(Vector3 position, Vector3 forward, float damage, float moveSpeed, float life, GameObject instigator)
    {
        transform.position = position;
        direction = forward.sqrMagnitude > 0.0001f ? forward.normalized : Vector3.forward;
        transform.rotation = Quaternion.LookRotation(direction);
        speed = Mathf.Max(0f, moveSpeed);
        power = Mathf.Max(0f, damage);
        lifetime = Mathf.Max(0.01f, life);
        elapsed = 0f;
        owner = instigator;
        flying = true;
    }

    private void Update()
    {
        if (!flying) return;
        float travel = speed * Time.deltaTime;
        if (travel > 0f)
        {
            // Ignore Raycast layer is excluded, so builder's player never blocks its own projectile.
            if (Physics.Raycast(transform.position, direction, out RaycastHit hit, travel,
                ~(1 << 2), QueryTriggerInteraction.Ignore))
            {
                if (owner == null || hit.collider.transform.root != owner.transform.root)
                {
                    var behaviours = hit.collider.GetComponentsInParent<MonoBehaviour>();
                    foreach (MonoBehaviour b in behaviours)
                        if (b is IDay58Damageable receiver) { receiver.TakeDamage(power); break; }
                    ReturnToPool();
                    return;
                }
            }
            transform.position += direction * travel;
        }
        elapsed += Time.deltaTime;
        if (elapsed >= lifetime) ReturnToPool();
    }

    public void ReturnToPool()
    {
        if (!flying) return;
        flying = false; // Hit + timeout cannot release twice.
        owner = null;
        if (returnAction != null) returnAction(this);
        else gameObject.SetActive(false);
    }
}

public interface IDay58Damageable { void TakeDamage(float damage); }
