using UnityEngine;
using UnityEngine.InputSystem;

// New Input System: class uses Keyboard for a standalone lab; UI buttons can call TryUseSlot too.
public sealed class Day58SkillInput : MonoBehaviour
{
    [SerializeField] private Day58SkillController controller;
    private void Awake()
    {
        if (controller == null) controller = GetComponent<Day58SkillController>();
    }
    private void Update()
    {
        if (controller == null || Keyboard.current == null) return;
        if (Keyboard.current.digit1Key.wasPressedThisFrame) controller.TryUseSlot(0);
        if (Keyboard.current.digit2Key.wasPressedThisFrame) controller.TryUseSlot(1);
        if (Keyboard.current.digit3Key.wasPressedThisFrame) controller.TryUseSlot(2);
    }
}
