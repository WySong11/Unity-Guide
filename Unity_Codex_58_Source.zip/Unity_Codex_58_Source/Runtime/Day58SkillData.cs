using UnityEngine;

public enum Day58SkillKind { Projectile, Heal, Dash }

// Shared configuration asset; never store remaining cooldown or player HP here.
[CreateAssetMenu(fileName = "Skill_New", menuName = "Day58/Skill Data")]
public sealed class Day58SkillData : ScriptableObject
{
    [SerializeField] private string displayName = "New Skill";
    [SerializeField] private Day58SkillKind skillKind;
    [Min(0f)] [SerializeField] private float cooldown = 2f;
    [Min(0f)] [SerializeField] private float manaCost = 10f;
    [Min(0f)] [SerializeField] private float power = 20f;
    [Min(0f)] [SerializeField] private float castDelay = 0.15f;
    [Min(0.01f)] [SerializeField] private float projectileSpeed = 15f;
    [Min(0.01f)] [SerializeField] private float projectileLifetime = 3f;
    [Min(0.01f)] [SerializeField] private float dashSpeed = 12f;
    [Min(0.01f)] [SerializeField] private float dashDuration = 0.18f;

    public string DisplayName => displayName;
    public Day58SkillKind Kind => skillKind;
    public float Cooldown => Mathf.Max(0f, cooldown);
    public float ManaCost => Mathf.Max(0f, manaCost);
    public float Power => Mathf.Max(0f, power);
    public float CastDelay => Mathf.Max(0f, castDelay);
    public float ProjectileSpeed => Mathf.Max(0.01f, projectileSpeed);
    public float ProjectileLifetime => Mathf.Max(0.01f, projectileLifetime);
    public float DashSpeed => Mathf.Max(0.01f, dashSpeed);
    public float DashDuration => Mathf.Max(0.01f, dashDuration);
}
