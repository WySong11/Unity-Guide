using UnityEngine;
using UnityEngine.Pool;

public sealed class Day58ProjectilePool : MonoBehaviour
{
    [SerializeField] private Day58Projectile prefab;
    [Min(0)] [SerializeField] private int prewarmCount = 8;
    [Min(1)] [SerializeField] private int maxInactive = 32;
    private ObjectPool<Day58Projectile> pool;
    public bool IsConfigured => prefab != null && pool != null;
    public int CountActive => pool != null ? pool.CountActive : 0;
    public int CountInactive => pool != null ? pool.CountInactive : 0;

    private void Awake()
    {
        if (prefab == null) { Debug.LogError("[Day58] Projectile prefab is missing.", this); return; }
        pool = new ObjectPool<Day58Projectile>(
            CreateProjectile,
            projectile => projectile.gameObject.SetActive(true),
            projectile => projectile.gameObject.SetActive(false),
            projectile => { if (projectile != null) Destroy(projectile.gameObject); },
            collectionCheck: true,
            defaultCapacity: Mathf.Max(1, prewarmCount),
            maxSize: Mathf.Max(1, maxInactive));
        int capacity = Mathf.Min(prewarmCount, Mathf.Max(1, maxInactive));
        var reserved = new Day58Projectile[capacity];
        for (int i = 0; i < capacity; i++) reserved[i] = pool.Get();
        for (int i = 0; i < capacity; i++) pool.Release(reserved[i]);
    }

    private Day58Projectile CreateProjectile()
    {
        Day58Projectile projectile = Instantiate(prefab, transform);
        projectile.BindReturn(ReturnProjectile);
        projectile.gameObject.SetActive(false);
        return projectile;
    }

    public bool Fire(Day58SkillData data, Vector3 origin, Vector3 forward, GameObject owner)
    {
        if (!IsConfigured || data == null) return false;
        var projectile = pool.Get();
        projectile.Launch(origin, forward, data.Power, data.ProjectileSpeed, data.ProjectileLifetime, owner);
        return true;
    }

    private void ReturnProjectile(Day58Projectile projectile)
    {
        if (pool != null && projectile != null) pool.Release(projectile);
    }

    private void OnDestroy()
    {
        if (pool != null) { pool.Dispose(); pool = null; }
    }
}
