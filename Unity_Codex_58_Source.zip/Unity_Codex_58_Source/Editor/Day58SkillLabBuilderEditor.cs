#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

// Safe project-scoped lab builder. Creates only new Day58_Skill_Lab[_N] folders.
public static class Day58SkillLabBuilderEditor
{
    [MenuItem("Tools/Day58 Skills/Create Independent Skill Lab")]
    private static void CreateLab()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        string root = FindNewFolder();
        string dataFolder = CreateSubfolder(root, "Data");
        string prefabFolder = CreateSubfolder(root, "Prefabs");
        string sceneFolder = CreateSubfolder(root, "Scenes");
        Day58SkillData fireball = CreateSkill(dataFolder, "Skill_Fireball", "Fireball",
            Day58SkillKind.Projectile, 2f, 10f, 20f, 0.15f, 15f, 3f, 12f, 0.18f);
        Day58SkillData heal = CreateSkill(dataFolder, "Skill_Heal", "Heal",
            Day58SkillKind.Heal, 5f, 15f, 30f, 0f, 15f, 3f, 12f, 0.18f);
        Day58SkillData dash = CreateSkill(dataFolder, "Skill_Dash", "Dash",
            Day58SkillKind.Dash, 4f, 20f, 0f, 0f, 15f, 3f, 12f, 0.18f);
        Day58Projectile projectile = CreateProjectilePrefab(prefabFolder);

        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        CreateFloor();
        CreateLightAndCamera();

        var poolObject = new GameObject("ProjectilePool");
        Day58ProjectilePool pool = poolObject.AddComponent<Day58ProjectilePool>();
        SetReference(pool, "prefab", projectile);

        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Player";
        player.layer = 2; // Built-in Ignore Raycast layer for the swept-ray projectile.
        player.transform.position = new Vector3(0f, 1f, 0f);
        Object.DestroyImmediate(player.GetComponent<CapsuleCollider>());
        CharacterController cc = player.AddComponent<CharacterController>();
        cc.height = 2f;
        cc.radius = 0.5f;
        cc.center = Vector3.zero;
        var body = player.GetComponent<Renderer>();
        if (body != null) body.sharedMaterial = CreateMaterial(dataFolder, "Mat_Player", new Color(0.2f, 0.55f, 1f));

        Day58PlayerStats stats = player.AddComponent<Day58PlayerStats>();
        Day58PlayerMover mover = player.AddComponent<Day58PlayerMover>();
        Day58SkillController controller = player.AddComponent<Day58SkillController>();
        player.AddComponent<Day58SkillInput>();
        player.AddComponent<Day58LabTools>();
        SetReference(player.GetComponent<Day58SkillInput>(), "controller", controller);
        SetReference(player.GetComponent<Day58LabTools>(), "stats", stats);
        SetReference(controller, "stats", stats);
        SetReference(controller, "mover", mover);
        SetReference(controller, "projectilePool", pool);

        GameObject firePoint = new GameObject("FirePoint");
        firePoint.transform.SetParent(player.transform, false);
        firePoint.transform.localPosition = new Vector3(0f, 0.35f, 0.95f);
        SetReference(controller, "firePoint", firePoint.transform);
        SerializedObject controllerSO = new SerializedObject(controller);
        SerializedProperty skills = controllerSO.FindProperty("skills");
        skills.arraySize = 3;
        skills.GetArrayElementAtIndex(0).objectReferenceValue = fireball;
        skills.GetArrayElementAtIndex(1).objectReferenceValue = heal;
        skills.GetArrayElementAtIndex(2).objectReferenceValue = dash;
        controllerSO.ApplyModifiedPropertiesWithoutUndo();

        var hudObject = new GameObject("HUD_And_Audit");
        Day58SkillHUD hud = hudObject.AddComponent<Day58SkillHUD>();
        Day58RuntimeAudit audit = hudObject.AddComponent<Day58RuntimeAudit>();
        SetReference(hud, "controller", controller);
        SetReference(hud, "stats", stats);
        SetReference(audit, "controller", controller);
        SetReference(audit, "projectilePool", pool);

        CreateDummy("Target_Center", new Vector3(0f, 1f, 8f), new Color(1f, 0.35f, 0.25f), dataFolder);
        CreateDummy("Target_Left", new Vector3(-3f, 1f, 8f), new Color(1f, 0.65f, 0.25f), dataFolder);
        CreateDummy("Target_Right", new Vector3(3f, 1f, 8f), new Color(0.9f, 0.25f, 0.55f), dataFolder);

        string path = sceneFolder + "/Day58_SkillLab.unity";
        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene, path);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<SceneAsset>(path));
        Debug.Log($"[Day58] Created {path}. Press Play. Controls: WASD, 1/2/3, H, M, R, P.");
    }

    private static string FindNewFolder()
    {
        const string parent = "Assets";
        const string prefix = "Day58_Skill_Lab";
        string name = prefix;
        int suffix = 1;
        while (AssetDatabase.IsValidFolder(parent + "/" + name)) name = prefix + "_" + suffix++;
        AssetDatabase.CreateFolder(parent, name);
        return parent + "/" + name;
    }

    private static string CreateSubfolder(string parent, string name)
    {
        AssetDatabase.CreateFolder(parent, name);
        return parent + "/" + name;
    }

    private static void SetReference(Object component, string field, Object value)
    {
        var serialized = new SerializedObject(component);
        SerializedProperty prop = serialized.FindProperty(field);
        if (prop == null) { Debug.LogError($"[Day58] Missing serialized field {field} on {component}"); return; }
        prop.objectReferenceValue = value;
        serialized.ApplyModifiedPropertiesWithoutUndo();
    }

    private static Day58SkillData CreateSkill(string path, string assetName, string displayName,
        Day58SkillKind kind, float cooldown, float mana, float power, float castDelay,
        float projectileSpeed, float projectileLife, float dashSpeed, float dashDuration)
    {
        var data = ScriptableObject.CreateInstance<Day58SkillData>();
        var serialized = new SerializedObject(data);
        serialized.FindProperty("displayName").stringValue = displayName;
        serialized.FindProperty("skillKind").enumValueIndex = (int)kind;
        serialized.FindProperty("cooldown").floatValue = cooldown;
        serialized.FindProperty("manaCost").floatValue = mana;
        serialized.FindProperty("power").floatValue = power;
        serialized.FindProperty("castDelay").floatValue = castDelay;
        serialized.FindProperty("projectileSpeed").floatValue = projectileSpeed;
        serialized.FindProperty("projectileLifetime").floatValue = projectileLife;
        serialized.FindProperty("dashSpeed").floatValue = dashSpeed;
        serialized.FindProperty("dashDuration").floatValue = dashDuration;
        serialized.ApplyModifiedPropertiesWithoutUndo();
        AssetDatabase.CreateAsset(data, path + "/" + assetName + ".asset");
        return data;
    }

    private static Day58Projectile CreateProjectilePrefab(string path)
    {
        GameObject temp = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        temp.name = "Projectile_Fireball";
        temp.transform.localScale = Vector3.one * 0.32f;
        Object.DestroyImmediate(temp.GetComponent<SphereCollider>());
        temp.GetComponent<Renderer>().sharedMaterial = CreateMaterial(path, "Mat_Fireball", new Color(1f, 0.4f, 0.07f));
        temp.AddComponent<Day58Projectile>();
        GameObject prefab = PrefabUtility.SaveAsPrefabAsset(temp, path + "/Projectile_Fireball.prefab");
        Object.DestroyImmediate(temp);
        return prefab.GetComponent<Day58Projectile>();
    }

    private static Material CreateMaterial(string path, string name, Color color)
    {
        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (shader == null) shader = Shader.Find("Standard");
        if (shader == null) shader = Shader.Find("Sprites/Default");
        Material material = new Material(shader);
        material.color = color;
        AssetDatabase.CreateAsset(material, path + "/" + name + ".mat");
        return material;
    }

    private static void CreateDummy(string name, Vector3 position, Color color, string materialsPath)
    {
        GameObject dummy = GameObject.CreatePrimitive(PrimitiveType.Cube);
        dummy.name = name;
        dummy.transform.position = position;
        dummy.transform.localScale = new Vector3(1.5f, 2f, 0.85f);
        dummy.GetComponent<Renderer>().sharedMaterial = CreateMaterial(materialsPath, "Mat_" + name, color);
        dummy.AddComponent<Day58TargetDummy>();
    }

    private static void CreateFloor()
    {
        GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
        floor.name = "Floor";
        floor.transform.position = new Vector3(0f, -0.25f, 3f);
        floor.transform.localScale = new Vector3(30f, 0.5f, 30f);
    }

    private static void CreateLightAndCamera()
    {
        GameObject lightObject = new GameObject("Directional Light");
        Light light = lightObject.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 1.2f;
        lightObject.transform.rotation = Quaternion.Euler(50f, -30f, 0f);
        GameObject cameraObject = new GameObject("Main Camera");
        cameraObject.tag = "MainCamera";
        Camera camera = cameraObject.AddComponent<Camera>();
        camera.clearFlags = CameraClearFlags.Skybox;
        cameraObject.transform.position = new Vector3(0f, 9f, -13f);
        cameraObject.transform.LookAt(new Vector3(0f, 1f, 4f));
    }
}
#endif
