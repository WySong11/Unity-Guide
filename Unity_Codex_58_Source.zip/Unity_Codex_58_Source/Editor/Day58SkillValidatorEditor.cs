#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

public static class Day58SkillValidatorEditor
{
    [MenuItem("Tools/Day58 Skills/Validate Open Skill Lab")]
    private static void Validate()
    {
        int issues = 0;
        Day58SkillController controller = Object.FindFirstObjectByType<Day58SkillController>();
        Day58PlayerStats stats = Object.FindFirstObjectByType<Day58PlayerStats>();
        Day58PlayerMover mover = Object.FindFirstObjectByType<Day58PlayerMover>();
        Day58ProjectilePool pool = Object.FindFirstObjectByType<Day58ProjectilePool>();
        Day58SkillHUD hud = Object.FindFirstObjectByType<Day58SkillHUD>();
        if (controller == null) { Debug.LogError("[Day58] Missing SkillController."); issues++; }
        if (stats == null) { Debug.LogError("[Day58] Missing PlayerStats."); issues++; }
        if (mover == null) { Debug.LogError("[Day58] Missing PlayerMover."); issues++; }
        if (pool == null) { Debug.LogError("[Day58] Missing ProjectilePool."); issues++; }
        if (hud == null) { Debug.LogError("[Day58] Missing SkillHUD."); issues++; }
        if (controller != null)
        {
            if (controller.SlotCount != 3) { Debug.LogWarning("[Day58] Expected 3 skill slots."); issues++; }
            for (int i = 0; i < controller.SlotCount; i++)
            {
                Day58SkillData data = controller.SkillAt(i);
                if (data == null) { Debug.LogError($"[Day58] Null SkillData in slot {i}."); issues++; continue; }
                if (data.Cooldown < 0f || data.ManaCost < 0f) { Debug.LogError("[Day58] Invalid values: " + data.name); issues++; }
            }
        }
        if (Object.FindObjectsByType<Day58TargetDummy>(FindObjectsSortMode.None).Length == 0)
        { Debug.LogWarning("[Day58] No target dummy in scene."); issues++; }
        Debug.Log(issues == 0 ? "[Day58] Static scene validation passed; run T01~T12 in Play Mode."
            : $"[Day58] Static scene validation found {issues} issue(s). Runtime behavior is NOT verified.");
    }
}
#endif
