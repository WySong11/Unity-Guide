# 58일차 학생 실습 워크시트

**학습 목표:** SkillData 3종과 Cooldown·Mana·Effect를 분리하고 3종 스킬을 오류 없이 재사용한다.

### 1. 구조 설명(10분)

1. SkillData와 SkillController의 책임을 각각 적어봅니다.
2. `cooldownEnd`를 SO 에셋에 저장하지 않는 이유를 설명합니다.
3. Heal을 Full HP에서 실패 처리해야 하는 근거를 설명합니다.

### 2. 데이터 설정(15분)

에디터 메뉴로 생성한 Fireball, Heal, Dash의 Cooldown/ManaCost/Power를 Inspector에서 확인합니다. Fireball 쿨타임을 2초에서 3초로 변경해 시연하고, 결과를 기록합니다.

### 3. 런타임 실습(45분)

- `1` 키: Projectile이 타깃을 맞추고 대미지가 20씩 감소하는지 확인합니다.
- `H` 후 `2`: 플레이어 HP가 60→90이 되는지, Mana가 100→85가 되는지 확인합니다.
- `3` 키: Dash가 0.18초 뒤 정상 종료하는지 확인합니다.
- `P`: Pause 상태에서 남은 Cooldown이 진행하지 않는지 확인합니다.
- `R`: HP/Mana를 초기화합니다. 주의: 예제의 `R`은 **쿨타임 리셋 기능이 아닙니다.**

### 4. 안전성 테스트(30분)

`Day58_Test_Checklist.csv`의 T01~T12를 실제 실행하여 통과/실패와 근거를 기록합니다. Test T10은 Fireball 캐스팅 동안 Player GameObject를 Disable하는 방식으로 확인할 수 있습니다.

### 5. Codex 리뷰 및 발표(20분)

`Day58_Codex_Prompts.md`의 프롬프트로 코드의 위험 요소를 분석하고, 정확한 수정 범위와 재현 테스트를 작성합니다.

**제출물:** Scene·SO 에셋 3개·코드·테스트 증거·Codex 리뷰 기록.
