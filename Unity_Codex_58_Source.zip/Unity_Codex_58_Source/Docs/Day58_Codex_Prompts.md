# Day58 Codex 지시 프롬프트

## 1. 정적 구조 리뷰

> Unity 6.3 + New Input System의 Day58SkillData, Day58SkillController, Day58PlayerStats, Day58ProjectilePool, Day58Projectile을 읽고 다음을 점검해줘. (1) 공유 SO 데이터의 런타임 변조 여부 (2) 3개 Slot별 독립 쿨타임 (3) 조건 실패 시 Mana·Cooldown 무변경 (4) 중복 Pool Release·참조 누수 위험 (5) 비활성화 시 시전 Coroutine 취소. 코드는 먼저 수정하지 말고 파일/라인/재현 조건/수정안/검증법으로 보고해줘.

## 2. 최소 수정

> 확인된 결함만 최소 범위로 수정해줘. 기존 Day55~57 스크립트는 변경하지 말고 Day58 파일만 수정해줘. AGENTS.md와 기존 코딩 규칙을 준수하고 변경 전/후 diff를 제시해줘. 스킬 데이터(SO)와 인스턴스 상태의 책임을 유지해줘.

## 3. Play Mode 테스트

> Unity Editor 실행 권한/도구 연결 여부부터 확인해줘. 실제 실행할 수 있으면 Day58 Test T01~T12를 수행하고 콘솔 로그·Inspector 변화·재현 스크린샷을 증거로 남겨줘. 실행할 수 없다면 컴파일 예상/정적 검사만 했다고 명시하고 ‘통과’라고 주장하지 마. T11은 scaled time 정책이 맞는지 확인해줘.

## 4. 확장 과제

> 3종 SkillData에 SkillType 하나를 추가할 때 SkillController의 수정량이 줄어들도록 IAbilityEffect 전략 객체로 분리하는 리팩터링 초안을 작성해줘. 현재 동작은 변경하지 말고 설계와 의존성 다이어그램만 먼저 보여줘.
