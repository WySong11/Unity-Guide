# 강사용 진행 노트 (120분)

| 시간 | 교수·학습 활동 | 핵심 질문 |
|---|---|---|
| 00~25분 | SO·MonoBehaviour·Slot Runtime·발동 순서 | “공유 설정에 현재 쿨타임을 저장하면?” |
| 25~55분 | SkillData 3종·마나·Cooldown 구현 | “마나 부족인데 CD를 시작하면?” |
| 55~100분 | Projectile·Heal·Dash와 Pool·HUD 연계 | “탄환 재사용 시 무엇을 초기화할까?” |
| 100~120분 | Pause·죽음·스킬 실패 등 검증, Codex 리뷰 | “관찰한 로그와 추측은 어떻게 구분할까?” |

## 빠른 시연 시나리오

- 시작: HP100/Mana100, Fireball1회 Mana90, 즉시 다시 누르면 추가 소비 없음.
- `H` → HP60, `2` Heal → HP90/Mana75 (이미 Fireball 비용10, Heal 비용15 반영됨).
- `R` → HP/Mana100, `2` 시도 → FullHP 때문에 거절. `R`은 기존 Cooldown을 초기화하지 않음.
- `3` Dash → Mana80(리셋 상태 기준), 정상 종료 확인.
- `P` Pause: `Time.time` 기반 CooldownRemaining 고정, `P` 다시 입력하면 재개.
- Projectile 재사용: 반복 발사 후 Pool CountInactive가 변하는 것과 더미 HP 변화를 비교.

## 주의

이 자료는 Unity Editor에서 자동 실행된 결과가 아니라 실행 가능한 예제와 검증 절차를 제공합니다. 버전/프로젝트 패키지/렌더 파이프라인에 따라 에디터 컴파일 및 Play Mode 검증이 필요합니다.
