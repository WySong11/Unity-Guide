# Unity × Codex | 58일차 스킬 및 쿨타임

Unity 6.3 / 3D URP 또는 3D / New Input System 기준의 독립 실습 패키지입니다.

## 설치 및 실행

1. ZIP의 `Runtime/*.cs`를 Unity 프로젝트의 `Assets/Scripts/Day58/` 폴더에 복사합니다.
2. `Editor/*.cs`를 반드시 `Assets/Editor/Day58/` 폴더에 복사합니다. (**Editor 스크립트가 Runtime 빌드에 포함되지 않아야 합니다.**)
3. Package Manager에서 `Input System`을 설치하고, `Project Settings > Player > Active Input Handling`을 `Input System Package (New)` 또는 `Both`로 설정합니다. 재시작 요청이 뜨면 재시작합니다.
4. 메뉴 `Tools > Day58 Skills > Create Independent Skill Lab`을 실행합니다. 현재 Scene의 저장 여부를 묻는 창이 나타날 수 있습니다.
5. 자동 생성된 `Assets/Day58_Skill_Lab[_N]/Scenes/Day58_SkillLab.unity` 씬에서 ▶ Play를 누릅니다.
6. `Tools > Day58 Skills > Validate Open Skill Lab`으로 필수 참조/에셋에 대한 정적 검사를 실행합니다.
7. `Docs/Day58_Test_Checklist.csv`의 T01~T12 Play Mode 테스트를 별도로 수행합니다.

> 안전성: 에디터 생성 메뉴는 `Day58_Skill_Lab` 폴더가 존재하면 `_1`, `_2` 등의 새 폴더를 만듭니다. 기존 Day57·Day56 프로젝트 파일을 덮어쓰지 않습니다.

## 조작

| 키 / 버튼 | 기능 |
|---|---|
| WASD | 3D 캐릭터 이동 |
| 1 / HUD USE | Fireball: Mana 10, CD 2초, Damage 20 |
| 2 / HUD USE | Heal: Mana 15, CD 5초, HP +30 |
| 3 / HUD USE | Dash: Mana 20, CD 4초, Speed 12, 0.18초 |
| H | 실습용 플레이어 피해 40 (Heal 확인) |
| M | 마나 100으로 회복 |
| R | HP·Mana 초기화 |
| P | Pause / Resume (`Time.timeScale` 토글) |

HUD는 Unity IMGUI(OnGUI)를 사용하며 TMP/Canvas 설정 없이 시연할 수 있습니다. 실제 UI 수업에서는 UGUI Slider/Image FillAmount 또는 UI Toolkit으로 치환할 수 있습니다.

## 코드 책임

- `Day58SkillData` (ScriptableObject): 스킬 공통 기준값. 런타임 쿨타임 또는 플레이어 마나 **저장 금지**.
- `Day58SkillController`: Slot별 쿨타임, 비용·사용 가능 조건, 효과 호출. `TryUseSlot(int)`을 UI Button에서도 호출 가능.
- `Day58PlayerStats`: 개별 플레이어 체력/마나, 회복 및 피해 처리.
- `Day58PlayerMover`: CharacterController로 이동 및 Dash 상태 처리.
- `Day58ProjectilePool` / `Day58Projectile`: UnityEngine.Pool.ObjectPool과 Raycast 이동. Get/Release에서 비행 상태를 안전하게 초기화하고 중복 Release 방지.
- `Day58TargetDummy`: 실습용 데미지 수신·자동 부활.
- `Day58SkillInput`: New Input System `Keyboard.current`에만 종속; Controller 본체는 UI/게임패드 등에 독립적.

## 정책 및 제한

- **쿨타임 시작 시점**: 사용 승인/마나 소모 시점. 발사체 시전 중 비활성화되더라도 이미 지불한 마나 및 쿨타임은 환급되지 않습니다.
- **시간 기준**: `Time.time` / `WaitForSeconds` = scaled time. `Time.timeScale=0`에서 쿨타임·시전·대시가 멈춥니다. UI는 계속 화면에 표시되지만 일시정지 중 `TryUseSlot`은 거절합니다.
- **Heal**: HP가 최대치면 사용 불가. 실패 입력은 마나/쿨타임을 소비하지 않습니다.
- **투사체**: 스윕 Raycast 충돌 모델(오브젝트의 물리 Collider는 필요 없음). 예제 씬은 Ignore Raycast 레이어를 Player에 지정합니다. 실제 프로젝트 통합 시 충돌 레이어/팀 판정을 다시 설계하세요.
- **투사체 Pool**: `maxInactive`는 활성 오브젝트 최대 수가 아니라, 반환해 보관하는 객체의 상한입니다. Prewarm은 실제 `Get → Release`를 수행합니다.
- **안전한 한계**: 이 코드는 독립 실습 예제이며 Day55~57의 스폰/AI/전투 시스템에 자동 통합되지는 않습니다. 시스템 간 인터페이스 연결과 Play Mode 검증이 별도로 필요합니다.
- **씬 검증기**: 필수 컴포넌트/에셋 존재에 대한 정적 검사만 진행합니다. Play Mode 동작 성공을 보장하지 않습니다.

## 제출물

프로젝트 `Day58_SkillLab` Scene, 3개 SkillData Asset, SkillController/ProjectilePool 코드, T01~T12 체크리스트, 콘솔 로그/Inspector 스크린샷 4장 이상, Codex diff 또는 분석 기록.

## Unity 공식 참고 문서

- ScriptableObject: https://docs.unity3d.com/kr/current/Manual/class-ScriptableObject.html
- ObjectPool<T>: https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/pool/objectpool1
- Time.unscaledTime: https://docs.unity3d.com/kr/current/ScriptReference/Time-unscaledTime.html
- WaitForSeconds: https://docs.unity.com/en-us/engine/6000.0/script-reference/unityengine/waitforseconds
- InputAction.WasPressedThisFrame: https://docs.unity.cn/Packages/com.unity.inputsystem@1.6/api/UnityEngine.InputSystem.InputAction.html
