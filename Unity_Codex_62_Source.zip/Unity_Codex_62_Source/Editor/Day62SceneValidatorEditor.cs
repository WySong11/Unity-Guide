#if UNITY_EDITOR
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class Day62SceneValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day62/Validate Current Lab")]
    public static void Validate()
    {
        var flow = Object.FindFirstObjectByType<Day62GameFlowManager>();
        if (flow == null)
        { Debug.LogError("[Day62] Missing FlowManager in current scene"); return; }
        string[] names = { flow.TitleSceneName, flow.GameSceneName,
                           flow.ResultSceneName };
        int errors = 0;
        foreach (var name in names)
        {
            bool ok = EditorBuildSettings.scenes.Any(x => x.enabled &&
                System.IO.Path.GetFileNameWithoutExtension(x.path) == name);
            if (!ok) { errors++; Debug.LogError("[Day62] Not in Scene List: " + name); }
        }
        var ui = Object.FindFirstObjectByType<Day62SceneScreenUI>();
        if (ui == null) { errors++; Debug.LogError("[Day62] No ScreenUI"); }
        if (Object.FindObjectsByType<Day62GameFlowManager>(
            FindObjectsSortMode.None).Length > 1)
        { errors++; Debug.LogWarning("[Day62] Duplicate managers in this scene"); }
        Debug.Log("[Day62] Validate: " + (errors == 0 ? "OK" : errors + " issues") +
                  " | Active Scene=" + SceneManager.GetActiveScene().name);
        // Asset checks are not Play Mode transition evidence.
    }

    [MenuItem("Tools/Unity Codex/Day62/Run DTO Smoke Tests")]
    public static void TestDTO() => Day62SaveSelfTests.Run();
}
#endif
