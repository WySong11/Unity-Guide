#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class Day62SceneLabBuilderEditor
{
    [MenuItem("Tools/Unity Codex/Day62/Create Scene Flow Lab")]
    public static void Build()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        string dir = "Assets/Day62_SceneFlow_Lab";
        int suffix = 2;
        while (AssetDatabase.IsValidFolder(dir))
        {
            dir = "Assets/Day62_SceneFlow_Lab_" + suffix.ToString("00");
            suffix++;
        }
        AssetDatabase.CreateFolder("Assets", dir.Substring("Assets/".Length));
        AssetDatabase.CreateFolder(dir, "Scenes");
        string tag = suffix == 2 ? "" : "_" + (suffix - 1).ToString("00");
        string title = "Day62_Title" + tag;
        string game = "Day62_Game" + tag;
        string result = "Day62_Result" + tag;

        string[] names = { title, game, result };
        Day62SceneKind[] kinds = { Day62SceneKind.Title,
            Day62SceneKind.Game, Day62SceneKind.Result };
        var paths = new List<string>();
        for (int i = 0; i < names.Length; i++)
        {
            var scene = EditorSceneManager.NewScene(
                NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            var managerRoot = new GameObject("Day62_FlowManager_Root");
            var flow = managerRoot.AddComponent<Day62GameFlowManager>();
            flow.ConfigureScenes(title, game, result);
            managerRoot.AddComponent<Day62LoadingOverlay>();
            var uiRoot = new GameObject("Day62_SceneScreenUI");
            uiRoot.AddComponent<Day62SceneScreenUI>().Configure(kinds[i]);
            if (kinds[i] == Day62SceneKind.Game)
                new GameObject("Day62_GameInput").AddComponent<Day62GameInput>();
            string path = dir + "/Scenes/" + names[i] + ".unity";
            if (!EditorSceneManager.SaveScene(scene, path))
            { Debug.LogError("Scene save failed: " + path); return; }
            paths.Add(path);
        }

        // Preserve all user scenes and append only newly generated demo scenes.
        var existing = new List<EditorBuildSettingsScene>(EditorBuildSettings.scenes);
        foreach (string path in paths)
        {
            int j = existing.FindIndex(x => x.path == path);
            if (j >= 0) existing[j] = new EditorBuildSettingsScene(path, true);
            else existing.Add(new EditorBuildSettingsScene(path, true));
        }
        EditorBuildSettings.scenes = existing.ToArray();
        AssetDatabase.SaveAssets();
        EditorSceneManager.OpenScene(paths[0]);
        Debug.Log("[Day62] Lab created in " + dir +
                  "; 3 scenes added to Build Profiles Scene List.");
    }
}
#endif
