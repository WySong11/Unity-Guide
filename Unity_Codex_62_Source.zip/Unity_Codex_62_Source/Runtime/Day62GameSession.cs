using System;

// No UnityEngine.Object references: this data survives scene changes
// only because Day62GameFlowManager owns this object persistently.
public sealed class Day62GameSession
{
    public event Action OnChanged;
    public int Coins { get; private set; }
    public int Lives { get; private set; } = 3;
    public int BestCoins { get; private set; }
    public int CompletedRuns { get; private set; }
    public Day62RunResult LastResult { get; private set; }

    public void BeginNewRun()
    {
        Coins = 0;
        Lives = 3;
        LastResult = Day62RunResult.None;
        Notify();
    }

    public void CollectCoin()
    {
        if (Lives <= 0 || Coins >= 9999) return;
        Coins++;
        Notify();
    }

    public bool TakeDamage()
    {
        if (Lives <= 0) return false;
        Lives--;
        Notify();
        return Lives == 0;
    }

    public void Finish(bool victory)
    {
        LastResult = victory ? Day62RunResult.Victory : Day62RunResult.Defeat;
        CompletedRuns = Math.Min(9999, CompletedRuns + 1);
        BestCoins = Math.Max(BestCoins, Coins);
        Notify();
    }

    public void RestoreRun(Day62RunSaveDto dto)
    {
        // The caller must validate the complete DTO before this call.
        Coins = dto.coins;
        Lives = dto.lives;
        BestCoins = dto.bestCoins;
        CompletedRuns = dto.completedRuns;
        LastResult = Day62RunResult.None;
        Notify();
    }

    private void Notify() => OnChanged?.Invoke();
}
