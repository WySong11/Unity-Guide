using System;
using System.IO;
using System.Text;
using UnityEngine;

[Serializable]
public sealed class Day62RunSaveDto
{
    public string marker;
    public int version;
    public string savedAtUtc;
    public int coins;
    public int lives;
    public int bestCoins;
    public int completedRuns;
}

public static class Day62SaveService
{
    public const string Marker = "UNITY_CODEX_DAY62_RUN";
    public const int Version = 1;
    public static string SavePath => Path.Combine(
        Application.persistentDataPath, "day62_run.json");

    public static Day62RunSaveDto Snapshot(Day62GameSession session)
    {
        return new Day62RunSaveDto
        {
            marker = Marker,
            version = Version,
            savedAtUtc = DateTime.UtcNow.ToString("o"),
            coins = session.Coins,
            lives = session.Lives,
            bestCoins = session.BestCoins,
            completedRuns = session.CompletedRuns
        };
    }

    public static bool Validate(Day62RunSaveDto data, out string error)
    {
        if (data == null) { error = "JSON DTO is null"; return false; }
        if (data.marker != Marker || data.version != Version)
        { error = "Marker/version mismatch"; return false; }
        if (data.coins < 0 || data.coins > 9999 ||
            data.lives < 1 || data.lives > 3 ||
            data.bestCoins < 0 || data.bestCoins > 9999 ||
            data.completedRuns < 0 || data.completedRuns > 9999)
        { error = "Run numbers out of valid range"; return false; }
        error = null;
        return true;
    }

    public static bool TrySave(Day62GameSession session, out string message)
    {
        Day62RunSaveDto data = Snapshot(session);
        if (!Validate(data, out message)) return false;
        try
        {
            Directory.CreateDirectory(Application.persistentDataPath);
            string json = JsonUtility.ToJson(data, true);
            // Teaching demo: direct file write. For production use backup and
            // platform-tested atomic replacement, encryption as needed.
            File.WriteAllText(SavePath, json, Encoding.UTF8);
            message = "Saved: " + SavePath;
            return true;
        }
        catch (Exception ex) when (ex is IOException ||
                                    ex is UnauthorizedAccessException)
        {
            message = "Save failed: " + ex.Message;
            return false;
        }
    }

    public static bool TryRead(out Day62RunSaveDto data, out string message)
    {
        data = null;
        if (!File.Exists(SavePath))
        { message = "No saved run"; return false; }
        try
        {
            string json = File.ReadAllText(SavePath, Encoding.UTF8);
            var candidate = JsonUtility.FromJson<Day62RunSaveDto>(json);
            if (!Validate(candidate, out message)) return false;
            data = candidate; // Only expose a fully validated snapshot.
            message = "Loaded and validated";
            return true;
        }
        catch (Exception ex) when (ex is IOException ||
                                    ex is UnauthorizedAccessException ||
                                    ex is ArgumentException)
        {
            message = "Load failed: " + ex.Message;
            return false;
        }
    }
}
