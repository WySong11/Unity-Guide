using System;
using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

// Attach ONLY to a root GameObject. Builder adds one candidate in each scene;
// duplicates are destroyed in Awake when a persistent manager already exists.
[DisallowMultipleComponent]
public sealed class Day62GameFlowManager : MonoBehaviour
{
    public static Day62GameFlowManager Instance { get; private set; }
    public event Action<Day62GameState> StateChanged;

    [SerializeField] private string titleScene = "Day62_Title";
    [SerializeField] private string gameScene = "Day62_Game";
    [SerializeField] private string resultScene = "Day62_Result";
    [SerializeField, Min(0f)] private float minimumLoadingSeconds = 0.3f;

    public Day62GameState State { get; private set; } = Day62GameState.Title;
    public Day62GameSession Session { get; } = new Day62GameSession();
    public bool IsLoading { get; private set; }
    public float LoadProgress { get; private set; }
    public string StatusMessage { get; private set; } = "Ready";
    public string TitleSceneName => titleScene;
    public string GameSceneName => gameScene;
    public string ResultSceneName => resultScene;

    public void ConfigureScenes(string title, string game, string result)
    {
        titleScene = title; gameScene = game; resultScene = result;
    }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
        Time.timeScale = 1f;
    }

    private void Start()
    {
        // Supports pressing Play directly in any of the three demo scenes.
        var name = SceneManager.GetActiveScene().name;
        ChangeState(name == gameScene ? Day62GameState.Playing :
                    name == resultScene ? Day62GameState.Result :
                    Day62GameState.Title);
    }

    private void OnDestroy()
    {
        if (Instance != this) return;
        Instance = null;
        Time.timeScale = 1f;
    }

    private void ChangeState(Day62GameState state)
    {
        State = state;
        StateChanged?.Invoke(state);
    }

    public void StartNewGame()
    {
        if (IsLoading || (State != Day62GameState.Title &&
                          State != Day62GameState.Result)) return;
        if (!CheckScene(gameScene)) return;
        Session.BeginNewRun();
        StartCoroutine(Travel(gameScene, Day62GameState.Playing));
    }

    public void TryContinue()
    {
        if (IsLoading || State != Day62GameState.Title) return;
        if (!CheckScene(gameScene)) return;
        if (!Day62SaveService.TryRead(out var dto, out var msg))
        { StatusMessage = msg; return; }
        Session.RestoreRun(dto);
        StatusMessage = msg;
        StartCoroutine(Travel(gameScene, Day62GameState.Playing));
    }

    public void GoTitle()
    {
        if (IsLoading || State == Day62GameState.Title) return;
        if (!CheckScene(titleScene)) return;
        Time.timeScale = 1f;
        StartCoroutine(Travel(titleScene, Day62GameState.Title));
    }

    public void Pause()
    {
        if (IsLoading || State != Day62GameState.Playing) return;
        Time.timeScale = 0f;
        ChangeState(Day62GameState.Paused);
    }

    public void Resume()
    {
        if (IsLoading || State != Day62GameState.Paused) return;
        Time.timeScale = 1f;
        ChangeState(Day62GameState.Playing);
    }

    public void TogglePause()
    {
        if (State == Day62GameState.Playing) Pause();
        else if (State == Day62GameState.Paused) Resume();
    }

    public void AddCoin()
    {
        if (State == Day62GameState.Playing && !IsLoading)
            Session.CollectCoin();
    }

    public void HitPlayer()
    {
        if (State == Day62GameState.Playing && !IsLoading &&
            Session.TakeDamage()) FinishRun(false);
    }

    public void FinishRun(bool victory)
    {
        if (IsLoading || State != Day62GameState.Playing) return;
        if (!CheckScene(resultScene)) return;
        ChangeState(victory ? Day62GameState.Victory : Day62GameState.Defeat);
        Session.Finish(victory);
        StartCoroutine(Travel(resultScene, Day62GameState.Result));
    }

    public void SaveRun()
    {
        if (IsLoading || (State != Day62GameState.Playing &&
                          State != Day62GameState.Paused)) return;
        bool ok = Day62SaveService.TrySave(Session, out var message);
        StatusMessage = (ok ? "OK: " : "ERROR: ") + message;
    }

    private bool CheckScene(string name)
    {
        if (!string.IsNullOrWhiteSpace(name) &&
            Application.CanStreamedLevelBeLoaded(name)) return true;
        StatusMessage = "Missing scene in Build Profiles: " + name;
        Debug.LogError("[Day62] " + StatusMessage);
        return false;
    }

    private IEnumerator Travel(string sceneName, Day62GameState finalState)
    {
        if (IsLoading) yield break;
        IsLoading = true;
        LoadProgress = 0f;
        ChangeState(Day62GameState.Loading);
        Time.timeScale = 1f; // Never enter another scene paused.

        AsyncOperation op = SceneManager.LoadSceneAsync(
            sceneName, LoadSceneMode.Single);
        if (op == null)
        {
            IsLoading = false;
            ChangeState(Day62GameState.Title);
            StatusMessage = "Could not start loading: " + sceneName;
            yield break;
        }

        op.allowSceneActivation = false;
        float started = Time.realtimeSinceStartup;
        while (op.progress < 0.9f)
        {
            LoadProgress = Mathf.Clamp01(op.progress / 0.9f);
            yield return null;
        }
        LoadProgress = 1f;
        while (Time.realtimeSinceStartup - started < minimumLoadingSeconds)
            yield return null;
        op.allowSceneActivation = true;
        while (!op.isDone) yield return null;
        IsLoading = false;
        LoadProgress = 0f;
        ChangeState(finalState);
        StatusMessage = "Scene ready: " + sceneName;
    }
}
