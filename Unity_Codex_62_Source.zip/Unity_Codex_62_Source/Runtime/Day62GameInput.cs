using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

// UI buttons also work without the Input System package.
public sealed class Day62GameInput : MonoBehaviour
{
    private void Update()
    {
#if ENABLE_INPUT_SYSTEM
        var keys = Keyboard.current;
        var f = Day62GameFlowManager.Instance;
        if (keys == null || f == null || f.IsLoading) return;
        if (keys.escapeKey.wasPressedThisFrame || keys.pKey.wasPressedThisFrame)
            f.TogglePause();
        if (keys.cKey.wasPressedThisFrame) f.AddCoin();
        if (keys.hKey.wasPressedThisFrame) f.HitPlayer();
        if (keys.vKey.wasPressedThisFrame) f.FinishRun(true);
        if (keys.dKey.wasPressedThisFrame) f.FinishRun(false);
        if (keys.f5Key.wasPressedThisFrame) f.SaveRun();
#endif
    }
}
