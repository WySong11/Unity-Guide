using UnityEngine;
using UnityEngine.SceneManagement;

// Minimal IMGUI demo: production teams can replace this with a Canvas / UI Toolkit UI.
public sealed class Day62SceneScreenUI : MonoBehaviour
{
    [SerializeField] private Day62SceneKind sceneKind;
    private Day62GameFlowManager flow;
    private string lastEvent = "-";

    public void Configure(Day62SceneKind kind) => sceneKind = kind;

    private void Start()
    {
        flow = Day62GameFlowManager.Instance;
        if (flow != null) flow.StateChanged += HandleStateChanged;
    }

    private void OnDisable()
    {
        if (flow != null) flow.StateChanged -= HandleStateChanged;
    }

    private void HandleStateChanged(Day62GameState state)
    { lastEvent = state.ToString(); }

    private void OnGUI()
    {
        if (flow == null) flow = Day62GameFlowManager.Instance;
        if (flow == null) return;
        float h = sceneKind == Day62SceneKind.Game ? 430 : 335;
        GUILayout.BeginArea(new Rect(20, 20, 405, h), GUI.skin.box);
        GUILayout.Label("UNITY × CODEX | DAY 62");
        GUILayout.Label("Scene: " + SceneManager.GetActiveScene().name);
        GUILayout.Label("State: " + flow.State + "  Event: " + lastEvent);
        GUILayout.Label("Coins: " + flow.Session.Coins +
                       "   Lives: " + flow.Session.Lives +
                       "   Best: " + flow.Session.BestCoins);
        GUILayout.Label("Status: " + flow.StatusMessage);
        GUI.enabled = !flow.IsLoading;
        switch (sceneKind)
        {
            case Day62SceneKind.Title:
                if (GUILayout.Button("NEW GAME", GUILayout.Height(40))) flow.StartNewGame();
                if (GUILayout.Button("CONTINUE SAVED RUN", GUILayout.Height(40))) flow.TryContinue();
                break;
            case Day62SceneKind.Game:
                if (flow.State == Day62GameState.Paused)
                {
                    if (GUILayout.Button("RESUME", GUILayout.Height(36))) flow.Resume();
                    if (GUILayout.Button("BACK TO TITLE", GUILayout.Height(36))) flow.GoTitle();
                }
                else if (flow.State == Day62GameState.Playing)
                {
                    if (GUILayout.Button("+ COIN", GUILayout.Height(30))) flow.AddCoin();
                    if (GUILayout.Button("HIT (-1 LIFE)", GUILayout.Height(30))) flow.HitPlayer();
                    if (GUILayout.Button("WIN", GUILayout.Height(30))) flow.FinishRun(true);
                    if (GUILayout.Button("LOSE", GUILayout.Height(30))) flow.FinishRun(false);
                    if (GUILayout.Button("PAUSE", GUILayout.Height(30))) flow.Pause();
                }
                if (GUILayout.Button("SAVE RUN", GUILayout.Height(30))) flow.SaveRun();
                break;
            case Day62SceneKind.Result:
                GUILayout.Label("Last result: " + flow.Session.LastResult);
                if (GUILayout.Button("RETRY", GUILayout.Height(40))) flow.StartNewGame();
                if (GUILayout.Button("BACK TO TITLE", GUILayout.Height(40))) flow.GoTitle();
                break;
        }
        GUI.enabled = true;
        GUILayout.Label("Save path: " + Day62SaveService.SavePath);
        GUILayout.EndArea();
    }
}
