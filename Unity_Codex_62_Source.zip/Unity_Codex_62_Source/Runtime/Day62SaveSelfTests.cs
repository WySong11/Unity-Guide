using UnityEngine;

// Lightweight serialization/validation smoke checks; not Play Mode scene tests.
public static class Day62SaveSelfTests
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void OnStartup()
    {
        // Intentionally not auto-run: execute via menu to inspect console.
    }

    public static bool Run()
    {
        var session = new Day62GameSession();
        session.BeginNewRun();
        session.CollectCoin();
        var dto = Day62SaveService.Snapshot(session);
        string json = JsonUtility.ToJson(dto);
        var restored = JsonUtility.FromJson<Day62RunSaveDto>(json);
        bool valid = Day62SaveService.Validate(restored, out _) &&
                     restored.coins == 1 && restored.lives == 3;
        restored.version = 999;
        bool invalidRejected = !Day62SaveService.Validate(restored, out _);
        Debug.Log("[Day62 Smoke] DTO roundtrip=" + valid +
                  ", invalid version rejected=" + invalidRejected);
        return valid && invalidRejected;
    }
}
