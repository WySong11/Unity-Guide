// Day 62 | Game logic states and the last run outcome.
public enum Day62GameState
{
    Title, Loading, Playing, Paused, Victory, Defeat, Result
}

public enum Day62RunResult
{
    None, Victory, Defeat
}

public enum Day62SceneKind
{
    Title, Game, Result
}
