using UnityEngine;

// Lives on the persistent manager root and can render during scene transitions.
public sealed class Day62LoadingOverlay : MonoBehaviour
{
    private void OnGUI()
    {
        var f = Day62GameFlowManager.Instance;
        if (f == null || !f.IsLoading) return;
        float cx = Screen.width * 0.5f;
        float cy = Screen.height * 0.5f;
        var panel = new Rect(cx - 210, cy - 80, 420, 160);
        GUI.depth = -100;
        GUI.Box(panel, "LOADING SCENE...");
        GUI.Label(new Rect(panel.x + 25, panel.y + 48, 360, 24),
            "Progress: " + Mathf.RoundToInt(f.LoadProgress * 100f) + "%");
        var bar = new Rect(panel.x + 25, panel.y + 92, 370, 28);
        GUI.Box(bar, "");
        var old = GUI.color;
        GUI.color = new Color(0.25f, 0.67f, 1f, 1f);
        GUI.Box(new Rect(bar.x + 2, bar.y + 2,
            Mathf.Max(0, (bar.width - 4) * f.LoadProgress), bar.height - 4), "");
        GUI.color = old;
    }
}
