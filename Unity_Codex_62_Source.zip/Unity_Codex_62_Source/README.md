# Unity × Codex | 62일차 — Scene 전환과 게임 상태 관리

**권장**: Unity 6.3 · 3D/URP 프로젝트 · 120분 · 44슬라이드.

## 1. 실습 시작

1. `Runtime/*.cs`를 프로젝트 `Assets/Scripts/Day62/`에 복사합니다.
2. `Editor/*.cs`를 `Assets/Editor/Day62/`에 복사합니다.
3. Unity Editor의 Console에서 C# 컴파일 오류가 없는지 확인합니다.
4. **Tools → Unity Codex → Day62 → Create Scene Flow Lab** 메뉴를 실행합니다.
5. 자동 생성되는 `Assets/Day62_SceneFlow_Lab[_NN]/Scenes/` 안의 `Day62_Title`, `Day62_Game`, `Day62_Result` 세 씬이 **Build Profiles → Scene List**에 포함되는지 확인합니다. 기존 씬 목록은 유지됩니다.
6. 열려 있는 Title 씬에서 **Play → NEW GAME**을 실행합니다. 비동기 로딩 화면 후 Game UI가 나타납니다.
7. Game에서 `+ COIN`, `HIT`, `PAUSE`, `RESUME`, `WIN`, `LOSE`, `SAVE RUN`을 시험합니다.
8. Title에서 **CONTINUE SAVED RUN**을 눌러 Save 직전 상태가 복원되는지 검증합니다.
9. **Tools → Unity Codex → Day62 → Validate Current Lab**, **Run DTO Smoke Tests**로 별도 검사합니다.

## 2. 씬/게임 상태 구조

- `Day62_Title`: NEW GAME / CONTINUE 메뉴.
- `Day62_Game`: 점수, 생명, 피해, 승패, 일시정지 UI.
- `Day62_Result`: 결과·재시작·타이틀 이동.
- `Day62GameFlowManager`: `DontDestroyOnLoad`로 영속하는 루트 MonoBehaviour, 상태 이벤트, `LoadSceneAsync`, 타임스케일 제어. 테스트용 3개 씬에는 매니저 **후보**를 각각 배치하지만 첫 매니저만 생존하며 중복 매니저는 `Awake`에서 파괴합니다.
- `Day62GameSession`: C# 값 객체. `Coins`, `Lives`, `BestCoins`, `LastResult`와 이벤트 보유.
- `Day62SaveService`: `Application.persistentDataPath/day62_run.json`에 플레이 중 Run 스냅샷 저장·검증 후 읽기.
- `Day62SceneScreenUI`, `Day62LoadingOverlay`: 수업용 IMGUI UI. Canvas/UI Toolkit 기반 UI로 교체 가능한 구조. IMGUI는 최종 제품용 UI로 권장하지 않습니다.

## 3. 전환 규칙

`Title → Loading → Playing ↔ Paused`, `Playing → Victory / Defeat → Loading → Result → Title / NewGame`.

- 게임 플레이 요청은 `Playing` 상태에서만 유효합니다.
- `Paused` 상태에서 `BACK TO TITLE` 선택 시 **Time.timeScale = 1**로 복구 후 Scene 전환.
- `isLoading` 중 중복 로드 요청은 거절합니다.
- `LoadSceneAsync`가 0.9에 도달하면 활성화 승인 전까지 대기할 수 있습니다. 실습에서는 최소 0.3초간 로딩 UI를 보여주고 활성화합니다. 로딩 진행률은 디스크 용량이나 남은 시간 예측 수치가 아닙니다.
- 스크립트에서 **직접 SceneManager.LoadScene**을 호출하지 않고 Manager API로 이동하도록 지도합니다.

## 4. Save / Continue 동작

- `SAVE RUN`: `Playing` 또는 `Paused` 상태에서 저장, `coins/lives/bestCoins/completedRuns`를 JSON으로 기록합니다.
- `CONTINUE`: Title 상태에서 JSON 전체 검증을 통과한 경우에만 `Day62GameSession.RestoreRun(dto)` 적용 후 Game 로드.
- DTO marker=`UNITY_CODEX_DAY62_RUN`, version=`1`. coins=0~9999, lives=1~3, bestCoins=0~9999, completedRuns=0~9999. 현재 run coins는 bestCoins보다 클 수 있습니다.
- **수업용 파일 저장은 `File.WriteAllText` 단순 기록**입니다. 원자적 교체, 백업, 암호화 및 클라우드 동기화는 구현하지 않았습니다. 운영 환경에서는 안전한 교체 정책을 추가해야 합니다.
- `Result` 화면에서 `SAVE RUN`은 지원하지 않습니다. 결과 최고 기록은 세션 중에는 유지되지만 앱을 완전히 종료했을 때까지의 최고기록 영속성은 별도의 정책/저장 시점 확장이 필요합니다.
- 기존 61일차 JSON Save 파일과 구조/파일명을 구분하며 자동 마이그레이션하지 않습니다.

## 5. 입력 / 버튼

- Title: `NEW GAME`, `CONTINUE SAVED RUN`
- Game: `+ COIN`, `HIT (-1 LIFE)`, `WIN`, `LOSE`, `PAUSE`, `RESUME`, `SAVE RUN`, `BACK TO TITLE` (Pause 시)
- Result: `RETRY`, `BACK TO TITLE`
- New Input System 사용 설정 시 Game 키보드: `C` 획득, `H` 피해, `P`/`Escape` 일시정지 토글, `V` 승리, `D` 패배, `F5` 저장. **입력 시스템이 없어도 GUI 버튼은 동작합니다.**

## 6. 기존 Day58~61 프로젝트에 통합할 때

1. 기존 `GameManager`/`CameraManager`/`Day61SaveService`와 이름·책임 충돌 여부 점검.
2. 기존 플레이어·몬스터·HUD 참조는 **씬 로컬**로 유지. Persistent Manager에서 직접 들고 있지 않도록 검토.
3. `Day62GameSession`과 61일차 플레이어·인벤토리 데이터 간 변환 DTO/어댑터 설계. 예제는 **독립 실습용**으로 이전 코드의 런타임 데이터와 자동 연결되지 않습니다.
4. 씬 빌드 목록·이벤트 구독/해제·Time.timeScale·씬 이동 동시성 점검.
5. 모든 변경 후 Docs 체크리스트 T01~T12를 Play Mode에서 실제 검증.

## 7. 검증 범위

- PPT 44장 렌더링·페이지 경계 검증과 ZIP 파일 무결성 검사는 배포 파일 생성 과정에서 수행합니다.
- 제공 C# 코드는 실행 가능한 예제로 작성했지만 **실제 Unity 6.3 에디터의 컴파일·Play Mode는 이 작업 환경에서 실행하지 않았습니다**. 테스트 결과를 허위 PASS로 기록하지 마세요.
- 생성되는 세 씬은 IMGUI 기반 학습 UI와 Unity 기본 카메라·조명을 이용하며 별도의 게임 아트/UI 패키지가 필요하지 않습니다.

공식 문서:
- https://docs.unity3d.com/kr/current/ScriptReference/SceneManagement.SceneManager.LoadScene.html
- https://docs.unity3d.com/kr/current/ScriptReference/AsyncOperation-allowSceneActivation.html
- https://docs.unity3d.com/kr/current/ScriptReference/Object.DontDestroyOnLoad.html
- https://docs.unity3d.com/kr/current/Manual/time-scale.html
