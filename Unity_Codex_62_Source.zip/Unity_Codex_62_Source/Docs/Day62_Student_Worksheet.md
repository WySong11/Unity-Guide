# Day62 | 학생 실습 워크시트

## 목표

- [ ] Title·Game·Result 3개 씬을 생성한다.
- [ ] Loading → Playing 과정을 직접 확인한다.
- [ ] `Paused`일 때 게임 입력과 시간 진행이 멈추는지 확인한다.
- [ ] Resume·GoTitle 시 timeScale이 1로 복원되는지 확인한다.
- [ ] Coins/Lives Save 후 Continue가 값을 복원하는지 확인한다.
- [ ] Result → Retry/Title에서 State와 점수가 기대값인지 확인한다.
- [ ] 오류 상황과 로그를 최소 2개 수집한다.

## 실습 A: Scene 등록

생성된 폴더 경로: ___________________

Scene List 3개 등록: ___________________

Title → Game 동작 및 Scene 이름: ___________________

## 실습 B: Game State

| 동작 | 전 State | 후 State | timeScale | 실제 결과 |
|---|---|---|---|---|
| Start New Game | Title | Playing | 1 | |
| Pause | Playing | Paused | 0 | |
| Resume | Paused | Playing | 1 | |
| Win | Playing | Result | 1 | |
| Retry | Result | Playing | 1 | |

## 실습 C: JSON 이어하기

Save 시점 Coins/Lives: ________/________

씬 이동 후 Continue Coins/Lives: ________/________

JSON 저장 파일 위치: ___________________

손상/버전 불일치 JSON을 원본 복사본에서 시험한 결과: ___________________

## 실습 D: 개선 과제

- 로딩 중 버튼을 여러 번 눌렀을 때 중복 로드가 발생하지 않는 근거를 제시한다.
- 게임이 Paused일 때 61일차 Save 시스템과 연결하는 어댑터 방식을 설명한다.
- Session에 GameObject 참조를 저장하면 발생할 수 있는 문제를 설명한다.

## 제출물

1. 세 Scene Hierarchy / Scene List 스크린샷
2. Game Pause / Result / Loading 화면 캡처
3. Save JSON 샘플과 Continue 복원 기록
4. T01~T12 테스트 결과표
5. Codex에 전달한 프롬프트와 수정 diff 또는 검토 결과
