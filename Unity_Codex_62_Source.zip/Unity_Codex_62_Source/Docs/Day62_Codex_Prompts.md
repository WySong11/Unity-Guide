# Day62 | Codex 검증 프롬프트

## 1. 구조 리뷰

> Unity 6.3 프로젝트의 Day62 Scene 전환·Game State 소스를 검토해줘. 씬 전환 요청이 GameFlowManager로만 모이는지, Enum 전이 가드, `isLoading` 동시성 차단, DDOL 루트와 Singleton 중복 파괴 여부를 확인해줘. 현재 프로젝트의 다른 DayXX 파일은 수정하지 말고 발견한 문제와 최소 수정 diff를 먼저 제시해줘.

## 2. Pause / Resume 회귀 검사

> Title → Game → Pause → Resume → Win → Result → Title 순서를 실제 Unity Editor Play Mode에서 테스트해줘. 각 단계의 활성 Scene, GameState, Time.timeScale과 GameSession.Coins/Lives를 기록해줘. 특히 Pause 상태에서 Title 이동 시 timeScale=1이 되는지 확인해줘. 테스트하지 못한 항목은 PASS라고 표시하지 마.

## 3. Async Scene

> SceneManager.LoadSceneAsync/AsyncOperation `progress`/`allowSceneActivation` 구현을 점검해줘. Build Profiles Scene List의 3개 Scene 등록 여부, 로딩 중 중복 요청, 0.9에서 진행률 멈춤, SceneLoad 실패 메시지 및 MinimumLoadingSeconds의 unscaled 시간 처리를 확인해줘. 실행하지 않은 단계는 미실행으로 기록해줘.

## 4. Save/Continue

> Day62RunSaveDto와 Day62SaveService의 JSON 직렬화, marker/version, 점수·생명 수치 검증, `persistentDataPath`, 잘못된 JSON/파일 없음 처리를 검사해줘. Load 오류 시 게임 Session이 바뀌지 않는지 확인하고 61일차 DTO/아이템·인벤토리와 통합할 어댑터 인터페이스만 설계해줘. 기존 Save 파일을 삭제하거나 덮어쓰지 마.

## 5. 통합 테스트

> Docs/Day62_Test_Checklist.csv의 T01~T12를 기준으로 테스트 계획과 실행 증거를 작성해줘. 로그·스크린샷·코드 실행 근거가 있는 항목만 PASS, 수행하지 않은 항목은 NOT RUN으로 명시해줘. 실패 항목은 원인→최소 수정→재검증으로 정리해줘.
