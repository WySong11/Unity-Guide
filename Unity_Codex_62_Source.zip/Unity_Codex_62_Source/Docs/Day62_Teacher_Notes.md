# Day62 | 강사용 진행 가이드 (120분)

| 시간 | 실습 | 지도 포인트 |
|---|---|---|
| 00~25 | Scene vs Game State·구조 | Title/Game/Result, DDOL vs Scene-local |
| 25~60 | Builder·Async 로드 | Scene List, isLoading, 0.9/allowSceneActivation |
| 60~100 | Pause/Resume·Save/Continue | Time.timeScale, Session, DTO validator |
| 100~120 | 오류 재현·Codex 검증 | T01~T12, 미실행 결과 분리 |

## 교사 데모 순서

1. Build Profiles Scene List 등록 전/후 비교.
2. New Game을 눌러 0.3초 최소 로딩 오버레이 확인.
3. Game에서 Coin을 두 번 늘리고 Pause 후 `Time.timeScale=0` 확인.
4. Resume, SAVE RUN, WIN 후 Result로 이동.
5. Title에서 CONTINUE를 선택하여 Save 시점 Coin/Life 복원 확인.
6. Save JSON 복사본을 변경해 version=999 또는 lives=-1 테스트 후 거절 확인.
7. Validator와 DTO Smoke Tests를 돌린 뒤 Editor Play Mode가 아닌 테스트 결과와 구분해 설명.

## 숙련도별 확장

- 기초: 버튼으로 Title/Game/Result를 왕복한다.
- 중급: 실제 Canvas/TMP와 StateChanged 이벤트를 연결한다.
- 고급: 61일차 Inventory/Equipment DTO와 통합하고 로딩 취소 또는 Additive Scene 구조를 설계한다.

## 유의사항

- `DontDestroyOnLoad`는 **루트 오브젝트**에 적용한다.
- `LoadSceneAsync` 진행률은 대기 시간 예측이 아니다.
- `Time.timeScale=0` 중에도 Update는 호출될 수 있으므로 State로 입력을 차단한다.
- IMGUI는 학습용. 실제 게임 HUD는 uGUI 또는 UI Toolkit이 적합하다.
- SaveService는 데모용 단순 덮어쓰기이며 원자성/백업을 보장하지 않는다.
- 샘플 빌더는 기존 Assets의 다른 파일/Scene을 덮어쓰지 않도록 접미 폴더를 만든다.
- 세 Scene UI는 각자 GameFlowManager 후보를 포함하며 활성 싱글턴만 살아남는다.
