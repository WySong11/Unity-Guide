# Git 검사 체크리스트

```bash
git status --short
git branch --show-current
git log -1 --oneline
git diff --stat
git diff --check
# 특정 파일의 실제 경로는 git status에서 확인
# git diff -- path/to/AudioSettingsController.cs
```

- [ ] 기존 미커밋 변경이 누구의 것인지 확인
- [ ] 수정 대상과 제외 대상이 명시됨
- [ ] Scene/Prefab/.meta가 의도치 않게 바뀌지 않음
- [ ] 테스트 결과가 실제 실행 증거와 일치
- [ ] Git diff를 동료/리뷰어가 확인
- [ ] 커밋/푸시는 별도 승인 이후에만 수행

주의: `git reset --hard`, `git clean -fd`, 강제 push를 관성적으로 실행하지 마세요.
