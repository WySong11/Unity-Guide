// 90일차 AudioMath.cs가 같은 프로젝트의 참조 가능한 어셈블리에 있어야 합니다.
using NUnit.Framework;

public class AudioMathEdgeCaseTests
{
    [TestCase(-1f, -80f)]
    [TestCase(0f, -80f)]
    [TestCase(1f, 0f)]
    public void LinearToDb_Boundaries(float input, float expected)
    {
        Assert.That(AudioMath.LinearToDb(input),
            Is.EqualTo(expected).Within(0.01f));
    }

    [Test]
    public void LinearToDb_HalfVolume_IsAboutMinusSixDb()
    {
        Assert.That(AudioMath.LinearToDb(0.5f),
            Is.EqualTo(-6.02f).Within(0.03f));
    }
}
