using NUnit.Framework;

public class StageProgressRulesTests
{
    [TestCase(0, 1, true, 1)]
    [TestCase(3, 2, true, 3)]
    [TestCase(3, 3, true, 3)]
    [TestCase(3, 5, true, 5)]
    [TestCase(3, 0, false, 3)]
    [TestCase(-1, 2, false, -1)]
    public void TryAdvance_AlwaysPreservesMaximum(
        int current, int cleared, bool expectedResult, int expectedNext)
    {
        bool actual = StageProgressRules.TryAdvance(current, cleared, out int next);
        Assert.That(actual, Is.EqualTo(expectedResult));
        Assert.That(next, Is.EqualTo(expectedNext));
    }
}
