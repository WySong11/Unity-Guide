using System;

/// <summary>
/// 90일차 GameSaveService.RecordStageClear의 진도 증가 규칙을
/// 파일 I/O와 분리한 순수 C# 로직. Runtime Assembly에 배치합니다.
/// </summary>
public static class StageProgressRules
{
    public static bool TryAdvance(int current, int cleared, out int next)
    {
        next = current;
        if (current < 0 || cleared <= 0)
            return false;

        next = Math.Max(current, cleared);
        return true;
    }
}
