# Codex 실습 프롬프트 3종

## ① 읽기 전용 리뷰
WAVE GUARD (Unity 6.3 LTS)의 90일차 저장·사운드 코드를 읽기 전용으로 리뷰해줘.
대상은 GameSaveService.cs, SaveDataCodec.cs, AudioSettingsController.cs, AudioMath.cs로 제한해.
AGENTS.md와 기존 공개 API·직렬화 데이터·씬 참조를 존중해.
출력은 우선순위(P0~P3), 파일:줄, 실패 시나리오, 영향, 최소 수정안, 검증 테스트, 확실성 순으로 작성해.
문제가 재현되지 않았다면 그 사실을 분명히 밝혀. 지금은 파일 수정과 명령 실행, 커밋을 하지 마.

## ② 리팩토링 계획과 승인 범위
리뷰 R-01에 대해 수정 전에 재현 절차/수용 기준/영향받는 파일 목록을 작성해줘.
Public API, SerializeField 필드명, PlayerPrefs 키, Mixer Exposed Parameter는 보존하고 신규 기능은 추가하지 마.
계획 단계에서 멈추고 파일을 수정하지 마.

## ③ 승인 후 최소 수정과 검증
사용자가 승인한 R-01만 수정해줘. 다른 파일 수정은 사유를 제시하고 별도 승인을 받아야 해.
가능하면 EditMode 회귀 테스트를 먼저 추가하고, 최소 수정 → 실제 실행한 검증 → git diff 검토 순으로 진행해.
성공하지 않은 테스트는 미실행/실패로 구분해. commit/push는 하지 마.

## ④ 독립 리뷰
수정된 Git diff를 읽기 전용으로 다시 점검해줘.
AGENTS.md와 R-01 수용 기준을 적용하고, 범위 밖 변경·기존 동작 변경·Scene/Prefab 영향·테스트 증거 누락을 찾아줘.
P0~P3 발견 사항을 먼저 제시하고 Go/No-Go와 잔여 위험을 보고해. 파일 수정 금지.
