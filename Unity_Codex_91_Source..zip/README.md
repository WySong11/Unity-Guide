# 91일차 | Codex 코드 리뷰 · 리팩토링 실습

## 목적
기존 85~90일차 WAVE GUARD Unity 프로젝트의 동작을 보존하면서 코드 리뷰와 작은 리팩토링, 검증 보고를 수행합니다.

## 환경
Unity 6.3 LTS, C#, Unity Test Framework(NUnit), VS Code/Codex, Git.

## 120분 작업 절차
1. `git status --short`로 미커밋 변경 확인. 기존 작업은 보호합니다.
2. `AudioSettingsController.cs`, `GameSaveService.cs`, `SaveDataCodec.cs` 등 현재 프로젝트의 실제 파일 위치 확인.
3. `Prompts/Codex_Review_Prompts.md`의 읽기 전용 프롬프트로 리뷰 요청. 보고서 작성.
4. 허가된 파일만 수정. 기존 공개 API, PlayerPrefs 키, Mixer exposed parameter, SerializeField 이름은 유지합니다.
5. `Code/StageProgressRules.cs` 순수 규칙을 필요시 프로젝트 Runtime 어셈블리에 추가하고 `Tests/EditMode` 테스트를 작성합니다.
6. `AudioMathEdgeCaseTests`는 90일차 AudioMath.cs가 프로젝트에 있을 때만 사용합니다.
7. EditMode 테스트와 PlayMode 확인을 실제 실행하고 결과를 기록합니다. 실행하지 않은 항목은 NOT RUN.
8. `git diff --stat`, `git diff --check`로 범위 확인. 커밋·푸시는 별도 승인 후 수행합니다.

## 실습 코드 설치 주의
- `Reference/AudioSettingsController_After.txt`는 리뷰 학습용 수정 가이드입니다. .cs로 **그대로 추가하지 마세요**. 기존 MonoBehaviour에 필요한 부분만 병합해야 중복 클래스가 생기지 않습니다.
- `Code/StageProgressRules.cs`와 `Tests/EditMode/StageProgressRulesTests.cs`는 독립 C# 예제입니다. Runtime/Test Assembly가 분리돼 있다면 테스트 어셈블리에서 런타임 어셈블리를 참조합니다.
- 90일차 AudioMath.cs가 없어 `AudioMathEdgeCaseTests.cs`가 컴파일되지 않으면 해당 테스트는 가져오지 않습니다.
- 제공한 파일은 실제 Unity 프로젝트에서 빌드하거나 테스트한 결과가 아닙니다. 사용자가 자신의 프로젝트에서 실행하고 검증해야 합니다.

## 유의사항
- Inspector 누락을 로그로 분명하게 출력합니다. null을 무조건 무시해서 문제를 숨기지 않습니다.
- `schemaVersion`, `SaveData` JSON 필드 이름, StageWaveController 이벤트 이름을 계획 없이 바꾸지 마세요.
- 디스크 저장을 원자적으로 변경하는 것은 플랫폼별 검증이 필요한 별도 작업입니다.
