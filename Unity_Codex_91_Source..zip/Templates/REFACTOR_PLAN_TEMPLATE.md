# REFACTOR_PLAN.md

## 목적
- 변경 전 문제 / 재현 근거:

## 포함 범위
- 수정 가능 파일:
- 새로운 테스트:

## 제외 범위
- 공개 API 변경 없음
- PlayerPrefs 키 변경 없음
- JSON schemaVersion/필드명 변경 없음
- Scene/Prefab 수동 변경 없음

## 행동 보존 계약
- 기존 동작:
- 경계값:

## 실행할 검증
- EditMode:
- PlayMode:
- Windows/Android 빌드:

## 승인/되돌리기
- 승인 상태:
- 작업 브랜치:
- 필요 시 되돌릴 커밋:
