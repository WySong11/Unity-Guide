using UnityEngine;

public sealed class Day61DemoHUD : MonoBehaviour
{
    [SerializeField] private Day61PlayerState player;
    [SerializeField] private Day61Inventory inventory;
    [SerializeField] private Day61SaveService saveService;
    private string status = "Day61 JSON Save/Load Lab";
    private Vector2 scroll;

    private void Awake()
    {
        if (player == null) player = GetComponent<Day61PlayerState>();
        if (inventory == null) inventory = GetComponent<Day61Inventory>();
        if (saveService == null) saveService = GetComponent<Day61SaveService>();
    }

    private void Start() => ResetDemo();
    private void ResetDemo()
    {
        player.ResetDemo();
        inventory.ResetDemo();
        status = "초기화 완료";
    }

    private void OnGUI()
    {
        GUILayout.BeginArea(new Rect(18, 18, 520, Mathf.Min(Screen.height - 30, 700)), GUI.skin.box);
        scroll = GUILayout.BeginScrollView(scroll);
        GUILayout.Label("UNITY × CODEX | Day61 JSON 저장 · 불러오기");
        GUILayout.Label($"HP {player.HP}/{player.MaxHp}   MP {player.Mana}/{player.MaxMana}   LV {player.Level}   Gold {player.Gold}");
        GUILayout.Label("장비 ID: " + (string.IsNullOrEmpty(inventory.EquippedItemId) ? "(없음)" : inventory.EquippedItemId));
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("HP -25")) player.ChangeHP(-25);
        if (GUILayout.Button("Gold +20")) player.ChangeGold(20);
        if (GUILayout.Button("LV +1")) player.ChangeLevel(1);
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Potion +2")) status = inventory.TryAdd("potion", 2) ? "획득 성공" : "슬롯 부족";
        if (GUILayout.Button("Gem +5")) status = inventory.TryAdd("gem", 5) ? "획득 성공" : "슬롯 부족";
        if (GUILayout.Button("Sword 장착")) status = inventory.TryEquip("sword") ? "장착 성공" : "장착 실패";
        if (GUILayout.Button("장착 해제")) { inventory.Unequip(); status = "장착 해제"; }
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("SAVE")) saveService.Save(out status);
        if (GUILayout.Button("LOAD")) saveService.Load(out status);
        if (GUILayout.Button("RESET RUNTIME")) ResetDemo();
        if (GUILayout.Button("JSON 검증 테스트"))
            status = Day61SaveSelfTests.Run(saveService);
        GUILayout.EndHorizontal();
        GUILayout.Label("저장 경로: " + saveService.SavePath);
        GUILayout.Label("STATUS: " + status);
        GUILayout.Space(8);
        GUILayout.Label("[Inventory 12 slots]");
        for (int i = 0; i < inventory.Capacity; i++)
        {
            var slot = inventory.GetSlot(i);
            if (slot != null && !slot.Empty)
                GUILayout.Label($"{i:00}   {slot.ItemId} × {slot.Quantity}");
        }
        GUILayout.EndScrollView();
        GUILayout.EndArea();
    }
}
