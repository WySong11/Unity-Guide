using System;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Day61_Catalog", menuName = "Unity Codex/Day61/Item Catalog")]
public sealed class Day61ItemCatalog : ScriptableObject
{
    [SerializeField] private Day61ItemData[] items = Array.Empty<Day61ItemData>();
    public Day61ItemData[] Items => items;

    public Day61ItemData Find(string id)
    {
        if (string.IsNullOrEmpty(id) || items == null) return null;
        foreach (var item in items)
            if (item != null && item.ItemId == id) return item;
        return null;
    }

    public bool Validate(out string error)
    {
        if (items == null || items.Length == 0) { error = "아이템 카탈로그가 비어 있음"; return false; }
        var seen = new HashSet<string>(StringComparer.Ordinal);
        foreach (var item in items)
        {
            if (item == null || string.IsNullOrWhiteSpace(item.ItemId))
            { error = "Null 아이템 또는 빈 ItemId"; return false; }
            if (!seen.Add(item.ItemId))
            { error = "중복 ItemId: " + item.ItemId; return false; }
        }
        error = "OK";
        return true;
    }
}
