using UnityEngine;

public enum Day61ItemKind { Consumable, Equipment, Material }

[CreateAssetMenu(fileName = "Day61_Item", menuName = "Unity Codex/Day61/Item Data")]
public sealed class Day61ItemData : ScriptableObject
{
    [SerializeField] private string itemId;
    [SerializeField] private string displayName;
    [SerializeField] private Day61ItemKind kind;
    [Min(1)] [SerializeField] private int maxStack = 1;

    public string ItemId => itemId;
    public string DisplayName => displayName;
    public Day61ItemKind Kind => kind;
    public int MaxStack => Mathf.Max(1, maxStack);
}
