using UnityEngine;

public sealed class Day61PlayerState : MonoBehaviour
{
    [Min(1)] [SerializeField] private int maxHp = 100;
    [Min(1)] [SerializeField] private int maxMana = 100;
    [SerializeField] private int hp = 100;
    [SerializeField] private int mana = 60;
    [SerializeField] private int level = 1;
    [SerializeField] private int gold = 100;

    public int MaxHp => maxHp;
    public int MaxMana => maxMana;
    public int HP => hp;
    public int Mana => mana;
    public int Level => level;
    public int Gold => gold;

    public Day61PlayerDto CreateSnapshot() => new Day61PlayerDto
    { hp = hp, mana = mana, level = level, gold = gold };

    public void ApplySnapshot(Day61PlayerDto state)
    {
        // 호출 전에 SaveValidator가 전부 검사했다고 가정합니다.
        hp = state.hp;
        mana = state.mana;
        level = state.level;
        gold = state.gold;
    }

    public bool ValidateSnapshot(Day61PlayerDto dto, out string error)
    {
        if (dto == null) { error = "Player 데이터 없음"; return false; }
        if (dto.hp < 0 || dto.hp > maxHp || dto.mana < 0 || dto.mana > maxMana ||
            dto.level < 1 || dto.level > 1000 || dto.gold < 0)
        { error = "Player 수치 범위 오류"; return false; }
        error = "OK";
        return true;
    }

    public void ResetDemo() { hp = maxHp; mana = 60; level = 1; gold = 100; }
    public void ChangeHP(int delta) => hp = Mathf.Clamp(hp + delta, 0, maxHp);
    public void ChangeGold(int delta) => gold = Mathf.Max(0, gold + delta);
    public void ChangeLevel(int delta) => level = Mathf.Clamp(level + delta, 1, 1000);
}
