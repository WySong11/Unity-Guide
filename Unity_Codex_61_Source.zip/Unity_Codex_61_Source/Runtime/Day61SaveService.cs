using System;
using System.IO;
using System.Text;
using UnityEngine;

public sealed class Day61SaveService : MonoBehaviour
{
    [SerializeField] private Day61PlayerState player;
    [SerializeField] private Day61Inventory inventory;
    [SerializeField] private Day61ItemCatalog catalog;
    [SerializeField] private string fileName = "day61_save.json";

    public string SavePath => Path.Combine(Application.persistentDataPath, fileName);

    private void Awake()
    {
        if (player == null) player = GetComponent<Day61PlayerState>();
        if (inventory == null) inventory = GetComponent<Day61Inventory>();
        if (catalog == null && inventory != null) catalog = inventory.Catalog;
    }

    private bool CanWork(out string reason)
    {
        if (player == null || inventory == null || catalog == null)
        { reason = "Player / Inventory / Catalog 참조 없음"; return false; }
        if (string.IsNullOrWhiteSpace(Application.persistentDataPath))
        { reason = "현재 플랫폼에서 persistentDataPath 사용 불가"; return false; }
        if (string.IsNullOrWhiteSpace(fileName) || fileName != Path.GetFileName(fileName))
        { reason = "fileName에는 파일명만 입력"; return false; }
        reason = "OK"; return true;
    }

    public Day61SaveData BuildSnapshot()
    {
        return new Day61SaveData
        {
            marker = Day61SaveValidator.Marker,
            version = Day61SaveValidator.Version,
            savedAtUtc = DateTime.UtcNow.ToString("o"),
            player = player.CreateSnapshot(),
            slots = inventory.CreateSnapshot(),
            equippedItemId = inventory.EquippedItemId
        };
    }

    public bool Save(out string message)
    {
        if (!CanWork(out message)) return false;
        string temp = SavePath + ".tmp";
        try
        {
            var snapshot = BuildSnapshot();
            if (!Day61SaveValidator.Validate(snapshot, catalog, inventory.Capacity,
                    player, out message)) return false;
            string json = JsonUtility.ToJson(snapshot, true);
            Directory.CreateDirectory(Application.persistentDataPath);
            File.WriteAllText(temp, json, new UTF8Encoding(false));
            if (File.Exists(SavePath))
                File.Replace(temp, SavePath, SavePath + ".bak");
            else
                File.Move(temp, SavePath);
            message = "저장 완료: " + SavePath;
            return true;
        }
        catch (Exception ex)
        {
            // File.Replace가 지원되지 않는 환경에서는 기존 파일을 건드리지 않고 실패합니다.
            // 플랫폼별 교체 정책은 테스트 후 별도로 구현하세요.
            message = "저장 실패 (원본을 확인하세요): " + ex.Message;
            Debug.LogWarning(message);
            return false;
        }
    }

    public bool ValidateJson(string json, out Day61SaveData valid, out string message)
    {
        valid = null;
        if (!CanWork(out message)) return false;
        if (string.IsNullOrWhiteSpace(json)) { message = "빈 JSON"; return false; }
        try
        {
            var parsed = JsonUtility.FromJson<Day61SaveData>(json);
            if (!Day61SaveValidator.Validate(parsed, catalog, inventory.Capacity,
                    player, out message)) return false;
            valid = parsed;
            return true;
        }
        catch (Exception ex)
        {
            message = "JSON 파싱 실패: " + ex.Message;
            return false;
        }
    }

    public bool Load(out string message)
    {
        if (!CanWork(out message)) return false;
        if (!File.Exists(SavePath)) { message = "저장 파일 없음"; return false; }
        try
        {
            string json = File.ReadAllText(SavePath, Encoding.UTF8);
            if (!ValidateJson(json, out var dto, out message)) return false;
            // 모든 검증을 통과한 뒤에만 실제 상태를 변경합니다.
            inventory.ApplySnapshot(dto.slots, dto.equippedItemId);
            player.ApplySnapshot(dto.player);
            message = "불러오기 완료";
            return true;
        }
        catch (Exception ex)
        {
            message = "파일 읽기/복원 실패: " + ex.Message;
            Debug.LogWarning(message);
            return false;
        }
    }
}
