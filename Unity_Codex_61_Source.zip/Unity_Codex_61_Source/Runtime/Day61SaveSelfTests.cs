using UnityEngine;

public static class Day61SaveSelfTests
{
    // 실습 중 현재 저장 파일을 수정하지 않는 순수 검증 테스트입니다.
    public static string Run(Day61SaveService service)
    {
        var snapshot = service.BuildSnapshot();
        string valid = JsonUtility.ToJson(snapshot);
        int passed = 0;
        if (service.ValidateJson(valid, out _, out _)) passed++;
        if (!service.ValidateJson("NOT_JSON", out _, out _)) passed++;

        snapshot.version = 999;
        if (!service.ValidateJson(JsonUtility.ToJson(snapshot), out _, out _)) passed++;
        snapshot.version = 2;

        snapshot.slots = new[]
        {
            new Day61SlotDto { index = 0, itemId = "unknown_id", quantity = 1 }
        };
        if (!service.ValidateJson(JsonUtility.ToJson(snapshot), out _, out _)) passed++;
        snapshot.slots = new[]
        {
            new Day61SlotDto { index = 0, itemId = "potion", quantity = 1 },
            new Day61SlotDto { index = 0, itemId = "gem", quantity = 1 }
        };
        if (!service.ValidateJson(JsonUtility.ToJson(snapshot), out _, out _)) passed++;
        snapshot.slots = new[]
        {
            new Day61SlotDto { index = 0, itemId = "potion", quantity = 999 }
        };
        if (!service.ValidateJson(JsonUtility.ToJson(snapshot), out _, out _)) passed++;

        string result = $"DTO 검사 {passed}/6 통과 (실제 파일은 변경하지 않음)";
        Debug.Log(result);
        return result;
    }
}
