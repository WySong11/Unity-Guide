using System;

[Serializable]
public sealed class Day61PlayerDto
{
    public int hp;
    public int mana;
    public int level;
    public int gold;
}

[Serializable]
public sealed class Day61SlotDto
{
    public int index;
    public string itemId;
    public int quantity;
}

[Serializable]
public sealed class Day61SaveData
{
    public string marker;
    public int version;
    public string savedAtUtc;
    public Day61PlayerDto player;
    public Day61SlotDto[] slots;
    public string equippedItemId;
}
