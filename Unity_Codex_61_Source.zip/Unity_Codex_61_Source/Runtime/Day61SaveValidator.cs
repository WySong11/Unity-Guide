using System;
using System.Collections.Generic;

public static class Day61SaveValidator
{
    public const string Marker = "UNITY_CODEX_61_SAVE";
    public const int Version = 2;

    public static bool Validate(Day61SaveData dto, Day61ItemCatalog catalog,
        int capacity, Day61PlayerState player, out string error)
    {
        if (dto == null || dto.marker != Marker || dto.version != Version)
        { error = "파일 종류 또는 저장 버전이 지원되지 않음"; return false; }
        if (catalog == null || player == null)
        { error = "Catalog 또는 Player 참조 없음"; return false; }
        if (!catalog.Validate(out error)) return false;
        if (!player.ValidateSnapshot(dto.player, out error)) return false;
        if (dto.slots == null || dto.slots.Length > capacity)
        { error = "저장 슬롯 목록 오류"; return false; }

        var seen = new HashSet<int>();
        bool equipInInventory = string.IsNullOrEmpty(dto.equippedItemId);
        foreach (var s in dto.slots)
        {
            if (s == null || s.index < 0 || s.index >= capacity || !seen.Add(s.index))
            { error = "중복 또는 범위 밖 슬롯"; return false; }
            var item = catalog.Find(s.itemId);
            if (item == null || s.quantity < 1 || s.quantity > item.MaxStack)
            { error = "알 수 없는 아이템 또는 스택 범위 오류"; return false; }
            if (s.itemId == dto.equippedItemId && item.Kind == Day61ItemKind.Equipment)
                equipInInventory = true;
        }
        if (!equipInInventory)
        { error = "장비 ID가 실제 인벤토리 장비와 일치하지 않음"; return false; }
        error = "OK";
        return true;
    }
}
