using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public sealed class Day61RuntimeSlot
{
    [SerializeField] private string itemId;
    [SerializeField] private int quantity;
    public string ItemId => itemId;
    public int Quantity => quantity;
    public bool Empty => string.IsNullOrEmpty(itemId) || quantity <= 0;
    internal void Set(string id, int count)
    { itemId = count > 0 ? id : ""; quantity = count > 0 ? count : 0; }
}

public sealed class Day61Inventory : MonoBehaviour
{
    [Range(1, 48)] [SerializeField] private int capacity = 12;
    [SerializeField] private Day61ItemCatalog catalog;
    [SerializeField] private List<Day61RuntimeSlot> slots = new List<Day61RuntimeSlot>();
    [SerializeField] private string equippedItemId = "";

    public int Capacity => capacity;
    public string EquippedItemId => equippedItemId;
    public Day61ItemCatalog Catalog => catalog;

    private void Awake() => EnsureSlots();

    private void EnsureSlots()
    {
        while (slots.Count < capacity) slots.Add(new Day61RuntimeSlot());
        if (slots.Count > capacity) slots.RemoveRange(capacity, slots.Count - capacity);
        for (int i = 0; i < slots.Count; i++)
            if (slots[i] == null) slots[i] = new Day61RuntimeSlot();
    }

    public Day61RuntimeSlot GetSlot(int index)
    { EnsureSlots(); return index >= 0 && index < slots.Count ? slots[index] : null; }

    public bool Contains(string itemId)
    {
        EnsureSlots();
        foreach (var s in slots) if (s.ItemId == itemId && !s.Empty) return true;
        return false;
    }

    public bool TryAdd(string itemId, int amount)
    {
        EnsureSlots();
        var item = catalog != null ? catalog.Find(itemId) : null;
        if (item == null || amount <= 0) return false;

        // 1) 공간을 먼저 계산하여 부분 획득을 방지합니다.
        int possible = 0;
        foreach (var s in slots)
        {
            if (s.Empty) possible += item.MaxStack;
            else if (s.ItemId == itemId) possible += item.MaxStack - s.Quantity;
            if (possible >= amount) break;
        }
        if (possible < amount) return false;

        int remaining = amount;
        foreach (var s in slots)
        {
            if (remaining == 0) break;
            if (s.Empty || s.ItemId != itemId) continue;
            int add = Mathf.Min(remaining, item.MaxStack - s.Quantity);
            if (add > 0) { s.Set(itemId, s.Quantity + add); remaining -= add; }
        }
        foreach (var s in slots)
        {
            if (remaining == 0) break;
            if (!s.Empty) continue;
            int add = Mathf.Min(remaining, item.MaxStack);
            s.Set(itemId, add);
            remaining -= add;
        }
        return remaining == 0;
    }

    public bool TryRemoveAt(int index, int amount)
    {
        var slot = GetSlot(index);
        if (slot == null || slot.Empty || amount <= 0 || amount > slot.Quantity) return false;
        string id = slot.ItemId;
        slot.Set(id, slot.Quantity - amount);
        if (id == equippedItemId && !Contains(id)) equippedItemId = "";
        return true;
    }

    public bool TryEquip(string itemId)
    {
        var item = catalog != null ? catalog.Find(itemId) : null;
        if (item == null || item.Kind != Day61ItemKind.Equipment || !Contains(itemId)) return false;
        equippedItemId = itemId;
        return true;
    }
    public void Unequip() => equippedItemId = "";

    public Day61SlotDto[] CreateSnapshot()
    {
        EnsureSlots();
        var saved = new List<Day61SlotDto>();
        for (int i = 0; i < slots.Count; i++)
        {
            if (slots[i].Empty) continue;
            saved.Add(new Day61SlotDto
            { index = i, itemId = slots[i].ItemId, quantity = slots[i].Quantity });
        }
        return saved.ToArray();
    }

    public void ApplySnapshot(Day61SlotDto[] data, string equipId)
    {
        // Validator에서 index, 수량, Catalog, 중복, 장비 ID를 검사한 후에 호출합니다.
        EnsureSlots();
        foreach (var s in slots) s.Set("", 0);
        foreach (var slot in data) slots[slot.index].Set(slot.itemId, slot.quantity);
        equippedItemId = equipId ?? "";
    }

    public void ResetDemo()
    {
        EnsureSlots();
        foreach (var s in slots) s.Set("", 0);
        equippedItemId = "";
        TryAdd("potion", 3);
        TryAdd("gem", 5);
        TryAdd("sword", 1);
        TryEquip("sword");
    }
}
