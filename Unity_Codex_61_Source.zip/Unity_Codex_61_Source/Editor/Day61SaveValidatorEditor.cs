#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

public static class Day61SaveValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day61/Validate Current Lab")]
    private static void Validate()
    {
        var player = Object.FindFirstObjectByType<Day61PlayerState>();
        var inventory = Object.FindFirstObjectByType<Day61Inventory>();
        var saver = Object.FindFirstObjectByType<Day61SaveService>();
        if (player == null || inventory == null || saver == null || inventory.Catalog == null)
        {
            Debug.LogError("[Day61] Scene에 Player, Inventory, SaveService, Catalog가 필요합니다.");
            return;
        }
        if (!inventory.Catalog.Validate(out string error))
        {
            Debug.LogError("[Day61] Catalog 문제: " + error);
            return;
        }
        var snapshot = saver.BuildSnapshot();
        if (!Day61SaveValidator.Validate(snapshot, inventory.Catalog, inventory.Capacity, player, out error))
        {
            Debug.LogError("[Day61] 저장 스냅샷 문제: " + error);
            return;
        }
        Debug.Log("[Day61] Catalog + Snapshot 검사 통과. 실제 File I/O와 Play Mode는 별도 테스트 필요.");
    }
}
#endif
