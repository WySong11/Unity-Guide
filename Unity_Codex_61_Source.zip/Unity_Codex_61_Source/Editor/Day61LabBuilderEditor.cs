#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class Day61LabBuilderEditor
{
    private const string Menu = "Tools/Unity Codex/Day61/Create JSON Save Lab";

    [MenuItem(Menu)]
    private static void Build()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        string folderName = "Day61_JSON_Lab";
        int suffix = 2;
        while (AssetDatabase.IsValidFolder("Assets/" + folderName))
            folderName = "Day61_JSON_Lab_" + suffix++;
        AssetDatabase.CreateFolder("Assets", folderName);
        string root = "Assets/" + folderName;
        AssetDatabase.CreateFolder(root, "Data");
        AssetDatabase.CreateFolder(root, "Scenes");

        Day61ItemData potion = CreateItem(root + "/Data", "Potion", "potion", "HP Potion", Day61ItemKind.Consumable, 5);
        Day61ItemData gem = CreateItem(root + "/Data", "Gem", "gem", "Blue Gem", Day61ItemKind.Material, 20);
        Day61ItemData sword = CreateItem(root + "/Data", "Sword", "sword", "Training Sword", Day61ItemKind.Equipment, 1);
        Day61ItemCatalog catalog = ScriptableObject.CreateInstance<Day61ItemCatalog>();
        AssetDatabase.CreateAsset(catalog, root + "/Data/ItemCatalog.asset");
        var c = new SerializedObject(catalog);
        var arr = c.FindProperty("items");
        arr.arraySize = 3;
        arr.GetArrayElementAtIndex(0).objectReferenceValue = potion;
        arr.GetArrayElementAtIndex(1).objectReferenceValue = gem;
        arr.GetArrayElementAtIndex(2).objectReferenceValue = sword;
        c.ApplyModifiedPropertiesWithoutUndo();

        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        var floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
        floor.name = "Floor";
        floor.transform.localScale = new Vector3(12f, 0.3f, 8f);
        floor.transform.position = new Vector3(0f, -0.2f, 0f);

        var go = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        go.name = "Player_Day61";
        go.transform.position = new Vector3(0f, 1f, 0f);
        var player = go.AddComponent<Day61PlayerState>();
        var inventory = go.AddComponent<Day61Inventory>();
        var save = go.AddComponent<Day61SaveService>();
        var hud = go.AddComponent<Day61DemoHUD>();

        var i = new SerializedObject(inventory);
        i.FindProperty("catalog").objectReferenceValue = catalog;
        i.ApplyModifiedPropertiesWithoutUndo();
        var s = new SerializedObject(save);
        s.FindProperty("player").objectReferenceValue = player;
        s.FindProperty("inventory").objectReferenceValue = inventory;
        s.FindProperty("catalog").objectReferenceValue = catalog;
        s.ApplyModifiedPropertiesWithoutUndo();
        var h = new SerializedObject(hud);
        h.FindProperty("player").objectReferenceValue = player;
        h.FindProperty("inventory").objectReferenceValue = inventory;
        h.FindProperty("saveService").objectReferenceValue = save;
        h.ApplyModifiedPropertiesWithoutUndo();

        if (Camera.main != null)
        {
            Camera.main.transform.position = new Vector3(0f, 6f, -9f);
            Camera.main.transform.LookAt(new Vector3(0f, 1f, 0f));
        }
        EditorSceneManager.SaveScene(scene, root + "/Scenes/Day61_JSONSaveLab.unity");
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        EditorUtility.DisplayDialog("Day61 JSON Lab", "새 실습 폴더, 아이템 3종, Catalog, Scene 생성 완료:\n" + root, "OK");
    }

    private static Day61ItemData CreateItem(string folder, string assetName, string id,
        string displayName, Day61ItemKind kind, int stack)
    {
        var item = ScriptableObject.CreateInstance<Day61ItemData>();
        AssetDatabase.CreateAsset(item, folder + "/" + assetName + ".asset");
        var s = new SerializedObject(item);
        s.FindProperty("itemId").stringValue = id;
        s.FindProperty("displayName").stringValue = displayName;
        s.FindProperty("kind").enumValueIndex = (int)kind;
        s.FindProperty("maxStack").intValue = stack;
        s.ApplyModifiedPropertiesWithoutUndo();
        return item;
    }
}
#endif
