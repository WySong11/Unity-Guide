# Unity × Codex | 61일차 — JSON 저장과 불러오기

- 권장: Unity 6.3 · 3D URP/3D 프로젝트 · 120분 · 44슬라이드.
- 이 소스는 **독립 실습**으로 동작하도록 `Day61` 접두사만 사용합니다. 60일차 컴포넌트 및 프로젝트 원본을 덮어쓰지 않습니다.
- `Runtime/*.cs`는 `Assets/Scripts/Day61/`에, `Editor/*.cs`는 `Assets/Editor/Day61/`에 복사합니다.

## 실행 단계

1. Unity 프로젝트를 열어 컴파일이 완료되었는지 확인합니다.
2. **Tools → Unity Codex → Day61 → Create JSON Save Lab** 실행. 새 `Assets/Day61_JSON_Lab[_N]` 폴더가 생성됩니다.
3. 생성된 `Day61_JSONSaveLab` 씬을 열고 Play를 누릅니다.
4. HUD의 `HP -25`, `Gold +20`, `Potion +2` 등을 눌러 상태를 변경한 뒤 **SAVE**를 누릅니다.
5. 추가로 값을 변경한 뒤 **LOAD**를 눌러 저장 시점으로 복원되는지 확인합니다.
6. `JSON 검증 테스트` 버튼은 실제 저장 파일을 변경하지 않고 **정상 JSON / 문법 오류 / 버전 불일치 / 잘못된 ID / 중복 슬롯 / 스택 초과** 6가지를 검사합니다.
7. 콘솔/GUI의 실제 `SavePath`에서 `day61_save.json`, 2회 저장 후 `day61_save.json.bak` 확인.
8. **Tools → Unity Codex → Day61 → Validate Current Lab**로 씬 구성과 스냅샷 검사.

## 구조

- `Day61ItemData`, `Day61ItemCatalog`: 고유 ID 및 MaxStack을 제공하는 **정의용 SO**.
- `Day61PlayerState`, `Day61Inventory`: 플레이어별 **변경되는 런타임 상태**.
- `Day61SaveDto`: `[Serializable]` 필드로만 구성된 **저장용 DTO**.
- `Day61SaveValidator`: marker/version, Player 범위, 슬롯 인덱스, 중복, Catalog ID, MaxStack 및 장착 ID 사전 검증.
- `Day61SaveService`: 스냅샷, `JsonUtility.ToJson` / `FromJson`, `Application.persistentDataPath`, 파일 IO.
- `Day61DemoHUD`: UI 테스트 버튼.
- `Day61SaveSelfTests`: 저장 파일을 건드리지 않는 DTO 검증 테스트.

## 중요한 설계 제약

- `JsonUtility`는 Unity 직렬화 규칙을 사용합니다. `Dictionary<>`나 속성만으로 이루어진 타입은 직접 직렬화할 수 없습니다. 배열·List는 직렬화 가능한 **루트 Wrapper 클래스**에 담아 사용합니다.
- `JsonUtility.FromJson<T>`는 일반 DTO를 대상으로 합니다. `MonoBehaviour`나 `ScriptableObject`를 새로 만드는 데 사용할 수 없습니다.
- 저장하는 것은 `ItemData` 객체가 아니라 `itemId`, `quantity`, `index`입니다. 로드 시 Catalog를 통해 검증합니다.
- 버전 2만 지원합니다. 다른 버전은 거절합니다. 자동 마이그레이션은 **구현하지 않았습니다**.
- `File.Replace`는 기존 파일을 교체하며 `.bak`에 백업을 남깁니다. **플랫폼별 지원/파일 시스템 특성을 확인해야 하며, 모든 플랫폼에서 완전한 원자성을 보장하지 않습니다.** 교체 지원이 없으면 성공으로 처리하지 않습니다.
- JSON은 **암호화·무결성 인증이 적용되지 않은 평문**입니다. 보안이 필요한 계정/서버 데이터에는 적합하지 않습니다.
- 실제 Save/Load 실패 시 현재 런타임 상태를 가능한 유지하도록 검증 후 적용하지만, 모든 예외 상황의 트랜잭션 보장을 주장하지 않습니다.
- Play Mode, 모바일 기기, 에디터 컴파일은 사용자 환경에서 검증해야 합니다.

## 60일차 프로젝트에 통합할 때

1. 기존 `Day60SaveSystem`과 새 `Day61SaveService`를 동시에 같은 파일 이름에 쓰지 않습니다. 새 서비스는 별도 `day61_save.json` 사용.
2. 기존 `Day60Stats/Day60Inventory`의 스냅샷을 `Day61PlayerDto/Day61SlotDto` 형식으로 변환하는 어댑터를 작성합니다.
3. 장착 아이템·ID·MaxStack의 의미를 Day60 Catalog와 맞춥니다. 기존 데이터 파일을 자동 변환하지 않습니다.
4. 저장 스키마 버전 정책을 정한 뒤, 로드 전 전수 검증과 회귀 테스트를 적용합니다.

Unity 공식 문서: https://docs.unity3d.com/kr/current/Manual/json-serialization.html

저장 경로: https://docs.unity3d.com/kr/current/ScriptReference/Application-persistentDataPath.html
