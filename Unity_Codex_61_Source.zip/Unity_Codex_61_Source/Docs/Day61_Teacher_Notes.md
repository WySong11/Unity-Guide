# 61일차 강사용 수업 노트 · 120분

## 00~25분: 직렬화의 데이터 경계

- Scene/Prefab/SO 에셋 정의와 Runtime State, Save DTO를 비교합니다.
- `JsonUtility.ToJson`, `JsonUtility.FromJson<T>`, `[Serializable]`와 **필드 직렬화**를 설명합니다.
- `Dictionary<>`·속성·루트 배열 사용의 제약을 시연합니다.
- 임의의 JSON 파일이 빈 필드를 가진 DTO로 역직렬화될 수 있으므로 **marker와 version을 반드시 검사**해야 합니다.

## 25~60분: Save 만들기

- `BuildSnapshot()`에서 Player / Slots / Equipped ID를 DTO로 복제합니다.
- `JsonUtility.ToJson(dto, true)` 후 `persistentDataPath` 아래 `day61_save.json`으로 저장합니다.
- 첫 저장은 File.Move, 기존 파일은 File.Replace로 교체하며 `.bak` 백업을 생성합니다.
- 파일 갱신과 백업의 실제 동작은 플랫폼별로 차이가 있으므로 WebGL·Android는 실기기에서 검증합니다.

## 60~100분: Load·검증

- `File.Exists` → `File.ReadAllText` → `FromJson` → `Validate` → `ApplySnapshot`.
- 버전·ID·중복 슬롯·수량·장비 ID·플레이어 값 오류를 모두 사전에 거절합니다.
- 기존 JSON에 대한 v1→v2 **마이그레이션은 구현하지 않았고** 수업에서 설계만 소개합니다.
- `Day61SaveSelfTests`는 파일에 쓰지 않고 DTO 문자열 6개를 검사합니다.

## 100~120분: 테스트·평가

- T01~T12 체크리스트와 100점 루브릭을 사용합니다.
- Save/Load 전후 Player와 Inventory를 캡처해 정확히 같은지 비교합니다.
- `File.Replace` 지원 여부 및 예외 메시지는 대상 OS마다 실제로 점검합니다.
- 빌드하지 않은 기기의 결과를 `PASS`로 표시하지 않습니다.

## 60일차와 연결 포인트

- 기존 `Day60SaveSystem`과의 공존이 필요하다면 **다른 파일명**을 사용하거나 한 서비스만 활성화합니다.
- `Day60DataCatalog`의 ItemId·MaxStack과 Day61 SlotDto의 제약을 맞춥니다.
- 필요하면 `Day60Inventory`의 snapshot/restore API를 작성하되, 데이터를 전부 검증한 뒤 적용합니다.

## 공식 참고 자료

- Unity JSON 직렬화: https://docs.unity3d.com/kr/current/Manual/json-serialization.html
- persistentDataPath: https://docs.unity3d.com/kr/current/ScriptReference/Application-persistentDataPath.html
