# 61일차 학생 실습 워크시트

**학습 목표:** Runtime → DTO → JSON → 파일 → DTO 검사 → Runtime 복원.

1. `ScriptableObject`와 `[Serializable]` DTO가 각각 저장하는 항목을 표로 정리한다.
2. `Application.persistentDataPath`의 실제 Editor 경로를 Console로 확인한다.
3. HP를 70, Gold를 120으로 설정한 다음 SAVE를 눌러 JSON을 연다.
4. HP 20, Gold 0으로 변경한 다음 LOAD 후 기대값을 기록한다.
5. Potion 수량 변경/복원을 테스트한다.
6. Sword 장착 여부 저장/복원을 테스트한다.
7. `JSON 검증 테스트` 버튼 결과를 기록한다.
8. 저장 파일을 안전하게 복사한 후, 복사본에서 버전 오류·중복 슬롯 JSON을 작성해 검증 로직을 살펴본다.
9. `File.Replace`가 지원되지 않는 플랫폼에서 현재 구현의 결과를 예측한다.
10. Codex를 사용해 관련 코드 diff와 테스트 계획을 제출한다.

제출: 실습 씬 스크린샷, JSON 샘플, 경로 로그, 테스트 체크리스트, Codex 사용 기록.
