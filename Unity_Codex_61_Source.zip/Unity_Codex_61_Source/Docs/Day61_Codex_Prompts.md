# Codex 실습 프롬프트

## 1) 설계 및 컴파일 점검

```
Unity 6.3 프로젝트의 Day61 JSON 저장 시스템을 검토해줘.
1. JsonUtility가 직렬화하지 못하는 필드/자료형 찾기.
2. Save DTO에 UnityEngine.Object 참조가 포함되었는지 점검.
3. SaveService의 참조, 경로, 예외 처리, 백업 정책 점검.
4. FindFirstObjectByType 및 Editor 스크립트 배치 확인.
5. 코드를 변경하기 전 원인과 재현 순서부터 보고해줘.
```

## 2) 복원 원자성 검토

```
Day61SaveService.Load에서 버전 오류, 중복 슬롯, 잘못된 ItemId,
수량 초과, 장비 ID 불일치, player HP 범위 오류가 있을 때
PlayerState/Inventory가 변경되지 않는지 테스트해줘.
테스트하지 않은 항목은 UNTESTED로 기록하고 실제 Console 로그를 첨부해줘.
```

## 3) 60일차 프로젝트와 연결

```
Day60Stats, Day60Inventory, Day60ItemData, Day60EquipmentController의
현재 인터페이스를 확인하고 Day61 DTO 기반 Save/Load 어댑터를 설계해줘.
기존 스크립트 변경을 최소화하고 클래스 중복 및 저장 형식 충돌을 피하며,
적용 전후 diff와 회귀 테스트 절차를 보여줘.
```

## 4) 플랫폼별 파일 검증

```
Editor/Windows/Android에서 persistentDataPath 값을 실측하고
File.Replace 지원 여부 및 .tmp/.bak 처리 결과를 확인해줘.
저장 파일의 삭제/변조 테스트는 원본을 먼저 복사하고 수행해줘.
플랫폼 테스트를 실제 실행하지 않았다면 PASS로 표시하지 마.
```
