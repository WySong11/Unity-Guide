using UnityEngine;
using WaveGuard.Performance;

// 최소 예제: 거리 탐지 주기만 분리. 차폐/시야각/기존 FSM 연결은 프로젝트에 맞춰 추가.
public sealed class TimedEnemyPerception2D : MonoBehaviour
{
    [SerializeField] private Transform target;
    [SerializeField, Min(0.01f)] private float senseInterval = 0.15f;
    [SerializeField, Min(0f)] private float detectionRadius = 5f;

    public bool TargetInRange { get; private set; }
    private PerceptionTickPolicy _policy;

    private void Awake()
    {
        _policy = new PerceptionTickPolicy(Mathf.Max(0.01f, senseInterval));
    }

    private void OnEnable()
    {
        _policy?.Reset(); // Pool에서 재활성화할 때 탐지 시점 초기화
    }

    private void Update()
    {
        if (target == null) { TargetInRange = false; return; }
        if (!_policy.ShouldRun(Time.time)) return;

        Vector2 difference = target.position - transform.position;
        TargetInRange = difference.sqrMagnitude <= detectionRadius * detectionRadius;
    }
}
