using System;

namespace WaveGuard.Performance
{
    // 주기적 탐지 여부를 판정하는 순수 C# 클래스 (Unity 의존성 없음)
    public sealed class PerceptionTickPolicy
    {
        public float Interval { get; }
        private float _nextTime;
        private bool _firstTick = true;

        public PerceptionTickPolicy(float interval)
        {
            if (interval <= 0f || float.IsNaN(interval) || float.IsInfinity(interval))
                throw new ArgumentOutOfRangeException(nameof(interval));
            Interval = interval;
        }

        public bool ShouldRun(float now)
        {
            if (float.IsNaN(now) || float.IsInfinity(now))
                throw new ArgumentOutOfRangeException(nameof(now));

            if (!_firstTick && now < _nextTime)
                return false;

            _firstTick = false;
            _nextTime = now + Interval;
            return true;
        }

        public void Reset() { _firstTick = true; _nextTime = 0f; }
    }
}
