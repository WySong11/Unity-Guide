using System.Collections.Generic;
using UnityEngine;

// Unity 6 / Physics2D.OverlapCircle: 결과 List를 재사용해 빈번한 배열 할당을 줄이는 예제.
public sealed class CachedOverlapQuery2D : MonoBehaviour
{
    [SerializeField] private LayerMask targetLayers;
    [SerializeField, Min(0f)] private float radius = 2f;
    [SerializeField, Min(1)] private int initialCapacity = 32;

    private List<Collider2D> _results;
    private ContactFilter2D _filter;

    public IReadOnlyList<Collider2D> Results => _results;

    private void Awake()
    {
        _results = new List<Collider2D>(initialCapacity);
        _filter = new ContactFilter2D();
        _filter.SetLayerMask(targetLayers);
    }

    public int Scan(Vector2 center)
    {
        // _results가 Capacity를 초과해 커지면 추가 할당이 발생할 수 있음.
        return Physics2D.OverlapCircle(center, radius, _filter, _results);
    }
}
