# UNITY × CODEX | Day 93 — 성능 최적화 실습 자료

환경: Unity 6.3 (6000.3) / 2D / URP / Test Framework (NUnit)

1. Scripts/PerceptionTickPolicy.cs는 Unity 엔진 의존성 없는 주기 판정 로직입니다.
2. Scripts/TimedEnemyPerception2D.cs는 Transform 거리 기반 탐지의 교육용 최소 예제입니다. 기존 Enemy FSM을 대체하는 완성형 AI가 아닙니다. 시야각·가림막·공격 조건은 별도입니다.
3. Scripts/CachedOverlapQuery2D.cs는 Unity 6의 Physics2D.OverlapCircle 결과 List 재사용 패턴을 설명합니다. Capacity 초과 시 List 확장이 발생할 수 있고, Collider 중복 필터링은 호출 측에서 처리해야 합니다.
4. Tests/PerceptionTickPolicyTests.cs는 Unity Test Framework EditMode 테스트 Assembly에 넣으세요. .asmdef에서 테스트 어셈블리의 참조 관계를 구성하세요.
5. Templates/*.md, TEST_CASES.csv는 수강생이 **직접 측정한 숫자**와 **실제 수행 결과**를 기입할 빈 서식입니다.

실습 시 유의:
- 성능 비교는 같은 기기, Build Profile, 씬, 게임 상태로 여러 번 수행해야 합니다.
- Development Build는 계측 오버헤드가 있으므로 Release Build 체감 성능과 구분합니다.
- Time.time 기반 스케줄러는 Time.timeScale=0 동안 멈춥니다. 이것이 의도한 Pause 동작인지 확인하세요.
- Profiler 숫자 없이 속도 개선 효과를 보장하거나 PASS로 표시하지 마세요.
- 실제 Unity 에디터에서 이 예제의 컴파일·테스트는 실행하지 않았습니다.

공식 참고: https://docs.unity3d.com/kr/current/Manual/Profiler.html
