using NUnit.Framework;
using WaveGuard.Performance;

public class PerceptionTickPolicyTests
{
    [Test]
    public void FirstTick_RunsImmediately()
    {
        var policy = new PerceptionTickPolicy(0.15f);
        Assert.That(policy.ShouldRun(0f), Is.True);
    }

    [Test]
    public void BeforeInterval_DoesNotRun()
    {
        var policy = new PerceptionTickPolicy(0.15f);
        policy.ShouldRun(0f);
        Assert.That(policy.ShouldRun(0.10f), Is.False);
    }

    [Test]
    public void AfterInterval_RunsAgain()
    {
        var policy = new PerceptionTickPolicy(0.15f);
        policy.ShouldRun(0f);
        Assert.That(policy.ShouldRun(0.16f), Is.True);
    }

    [Test]
    public void Reset_AllowsImmediateScan()
    {
        var policy = new PerceptionTickPolicy(0.15f);
        policy.ShouldRun(0f);
        policy.Reset();
        Assert.That(policy.ShouldRun(0.01f), Is.True);
    }

    [Test]
    public void NonPositiveInterval_Throws()
    {
        Assert.Throws<System.ArgumentOutOfRangeException>(() => new PerceptionTickPolicy(0f));
    }
}
