# Day 93 | Codex 최적화 프롬프트

## 1. 읽기 전용 진단
WAVE GUARD Unity 6.3 프로젝트를 읽기 전용으로 분석해줘. PERF_BASELINE.md와 첨부 Profiler 수치를 기반으로 CPU Main/GC Alloc/Memory 병목을 파일과 메서드로 연결하고, 증거와 추측을 구분해. 코드는 수정하지 말고 가장 가치가 높은 작은 변경 1개를 추천해줘.

## 2. 최소 수정
제공한 Profiler 근거에 따라 승인된 병목 1개만 최적화해줘. 기존 public API, SerializeField 이름, PlayerHealth/EnemyHealth 이벤트, Wave 완료 조건은 보존해. 테스트를 실행하고 git diff를 점검한 뒤 변경 파일·검증 결과·남은 위험을 보고해. 미실행 테스트를 PASS라고 하지 마.

## 3. 독립 검증
Before/After Profiler 원본, PERF_RESULTS.md, Git diff, EditMode/PlayMode 결과를 대조해줘. 동일한 기기·씬·품질·측정 구간인지 검사하고, CPU/GC/Memory 변화와 기능 회귀를 분리해 보고해. 실행되지 않은 항목은 미검증으로 표시해줘.
