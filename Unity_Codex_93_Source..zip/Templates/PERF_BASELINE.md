# PERF_BASELINE — Day 93

- Unity Version: 6000.3.x / 기재: __________
- Git commit (before): __________
- Target / OS / Device: __________
- Build: Development Build / Deep Profiling OFF
- Scene / Wave / Enemy Count: __________
- Resolution / Graphics / VSync / Target FPS: __________
- Warm-up / Measurement duration / Runs: __________

| Run | CPU Main median (ms) | Worst frame (ms) | GC Alloc avg (B/frame) | Managed Memory (MB) | Notes |
| --- | ---: | ---: | ---: | ---: | --- |
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |

Profiler 원본 파일 / 스크린샷 경로:

확인된 병목 샘플 및 근거(파일·함수·Calls·Self ms):

추측(미검증):
