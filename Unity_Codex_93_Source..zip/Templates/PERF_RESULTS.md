# PERF_RESULTS — Day 93

| KPI | Before | After | Improvement / Change | Evidence |
| --- | ---: | ---: | ---: | --- |
| CPU Main median (ms) | | | | |
| GC Alloc average (B/frame) | | | | |
| Managed Memory (MB) | | | | |
| Worst frame (ms) | | | | |
| Spawns / Kills / Wave Clear correctness | | | | |

## Measurement equivalence
- Same device, build profile, scene, wave, enemy count, quality, time window? __________
- Performance capture locations: __________

## Regression
- EditMode run/execution evidence: __________
- PlayMode run/execution evidence: __________
- Windows/Android smoke test evidence: __________

## Decision
- Accept / Reject / Need more data: __________
- Remaining risks / Unverified items: __________
