using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

public class Day49DebugDamageEnemy : MonoBehaviour
{
    [SerializeField] private Day49EnemyHealth enemy;
    [SerializeField, Min(1)] private int damage = 10;
    private void Awake()
    {
        if (enemy == null) enemy = FindFirstObjectByType<Day49EnemyHealth>();
    }
    private void Update()
    {
#if ENABLE_INPUT_SYSTEM
        if (enemy != null && Keyboard.current != null && Keyboard.current.kKey.wasPressedThisFrame)
            enemy.TakeDamage(damage);
#endif
    }
}
