// Day49: 유한 상태 머신(FSM)의 상태 정의
public enum Day49EnemyState
{
    Patrol,
    Chase,
    Attack,
    Return,
    Dead
}
