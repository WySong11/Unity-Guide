using UnityEngine;

public class Day49EnemyAttack : MonoBehaviour
{
    [SerializeField, Min(1)] private int damage = 10;
    [SerializeField, Min(0.1f)] private float cooldown = 1.2f;
    [SerializeField, Min(0.1f)] private float attackRange = 1.8f;
    private float nextAttackAt;
    public float AttackRange => attackRange;
    public float CooldownLeft => Mathf.Max(0f, nextAttackAt - Time.time);

    public bool TryAttack(Transform target)
    {
        if (target == null || Time.time < nextAttackAt) return false;
        if (Vector3.Distance(transform.position, target.position) > attackRange) return false;
        // 실습용 즉시 피해. 실게임은 Animation Event에 피해 시점을 연결할 수 있습니다.
        var health = target.GetComponent<IDay49Damageable>();
        if (health == null) health = target.GetComponentInParent<IDay49Damageable>();
        if (health == null) return false;
        nextAttackAt = Time.time + cooldown;
        health.TakeDamage(damage);
        return true;
    }
}
