using System;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent), typeof(Day49EnemyPerception), typeof(Day49EnemyHealth))]
public class Day49EnemyBrain : MonoBehaviour
{
    [Header("Target / Waypoints")]
    [SerializeField] private Transform player;
    [SerializeField] private Transform[] patrolPoints;
    [Header("Behaviour")]
    [SerializeField, Min(0.1f)] private float chaseRange = 8f;
    [SerializeField, Min(0.1f)] private float leashDistance = 13f;
    [SerializeField, Min(0.1f)] private float lostTargetDelay = 1.5f;
    [SerializeField, Min(0f)] private float patrolWait = 0.7f;
    [SerializeField, Min(0.05f)] private float repathInterval = 0.2f;
    [SerializeField, Min(0.05f)] private float waypointThreshold = 0.45f;
    [SerializeField, Min(0.05f)] private float attackExitPadding = 0.45f;
    [Header("Movement")]
    [SerializeField, Min(0.1f)] private float patrolSpeed = 2.2f;
    [SerializeField, Min(0.1f)] private float chaseSpeed = 4.0f;

    private NavMeshAgent agent;
    private Day49EnemyPerception perception;
    private Day49EnemyHealth health;
    private Day49EnemyAttack attack;
    private Vector3 spawnPoint;
    private int waypointIndex;
    private float nextRepathAt;
    private float lastSeenAt = float.NegativeInfinity;
    private float patrolResumeAt;
    private bool waypointWaiting;

    public Day49EnemyState CurrentState { get; private set; } = Day49EnemyState.Patrol;
    public Transform Player => player;
    public event Action<Day49EnemyState> StateChanged;

    public void SetPlayer(Transform target) => player = target;
    public void SetPatrolPoints(Transform[] points) => patrolPoints = points;

    private void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        perception = GetComponent<Day49EnemyPerception>();
        health = GetComponent<Day49EnemyHealth>();
        attack = GetComponent<Day49EnemyAttack>();
        spawnPoint = transform.position;
        if (attack == null) Debug.LogWarning("[Day49] Day49EnemyAttack 컴포넌트를 추가하세요.", this);
    }

    private void OnEnable()
    {
        if (health != null) health.Died += HandleDeath;
    }
    private void OnDisable()
    {
        if (health != null) health.Died -= HandleDeath;
    }

    private void Start() { EnterState(Day49EnemyState.Patrol, true); }

    private void Update()
    {
        if (CurrentState == Day49EnemyState.Dead) return;
        if (!agent.isOnNavMesh) return; // NavMesh Surface Bake 여부를 검사하세요.

        bool visible = player != null && perception.CanSee(player);
        float playerDist = player == null ? float.PositiveInfinity :
            Vector3.Distance(transform.position, player.position);
        if (visible) lastSeenAt = Time.time;

        // 추적 범위를 벗어나면 복귀: 무한 추격 방지
        if ((CurrentState == Day49EnemyState.Chase || CurrentState == Day49EnemyState.Attack) &&
            Vector3.Distance(transform.position, spawnPoint) > leashDistance)
        {
            EnterState(Day49EnemyState.Return);
        }

        switch (CurrentState)
        {
            case Day49EnemyState.Patrol:
                if (visible && playerDist <= chaseRange) EnterState(Day49EnemyState.Chase);
                else UpdatePatrol();
                break;
            case Day49EnemyState.Chase:
                if (Time.time - lastSeenAt >= lostTargetDelay) EnterState(Day49EnemyState.Return);
                else if (attack != null && visible && playerDist <= attack.AttackRange)
                    EnterState(Day49EnemyState.Attack);
                else if (player != null) Navigate(player.position, chaseSpeed);
                break;
            case Day49EnemyState.Attack:
                if (Time.time - lastSeenAt >= lostTargetDelay) EnterState(Day49EnemyState.Return);
                else if (!visible || attack == null || playerDist > attack.AttackRange + attackExitPadding)
                    EnterState(Day49EnemyState.Chase);
                else
                {
                    StopAgent();
                    FacePlayer();
                    attack.TryAttack(player);
                }
                break;
            case Day49EnemyState.Return:
                Navigate(spawnPoint, patrolSpeed);
                if ((!agent.pathPending && ReachedDestination(waypointThreshold)) ||
                    Vector3.Distance(transform.position, spawnPoint) <= waypointThreshold)
                    EnterState(Day49EnemyState.Patrol);
                break;
        }
    }

    private void UpdatePatrol()
    {
        if (patrolPoints == null || patrolPoints.Length == 0)
        {
            StopAgent(); return;
        }
        Transform waypoint = patrolPoints[waypointIndex % patrolPoints.Length];
        if (waypoint == null) return;
        if (waypointWaiting)
        {
            StopAgent();
            if (Time.time >= patrolResumeAt)
            {
                waypointIndex = (waypointIndex + 1) % patrolPoints.Length;
                waypointWaiting = false;
            }
            return;
        }
        Navigate(waypoint.position, patrolSpeed);
        if (ReachedDestination(waypointThreshold) ||
            (!agent.pathPending && Vector3.Distance(transform.position, waypoint.position) <= waypointThreshold))
        {
            waypointWaiting = true;
            patrolResumeAt = Time.time + patrolWait;
        }
    }

    private void Navigate(Vector3 destination, float speed)
    {
        if (!agent.isOnNavMesh) return;
        agent.isStopped = false;
        agent.speed = speed;
        if (Time.time < nextRepathAt) return;
        nextRepathAt = Time.time + repathInterval;
        if (!agent.SetDestination(destination))
            Debug.LogWarning("[Day49] NavMesh 목적지 설정 실패", this);
    }

    private bool ReachedDestination(float threshold)
    {
        return agent.isOnNavMesh && !agent.pathPending && agent.hasPath &&
            !float.IsInfinity(agent.remainingDistance) &&
            agent.remainingDistance <= Mathf.Max(agent.stoppingDistance, threshold);
    }

    private void StopAgent()
    {
        if (!agent.isOnNavMesh) return;
        agent.isStopped = true;
        agent.ResetPath();
    }

    private void FacePlayer()
    {
        if (player == null) return;
        Vector3 direction = player.position - transform.position;
        direction.y = 0f;
        if (direction.sqrMagnitude < 0.001f) return;
        transform.rotation = Quaternion.RotateTowards(transform.rotation,
            Quaternion.LookRotation(direction), 400f * Time.deltaTime);
    }

    private void EnterState(Day49EnemyState next, bool force = false)
    {
        if (!force && CurrentState == next) return;
        CurrentState = next;
        nextRepathAt = 0f;
        if (next == Day49EnemyState.Patrol)
        {
            waypointWaiting = false;
            if (agent.isOnNavMesh) agent.ResetPath();
        }
        if (next == Day49EnemyState.Attack || next == Day49EnemyState.Dead)
            StopAgent();
        StateChanged?.Invoke(next);
    }

    private void HandleDeath() { EnterState(Day49EnemyState.Dead); }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(Application.isPlaying ? spawnPoint : transform.position, leashDistance);
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, chaseRange);
    }
}
