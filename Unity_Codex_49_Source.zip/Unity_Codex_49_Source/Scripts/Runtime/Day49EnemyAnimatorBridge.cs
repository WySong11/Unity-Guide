using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(Day49EnemyBrain))]
public class Day49EnemyAnimatorBridge : MonoBehaviour
{
    [SerializeField] private Animator animator;
    [SerializeField] private string speedParameter = "Speed";
    [SerializeField] private string deadParameter = "Dead";
    private NavMeshAgent agent;
    private Day49EnemyBrain brain;

    private void Awake()
    {
        if (animator == null) animator = GetComponentInChildren<Animator>();
        agent = GetComponent<NavMeshAgent>();
        brain = GetComponent<Day49EnemyBrain>();
    }
    private void OnEnable() { if (brain != null) brain.StateChanged += OnStateChanged; }
    private void OnDisable() { if (brain != null) brain.StateChanged -= OnStateChanged; }
    private void Update()
    {
        if (animator != null)
            animator.SetFloat(speedParameter, agent != null && agent.isOnNavMesh ? agent.velocity.magnitude : 0f);
    }
    private void OnStateChanged(Day49EnemyState state)
    {
        if (animator != null && state == Day49EnemyState.Dead)
            animator.SetTrigger(deadParameter);
    }
}
