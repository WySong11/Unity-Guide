using UnityEngine;
using UnityEngine.AI;

public class Day49AIDiagnostics : MonoBehaviour
{
    [SerializeField] private Day49EnemyBrain brain;
    [SerializeField] private Day49EnemyPerception perception;
    [SerializeField] private NavMeshAgent agent;
    private void Awake()
    {
        if (brain == null) brain = FindFirstObjectByType<Day49EnemyBrain>();
        if (brain != null)
        {
            if (perception == null) perception = brain.GetComponent<Day49EnemyPerception>();
            if (agent == null) agent = brain.GetComponent<NavMeshAgent>();
        }
    }
    private void OnGUI()
    {
        if (brain == null || agent == null) return;
        string line1 = $"Enemy: {brain.CurrentState} | NavMesh: {agent.isOnNavMesh}";
        string line2 = $"PathPending: {agent.pathPending} | HasPath: {agent.hasPath}";
        string line3 = $"Velocity: {agent.velocity.magnitude:F1} | Remaining: {agent.remainingDistance:F1}";
        bool visible = perception != null && perception.CanSee(brain.Player);
        string line4 = $"Player Visible: {visible} | Player: {(brain.Player != null ? brain.Player.name : "None")}";
        GUI.Box(new Rect(12, 12, 410, 123), "DAY49 ENEMY AI DEBUG");
        GUI.Label(new Rect(25, 37, 390, 20), line1);
        GUI.Label(new Rect(25, 58, 390, 20), line2);
        GUI.Label(new Rect(25, 79, 390, 20), line3);
        GUI.Label(new Rect(25, 100, 390, 20), line4);
    }
}
