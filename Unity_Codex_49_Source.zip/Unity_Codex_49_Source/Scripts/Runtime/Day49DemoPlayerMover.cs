using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

[RequireComponent(typeof(CharacterController))]
public class Day49DemoPlayerMover : MonoBehaviour
{
    [SerializeField, Min(0.1f)] private float moveSpeed = 4f;
    private CharacterController controller;
    private void Awake() { controller = GetComponent<CharacterController>(); }

    private void Update()
    {
        Vector2 input = Vector2.zero;
#if ENABLE_INPUT_SYSTEM
        var k = Keyboard.current;
        if (k != null)
        {
            input.x = (k.dKey.isPressed ? 1f : 0f) - (k.aKey.isPressed ? 1f : 0f);
            input.y = (k.wKey.isPressed ? 1f : 0f) - (k.sKey.isPressed ? 1f : 0f);
        }
#endif
        Vector3 move = new Vector3(input.x, 0f, input.y).normalized;
        controller.SimpleMove(move * moveSpeed);
        if (move.sqrMagnitude > 0.0001f)
            transform.forward = Vector3.Slerp(transform.forward, move, 12f * Time.deltaTime);
    }
}
