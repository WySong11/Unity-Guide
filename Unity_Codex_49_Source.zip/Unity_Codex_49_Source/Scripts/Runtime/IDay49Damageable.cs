public interface IDay49Damageable
{
    void TakeDamage(int damage);
}
