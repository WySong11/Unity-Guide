using UnityEngine;

/// <summary>탐지 반경, 시야각, 장애물 가림(LOS)을 검사합니다.</summary>
public class Day49EnemyPerception : MonoBehaviour
{
    [Header("Sight")]
    [SerializeField, Min(0.5f)] private float sightRadius = 8f;
    [SerializeField, Range(1f, 180f)] private float sightAngle = 110f;
    [SerializeField, Min(0f)] private float eyeHeight = 1.35f;
    [SerializeField] private LayerMask obstacleMask;
    [SerializeField] private bool debugGizmos = true;
    private readonly RaycastHit[] rayHits = new RaycastHit[16];

    public float SightRadius => sightRadius;
    public void SetObstacleMask(LayerMask mask) { obstacleMask = mask; }

    public bool CanSee(Transform target)
    {
        if (target == null) return false;
        Vector3 eye = transform.position + Vector3.up * eyeHeight;
        Vector3 targetPoint = target.position + Vector3.up * 1.1f;
        Vector3 delta = targetPoint - eye;
        float distance = delta.magnitude;
        if (distance > sightRadius || distance < 0.0001f) return false;
        Vector3 flat = Vector3.ProjectOnPlane(delta, Vector3.up);
        if (flat.sqrMagnitude > 0.0001f &&
            Vector3.Angle(transform.forward, flat) > sightAngle * 0.5f) return false;
        int count = Physics.RaycastNonAlloc(eye, delta / distance, rayHits,
                         distance, obstacleMask, QueryTriggerInteraction.Ignore);
        for (int i = 0; i < count; i++)
        {
            Transform hitTransform = rayHits[i].collider.transform;
            // 자기 몸체와 타깃 Collider는 장애물이 아닙니다.
            if (hitTransform.IsChildOf(transform) || hitTransform.IsChildOf(target)) continue;
            return false;
        }
        return true;
    }

    private void OnDrawGizmosSelected()
    {
        if (!debugGizmos) return;
        Vector3 eye = transform.position + Vector3.up * eyeHeight;
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(eye, sightRadius);
        Quaternion left = Quaternion.AngleAxis(-sightAngle * 0.5f, Vector3.up);
        Quaternion right = Quaternion.AngleAxis(sightAngle * 0.5f, Vector3.up);
        Gizmos.DrawRay(eye, left * transform.forward * sightRadius);
        Gizmos.DrawRay(eye, right * transform.forward * sightRadius);
    }
}
