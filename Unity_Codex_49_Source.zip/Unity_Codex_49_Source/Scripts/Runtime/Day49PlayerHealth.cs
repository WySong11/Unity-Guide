using System;
using UnityEngine;

public class Day49PlayerHealth : MonoBehaviour, IDay49Damageable
{
    [SerializeField, Min(1)] private int maxHealth = 100;
    public int CurrentHealth { get; private set; }
    public event Action<int, int> HealthChanged;
    public event Action Died;

    private void Awake() { CurrentHealth = maxHealth; }

    public void TakeDamage(int damage)
    {
        if (damage <= 0 || CurrentHealth <= 0) return;
        CurrentHealth = Mathf.Max(0, CurrentHealth - damage);
        HealthChanged?.Invoke(CurrentHealth, maxHealth);
        if (CurrentHealth == 0) Died?.Invoke();
    }

    public void ResetHealth()
    {
        CurrentHealth = maxHealth;
        HealthChanged?.Invoke(CurrentHealth, maxHealth);
    }
}
