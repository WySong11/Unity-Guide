using System;
using UnityEngine;

public class Day49EnemyHealth : MonoBehaviour, IDay49Damageable
{
    [SerializeField, Min(1)] private int maxHealth = 40;
    public int CurrentHealth { get; private set; }
    public bool IsDead => CurrentHealth <= 0;
    public event Action Died;
    public event Action<int, int> HealthChanged;

    private void Awake() { CurrentHealth = maxHealth; }
    public void TakeDamage(int damage)
    {
        if (damage <= 0 || IsDead) return;
        CurrentHealth = Mathf.Max(0, CurrentHealth - damage);
        HealthChanged?.Invoke(CurrentHealth, maxHealth);
        if (IsDead) Died?.Invoke();
    }
}
