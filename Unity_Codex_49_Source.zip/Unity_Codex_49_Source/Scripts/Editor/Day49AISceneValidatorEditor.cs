#if UNITY_EDITOR
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.AI;

public static class Day49AISceneValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day49/Validate Enemy AI Lab")]
    public static void Validate()
    {
        var enemies = Object.FindObjectsByType<Day49EnemyBrain>(FindObjectsSortMode.None);
        int errors = 0;
        if (enemies.Length == 0) { Debug.LogError("[Day49] 적 FSM을 찾지 못했습니다."); errors++; }
        foreach (var brain in enemies)
        {
            var agent = brain.GetComponent<NavMeshAgent>();
            if (agent == null) { Debug.LogError("[Day49] NavMeshAgent 없음", brain); errors++; }
            else if (!agent.isOnNavMesh) Debug.LogWarning("[Day49] Play Mode에서 NavMeshSurface Bake 및 Agent 위치 확인", brain);
            if (brain.Player == null) { Debug.LogError("[Day49] Player 참조 없음", brain); errors++; }
            if (brain.GetComponent<Day49EnemyAttack>() == null) { Debug.LogError("[Day49] Attack 컴포넌트 없음", brain); errors++; }
        }
        bool hasSurface = Object.FindObjectsByType<Component>(FindObjectsSortMode.None)
                                .Any(c => c != null && c.GetType().Name == "NavMeshSurface");
        if (!hasSurface) Debug.LogWarning("[Day49] NavMeshSurface 없음: AI Navigation 패키지 및 Bake 확인");
        Debug.Log(errors == 0 ? "[Day49] 기본 구성 검사 PASS (Bake·Play Mode 별도 확인)" :
            "[Day49] 기본 구성 검사 FAIL: " + errors + "개 오류");
    }
}
#endif
