#if UNITY_EDITOR
using System;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.SceneManagement;

public static class Day49AISceneBuilderEditor
{
    private const string Root = "Assets/Day49EnemyAI/Lab";
    [MenuItem("Tools/Unity Codex/Day49/Create Enemy AI Lab")]
    public static void Build()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        EnsureFolder("Assets", "Day49EnemyAI");
        EnsureFolder("Assets/Day49EnemyAI", "Lab");
        EnsureFolder(Root, "Scenes");
        EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);

        GameObject environment = new GameObject("Environment_NavMeshSurface_Here");
        CreateBox("Ground", new Vector3(0, -.25f, 0), new Vector3(26, .5f, 26), environment.transform, new Color(.30f, .39f, .40f));
        CreateBox("WallA", new Vector3(0, 1, 2), new Vector3(5, 2, .5f), environment.transform, Color.gray);
        CreateBox("WallB", new Vector3(5, 1, -3), new Vector3(.5f, 2, 6), environment.transform, Color.gray);

        GameObject player = new GameObject("Player_Target_WASD");
        player.transform.position = new Vector3(4, 0, 4);
        CharacterController cc = player.AddComponent<CharacterController>();
        cc.center = new Vector3(0, 1, 0); cc.height = 2f;
        player.AddComponent<Day49PlayerHealth>();
        player.AddComponent<Day49DemoPlayerMover>();
        Visual("Player_Visual", player.transform, Color.cyan);

        GameObject enemy = new GameObject("Enemy_FSM");
        enemy.transform.position = Vector3.zero;
        var agent = enemy.AddComponent<NavMeshAgent>();
        agent.radius = .4f; agent.height = 2f; agent.stoppingDistance = 1.3f;
        var perception = enemy.AddComponent<Day49EnemyPerception>();
        // 데모는 Default Layer 전체를 검사하되, Perception에서 자기 몸체/타깃 Collider를 제외합니다.
        perception.SetObstacleMask(1 << 0);
        enemy.AddComponent<Day49EnemyHealth>();
        enemy.AddComponent<Day49EnemyAttack>();
        var brain = enemy.AddComponent<Day49EnemyBrain>();
        brain.SetPlayer(player.transform);
        Visual("Enemy_Visual", enemy.transform, new Color(1f, .40f, .36f));
        var points = new Transform[4];
        Vector3[] positions = {new Vector3(-4, 0, -4), new Vector3(4, 0, -4), new Vector3(4, 0, 4), new Vector3(-4, 0, 4)};
        for (int i = 0; i < points.Length; i++)
        {
            GameObject go = new GameObject("PatrolPoint_" + (i + 1));
            go.transform.position = positions[i]; points[i] = go.transform;
        }
        brain.SetPatrolPoints(points);
        GameObject diagnostics = new GameObject("Debug_AI_Overlay");
        diagnostics.AddComponent<Day49AIDiagnostics>();
        diagnostics.AddComponent<Day49DebugDamageEnemy>();
        Camera cam = Camera.main;
        if (cam != null)
        {
            cam.transform.position = new Vector3(0, 16, -21);
            cam.transform.rotation = Quaternion.Euler(36, 0, 0);
        }
        // AI Navigation package가 설치된 경우 NavMeshSurface를 자동으로 추가합니다.
        Type navSurface = FindNavMeshSurfaceType();
        if (navSurface != null) environment.AddComponent(navSurface);
        else Debug.LogWarning("[Day49] Window > Package Manager에서 AI Navigation을 설치하세요.");
        string scenePath = AssetDatabase.GenerateUniqueAssetPath(Root + "/Scenes/Day49_EnemyAI_Lab.unity");
        EditorSceneManager.SaveScene(SceneManager.GetActiveScene(), scenePath);
        AssetDatabase.Refresh();
        Selection.activeGameObject = enemy;
        Debug.Log("[Day49] 씬 생성 완료: " + scenePath + "\nNavMeshSurface를 Bake한 뒤 Play하세요.");
    }

    private static Type FindNavMeshSurfaceType()
    {
        foreach (var type in TypeCache.GetTypesDerivedFrom<Component>())
            if (type.Name == "NavMeshSurface" && !type.IsAbstract) return type;
        return null;
    }
    private static void EnsureFolder(string parent, string name)
    {
        if (!AssetDatabase.IsValidFolder(parent + "/" + name)) AssetDatabase.CreateFolder(parent, name);
    }
    private static void CreateBox(string name, Vector3 pos, Vector3 scale, Transform parent, Color color)
    {
        GameObject box = GameObject.CreatePrimitive(PrimitiveType.Cube);
        box.name = name; box.transform.SetParent(parent);
        box.transform.position = pos; box.transform.localScale = scale;
        SetColor(box, color);
    }
    private static void Visual(string name, Transform parent, Color color)
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        go.name = name; go.transform.SetParent(parent, false);
        go.transform.localPosition = new Vector3(0f, 1f, 0f);
        UnityEngine.Object.DestroyImmediate(go.GetComponent<Collider>());
        SetColor(go, color);
    }
    private static void SetColor(GameObject obj, Color color)
    {
        var renderer = obj.GetComponent<Renderer>();
        if (renderer == null) return;
        Shader shader = Shader.Find("Universal Render Pipeline/Lit");
        if (shader == null) shader = Shader.Find("Standard");
        if (shader == null) return;
        var mat = new Material(shader);
        if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", color);
        else if (mat.HasProperty("_Color")) mat.SetColor("_Color", color);
        renderer.sharedMaterial = mat;
    }
}
#endif
