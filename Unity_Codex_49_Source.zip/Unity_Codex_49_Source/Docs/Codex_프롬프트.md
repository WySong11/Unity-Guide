# Codex 실습 프롬프트

## A · 분석
현재 Enemy AI 스크립트 구조를 읽기 전용으로 분석해줘. EnemyBrain, EnemyPerception,
EnemyAttack, EnemyHealth의 책임과 의존성, 상태 전이표, 갱신 주기를 알려줘.
먼저 파일과 호출 관계만 보고하고 수정은 하지 마.

## B · 재현 증거 중심 수정
Unity 6.3 프로젝트에서 Enemy가 플레이어 뒤쪽을 보는 중에도 추적을 시작하는 문제를 재현했어.
시야각·장애물 Raycast·LayerMask 설정을 확인해 원인과 최소 수정안을 제안해줘.
기존 43~48일차 Player 코드는 변경하지 말고 변경 파일 목록과 diff를 먼저 보여줘.

## C · NavMesh 진단
NavMeshAgent.isOnNavMesh가 false이고 경로가 생성되지 않아. NavMeshSurface Bake,
Agent 시작 좌표, Renderer/Collider, pathPending 및 pathStatus를 확인해줘.
씬 자동 생성 코드는 기존 Scene을 덮어쓰지 않도록 해줘.

## D · 회귀 테스트
Patrol→Chase→Attack→Return→Dead 상태 흐름을 10개 테스트 케이스로 검증해줘.
각 항목에 절차·기대 결과·실제 결과·증거를 기록하고 실패 항목만 최소 수정해줘.
수정 후 git diff와 기존 이동·체력 시스템 영향 범위를 정리해줘.
