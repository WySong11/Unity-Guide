# Unity Codex 49일차 · Enemy AI와 상태 머신

## 기준
- Unity 6.3 계열 / URP Universal 3D
- Window > Package Manager에서 **AI Navigation** 설치 확인
- New Input System 지원. 테스트 플레이어는 ENABLE_INPUT_SYSTEM 매크로가 활성일 때 WASD를 사용합니다.

## 설치
1. ZIP의 `Scripts/Runtime`을 프로젝트 `Assets/Day49EnemyAI/Scripts/Runtime`으로 복사합니다.
2. `Scripts/Editor`는 반드시 `Assets/Day49EnemyAI/Scripts/Editor`에 복사합니다.
3. Unity 컴파일 완료 후 `Tools > Unity Codex > Day49 > Create Enemy AI Lab` 실행.
4. 생성된 Scene의 `Environment_NavMeshSurface_Here`에 NavMeshSurface가 있는지 확인합니다.
5. `NavMeshSurface`의 **Bake** 실행. NavMesh 시각화로 바닥이 포함되는지 확인합니다.
6. Play 후 `WASD`로 플레이어 이동, `K`로 적에게 10 데미지.
7. `Tools > Unity Codex > Day49 > Validate Enemy AI Lab`으로 구성 검사.

**주의**: 실습 Scene 자동 생성은 기존 Scene을 저장할지 확인하며, 기존 Day49 Scene 파일을 덮어쓰지 않습니다.

## 정상 동작 흐름
Patrol (웨이포인트 이동) → 플레이어 시야 내 탐지 → Chase → 공격 거리 → Attack →
타깃 사라짐/사망/범위 이탈 → Return → 순찰 재개 / HP 0이면 Dead.

## 탐지 테스트
- 적 전방에 플레이어가 있으면 Chase
- 적 뒤/감지 거리 밖이면 Patrol
- 장애물 뒤에서는 시선이 가려져 탐지 실패
- 추적 중 목표를 놓치면 `lostTargetDelay` 후 Return
- 적이 스폰 위치에서 `leashDistance`만큼 멀어지면 복귀

## 중요한 설계 결정
- `Day49EnemyPerception`: 감지 범위·각도·가림 판정만 수행
- `Day49EnemyBrain`: 상태 전이, 경로, 공격 허용 여부 처리
- `Day49EnemyAttack`: 공격 거리·쿨다운·피해 처리
- `Day49EnemyHealth`: HP와 사망 이벤트
- `Day49AIDiagnostics`: AI 상태와 NavMesh 상태 표시

**실무 전환:** 데모의 즉시 피해 방식은 다음 차시에서 Animation Event를 통해 정확한 타격 프레임으로 전환할 수 있습니다.

## 점검
- `isOnNavMesh=false`: NavMeshSurface Bake / Agent의 시작 좌표 확인
- 전방에서도 미탐지: obstacleMask 확인, Raycast 디버그 및 타깃 Collider 필터 확인(전용 장애물 레이어 권장)
- 추적이 멈춤: `pathPending`, `remainingDistance`, 벽/NavMesh 연결 확인
- 공격 시 HP 미변경: 플레이어 루트에 Day49PlayerHealth가 있는지 확인
- 여러 적 테스트: SetDestination 갱신 주기 및 NavMeshAgent 성능 확인

## 기존 43~47일차 시스템에 통합하는 방법
- `Day49PlayerHealth`는 독립 실습용입니다. 실제 프로젝트에서는 기존 체력 컴포넌트에
  `IDay49Damageable` 어댑터를 추가하거나 `Day49EnemyAttack`의 피해 전달부를 연결하세요.
- 기존 플레이어 이동 컴포넌트가 있으면 Day49DemoPlayerMover와 CharacterController를 중복 적용하지 마세요.
- 기존 Enemy FSM이 있다면 새 Brain을 겹쳐 붙이지 말고 하나의 컨트롤러만 활성화하세요.
