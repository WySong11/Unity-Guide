# 69일차 · MCP 개념과 보안

**환경:** Unity 6.3 / VS Code Codex / Windows 11 기준 설명. 수업 시간 120분.

이 패키지는 MCP 서버를 직접 설치하거나 인터넷으로 연결하지 않습니다. **실제 비밀 값(API Key, OAuth 토큰, 비밀번호)은 포함하지 않습니다.** 예제 Unity 프로젝트는 오프라인 허용/거절 정책 시뮬레이터입니다.

## 실습 순서

1. 기존 프로젝트와 `.codex/config.toml` 또는 사용자 `~/.codex/config.toml`을 백업합니다. 기존 `AGENTS.md`가 있다면 덮어쓰지 말고 검토 후 필요한 조항만 병합합니다.
2. `AGENTS_MCP_SECURITY_SECTION.md`를 읽고 프로젝트 규칙에 통합합니다.
3. `THREAT_MODEL.md`의 자산·공격 경로·통제 수단을 분석합니다.
4. Codex에서 먼저 `codex mcp list`를 실행하고 알려진 서버의 출처·쓰기 권한을 검토합니다.
5. 공식 OpenAI 문서 MCP 연결 예제는 선택 사항입니다. 기존 동명 서버가 없고 사용자 승인이 있을 때만 `codex mcp add openaiDeveloperDocs --url https://developers.openai.com/mcp` 명령을 사용합니다. 새 연결 후 `codex mcp list`로 확인합니다. 운영체제/설치 버전에 따라 명령 옵션을 `codex mcp --help`에서 확인하십시오.
6. 필요 없어진 수업 전용 서버는 해당 이름이 맞는지 확인한 후 `codex mcp remove openaiDeveloperDocs`로 정리할 수 있습니다. 기존 사용자 서버는 삭제하지 마세요.
7. Unity 프로젝트의 `Assets/Scripts/Day69`에 Runtime C# 파일을 추가합니다. `Assets/Editor`에 Editor 파일을 배치합니다. 메뉴 `Tools > Unity Codex > Day69 > Create Security Lab`을 실행하고 생성된 씬을 확인합니다.
8. 에디터 시뮬레이터는 외부 MCP 서버를 호출하지 않으며, 모의 Tool Request를 허용·거절·승인 필요로 분류합니다.
9. `QA_MATRIX.csv`에 실제 결과를 PASS/FAIL/NOT RUN으로 기록합니다. 실제 Unity 연결·토큰 접근·네트워크 권한은 별도 검사해야 합니다.

## 학습 포인트

- **Host / Client / Server**: 호스트가 서버별 클라이언트를 관리합니다.
- **Tools / Resources / Prompts**: 실행 기능·데이터·템플릿을 구분합니다.
- **신뢰 경계**: 서버가 제공한 문서나 반환값은 명령이 아니라 비신뢰 데이터입니다.
- **최소 권한**: 가능하면 읽기 전용, 검증 가능한 서버와 도구만 사용합니다.
- **승인과 기록**: 쓰기·삭제·외부 전송은 사전에 명시적으로 승인하고 증거를 남깁니다.
- **버전**: MCP 2026-07-28은 이전 2025 프로토콜 초기화 모델과 다릅니다. 구체 구현은 SDK/서버 버전을 확인합니다.

## 강의자료와 실습 연결

슬라이드 7-15(개념) → 16-19(읽기 연결/승인) → 20-27(공격 경로/보안 규칙) → 28-42(실습/QA).

## 주의

- 이 패키지의 C# 코드는 학습용 **로컬 정책 시뮬레이터**이며 실제 MCP 보안·인증을 대체하지 않습니다.
- 서버 연결 여부, CLI 호환, Unity Editor 컴파일/Play Mode는 별도로 실행하여 검증하세요.
- MCP 서버나 도구에 공개하지 않을 비밀 파일을 읽어달라고 요청하지 마세요.
- 서버가 Tool을 `readOnly`라고 선언해도 실제 작업이 무해하다는 뜻은 아닙니다.
