# 강의 출처 / 문서 링크 (2026-10-27 확인)

- MCP 공식 개요 및 사양: https://modelcontextprotocol.io/
- MCP 2026-07-28 변경 사항: https://blog.modelcontextprotocol.io/posts/2026-07-28/
- MCP 2025-11-25 OAuth: https://github.com/modelcontextprotocol/modelcontextprotocol/blob/main/docs/specification/2025-11-25/basic/authorization.mdx
- OpenAI 공식 문서 MCP(읽기 전용) / Codex 등록 명령: https://developers.openai.com/learn/docs-mcp
- MCP 보안/Prompt Injection 위험: https://developers.openai.com/api/docs/mcp
- OpenAI Sandbox 보안: https://developers.openai.com/api/docs/guides/agents-api/environments/security

2026-07-28 프로토콜은 일부 구 SDK와의 호환 방식이 다릅니다. 교재 예제는 입문용이며, 실제 라이브 연결은 사용 환경을 확인한 후 진행하세요.
