# 학생용 실습 워크시트

- 사용 환경(Host/CLI 버전):
- 확인한 MCP 서버 이름 / 공식 URL:
- 연결 방식(Local stdio / Remote HTTP):
- 서버가 제공한 Tools / Resources / Prompts:
- Read / Write / Delete / External Send 권한 차이:
- 읽기 전용 검색 실행 여부 (PASS/FAIL/NOT RUN):
- 발견한 Prompt Injection 유사 문장과 대응:
- 서버 신뢰 경계와 자격증명 보호 방법:
- 실행된 도구 로그 / 실행하지 못한 이유:
- 기존 AGENTS.md와 병합할 3개 규칙:
- 다음 프로젝트에 적용할 최소 권한 원칙:

## 제출물
서버 인벤토리, 위협 모델, QA 결과 CSV, Codex 프롬프트, 최종 보안 보고서.
