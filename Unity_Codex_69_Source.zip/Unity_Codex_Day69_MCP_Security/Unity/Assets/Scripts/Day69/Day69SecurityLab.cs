using UnityEngine;

namespace UnityCodex.Day69
{
    public sealed class Day69SecurityLab : MonoBehaviour
    {
        [SerializeField] private Day69ToolPolicy policy;
        [SerializeField] private Day69AuditTrail audit;
        private bool trusted = true;
        private bool includesSecret;
        private string message = "오프라인 학습용 시뮬레이터 / 네트워크 호출 없음";

        private void OnGUI()
        {
            GUILayout.BeginArea(new Rect(30, 30, 610, 440), GUI.skin.box);
            GUILayout.Label("Day69 MCP Security Lab (Offline)");
            trusted = GUILayout.Toggle(trusted, "검증된 서버 (모의 값)");
            includesSecret = GUILayout.Toggle(includesSecret, "민감 데이터 포함 (모의 값)");
            foreach (Day69Operation op in System.Enum.GetValues(typeof(Day69Operation)))
            {
                if (GUILayout.Button("Evaluate " + op, GUILayout.Height(30))) Evaluate(op);
            }
            GUILayout.Space(8);
            GUILayout.Label(message);
            if (audit != null) foreach (string entry in audit.Entries) GUILayout.Label(entry);
            GUILayout.EndArea();
        }

        private void Evaluate(Day69Operation op)
        {
            if (policy == null)
            {
                message = "Day69ToolPolicy Asset을 연결해야 합니다.";
                return;
            }
            Day69Decision decision = policy.Evaluate(trusted, op, includesSecret);
            message = $"{op} → {decision} (실제 MCP 호출 아님)";
            if (audit != null) audit.Record(op, decision);
        }
    }
}
