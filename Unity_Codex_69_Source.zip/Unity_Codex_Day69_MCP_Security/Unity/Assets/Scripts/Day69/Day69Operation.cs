namespace UnityCodex.Day69
{
    public enum Day69Operation
    {
        ReadDocument,
        ReadProjectFile,
        WriteProjectFile,
        DeleteFile,
        SendExternalData
    }
    public enum Day69Decision { Allow, Deny, NeedsApproval }
}
