using System;
using System.Collections.Generic;
using UnityEngine;

namespace UnityCodex.Day69
{
    public sealed class Day69AuditTrail : MonoBehaviour
    {
        private readonly Queue<string> entries = new Queue<string>();
        public IEnumerable<string> Entries => entries;

        public void Record(Day69Operation operation, Day69Decision decision)
        {
            string line = $"{DateTime.UtcNow:HH:mm:ss}  {operation}  => {decision}";
            entries.Enqueue(line);
            while (entries.Count > 12) entries.Dequeue();
            Debug.Log("[Day69 Security Lab] " + line);
            // 실제 비밀 값, 토큰 또는 민감 Tool 인자를 기록하지 않습니다.
        }
    }
}
