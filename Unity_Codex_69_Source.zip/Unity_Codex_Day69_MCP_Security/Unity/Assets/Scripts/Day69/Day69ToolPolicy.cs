using UnityEngine;

namespace UnityCodex.Day69
{
    [CreateAssetMenu(fileName = "Day69ToolPolicy", menuName = "Unity Codex/Day69/Tool Policy")]
    public class Day69ToolPolicy : ScriptableObject
    {
        [SerializeField] private bool allowTrustedRead = true;
        [SerializeField] private bool requireApprovalForWrite = true;

        public Day69Decision Evaluate(bool trustedServer, Day69Operation op, bool includesSecret)
        {
            if (!trustedServer || includesSecret) return Day69Decision.Deny;
            if (op == Day69Operation.ReadDocument || op == Day69Operation.ReadProjectFile)
                return allowTrustedRead ? Day69Decision.Allow : Day69Decision.Deny;
            return requireApprovalForWrite ? Day69Decision.NeedsApproval : Day69Decision.Deny;
        }
    }
}
