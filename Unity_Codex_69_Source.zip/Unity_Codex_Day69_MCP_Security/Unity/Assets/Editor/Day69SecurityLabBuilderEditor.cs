#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityCodex.Day69;

public static class Day69SecurityLabBuilderEditor
{
    [MenuItem("Tools/Unity Codex/Day69/Create Security Lab")]
    public static void CreateLab()
    {
        string folder = "Assets/Day69McpSecurityLab";
        if (AssetDatabase.IsValidFolder(folder))
        {
            EditorUtility.DisplayDialog("Day69", "기존 Day69 실습 폴더가 있습니다. 덮어쓰지 않습니다.", "OK");
            return;
        }
        AssetDatabase.CreateFolder("Assets", "Day69McpSecurityLab");
        Day69ToolPolicy policy = ScriptableObject.CreateInstance<Day69ToolPolicy>();
        AssetDatabase.CreateAsset(policy, folder + "/Day69ToolPolicy.asset");
        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        var go = new GameObject("Day69_MCP_Security_Lab");
        var audit = go.AddComponent<Day69AuditTrail>();
        var demo = go.AddComponent<Day69SecurityLab>();
        using (var serialized = new SerializedObject(demo))
        {
            serialized.FindProperty("policy").objectReferenceValue = policy;
            serialized.FindProperty("audit").objectReferenceValue = audit;
            serialized.ApplyModifiedPropertiesWithoutUndo();
        }
        EditorSceneManager.SaveScene(scene, folder + "/Day69SecurityLab.unity");
        AssetDatabase.SaveAssets();
        EditorGUIUtility.PingObject(policy);
        Debug.Log("Day69 security lab created. Offline permission simulation only.");
    }
}
#endif
