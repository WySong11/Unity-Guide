#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using UnityCodex.Day69;

public static class Day69SecurityLabValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day69/Validate Security Lab")]
    public static void Validate()
    {
        var all = Object.FindObjectsByType<Day69SecurityLab>(FindObjectsSortMode.None);
        if (all.Length != 1)
        {
            Debug.LogWarning($"Day69: SecurityLab count={all.Length}; expected 1 in open Scene.");
            return;
        }
        var property = new SerializedObject(all[0]).FindProperty("policy");
        if (property.objectReferenceValue == null)
            Debug.LogError("Day69: missing policy reference.");
        else
            Debug.Log("Day69: scene policy reference present. Runtime tests still required.");
    }
}
#endif
