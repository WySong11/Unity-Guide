using System;
using System.Collections.Generic;

// JSON으로 저장할 값만 보관합니다. MonoBehaviour를 저장하지 않습니다.
[Serializable]
public class SaveData
{
    public int schemaVersion = 1;
    public int highestClearedStage = 0;
    public int totalCoins = 0;
    public List<string> unlockedSkillIds = new List<string>();
}
