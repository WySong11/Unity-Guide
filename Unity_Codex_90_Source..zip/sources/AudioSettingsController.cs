using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.UI;

public class AudioSettingsController : MonoBehaviour
{
    [SerializeField] private AudioMixer mixer;
    [SerializeField] private Slider bgmSlider;
    [SerializeField] private Slider sfxSlider;
    private const string BgmKey = "Audio.BGM";
    private const string SfxKey = "Audio.SFX";

    private void Start()
    {
        float bgm = Mathf.Clamp01(PlayerPrefs.GetFloat(BgmKey, 0.8f));
        float sfx = Mathf.Clamp01(PlayerPrefs.GetFloat(SfxKey, 1.0f));
        bgmSlider.SetValueWithoutNotify(bgm);
        sfxSlider.SetValueWithoutNotify(sfx);
        Apply("BGMVolume", bgm);
        Apply("SFXVolume", sfx);
        bgmSlider.onValueChanged.AddListener(SetBgm);
        sfxSlider.onValueChanged.AddListener(SetSfx);
    }

    public void SetBgm(float value) => Set("BGMVolume", BgmKey, value);
    public void SetSfx(float value) => Set("SFXVolume", SfxKey, value);

    private void Set(string parameter, string key, float value)
    {
        value = Mathf.Clamp01(value);
        Apply(parameter, value);
        PlayerPrefs.SetFloat(key, value);
        // Slider 이동 중에는 디스크 저장을 반복하지 않습니다.
    }

    private void Apply(string parameter, float value)
    {
        if (mixer == null || !mixer.SetFloat(parameter, AudioMath.LinearToDb(value)))
            Debug.LogWarning($"AudioMixer exposed parameter not found: {parameter}");
    }

    // 설정창 Close 버튼에 연결하거나 앱이 백그라운드로 갈 때 호출합니다.
    public void SaveSettings() => PlayerPrefs.Save();
    private void OnApplicationPause(bool pause)
    {
        if (pause) SaveSettings();
    }
    private void OnApplicationQuit() => SaveSettings();

    private void OnDestroy()
    {
        if (bgmSlider != null) bgmSlider.onValueChanged.RemoveListener(SetBgm);
        if (sfxSlider != null) sfxSlider.onValueChanged.RemoveListener(SetSfx);
    }
}
