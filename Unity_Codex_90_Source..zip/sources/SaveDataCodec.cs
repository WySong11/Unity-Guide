using System;
using UnityEngine;

public static class SaveDataCodec
{
    public static string Serialize(SaveData data)
    {
        if (data == null) throw new ArgumentNullException(nameof(data));
        return JsonUtility.ToJson(data, true);
    }

    public static bool TryDeserialize(string json, out SaveData data)
    {
        data = null;
        if (string.IsNullOrWhiteSpace(json)) return false;
        try
        {
            SaveData loaded = JsonUtility.FromJson<SaveData>(json);
            if (loaded == null || loaded.schemaVersion != 1) return false;
            // JSON 문법은 맞아도 값이 이상할 수 있으므로 검증합니다.
            if (loaded.highestClearedStage < 0 || loaded.totalCoins < 0) return false;
            loaded.unlockedSkillIds ??= new System.Collections.Generic.List<string>();
            data = loaded;
            return true;
        }
        catch (Exception)
        {
            return false;
        }
    }
}
