# 90일차 저장 및 사운드 실습 (Unity 6.3 LTS)

## 전제
- 85일차 `PlayerHealth`, 87일차 `StageWaveController` / `StageRunState`, 88일차 `StageUIController`가 이미 있는 **WAVE GUARD** 프로젝트입니다.
- 이 ZIP에는 90일차에 추가하는 스크립트만 있습니다. 기존 85~89일차 코드가 없다면 먼저 연동해야 합니다.

## 1. 저장 시스템
1. `SaveData.cs`, `SaveDataCodec.cs`, `GameSaveService.cs`, `StageClearSaveBridge.cs`를 게임 어셈블리에 추가합니다.
2. Stage 씬에 `GameSaveService` 오브젝트를 생성합니다. 기존 GameManager에 이미 Save 기능이 있다면 역할 중복을 피하세요.
3. `StageClearSaveBridge`에 `StageWaveController`, `GameSaveService`, `currentStageNumber = 1`을 연결합니다.
4. Stage Clear 시 `save_v1.json`이 `Application.persistentDataPath`에 기록되는지 확인하세요.
5. 시작 메뉴 등에서 로드가 필요할 때 `GameSaveService.TryLoad()`를 호출합니다. **씬 로드보다 먼저** 진행도를 읽으세요.
6. 예제에서는 "마지막 클리어 스테이지"만 저장합니다. 웨이브 중간을 복원하려면 StageWaveController의 시작 지점/적 상태 복원 등을 추가로 설계해야 합니다.
7. SaveData는 게임 진행 상태의 DTO일 뿐, `ScriptableObject` 에셋이나 MonoBehaviour 직렬화가 아닙니다.

## 2. 사운드 시스템
1. `AudioMixer`를 생성해 `Master` 아래 `BGM`, `SFX`, `UI` 그룹을 만듭니다.
2. BGM과 SFX 그룹의 Volume을 `BGMVolume`, `SFXVolume`으로 **Expose to script**하고 정확하게 이름을 지정합니다.
3. Stage 씬에 `GameAudioPlayer`를 추가하고 BGM/SFX/UI AudioSource를 할당합니다. 각각 적절한 Output AudioMixerGroup을 설정하세요.
4. `AudioSettingsController`를 Settings 패널에 추가하고 AudioMixer, 0~1 범위의 Slider 2개를 연결합니다. AudioMixer 초기 값 적용은 Start()에서 수행합니다.
5. 설정창 Close 버튼에서 `AudioSettingsController.SaveSettings()`를 호출해 PlayerPrefs 데이터를 디스크에 반영하세요. 슬라이더 드래그 중에는 `SetFloat`만 호출합니다.
6. 버튼 `OnClick` → `GameAudioPlayer.PlayButton` 연결; 전투 시작 시 `StartBattleBgm` 호출; 타격 이벤트 → `PlayHit` 연결.
7. 88일차 Pause/Resume 시 `GameAudioPlayer.SetGameplayPaused(true/false)`를 **추가로 호출**하세요. `Time.timeScale = 0`은 오디오 정지 제어가 아닙니다.
8. UI 클릭음을 일시정지 중에도 재생하려면 `uiSource.ignoreListenerPause = true`가 필요합니다.
9. 씬 전환 전 반드시 `AudioListener.pause = false`가 되도록 하고 중복 AudioListener를 만들지 마세요.

## 3. 테스트 및 주의
- EditMode Test Assembly를 만들고 `SaveDataCodecTests.cs`, `AudioMathTests.cs`를 추가하세요.
- `GameSaveService`의 File I/O 및 Android 경로 검증은 PlayMode / 실제 빌드에서 해야 합니다. 예제 코드를 이 환경에서 Unity 컴파일·실행 테스트한 것은 아닙니다.
- `PlayerPrefs`는 보안 저장소가 아니므로 코인, 점수, 계정 비밀번호 같은 신뢰 대상 데이터를 저장하지 마세요.
- 수업용 `File.WriteAllText`는 파일 교체 중 앱이 종료되면 손상 가능성이 있습니다. 출시용으로는 백업/임시 파일/검증 후 교체 및 오류 복구 전략을 별도로 구현하세요.
- Android 업데이트, 앱 데이터 삭제, 재설치, 저장 권한·경로 접근성 등은 기기별로 시험하세요.
- 일부 코드에 C# 8 문법(`??=`)이 사용되었습니다. 프로젝트의 언어 수준에 맞추어 수정할 수 있습니다.
