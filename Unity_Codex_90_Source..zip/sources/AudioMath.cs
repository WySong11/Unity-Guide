using UnityEngine;

public static class AudioMath
{
    // UI 슬라이더는 선형 0..1, AudioMixer는 dB를 사용합니다.
    public static float LinearToDb(float linear)
    {
        if (linear <= 0f) return -80f;
        return Mathf.Clamp(20f * Mathf.Log10(linear), -80f, 0f);
    }
}
