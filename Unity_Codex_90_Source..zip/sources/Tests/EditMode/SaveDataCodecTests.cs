using NUnit.Framework;

public class SaveDataCodecTests
{
    [Test]
    public void RoundTrip_PreservesProgress()
    {
        var source = new SaveData { highestClearedStage = 2, totalCoins = 30 };
        source.unlockedSkillIds.Add("shockwave");
        Assert.That(SaveDataCodec.TryDeserialize(SaveDataCodec.Serialize(source), out var result), Is.True);
        Assert.That(result.highestClearedStage, Is.EqualTo(2));
        Assert.That(result.unlockedSkillIds, Does.Contain("shockwave"));
    }

    [TestCase("")]
    [TestCase("{broken")]
    [TestCase("{\"schemaVersion\":99,\"highestClearedStage\":1}")]
    [TestCase("{\"schemaVersion\":1,\"highestClearedStage\":-3}")]
    public void InvalidSave_IsRejected(string json)
    {
        Assert.That(SaveDataCodec.TryDeserialize(json, out _), Is.False);
    }
}
