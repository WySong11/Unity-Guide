using NUnit.Framework;

public class AudioMathTests
{
    [TestCase(1f, 0f)]
    [TestCase(0.5f, -6.0206f)]
    [TestCase(0.1f, -20f)]
    [TestCase(0f, -80f)]
    public void LinearToDb_ExpectedValue(float linear, float db)
    {
        Assert.That(AudioMath.LinearToDb(linear), Is.EqualTo(db).Within(0.01f));
    }
}
