using UnityEngine;

public class GameAudioPlayer : MonoBehaviour
{
    [SerializeField] private AudioSource bgmSource;
    [SerializeField] private AudioSource sfxSource;
    [SerializeField] private AudioSource uiSource;
    [SerializeField] private AudioClip battleBgm;
    [SerializeField] private AudioClip hitSfx;
    [SerializeField] private AudioClip clearSfx;
    [SerializeField] private AudioClip buttonSfx;

    private void Awake()
    {
        if (bgmSource != null) bgmSource.loop = true;
        // Pause 메뉴 버튼 소리만 계속 재생하려는 경우 UI Source에서 활성화
        if (uiSource != null) uiSource.ignoreListenerPause = true;
    }
    public void StartBattleBgm()
    {
        if (bgmSource == null || battleBgm == null) return;
        bgmSource.clip = battleBgm;
        bgmSource.Play();
    }
    public void PlayHit() { if (hitSfx != null) sfxSource?.PlayOneShot(hitSfx); }
    public void PlayClear() { if (clearSfx != null) sfxSource?.PlayOneShot(clearSfx); }
    public void PlayButton() { if (buttonSfx != null) uiSource?.PlayOneShot(buttonSfx); }

    public void SetGameplayPaused(bool paused)
    {
        AudioListener.pause = paused; // Time.timeScale만으로 오디오는 정지하지 않습니다.
    }
    private void OnDestroy() => AudioListener.pause = false;
}
