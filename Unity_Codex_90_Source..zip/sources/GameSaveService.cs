using System;
using System.IO;
using UnityEngine;

public class GameSaveService : MonoBehaviour
{
    public SaveData Current { get; private set; } = new SaveData();
    public string SavePath => Path.Combine(Application.persistentDataPath, "save_v1.json");

    public bool TryLoad()
    {
        if (!File.Exists(SavePath))
        {
            Current = new SaveData();  // 새 게임, 실패가 아닙니다.
            return true;
        }
        try
        {
            string json = File.ReadAllText(SavePath);
            if (!SaveDataCodec.TryDeserialize(json, out var loaded)) return false;
            Current = loaded;
            return true;
        }
        catch (Exception e) when (e is IOException || e is UnauthorizedAccessException)
        {
            Debug.LogWarning($"[Save] Load failed: {e.Message}");
            return false;
        }
    }

    public bool TrySave()
    {
        try
        {
            Directory.CreateDirectory(Application.persistentDataPath);
            File.WriteAllText(SavePath, SaveDataCodec.Serialize(Current));
            return true;
        }
        catch (Exception e) when (e is IOException || e is UnauthorizedAccessException)
        {
            Debug.LogError($"[Save] Save failed: {e.Message}");
            return false;
        }
    }

    public bool RecordStageClear(int clearedStageNumber)
    {
        if (clearedStageNumber <= 0) return false;
        int before = Current.highestClearedStage;
        Current.highestClearedStage = Mathf.Max(before, clearedStageNumber);
        if (Current.highestClearedStage == before) return true;
        if (TrySave()) return true;
        Current.highestClearedStage = before;
        return false;
    }
}
