using UnityEngine;

// 87일차 StageWaveController의 StateChanged 이벤트 연결용 예제입니다.
public class StageClearSaveBridge : MonoBehaviour
{
    [SerializeField] private StageWaveController stage;
    [SerializeField] private GameSaveService save;
    [SerializeField, Min(1)] private int currentStageNumber = 1;
    private bool recorded;

    private void OnEnable()
    {
        if (stage != null) stage.StateChanged += OnStageStateChanged;
    }

    private void Start()
    {
        if (stage != null) OnStageStateChanged(stage.State);
    }

    private void OnStageStateChanged(StageRunState state)
    {
        if (recorded || state != StageRunState.Clear || save == null) return;
        if (save.RecordStageClear(currentStageNumber)) recorded = true;
        else Debug.LogWarning("[Save] Stage clear was not persisted.");
    }

    private void OnDisable()
    {
        if (stage != null) stage.StateChanged -= OnStageStateChanged;
    }
}
