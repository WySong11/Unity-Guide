#if UNITY_EDITOR
using System;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class Day55WaveLabBuilderEditor
{
    [MenuItem("Tools/Unity Codex/Day55/Create Wave Lab")]
    private static void CreateLab()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        const string root = "Assets/Day55_WaveDifficultyLab";
        EnsureFolder(root);
        string folder = root + "/Lab_" + DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");
        AssetDatabase.CreateFolder(root, folder.Substring(folder.LastIndexOf('/') + 1));

        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        var ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Ground";
        ground.transform.localScale = new Vector3(5f, 1f, 5f);

        var player = GameObject.CreatePrimitive(PrimitiveType.Cube);
        player.name = "PlayerTarget";
        player.transform.position = new Vector3(0f, 0.6f, 0f);
        player.transform.localScale = new Vector3(1f, 1.2f, 1f);

        // 자동 생성 Prefab: AI Navigation 패키지 없이도 동작하는 단순 추적 연습용.
        var prefabTemporary = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        prefabTemporary.name = "Day55Monster";
        prefabTemporary.AddComponent<Day55MonsterUnit>();
        prefabTemporary.SetActive(false);
        string prefabPath = folder + "/Day55Monster.prefab";
        GameObject prefab = PrefabUtility.SaveAsPrefabAsset(prefabTemporary, prefabPath);
        UnityEngine.Object.DestroyImmediate(prefabTemporary);

        var config = ScriptableObject.CreateInstance<Day55WaveConfig>();
        AssetDatabase.CreateAsset(config, folder + "/Day55WaveConfig.asset");

        var pointRoot = new GameObject("SpawnPoints");
        Transform[] points = new Transform[3];
        Vector3[] positions = { new Vector3(-9,1,9), new Vector3(9,1,9), new Vector3(0,1,-11) };
        for (int i = 0; i < points.Length; i++)
        {
            var obj = new GameObject("SpawnPoint_" + (i + 1));
            obj.transform.SetParent(pointRoot.transform);
            obj.transform.position = positions[i];
            points[i] = obj.transform;
        }

        var poolGO = new GameObject("MonsterPool");
        var pool = poolGO.AddComponent<Day55MonsterPool>();
        AssignObject(pool, "monsterPrefab", prefab.GetComponent<Day55MonsterUnit>());

        var directorGO = new GameObject("DifficultyDirector");
        var director = directorGO.AddComponent<Day55DifficultyDirector>();

        var spawnerGO = new GameObject("WaveSpawner");
        var spawner = spawnerGO.AddComponent<Day55WaveSpawner>();
        AssignObject(spawner, "waveConfig", config);
        AssignObject(spawner, "difficultyDirector", director);
        AssignObject(spawner, "monsterPool", pool);
        AssignObject(spawner, "playerTarget", player.transform);
        AssignTransformArray(spawner, "spawnPoints", points);

        var hudGO = new GameObject("WaveHUD");
        var hud = hudGO.AddComponent<Day55WaveHUD>();
        AssignObject(hud, "spawner", spawner);
        AssignObject(hud, "pool", pool);
        var recorder = hudGO.AddComponent<Day55BalanceRecorder>();
        AssignObject(recorder, "spawner", spawner);

        EditorSceneManager.SaveScene(scene, folder + "/Day55_WaveLab.unity");
        AssetDatabase.SaveAssets();
        Selection.activeGameObject = spawnerGO;
        Debug.Log("[Day55] Generated new scene and assets: " + folder);
    }

    private static void EnsureFolder(string path)
    {
        if (AssetDatabase.IsValidFolder(path)) return;
        AssetDatabase.CreateFolder("Assets", "Day55_WaveDifficultyLab");
    }

    private static void AssignObject(UnityEngine.Object obj, string name, UnityEngine.Object value)
    {
        var data = new SerializedObject(obj);
        data.FindProperty(name).objectReferenceValue = value;
        data.ApplyModifiedPropertiesWithoutUndo();
    }

    private static void AssignTransformArray(UnityEngine.Object obj, string name, Transform[] values)
    {
        var data = new SerializedObject(obj);
        SerializedProperty array = data.FindProperty(name);
        array.arraySize = values.Length;
        for (int i = 0; i < values.Length; i++)
            array.GetArrayElementAtIndex(i).objectReferenceValue = values[i];
        data.ApplyModifiedPropertiesWithoutUndo();
    }
}
#endif
