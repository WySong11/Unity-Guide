#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

public static class Day55WaveValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day55/Validate Current Scene")]
    private static void Validate()
    {
        var spawner = Object.FindFirstObjectByType<Day55WaveSpawner>();
        var pool = Object.FindFirstObjectByType<Day55MonsterPool>();
        var director = Object.FindFirstObjectByType<Day55DifficultyDirector>();
        if (spawner == null || pool == null || director == null)
        {
            Debug.LogError("[Day55] Required components missing in the scene.");
            return;
        }
        var obj = new SerializedObject(spawner);
        var config = obj.FindProperty("waveConfig").objectReferenceValue as Day55WaveConfig;
        if (config == null || config.waves == null || config.waves.Length == 0)
        {
            Debug.LogError("[Day55] WaveConfig is missing/empty.");
            return;
        }
        var points = obj.FindProperty("spawnPoints");
        if (points.arraySize == 0)
        {
            Debug.LogError("[Day55] SpawnPoints are empty.");
            return;
        }
        for (int i = 0; i < config.waves.Length; i++)
        {
            if (config.waves[i] == null)
            {
                Debug.LogError($"[Day55] Null wave entry: {i + 1}");
                return;
            }
            var plan = director.Evaluate(config.waves[i], i);
            Debug.Log($"[Day55] Wave {i + 1}: count {plan.monsterCount}, " +
                $"maxAlive {plan.maxAlive}, HP {plan.hp:F1}, speed {plan.moveSpeed:F1}");
        }
        Debug.Log("[Day55] Static setup validation passed. Run Play Mode separately.");
    }
}
#endif
