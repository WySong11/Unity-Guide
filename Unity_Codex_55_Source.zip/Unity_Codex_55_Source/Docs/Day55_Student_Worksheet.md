# 55일차 학생 워크시트 — Wave & Difficulty

## 1. 개념 확인

1. `monsterCount`와 `maxAlive`의 차이를 본인이 만든 게임 상황을 예로 들어 설명하세요.
2. `Day55WaveConfig`와 `Day55DifficultyDirector`의 책임이 다른 이유를 쓰세요.
3. `Prewarm`과 `defaultCapacity`의 차이를 설명하세요.
4. `Spawning`, `Clearing`, `Break`에서 각자 무엇을 기다리는지 쓰세요.
5. `GameObject.SetActive(false)` 뒤에도 남아 있을 수 있는 상태 3가지를 쓰세요.

## 2. 실습 A — 고정 3 Wave

Wave 1 = 4마리, 최대 3마리, HP40 / Wave 2 = 6마리, 최대 4마리, HP55 / Wave 3 = 8마리, 최대 5마리, HP75 로 설정합니다. 각 웨이브마다 HUD의 `Spawned`, `Killed`, `Alive`를 스크린샷으로 기록하세요.

## 3. 실습 B — 난이도 조절

1. HP 성장 배율을 1.15로 바꾼 뒤 Wave1~3 실행용 HP를 적으세요.
2. Count Growth를 1.2로 변경해 생성 수가 과도하게 늘지 않는지 관찰하세요.
3. Interval Factor를 0.9로 변경해 체감 난이도와 실제 생존 수의 차이를 기록하세요.
4. 수치 하나만 바꿔 다시 테스트하고 **변경 전/후**를 비교하세요.

## 4. 실습 C — 버그 재현

- Wave 진행 중 Restart: 중복 Coroutine이 있는지 확인합니다.
- SpawnPoint를 비우거나 NavMesh 필터를 켜고 Bake 없이 실행: 5회 실패 후 Failed가 되는지 확인합니다.
- 풀 재사용: 이전 HP/MoveSpeed가 유지되지 않는지 확인합니다.
- Time.timeScale=0: 새 스폰과 인터미션 타이머가 멈추는지 확인합니다.

## 5. 제출물

씬/설정 에셋, 작성 코드, Inspector 캡처 2장 이상, 3개 Wave 진행 스크린샷, 테스트 결과표, Codex 프롬프트와 diff 요약을 제출합니다.
