# Codex 지시 프롬프트

## 1. 기존 프로젝트 분석용

> Unity 6.3 프로젝트를 읽고 기존 53일차 WaveSpawner와 54일차 MonsterPool의 실제 메서드, Prefab 소유권, 반환 이벤트, 활성 카운트 방식을 먼저 정리해줘. 기존 파일은 수정하지 말고 `읽기 전용 분석 보고서`만 작성해줘. 추측한 API 이름은 사용하지 마.

## 2. 설계·구현용

> 기존 설계를 검토한 뒤 `WaveConfig(ScriptableObject)`, `DifficultyDirector`, `WaveSpawner`를 책임별로 분리해줘. Wave의 성공 생성 수와 동시 활성 상한을 구분하고 Spawn 실패 횟수 상한, Stop/Restart 중복 Coroutine 방어, 체력과 속도 초기화, Wave Clear 조건을 구현해줘. 기존 54일차 소스는 삭제하거나 덮어쓰지 마. 우선 파일별 변경 계획·호환 위험·검증표를 보여줘.

## 3. 오류 재현/최소 수정용

> 재현 단계, Console Stack Trace, Inspector 설정값, Wave Index, Spawned/Killed/Alive, Pool.CountActive/All/Inactive를 근거로 원인 후보를 우선순위로 정리해줘. 원인을 입증하지 못하면 임의로 코드를 고치지 말고 필요한 추가 로그만 제안해줘. 가장 작은 범위로 수정하고 Git diff와 회귀 테스트 12항목을 제공해줘.

## 4. 테스트용

> Editor 컴파일 상태, Play Mode 자동/수동 테스트, 3개의 Wave 정상 진행, maxAlive 준수, SpawnPoint 오류, Restart/Pause, Pool 재사용, 500회 스트레스 테스트를 차례로 검증해줘. Unity MCP나 CLI가 실제 연결되지 않았다면 테스트를 수행했다고 주장하지 말고 `미검증`으로 기록해줘.
