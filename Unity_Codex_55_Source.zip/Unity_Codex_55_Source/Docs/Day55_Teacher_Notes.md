# 55일차 교강사용 해설

**120분 배분:** 개념 25분 / 데이터·상태 설계 30분 / 구현 45분 / 검증·발표 20분.

- `monsterCount`: 이번 Wave 동안 성공해야 할 생성 횟수이며 동시 수가 아님.
- `maxAlive`: Pool의 활성 수 상한. 이 수에 도달하면 새 Spawn을 대기함.
- `Clearing`: Spawned가 monsterCount에 도달한 이후 살아 있는 적이 모두 반환될 때까지 대기.
- `CountAll = CountActive + CountInactive`는 Unity ObjectPool 내부 수치 기준으로 참임. 다만 Spawner의 `Killed`와 ReturnAll 개수는 다름.
- Prewarm은 실제 인스턴스 `Get()`과 `Release()`를 반복하는 준비 동작이고, `defaultCapacity`는 내부 컬렉션의 초기 용량 힌트임.
- 난이도 성장 곡선은 자동으로 재미를 보장하지 않음. TTK, 피격량, 최대 동시 수, FPS로 검증해야 함.
- `ScriptableObject`의 원본 수치가 Runtime에서 변경되지 않는지 점검.
- `Time.timeScale = 0`에서는 `WaitForSeconds`가 정지하지만 IMGUI와 일부 Update는 계속 호출될 수 있음. 게임플레이 명령은 상태로 보호해야 함.
- 독립 실습 Scene은 AI Navigation Bake를 필요로 하지 않음. NavMesh 연동은 확장 과제.

## 채점: 총 100점

웨이브 상태·완료 판정 25점, 난이도 데이터화 20점, Pool 통합 25점, 경계·오류 처리 15점, Codex 검증·보고 15점.
