# Unity Codex — 55일차: 웨이브와 난이도

**대상 환경:** Unity 6.3, 3D/URP 또는 Universal 3D 프로젝트, C# / Unity Editor.

## 학습 결과

- 웨이브별 몬스터 총 생성 수, 최대 동시 생존 수, 생성 간격을 구별합니다.
- `Day55WaveConfig`에서 데이터를 설정하고 `Day55DifficultyDirector`에서 실행 수치를 계산합니다.
- `Day55WaveSpawner`의 Ready → Spawning → Clearing → Break → Completed 전환을 구현합니다.
- `Day55MonsterPool`의 Prewarm/Get/Release/카운트를 사용하고 재생성 때 체력·속도를 초기화합니다.
- 코드와 에셋을 무작정 수정하지 않고 Play Mode 지표로 난이도를 검증합니다.

## Unity 프로젝트에 설치

1. 이 ZIP의 `Runtime/*.cs` 파일을 프로젝트 `Assets/Day55/Runtime/` 폴더에 복사합니다.
2. `Editor/*.cs` 파일은 반드시 `Assets/Day55/Editor/`에 복사합니다. `UnityEditor` 네임스페이스는 빌드 대상에 포함되면 안 됩니다.
3. Unity 컴파일 오류가 없는지 Console을 확인합니다.
4. 상단 메뉴 `Tools → Unity Codex → Day55 → Create Wave Lab`을 실행합니다.
5. **새 Scene과 Prefab, ScriptableObject 에셋이 별도의 시각 포함 폴더에 생성**됩니다. 기존 씬 저장 여부를 묻는 창이 나올 수 있습니다.
6. `Day55_WaveLab.unity`가 열리면 `WaveSpawner`와 `Day55WaveConfig.asset` Inspector 값을 확인합니다.
7. Play ▶: 자동으로 1~3 Wave가 시작됩니다. 화면 좌상단 HUD 버튼으로 몬스터를 처치하고 전환을 확인합니다.
8. 메뉴 `Tools → Unity Codex → Day55 → Validate Current Scene`으로 구성 검사도 수행합니다.

## HUD 버튼

| 버튼 | 동작 |
|---|---|
| Start | 첫 웨이브부터 실행(실행 중이면 기존 루프 종료 후 초기화) |
| Restart | 현재 런 취소 후 첫 웨이브부터 새로 시작 |
| Stop | 스폰 루프 중지 및 활성 몬스터 모두 반환 |
| Defeat One | 활성 몬스터 1마리에게 충분한 데미지 |
| Defeat All | 활성 몬스터 전부 처치 |

**실습 포인트:** `monsterCount = 8`, `maxAlive = 3`이면 8마리 전부 생성될 때까지, 한 번에 최대 3마리만 활성 상태입니다. 8마리 생성 완료 후 `CountActive == 0`이 되어야 Wave Clear로 넘어갑니다.

## 난이도 수치 설정

`Day55WaveConfig.asset`에서 1~3 웨이브의 기본 생성 수·최대 동시 생존 수·기본 HP·이동 속도·생성 간격을 수정할 수 있습니다. `Day55DifficultyDirector`의 growth가 1이면 에셋의 각 웨이브 고유 값만 적용됩니다. 성장 배율이 1을 초과하면 에셋 값에 단계별 배율이 추가로 곱해지므로 **이중 증가 여부를 확인**하세요. 최대치 설정은 과도한 증가를 막습니다.

## 52~54일차 프로젝트 통합 시 주의

이 코드는 **독립 실습용**으로 설계했습니다. 54일차 MonsterPool 및 52일차 EnemyBrain의 클래스·구독 방식을 모른 채 강제로 덮어쓰지 않습니다. 실제 프로젝트에는 다음 연결 방식을 권장합니다.

- 기존 적 Prefab과 52일차 AI는 유지합니다.
- 스폰 성공 여부, 몬스터 반환 이벤트, 활성 수를 추상화한 어댑터를 만듭니다.
- Spawner만 기존 풀 구현을 호출하도록 변경합니다.
- 기존 웨이브 관리자와 `Day55WaveSpawner`를 동일 씬에서 동시에 실행하지 않습니다.
- `Day55MonsterUnit`은 간단한 이동 데모이며, NavMeshAgent가 없는 경우 Transform 기반으로 이동합니다. **AI Navigation Bake는 자동 수행하지 않습니다.**
- NavMesh 기반 프로젝트에 연결하려면 NavMesh Bake 후 `useNavMeshPositionCheck`를 사용하고, Agent 설정/Spawn 위치를 재검토합니다.

## 검증 환경과 한계

PPT와 예제 소스의 구조 및 API 명칭은 확인했으나 **실제 사용자 Unity 프로젝트 안에서의 컴파일·Play Mode·빌드 실행은 수행하지 않았습니다.** 도입 전 복사본 또는 신규 씬에서 검증하고 `Docs/Day55_Test_Checklist.csv`로 결과를 남기세요.

## 공식 API 참고

- https://docs.unity.com/en-us/engine/6000.6/script-reference/unityengine/pool/objectpool1
- https://docs.unity.com/en-us/engine/6000.7/script-reference/unityengine/ai/navmesh/sampleposition
- https://docs.unity3d.com/kr/current/Manual/class-ScriptableObject.html
