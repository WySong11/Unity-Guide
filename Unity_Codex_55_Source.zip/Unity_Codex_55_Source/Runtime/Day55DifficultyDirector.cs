using UnityEngine;

// 고정 Wave 데이터를 '실행용 수치'로 환산합니다.
public class Day55DifficultyDirector : MonoBehaviour
{
    [Header("Growth per wave (1 = keep authored values)")]
    [SerializeField, Min(1f)] private float countGrowth = 1f;
    [SerializeField, Min(1f)] private float hpGrowth = 1f;
    [SerializeField, Min(1f)] private float speedGrowth = 1f;
    [SerializeField, Range(0.5f, 1f)] private float intervalFactor = 1f;

    [Header("Safety limits")]
    [SerializeField, Min(1)] private int maxMonsterCount = 40;
    [SerializeField, Min(1)] private int maxConcurrentAlive = 12;
    [SerializeField, Min(1f)] private float maxMonsterHP = 500f;
    [SerializeField, Min(0.1f)] private float maxMoveSpeed = 10f;
    [SerializeField, Min(0.05f)] private float minSpawnInterval = 0.25f;

    public Day55WavePlan Evaluate(Day55WaveEntry entry, int zeroBasedWaveIndex)
    {
        int index = Mathf.Max(0, zeroBasedWaveIndex);
        int count = Mathf.Clamp(
            Mathf.RoundToInt(entry.monsterCount * Mathf.Pow(countGrowth, index)),
            1, Mathf.Max(1, maxMonsterCount));

        return new Day55WavePlan
        {
            monsterCount = count,
            maxAlive = Mathf.Clamp(entry.maxAlive, 1, Mathf.Min(count, Mathf.Max(1, maxConcurrentAlive))),
            hp = Mathf.Clamp(entry.monsterHP * Mathf.Pow(hpGrowth, index), 1f, Mathf.Max(1f, maxMonsterHP)),
            moveSpeed = Mathf.Clamp(entry.moveSpeed * Mathf.Pow(speedGrowth, index), 0.1f, Mathf.Max(0.1f, maxMoveSpeed)),
            spawnInterval = Mathf.Max(Mathf.Max(0.05f, minSpawnInterval),
                entry.spawnInterval * Mathf.Pow(intervalFactor, index))
        };
    }
}
