using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

[DisallowMultipleComponent]
public class Day55MonsterPool : MonoBehaviour
{
    [SerializeField] private Day55MonsterUnit monsterPrefab;
    [SerializeField] private Transform poolRoot;
    [SerializeField, Min(0)] private int prewarm = 8;
    [SerializeField, Min(1)] private int maxInactive = 30;

    public event Action<Day55MonsterUnit> UnitKilled;
    public int CountActive => active.Count;
    public int CountAll => pool == null ? 0 : pool.CountAll;
    public int CountInactive => pool == null ? 0 : pool.CountInactive;

    private IObjectPool<Day55MonsterUnit> pool;
    private readonly HashSet<Day55MonsterUnit> active = new HashSet<Day55MonsterUnit>();

    private void Awake()
    {
        if (monsterPrefab == null)
        {
            Debug.LogError("[Day55] Monster prefab missing", this);
            enabled = false;
            return;
        }
        if (poolRoot == null) poolRoot = transform;
        pool = new ObjectPool<Day55MonsterUnit>(Create, OnGet, OnRelease, OnDestroyItem,
            collectionCheck: true, defaultCapacity: Mathf.Max(1, prewarm), maxSize: Mathf.Max(1, maxInactive));

        // defaultCapacity는 인스턴스를 생성하지 않으므로 직접 Prewarm 합니다.
        var temporary = new List<Day55MonsterUnit>(prewarm);
        for (int i = 0; i < prewarm; i++) temporary.Add(pool.Get());
        foreach (var unit in temporary) pool.Release(unit);
    }

    private Day55MonsterUnit Create()
    {
        var unit = Instantiate(monsterPrefab, poolRoot);
        unit.gameObject.SetActive(false);
        unit.Died += HandleDied; // 한 인스턴스당 1회만 등록
        return unit;
    }

    private void OnGet(Day55MonsterUnit unit) { /* 좌표와 난이도를 확정한 뒤 Spawn에서 활성화 */ }
    private void OnRelease(Day55MonsterUnit unit) => unit.Despawn();
    private void OnDestroyItem(Day55MonsterUnit unit)
    {
        if (unit == null) return;
        unit.Died -= HandleDied;
        Destroy(unit.gameObject);
    }

    public bool TrySpawn(Vector3 position, Day55WavePlan plan, Transform target)
    {
        if (pool == null) return false;
        var unit = pool.Get();
        if (!active.Add(unit))
        {
            Debug.LogError("[Day55] Instance was rented twice.", unit);
            pool.Release(unit);
            return false;
        }
        unit.Spawn(position, plan, target);
        return true;
    }

    private void HandleDied(Day55MonsterUnit unit)
    {
        if (!active.Contains(unit)) return;
        Return(unit);
        UnitKilled?.Invoke(unit);
    }

    public void Return(Day55MonsterUnit unit)
    {
        if (unit == null || pool == null || !active.Remove(unit)) return;
        pool.Release(unit);
    }

    public void ReturnAll()
    {
        var snapshot = new List<Day55MonsterUnit>(active);
        foreach (var unit in snapshot) Return(unit);
    }

    public bool DamageOne(float damage)
    {
        foreach (var unit in active)
        {
            if (unit == null) continue;
            unit.TakeDamage(damage);
            return true; // 루프 반복 중 HashSet 변경 방지
        }
        return false;
    }

    public void DamageAll(float damage)
    {
        var snapshot = new List<Day55MonsterUnit>(active);
        foreach (var unit in snapshot) if (unit != null) unit.TakeDamage(damage);
    }

    private void OnDestroy()
    {
        active.Clear();
        pool?.Clear(); // 비활성 보관 객체만 정리
    }
}
