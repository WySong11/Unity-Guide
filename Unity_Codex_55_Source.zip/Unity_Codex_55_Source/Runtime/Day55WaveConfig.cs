using System;
using UnityEngine;

// 설정 데이터는 에셋에 저장하고 런타임에서는 수정하지 않습니다.
[Serializable]
public class Day55WaveEntry
{
    [Min(1)] public int monsterCount = 4;
    [Min(1)] public int maxAlive = 3;
    [Min(1f)] public float monsterHP = 40f;
    [Min(0.1f)] public float moveSpeed = 2.5f;
    [Min(0.05f)] public float spawnInterval = 1.0f;
}

public struct Day55WavePlan
{
    public int monsterCount;
    public int maxAlive;
    public float hp;
    public float moveSpeed;
    public float spawnInterval;
}

[CreateAssetMenu(fileName = "Day55WaveConfig", menuName = "Unity Codex/Day55/Wave Config")]
public class Day55WaveConfig : ScriptableObject
{
    public Day55WaveEntry[] waves =
    {
        new Day55WaveEntry { monsterCount = 4, maxAlive = 3, monsterHP = 40f, moveSpeed = 2.5f, spawnInterval = 1f },
        new Day55WaveEntry { monsterCount = 6, maxAlive = 4, monsterHP = 55f, moveSpeed = 3f, spawnInterval = 0.85f },
        new Day55WaveEntry { monsterCount = 8, maxAlive = 5, monsterHP = 75f, moveSpeed = 3.5f, spawnInterval = 0.7f }
    };

    [Min(0f)] public float breakSeconds = 3f;

    private void OnValidate()
    {
        breakSeconds = Mathf.Max(0f, breakSeconds);
        if (waves == null) return;
        foreach (var entry in waves)
        {
            if (entry == null) continue;
            entry.monsterCount = Mathf.Max(1, entry.monsterCount);
            entry.maxAlive = Mathf.Clamp(entry.maxAlive, 1, entry.monsterCount);
            entry.monsterHP = Mathf.Max(1f, entry.monsterHP);
            entry.moveSpeed = Mathf.Max(0.1f, entry.moveSpeed);
            entry.spawnInterval = Mathf.Max(0.05f, entry.spawnInterval);
        }
    }
}
