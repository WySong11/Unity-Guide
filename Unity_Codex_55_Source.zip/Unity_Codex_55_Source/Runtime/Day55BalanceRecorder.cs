using UnityEngine;

// 시간을 기록해 난이도 조정의 정량 지표로 사용합니다.
public class Day55BalanceRecorder : MonoBehaviour
{
    [SerializeField] private Day55WaveSpawner spawner;
    private float startScaledTime;

    private void OnEnable()
    {
        if (spawner == null) return;
        spawner.WaveStarted += OnWaveStarted;
        spawner.WaveCleared += OnWaveCleared;
    }

    private void OnDisable()
    {
        if (spawner == null) return;
        spawner.WaveStarted -= OnWaveStarted;
        spawner.WaveCleared -= OnWaveCleared;
    }

    private void OnWaveStarted(int number, Day55WavePlan plan)
    {
        startScaledTime = Time.time;
        Debug.Log($"[Day55] Wave {number} start: count={plan.monsterCount}, " +
                  $"maxAlive={plan.maxAlive}, HP={plan.hp:F1}, speed={plan.moveSpeed:F1}");
    }

    private void OnWaveCleared(int number)
    {
        Debug.Log($"[Day55] Wave {number} cleared in {Time.time - startScaledTime:F2} scaled seconds");
    }
}
