using System;
using System.Collections;
using UnityEngine;
using UnityEngine.AI;

public enum Day55WaveState { Idle, Ready, Spawning, Clearing, Break, Completed, Failed }

[DisallowMultipleComponent]
public class Day55WaveSpawner : MonoBehaviour
{
    [SerializeField] private Day55WaveConfig waveConfig;
    [SerializeField] private Day55DifficultyDirector difficultyDirector;
    [SerializeField] private Day55MonsterPool monsterPool;
    [SerializeField] private Transform playerTarget;
    [SerializeField] private Transform[] spawnPoints;
    [SerializeField] private bool useNavMeshPositionCheck;
    [SerializeField, Min(0.2f)] private float sampleRadius = 1.5f;
    [SerializeField] private bool startAutomatically = true;

    public event Action<Day55WaveState> StateChanged;
    public event Action<int, Day55WavePlan> WaveStarted;
    public event Action<int> WaveCleared;
    public event Action RunCompleted;

    public Day55WaveState State { get; private set; } = Day55WaveState.Idle;
    public int WaveNumber { get; private set; }
    public int Spawned { get; private set; }
    public int Killed { get; private set; }
    public int Alive => monsterPool == null ? 0 : monsterPool.CountActive;
    public Day55WavePlan CurrentPlan { get; private set; }

    private Coroutine routine;
    private int nextPointIndex;

    private void OnEnable()
    {
        if (monsterPool != null) monsterPool.UnitKilled += HandleUnitKilled;
    }

    private void Start()
    {
        if (startAutomatically) StartRun();
    }

    private void OnDisable()
    {
        if (monsterPool != null) monsterPool.UnitKilled -= HandleUnitKilled;
        if (routine != null) StopCoroutine(routine);
        routine = null;
    }

    public void StartRun()
    {
        StopRun();
        if (!ValidateSetup())
        {
            SetState(Day55WaveState.Failed);
            return;
        }
        routine = StartCoroutine(RunAllWaves());
    }

    public void RestartRun() => StartRun();

    public void StopRun()
    {
        if (routine != null) StopCoroutine(routine);
        routine = null;
        if (monsterPool != null) monsterPool.ReturnAll();
        WaveNumber = 0;
        Spawned = 0;
        Killed = 0;
        nextPointIndex = 0;
        SetState(Day55WaveState.Idle);
    }

    private bool ValidateSetup()
    {
        bool valid = waveConfig != null && waveConfig.waves != null && waveConfig.waves.Length > 0
            && difficultyDirector != null && monsterPool != null && monsterPool.enabled
            && spawnPoints != null && spawnPoints.Length > 0;
        if (!valid) Debug.LogError("[Day55] Config / Director / Pool / SpawnPoints missing", this);
        return valid;
    }

    private IEnumerator RunAllWaves()
    {
        for (int index = 0; index < waveConfig.waves.Length; index++)
        {
            var entry = waveConfig.waves[index];
            if (entry == null) { Fail("Null wave entry"); yield break; }

            WaveNumber = index + 1;
            Spawned = 0;
            Killed = 0;
            CurrentPlan = difficultyDirector.Evaluate(entry, index);
            SetState(Day55WaveState.Ready);
            WaveStarted?.Invoke(WaveNumber, CurrentPlan);
            yield return null;
            SetState(Day55WaveState.Spawning);
            int consecutiveFailures = 0;

            while (Spawned < CurrentPlan.monsterCount)
            {
                if (Alive >= CurrentPlan.maxAlive)
                {
                    yield return null;
                    continue;
                }
                if (!TrySpawn(CurrentPlan))
                {
                    consecutiveFailures++;
                    if (consecutiveFailures >= 5)
                    {
                        Fail("Spawn failed five consecutive times");
                        yield break;
                    }
                    yield return new WaitForSeconds(0.25f);
                    continue;
                }
                consecutiveFailures = 0;
                Spawned++;
                yield return new WaitForSeconds(CurrentPlan.spawnInterval);
            }

            SetState(Day55WaveState.Clearing);
            while (Alive > 0) yield return null;
            WaveCleared?.Invoke(WaveNumber);

            if (index < waveConfig.waves.Length - 1)
            {
                SetState(Day55WaveState.Break);
                if (waveConfig.breakSeconds > 0f)
                    yield return new WaitForSeconds(waveConfig.breakSeconds);
            }
        }

        SetState(Day55WaveState.Completed);
        routine = null;
        RunCompleted?.Invoke();
    }

    private bool TrySpawn(Day55WavePlan plan)
    {
        if (spawnPoints.Length == 0) return false;
        int count = spawnPoints.Length;
        for (int attempt = 0; attempt < count; attempt++)
        {
            int index = nextPointIndex++ % count;
            Transform point = spawnPoints[index];
            if (point == null) continue;
            Vector3 position = point.position;
            if (useNavMeshPositionCheck)
            {
                if (!NavMesh.SamplePosition(position, out NavMeshHit hit,
                    sampleRadius, NavMesh.AllAreas)) continue;
                position = hit.position;
            }
            return monsterPool.TrySpawn(position, plan, playerTarget);
        }
        return false;
    }

    private void HandleUnitKilled(Day55MonsterUnit unit) => Killed++;
    private void Fail(string message)
    {
        Debug.LogError("[Day55] " + message, this);
        SetState(Day55WaveState.Failed);
        routine = null;
    }
    private void SetState(Day55WaveState next)
    {
        if (State == next) return;
        State = next;
        StateChanged?.Invoke(next);
    }
}
