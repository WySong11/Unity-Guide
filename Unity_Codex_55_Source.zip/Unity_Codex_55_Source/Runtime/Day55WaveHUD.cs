using UnityEngine;

// Unity UI 설정 없이 Play 모드에서 테스트할 수 있는 임시 IMGUI HUD.
public class Day55WaveHUD : MonoBehaviour
{
    [SerializeField] private Day55WaveSpawner spawner;
    [SerializeField] private Day55MonsterPool pool;
    [SerializeField, Min(1f)] private float damagePerClick = 9999f;
    [SerializeField] private bool showHUD = true;

    private void OnGUI()
    {
        if (!showHUD || spawner == null || pool == null) return;
        GUILayout.BeginArea(new Rect(15f, 15f, 320f, 240f), GUI.skin.box);
        GUILayout.Label("DAY55 | WAVE & DIFFICULTY");
        GUILayout.Label($"Wave: {spawner.WaveNumber}   State: {spawner.State}");
        GUILayout.Label($"Spawned: {spawner.Spawned} / {spawner.CurrentPlan.monsterCount}");
        GUILayout.Label($"Killed: {spawner.Killed}   Alive: {spawner.Alive}");
        GUILayout.Label($"Pool: All {pool.CountAll}, Active {pool.CountActive}, Inactive {pool.CountInactive}");
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Start")) spawner.StartRun();
        if (GUILayout.Button("Restart")) spawner.RestartRun();
        if (GUILayout.Button("Stop")) spawner.StopRun();
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Defeat One")) pool.DamageOne(damagePerClick);
        if (GUILayout.Button("Defeat All")) pool.DamageAll(damagePerClick);
        GUILayout.EndHorizontal();
        GUILayout.EndArea();
    }
}
