using System;
using UnityEngine;
using UnityEngine.AI;

[DisallowMultipleComponent]
public class Day55MonsterUnit : MonoBehaviour
{
    [SerializeField] private NavMeshAgent optionalAgent;
    [SerializeField, Min(0f)] private float stoppingDistance = 1.5f;

    public event Action<Day55MonsterUnit> Died;
    public float HP { get; private set; }
    public float MaxHP { get; private set; }
    public float MoveSpeed { get; private set; }
    public bool IsDead { get; private set; } = true;

    private Transform target;
    private float nextRepathTime;

    // Object Pool에서 Get한 객체를 새 Wave 상태로 재초기화합니다.
    public void Spawn(Vector3 position, Day55WavePlan plan, Transform followTarget)
    {
        target = followTarget;
        MaxHP = Mathf.Max(1f, plan.hp);
        HP = MaxHP;
        MoveSpeed = Mathf.Max(0.1f, plan.moveSpeed);
        IsDead = false;
        nextRepathTime = 0f;

        transform.position = position;
        gameObject.SetActive(true);

        if (optionalAgent != null && optionalAgent.enabled && optionalAgent.isOnNavMesh)
        {
            optionalAgent.Warp(position);
            optionalAgent.isStopped = false;
            optionalAgent.speed = MoveSpeed;
            optionalAgent.ResetPath();
        }
    }

    private void Update()
    {
        if (IsDead || target == null) return;
        Vector3 delta = target.position - transform.position;
        delta.y = 0f;
        if (delta.sqrMagnitude <= stoppingDistance * stoppingDistance) return;

        if (optionalAgent != null && optionalAgent.enabled && optionalAgent.isOnNavMesh)
        {
            if (Time.time < nextRepathTime) return;
            nextRepathTime = Time.time + 0.2f;
            optionalAgent.SetDestination(target.position);
        }
        else
        {
            Vector3 next = Vector3.MoveTowards(transform.position,
                transform.position + delta, MoveSpeed * Time.deltaTime);
            transform.position = next;
        }
    }

    public void TakeDamage(float damage)
    {
        if (IsDead || damage <= 0f) return;
        HP = Mathf.Max(0f, HP - damage);
        if (HP > 0f) return;
        IsDead = true;
        Died?.Invoke(this);
    }

    public void Despawn()
    {
        IsDead = true;
        target = null;
        if (optionalAgent != null && optionalAgent.enabled && optionalAgent.isOnNavMesh)
        {
            optionalAgent.isStopped = true;
            optionalAgent.ResetPath();
        }
        gameObject.SetActive(false);
    }
}
