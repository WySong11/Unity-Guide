# Unity × Codex | 63일차 사운드 · 이펙트 · 애니메이션

Unity 6.3 + URP + Input System 기반 독립 실습 프로젝트 소스입니다. 총 11개의 C# 스크립트가 포함됩니다.

## 설치 및 실행
1. Unity 6.3 URP 프로젝트를 생성하고 **Input System** 패키지를 활성화합니다.
2. 이 ZIP의 `Assets/Day63_FeedbackLab/Runtime`, `Editor`를 Unity 프로젝트 `Assets/Day63_FeedbackLab/` 아래에 복사합니다.
3. 컴파일 완료 후 `Tools > Unity Codex > Day63 > Create Feedback Lab` 메뉴를 실행합니다.
4. `Assets/Day63_Feedback_Lab[_N]/Scenes/Day63_FeedbackDemo.unity` 씬을 엽니다.
5. Play Mode에서 `1` Attack, `2` Hit, `3` Kill, `R` Reset, `P` Pause를 테스트합니다.
6. `Tools > Unity Codex > Day63 > Validate Active Scene`으로 정적 연결을 확인합니다.

## 구조
CombatActor는 이벤트만 발행합니다. CombatPresenter가 AudioService · ParticleFxPool · AnimatorBridge를 호출합니다. AudioService는 **교육용 자체 생성 톤**을 사용하므로 외부 유료 SFX 없이 들리는 음을 테스트할 수 있습니다. 이 클립은 상용 게임에 바로 쓰는 효과음이 아닙니다.

## 기존 프로젝트 연결
- Day51·Day52의 전투/EnemyBrain을 한 오브젝트에 중복 부착하지 않습니다. 기존 전투 이벤트를 Day63CombatPresenter의 입력 이벤트로 어댑팅하십시오.
- Day62 GameFlowManager의 Pause 이벤트에서 `Day63AudioService.SetGameAudioPaused`를 호출할 수 있습니다. Day63InputDemo의 P 테스트용 Pause와 동시에 적용하지 마십시오.
- AnimatorController는 샘플용 크기 변화 클립만 포함합니다. 실제 캐릭터 클립으로 교체하십시오.
- AudioMixer의 Exposed Parameter `SFXVolume`과 Mixer Group은 Unity Editor에서 별도 생성·연결하면 됩니다.

## 테스트 한계
본 자료 제작 환경에서는 PPT 렌더링·ZIP 검사를 수행했습니다. Unity Editor 내 실제 컴파일과 Play Mode 실행은 수강생 환경에서 진행해야 합니다.
