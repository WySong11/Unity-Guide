# 63일차 학생 워크시트 (120분)

## 과제 A (0~25분)
CombatActor → Presenter → Audio/VFX/Animator 의존성 다이어그램을 그리세요. Gameplay 이벤트와 Presentation 책임을 구분하세요.

## 과제 B (25~50분)
AudioSource 2개를 확인하고 Attack/Hit/Dead 오디오가 다른 시점에 재생되는지 검증하세요. BGM Pause/Resume과 SFX PlayOneShot의 차이를 적으세요.

## 과제 C (50~95분)
ParticleSystem의 Looping·StopAction을 확인하고 20번 연속 테스트에서 Pool Active/Inactive가 복구되는지 검사하세요. Animator Attack/Hit/IsDead 전이를 관찰하세요.

## 과제 D (95~120분)
T01~T12 체크리스트의 실행 결과·증거·재현 단계를 작성하고 Codex 리뷰 후 실제 수정 diff를 남기세요.

## 제출
스크린샷 6장 이상(씬·Inspector·Particle·Animator·HUD·Profiler 또는 Console), 테스트표, 수정 전후 설명, 남은 문제.
