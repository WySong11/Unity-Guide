# Codex에 내릴 Prompt

## 구조 리뷰
Unity 6.3 URP 프로젝트의 Day63 전투 피드백을 분석해줘. Attack/Hit/Dead 이벤트에서 Sound/Particle/Animator 호출 시점이 다른지 확인하고, OnEnable/OnDisable 구독 수명과 중복 사망 이벤트를 검사해줘. 다른 날짜 소스는 수정하지 마.

## ObjectPool 검증
Day63ParticleFxPool의 Prewarm·Release·OnParticleSystemStopped 수명을 코드 기준으로 점검해줘. Callback/Loop 설정, 중복 반환, maxSize 의미, 씬 종료 시 null 가능성을 보고해줘. 수정 전후 diff를 만들어줘.

## 실기 테스트
T01~T12 체크리스트대로 Unity Editor Play Mode를 테스트해줘. 직접 실행하여 확인한 항목, 로그나 스크린샷을 근거로 확인한 항목, 실행하지 못한 항목을 명확히 구분하고 미실행은 통과로 처리하지 마.

## 성능
연속 Hit 50회 재현 시 GC Alloc, Active FX, Audio Voices를 Profiler에서 비교하고 중복 연출과 메모리 누수 가능성만 최소한으로 수정해줘.
