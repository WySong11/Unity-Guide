# 63일차 강사용 진행 가이드

- 00~25분: Attack → Hit → Dead 시점 차이, Event Presenter 아키텍처 설명
- 25~50분: AudioSource.PlayOneShot, BGM/Pause, Mixer 라우팅 비교
- 50~95분: ParticleSystem Callback, ObjectPool<T>·Prewarm, Animator 전이 실습
- 95~120분: T01~T12 / Codex 코드 리뷰 / 제출 증빙 확인

### 강조할 기술적 주의사항
1. `Time.timeScale=0`은 AudioSource를 자동 정지하지 않습니다.
2. `ObjectPool<T>.maxSize`는 **풀 보관 수** 상한이지 동시 활성 총수 하드캡이 아닙니다.
3. `ParticleSystem.MainModule.stopAction=Callback` 설정이 되어야 `OnParticleSystemStopped()`를 받습니다.
4. 죽음 이벤트는 HP가 0에 도달할 때 한 번만 발생해야 합니다.
5. `OnEnable`/`OnDisable` 구독과 해제를 반드시 짝지으세요.
6. Animator Transition에 `IsDead` 전환 우선순위를 설정하거나 실제 캐릭터에서는 생존 상태가 아닐 때 Attack/Hit 트리거를 차단해야 합니다.
7. 오디오·VFX 실패가 HP 계산 결과를 바꾸면 안 됩니다.
8. 데모 Animator는 Scale 애니메이션이며 실전용 리깅/클립이 아닙니다.

### 평가
Rubric CSV 100점, T01~T12 실행 결과는 자동 채점이 아니라 사람의 재현 검증입니다.
