# Unity API 참고

- Unity Scripting API | `Animator.SetTrigger`: https://docs.unity3d.com/6000.0/Documentation/ScriptReference/Animator.SetTrigger.html
- Unity Scripting API | `MonoBehaviour.OnParticleSystemStopped`: https://docs.unity3d.com/6000.0/Documentation/ScriptReference/MonoBehaviour.OnParticleSystemStopped.html
- Unity Scripting API | `Pool.ObjectPool<T>`: https://docs.unity3d.com/6000.0/Documentation/ScriptReference/Pool.ObjectPool_1-ctor.html
- Unity Scripting API | `AudioSource.PlayOneShot`: https://docs.unity3d.com/ScriptReference/AudioSource.PlayOneShot.html
- Unity Scripting API | `AudioMixer.SetFloat`: https://docs.unity3d.com/ScriptReference/Audio.AudioMixer.SetFloat.html

샘플은 2026년 10월 Unity 6.3 대상이며, 실제 환경에서 버전별 API 동작을 다시 확인하십시오.
