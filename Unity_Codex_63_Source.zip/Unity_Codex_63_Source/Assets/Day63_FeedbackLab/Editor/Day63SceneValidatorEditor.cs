#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

public static class Day63SceneValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day63/Validate Active Scene")]
    public static void ValidateScene()
    {
        var actor = Object.FindFirstObjectByType<Day63CombatActor>();
        var audio = Object.FindFirstObjectByType<Day63AudioService>();
        var pool = Object.FindFirstObjectByType<Day63ParticleFxPool>();
        var bridge = Object.FindFirstObjectByType<Day63AnimatorBridge>();
        var presenter = Object.FindFirstObjectByType<Day63CombatPresenter>();
        var control = Object.FindFirstObjectByType<Day63InputDemo>();
        int errors=0;
        if(actor==null) {Debug.LogError("Day63: CombatActor missing");errors++;}
        if(audio==null) {Debug.LogError("Day63: AudioService missing");errors++;}
        if(pool==null) {Debug.LogError("Day63: FxPool missing");errors++;}
        if(bridge==null) {Debug.LogError("Day63: AnimatorBridge missing");errors++;}
        if(presenter==null) {Debug.LogError("Day63: CombatPresenter missing");errors++;}
        if(control==null) {Debug.LogError("Day63: InputDemo missing");errors++;}
        if(presenter!=null)
        {
            var so=new SerializedObject(presenter);
            foreach(string prop in new[]{"actor","audioService","hitPool","animations","effectOrigin"})
                if(so.FindProperty(prop).objectReferenceValue==null) {Debug.LogError("Day63: missing presenter ref: "+prop); errors++;}
        }
        Debug.Log(errors==0?"Day63: scene static checks passed (Play Mode tests required).":$"Day63: {errors} static issues found.");
    }
}
#endif
