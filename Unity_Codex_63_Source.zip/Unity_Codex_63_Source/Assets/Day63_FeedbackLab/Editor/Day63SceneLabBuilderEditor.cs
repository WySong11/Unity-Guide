#if UNITY_EDITOR
using System;
using UnityEditor;
using UnityEditor.Animations;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class Day63SceneLabBuilderEditor
{
    [MenuItem("Tools/Unity Codex/Day63/Create Feedback Lab")]
    public static void CreateLab()
    {
        const string basePath = "Assets/Day63_Feedback_Lab";
        string folder = AssetDatabase.GenerateUniqueAssetPath(basePath);
        AssetDatabase.CreateFolder("Assets", folder.Substring("Assets/".Length));
        string fxDir = MakeDir(folder, "Prefabs");
        string animationDir = MakeDir(folder, "Animations");
        string sceneDir = MakeDir(folder, "Scenes");
        var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Ground";ground.transform.position = Vector3.zero;
        ground.transform.localScale = new Vector3(2,1,2);
        GameObject actorObject = new GameObject("EnemyActor");
        actorObject.transform.position = new Vector3(0f,0f,2f);
        var actor = actorObject.AddComponent<Day63CombatActor>();
        var visual = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        visual.name = "Visual";visual.transform.SetParent(actorObject.transform,false);
        visual.transform.localPosition = Vector3.up;
        var animator = visual.AddComponent<Animator>();
        animator.applyRootMotion = false;
        animator.runtimeAnimatorController = CreateAnimator(animationDir);
        var bridge = actorObject.AddComponent<Day63AnimatorBridge>();
        SetRef(bridge, "animator", animator);
        var sfx = new GameObject("AudioSystem");
        var sfxSource = sfx.AddComponent<AudioSource>();
        var bgmSource = sfx.AddComponent<AudioSource>();
        sfxSource.playOnAwake = false;
        bgmSource.playOnAwake = false;
        var audio = sfx.AddComponent<Day63AudioService>();
        SetRef(audio,"sfxSource",sfxSource);
        SetRef(audio,"bgmSource",bgmSource);
        var fxPrefab = new GameObject("BurstFx");
        var ps = fxPrefab.AddComponent<ParticleSystem>();
        var main = ps.main; main.loop = false;main.duration = 0.12f;
        main.startLifetime = 0.35f;main.startSize = 0.12f;
        main.startSpeed = 2.4f;main.startColor = new Color(1f,0.55f,0.08f);
        main.stopAction = ParticleSystemStopAction.Callback;
        var emission = ps.emission;emission.rateOverTime = 0;
        emission.SetBursts(new[] {new ParticleSystem.Burst(0f, (short)22)});
        var shape=ps.shape;shape.shapeType=ParticleSystemShapeType.Sphere;shape.radius=0.2f;
        fxPrefab.AddComponent<Day63PooledFx>();
        // Create a URP-compatible particle material when URP is installed.
        Shader shader = Shader.Find("Universal Render Pipeline/Particles/Unlit");
        if (shader != null)
        {
            var material = new Material(shader);
            AssetDatabase.CreateAsset(material, fxDir + "/Day63_URPParticle.mat");
            var renderer = fxPrefab.GetComponent<ParticleSystemRenderer>();
            if (renderer != null) renderer.sharedMaterial = material;
        }
        else Debug.LogWarning("Day63: URP Particle Shader not found. Assign a particle material in Inspector.");
        string prefabPath = fxDir + "/Day63_BurstFx.prefab";
        var prefab = PrefabUtility.SaveAsPrefabAsset(fxPrefab,prefabPath);
        UnityEngine.Object.DestroyImmediate(fxPrefab);
        var fxRoot = new GameObject("VFX_Pool");
        var pool = fxRoot.AddComponent<Day63ParticleFxPool>();
        SetRef(pool,"prefab",prefab.GetComponent<Day63PooledFx>());
        var presenter = actorObject.AddComponent<Day63CombatPresenter>();
        SetRef(presenter,"actor",actor);SetRef(presenter,"audioService",audio);
        SetRef(presenter,"hitPool",pool);SetRef(presenter,"animations",bridge);
        SetRef(presenter,"effectOrigin",visual.transform);
        var uiObj = new GameObject("DemoControls");
        var input=uiObj.AddComponent<Day63InputDemo>();
        SetRef(input,"actor",actor);SetRef(input,"audioService",audio);
        var hud=uiObj.AddComponent<Day63DebugHUD>();
        SetRef(hud,"actor",actor);SetRef(hud,"audioService",audio);
        SetRef(hud,"fxPool",pool);SetRef(hud,"input",input);
        var camera = Camera.main;
        if(camera!=null) { camera.transform.position = new Vector3(0,3.2f,-8f); camera.transform.LookAt(new Vector3(0,1,2)); }
        string scenePath=sceneDir+"/Day63_FeedbackDemo.unity";
        EditorSceneManager.SaveScene(scene,scenePath);
        AssetDatabase.SaveAssets();AssetDatabase.Refresh();
        EditorUtility.DisplayDialog("Day63 Lab", "Created scene, FX prefab, and Animator Controller in:\n"+folder+"\nOpen demo scene and press Play.","OK");
        Selection.activeObject=AssetDatabase.LoadAssetAtPath<SceneAsset>(scenePath);
    }
    private static string MakeDir(string parent,string name)
    {
        AssetDatabase.CreateFolder(parent,name); return parent+"/"+name;
    }
    private static void SetRef(UnityEngine.Object target,string field,UnityEngine.Object value)
    {
        var so = new SerializedObject(target);
        so.FindProperty(field).objectReferenceValue=value;
        so.ApplyModifiedPropertiesWithoutUndo();
    }
    private static AnimationClip Clip(string path,string name,float start,float peak,float end)
    {
        var clip=new AnimationClip();clip.name=name;clip.frameRate=30;
        clip.SetCurve("",typeof(Transform),"m_LocalScale.y",
            new AnimationCurve(new Keyframe(0,start),new Keyframe(0.12f,peak),new Keyframe(0.3f,end)));
        AssetDatabase.CreateAsset(clip,path+"/"+name+".anim");return clip;
    }
    private static RuntimeAnimatorController CreateAnimator(string dir)
    {
        string path=dir+"/Day63_Feedback.controller";
        var ctl=AnimatorController.CreateAnimatorControllerAtPath(path);
        ctl.AddParameter("Attack",AnimatorControllerParameterType.Trigger);
        ctl.AddParameter("Hit",AnimatorControllerParameterType.Trigger);
        ctl.AddParameter("IsDead",AnimatorControllerParameterType.Bool);
        var machine=ctl.layers[0].stateMachine;
        var idle=machine.AddState("Idle"); idle.motion=Clip(dir,"Idle",1f,1f,1f);
        var attack=machine.AddState("AttackState");attack.motion=Clip(dir,"Attack",1f,1.3f,1f);
        var hit=machine.AddState("HitState");hit.motion=Clip(dir,"Hit",1f,0.75f,1f);
        var dead=machine.AddState("DeadState");dead.motion=Clip(dir,"Dead",1f,0.4f,0.4f);
        machine.defaultState=idle;
        var atk=machine.AddAnyStateTransition(attack);atk.hasExitTime=false;atk.duration=0f;
        atk.AddCondition(AnimatorConditionMode.If,0,"Attack");
        atk.AddCondition(AnimatorConditionMode.IfNot,0,"IsDead");
        var hurt=machine.AddAnyStateTransition(hit);hurt.hasExitTime=false;hurt.duration=0f;
        hurt.AddCondition(AnimatorConditionMode.If,0,"Hit");
        hurt.AddCondition(AnimatorConditionMode.IfNot,0,"IsDead");
        var die=machine.AddAnyStateTransition(dead);die.hasExitTime=false;die.duration=0f;
        die.AddCondition(AnimatorConditionMode.If,0,"IsDead");
        var atkBack=attack.AddTransition(idle);atkBack.hasExitTime=true;atkBack.exitTime=0.95f;atkBack.duration=0f;
        var hitBack=hit.AddTransition(idle);hitBack.hasExitTime=true;hitBack.exitTime=0.95f;hitBack.duration=0f;
        return ctl;
    }
}
#endif
