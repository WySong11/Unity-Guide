using UnityEngine;

public sealed class Day63AudioService : MonoBehaviour
{
    [SerializeField] private AudioSource sfxSource;
    [SerializeField] private AudioSource bgmSource;
    [SerializeField] private AudioClip attackClip;
    [SerializeField] private AudioClip hitClip;
    [SerializeField] private AudioClip deathClip;
    [SerializeField, Range(0f, 1f)] private float sfxVolume = 0.8f;
    public int PlayedAttack { get; private set; }
    public int PlayedHit { get; private set; }
    public int PlayedDeath { get; private set; }

    private void Awake()
    {
        // Procedural clips remove the need to distribute licensed audio assets.
        if (attackClip == null) attackClip = MakeTone("Attack", 660f, 0.09f);
        if (hitClip == null) hitClip = MakeTone("Hit", 240f, 0.16f);
        if (deathClip == null) deathClip = MakeTone("Death", 125f, 0.35f);
        if (sfxSource != null) { sfxSource.playOnAwake = false; sfxSource.spatialBlend = 0f; }
        if (bgmSource != null)
        {
            bgmSource.playOnAwake = false;
            bgmSource.loop = true;
            bgmSource.spatialBlend = 0f;
            if (bgmSource.clip == null) bgmSource.clip = MakeTone("Demo BGM", 110f, 1f);
            bgmSource.volume = 0.08f;
            bgmSource.Play();
        }
    }
    private static AudioClip MakeTone(string name, float hz, float duration)
    {
        const int sampleRate = 22050;
        int count = Mathf.CeilToInt(sampleRate * duration);
        var samples = new float[count];
        for (int i = 0; i < count; i++)
        {
            float t = (float)i / sampleRate;
            float fade = Mathf.Min(1f, t * 120f) * Mathf.Clamp01((duration - t) * 18f);
            samples[i] = Mathf.Sin(2f * Mathf.PI * hz * t) * fade * 0.18f;
        }
        var result = AudioClip.Create(name, count, 1, sampleRate, false);
        result.SetData(samples, 0);
        return result;
    }
    public void PlayAttack() { PlayClip(attackClip); PlayedAttack++; }
    public void PlayHit() { PlayClip(hitClip); PlayedHit++; }
    public void PlayDeath() { PlayClip(deathClip); PlayedDeath++; }
    private void PlayClip(AudioClip clip)
    {
        if (sfxSource != null && clip != null) sfxSource.PlayOneShot(clip, sfxVolume);
    }
    public void SetGameAudioPaused(bool paused)
    {
        if (bgmSource == null) return;
        if (paused) bgmSource.Pause(); else bgmSource.UnPause();
    }
}
