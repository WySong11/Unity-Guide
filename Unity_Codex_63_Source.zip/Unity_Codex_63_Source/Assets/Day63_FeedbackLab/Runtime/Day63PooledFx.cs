using UnityEngine;

[RequireComponent(typeof(ParticleSystem))]
public sealed class Day63PooledFx : MonoBehaviour
{
    private ParticleSystem ps;
    private Day63ParticleFxPool owner;
    private bool inUse;
    private void Awake()
    {
        ps = GetComponent<ParticleSystem>();
        var main = ps.main;
        main.loop = false;
        main.stopAction = ParticleSystemStopAction.Callback;
    }
    public void Initialize(Day63ParticleFxPool pool) { owner = pool; }
    public void PlayAt(Vector3 position, Quaternion rotation)
    {
        if (ps == null) ps = GetComponent<ParticleSystem>();
        transform.SetPositionAndRotation(position, rotation);
        ps.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
        inUse = true;
        ps.Play(true);
    }
    public void MarkReturned()
    {
        if (!inUse) return;
        inUse = false;
        if (ps != null) ps.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
    }
    private void OnParticleSystemStopped()
    {
        if (inUse && owner != null) owner.Release(this);
    }
}
