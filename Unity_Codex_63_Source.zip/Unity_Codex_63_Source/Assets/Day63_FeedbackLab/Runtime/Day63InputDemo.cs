using UnityEngine;
using UnityEngine.InputSystem;

public sealed class Day63InputDemo : MonoBehaviour
{
    [SerializeField] private Day63CombatActor actor;
    [SerializeField] private Day63AudioService audioService;
    public bool IsPaused { get; private set; }
    private void Update()
    {
        var keyboard = Keyboard.current;
        if (keyboard == null) return;
        if (keyboard.pKey.wasPressedThisFrame) TogglePause();
        if (keyboard.rKey.wasPressedThisFrame) ResetDemo();
        if (IsPaused || actor == null) return;
        if (keyboard.digit1Key.wasPressedThisFrame) actor.TryAttack();
        if (keyboard.digit2Key.wasPressedThisFrame) actor.TakeDamage(10);
        if (keyboard.digit3Key.wasPressedThisFrame) actor.TakeDamage(actor.HP);
    }
    public void TogglePause()
    {
        IsPaused = !IsPaused;
        Time.timeScale = IsPaused ? 0f : 1f;
        audioService?.SetGameAudioPaused(IsPaused);
    }
    public void ResetDemo()
    {
        Time.timeScale = 1f;
        IsPaused = false;
        audioService?.SetGameAudioPaused(false);
        actor?.ResetActor();
    }
    private void OnDisable()
    {
        Time.timeScale = 1f;
        audioService?.SetGameAudioPaused(false);
    }
}
