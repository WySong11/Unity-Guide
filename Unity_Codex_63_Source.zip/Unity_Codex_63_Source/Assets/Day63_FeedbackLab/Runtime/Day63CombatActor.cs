using System;
using UnityEngine;

public sealed class Day63CombatActor : MonoBehaviour
{
    [SerializeField, Min(1)] private int maxHp = 50;
    [SerializeField, Min(0f)] private float attackCooldown = 0.45f;
    private float nextAttackAt;
    public int HP { get; private set; }
    public int MaxHP => maxHp;
    public bool IsAlive => HP > 0;
    public event Action OnAttacked;
    public event Action<int> OnDamaged;
    public event Action OnDied;
    public event Action OnReset;

    private void Awake() { HP = maxHp; }
    public bool TryAttack()
    {
        if (!IsAlive || Time.time < nextAttackAt) return false;
        nextAttackAt = Time.time + attackCooldown;
        OnAttacked?.Invoke();
        return true;
    }
    public bool TakeDamage(int amount)
    {
        if (!IsAlive || amount <= 0) return false;
        var applied = Mathf.Min(amount, HP);
        HP -= applied;
        OnDamaged?.Invoke(applied);
        if (HP == 0) OnDied?.Invoke();
        return true;
    }
    public void ResetActor()
    {
        HP = maxHp;
        nextAttackAt = 0f;
        OnReset?.Invoke();
    }
}
