using UnityEngine;

public sealed class Day63CombatPresenter : MonoBehaviour
{
    [SerializeField] private Day63CombatActor actor;
    [SerializeField] private Day63AudioService audioService;
    [SerializeField] private Day63ParticleFxPool hitPool;
    [SerializeField] private Day63AnimatorBridge animations;
    [SerializeField] private Transform effectOrigin;
    private void OnEnable()
    {
        if (actor == null) return;
        actor.OnAttacked += HandleAttack;
        actor.OnDamaged += HandleDamaged;
        actor.OnDied += HandleDead;
        actor.OnReset += HandleReset;
    }
    private void OnDisable()
    {
        if (actor == null) return;
        actor.OnAttacked -= HandleAttack;
        actor.OnDamaged -= HandleDamaged;
        actor.OnDied -= HandleDead;
        actor.OnReset -= HandleReset;
    }
    private Vector3 FxAt => effectOrigin != null ? effectOrigin.position : actor.transform.position;
    private void HandleAttack()
    {
        audioService?.PlayAttack();
        animations?.PlayAttack();
    }
    private void HandleDamaged(int appliedDamage)
    {
        audioService?.PlayHit();
        animations?.PlayHit();
        if (hitPool != null) hitPool.Play(FxAt);
    }
    private void HandleDead()
    {
        audioService?.PlayDeath();
        animations?.PlayDeath();
        if (hitPool != null) hitPool.Play(FxAt + Vector3.up * 0.3f);
    }
    private void HandleReset() { animations?.ResetState(); }
}
