using UnityEngine;

public sealed class Day63DebugHUD : MonoBehaviour
{
    [SerializeField] private Day63CombatActor actor;
    [SerializeField] private Day63InputDemo input;
    [SerializeField] private Day63AudioService audioService;
    [SerializeField] private Day63ParticleFxPool fxPool;
    private void OnGUI()
    {
        GUILayout.BeginArea(new Rect(18, 18, 390, 315), GUI.skin.box);
        GUILayout.Label("DAY 63 | AUDIO / VFX / ANIMATOR");
        if (actor != null) GUILayout.Label($"Actor HP : {actor.HP} / {actor.MaxHP}");
        if (audioService != null)
            GUILayout.Label($"SFX A/H/D : {audioService.PlayedAttack} / {audioService.PlayedHit} / {audioService.PlayedDeath}");
        if (fxPool != null)
            GUILayout.Label($"FX Active/Inactive : {fxPool.CountActive} / {fxPool.CountInactive}");
        GUILayout.Label("Keys: 1 Attack | 2 Hit | 3 Kill | R Reset | P Pause");
        GUILayout.Label(input != null && input.IsPaused ? "PAUSED" : "PLAYING");
        GUI.enabled = input == null || !input.IsPaused;
        if (GUILayout.Button("ATTACK (1)")) actor?.TryAttack();
        if (GUILayout.Button("HIT 10 (2)")) actor?.TakeDamage(10);
        if (GUILayout.Button("KILL (3)")) { if (actor != null) actor.TakeDamage(actor.HP); }
        GUI.enabled = true;
        if (GUILayout.Button("RESET (R)")) input?.ResetDemo();
        if (GUILayout.Button("PAUSE / RESUME (P)")) input?.TogglePause();
        GUILayout.EndArea();
    }
}
