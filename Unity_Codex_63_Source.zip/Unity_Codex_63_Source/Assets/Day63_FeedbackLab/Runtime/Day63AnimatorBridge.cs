using UnityEngine;

public sealed class Day63AnimatorBridge : MonoBehaviour
{
    [SerializeField] private Animator animator;
    private static readonly int AttackHash = Animator.StringToHash("Attack");
    private static readonly int HitHash = Animator.StringToHash("Hit");
    private static readonly int DeadHash = Animator.StringToHash("IsDead");
    private bool Valid => animator != null && animator.runtimeAnimatorController != null;
    public bool HasController => Valid;
    public void PlayAttack() { if (Valid) animator.SetTrigger(AttackHash); }
    public void PlayHit() { if (Valid) animator.SetTrigger(HitHash); }
    public void PlayDeath() { if (Valid) animator.SetBool(DeadHash, true); }
    public void ResetState()
    {
        if (!Valid) return;
        animator.ResetTrigger(AttackHash);
        animator.ResetTrigger(HitHash);
        animator.SetBool(DeadHash, false);
        animator.Play("Idle", 0, 0f);
    }
}
