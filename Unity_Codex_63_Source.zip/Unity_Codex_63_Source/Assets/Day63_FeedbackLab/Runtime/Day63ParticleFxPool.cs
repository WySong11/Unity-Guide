using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

public sealed class Day63ParticleFxPool : MonoBehaviour
{
    [SerializeField] private Day63PooledFx prefab;
    [SerializeField, Min(0)] private int prewarmCount = 8;
    [SerializeField, Min(1)] private int maxInactive = 32;
    private ObjectPool<Day63PooledFx> pool;
    public int CountInactive => pool != null ? pool.CountInactive : 0;
    public int CountActive => pool != null ? pool.CountActive : 0;
    public int CountAll => pool != null ? pool.CountAll : 0;
    private void Awake()
    {
        if (prefab == null) { Debug.LogWarning("Day63 FX prefab missing", this); return; }
        pool = new ObjectPool<Day63PooledFx>(Create,
            fx => fx.gameObject.SetActive(true),
            fx => fx.gameObject.SetActive(false),
            fx => { if (fx != null) Destroy(fx.gameObject); },
            collectionCheck: true,
            defaultCapacity: Mathf.Max(1, prewarmCount),
            maxSize: Mathf.Max(1, maxInactive));
        var initial = new List<Day63PooledFx>();
        int amount = Mathf.Min(prewarmCount, Mathf.Max(1, maxInactive));
        for (int i = 0; i < amount; i++) initial.Add(pool.Get());
        foreach (var fx in initial) pool.Release(fx);
    }
    private Day63PooledFx Create()
    {
        var fx = Instantiate(prefab, transform);
        fx.Initialize(this);
        return fx;
    }
    public void Play(Vector3 position)
    {
        if (pool == null) return;
        var fx = pool.Get();
        fx.PlayAt(position, Quaternion.identity);
    }
    public void Release(Day63PooledFx fx)
    {
        if (pool == null || fx == null) return;
        fx.MarkReturned();
        pool.Release(fx);
    }
    private void OnDestroy() { pool?.Clear(); }
}
