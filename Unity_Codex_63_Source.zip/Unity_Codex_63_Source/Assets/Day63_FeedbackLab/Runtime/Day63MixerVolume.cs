using UnityEngine;
using UnityEngine.Audio;

public sealed class Day63MixerVolume : MonoBehaviour
{
    [SerializeField] private AudioMixer mixer;
    [SerializeField] private string exposedParameter = "SFXVolume";
    public bool SetLinearVolume(float linear)
    {
        if (mixer == null || string.IsNullOrWhiteSpace(exposedParameter)) return false;
        // dB = 20 log10(linear). 0 maps to a practical -80 dB mute.
        float db = linear <= 0f ? -80f : 20f * Mathf.Log10(Mathf.Clamp(linear, 0.0001f, 1f));
        return mixer.SetFloat(exposedParameter, db);
    }
}
