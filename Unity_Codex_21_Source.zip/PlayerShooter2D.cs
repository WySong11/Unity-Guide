using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerShooter2D : MonoBehaviour
{
    [Header("Attack")]
    [SerializeField] private InputActionReference fireAction;
    [SerializeField] private Projectile2D projectilePrefab;
    [SerializeField] private Transform firePoint;
    [SerializeField, Min(0.05f)] private float fireInterval = 0.25f;
    [SerializeField, Min(0.1f)] private float projectileSpeed = 12f;
    [SerializeField, Min(1)] private int damage = 1;
    [SerializeField] private bool facingRight = true;

    private float nextFireTime;

    private void OnEnable()
    {
        // This demo owns its Fire action. Do not disable a shared PlayerInput action.
        if (fireAction != null && fireAction.action != null)
            fireAction.action.Enable();
    }

    private void OnDisable()
    {
        if (fireAction != null && fireAction.action != null)
            fireAction.action.Disable();
    }

    private void Update()
    {
        if (fireAction == null || fireAction.action == null)
            return;

        if (fireAction.action.WasPerformedThisFrame())
            TryFire();
    }

    // Call from the movement controller whenever facing changes.
    public void SetFacingRight(bool value) => facingRight = value;

    public bool TryFire()
    {
        if (Time.time < nextFireTime)
            return false;
        if (projectilePrefab == null || firePoint == null)
        {
            Debug.LogWarning("[Shooter] Assign projectilePrefab and firePoint.", this);
            return false;
        }

        Vector2 direction = facingRight ? Vector2.right : Vector2.left;
        Projectile2D projectile = Instantiate(projectilePrefab, firePoint.position,
            Quaternion.identity);
        projectile.Launch(direction, projectileSpeed, damage, transform);
        nextFireTime = Time.time + fireInterval;
        return true;
    }
}