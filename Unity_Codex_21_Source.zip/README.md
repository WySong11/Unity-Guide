# 21일차 | 2D 공격 · 발사체 생성

권장: Unity 6.3 (6000.3) 계열 / Input System 패키지 설치.

## 장면 준비
1. 20일차 프로젝트를 복제하거나 새 2D URP 씬을 만듭니다.
2. 플레이어에 PlayerShooter2D를 추가하고 `FirePoint` 자식 GameObject를 만듭니다.
3. `Fire`라는 Button Input Action을 만들고 `<Keyboard>/j` 또는 마우스 좌클릭에 바인딩합니다.
4. **이 독립 실습에서는 PlayerShooter2D가 Fire Action을 직접 Enable/Disable 합니다.** 기존 PlayerInput이 같은 Action을 관리하면 중복 활성화/비활성화 관리하지 말고 소유자를 한 곳으로 통일하세요.
5. `Projectile` 프리팹에 SpriteRenderer, Rigidbody2D (Dynamic, Gravity Scale 0, Collision Detection Continuous), CircleCollider2D (Is Trigger ON), Projectile2D를 붙입니다.
6. 프리팹을 PlayerShooter2D의 Projectile Prefab 필드에 연결합니다.
7. 적에는 EnemyHealth2D와 Collider2D를 부착합니다. 발사체의 Collider2D는 Trigger, 적의 Collider2D는 기본 Collider여야 합니다.
8. Play Mode에서 J 키로 발사하여 적 HP 감소 / 제한 시간 제거를 확인합니다.

## 체크 항목
- FirePoint 위치를 공격 방향 앞에 두세요. SpriteRenderer.flipX만 사용하는 이동 스크립트라면 발사 방향을 `SetFacingRight(bool)`로 직접 업데이트하세요.
- EnemyHealth2D는 상위 오브젝트에 있어도 동작합니다 (`GetComponentInParent`).
- 플레이어·발사체 Layer 충돌 설정과 Physics 2D Collision Matrix를 확인하세요.
- Projectile2D는 **Instantiate/Destroy 방식의 첫 수업 예제**입니다. 오브젝트 풀은 다음 확장 단원에서 다룹니다.
- 빠른 발사체는 Trigger 터널링을 일으킬 수 있으므로 Collision Detection을 Continuous로 설정하고, 필요한 경우 Raycast/Sweep를 도입합니다.
- 직접 프로젝트에서 컴파일/Play Mode 테스트는 별도 진행하세요.

## 참고 (Unity 공식)
https://docs.unity3d.com/kr/current/ScriptReference/Rigidbody2D.html
https://docs.unity3d.com/kr/current/Manual/instantiating-prefabs-projectiles.html
https://docs.unity3d.com/ja/current/ScriptReference/MonoBehaviour.OnTriggerEnter2D.html
