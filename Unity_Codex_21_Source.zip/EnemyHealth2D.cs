using UnityEngine;

public class EnemyHealth2D : MonoBehaviour
{
    [SerializeField, Min(1)] private int maxHealth = 3;
    private int currentHealth;
    private bool defeated;

    private void Awake() => currentHealth = maxHealth;

    public void TakeDamage(int amount)
    {
        if (defeated || amount <= 0) return;
        currentHealth = Mathf.Max(0, currentHealth - amount);
        Debug.Log($"[Enemy] HP {currentHealth}/{maxHealth}", this);
        if (currentHealth != 0) return;
        defeated = true;
        Debug.Log("[Enemy] Defeated", this);
        Destroy(gameObject);
    }
}