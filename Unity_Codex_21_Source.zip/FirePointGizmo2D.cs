using UnityEngine;

public class FirePointGizmo2D : MonoBehaviour
{
    [SerializeField] private float radius = 0.1f;
    private void OnDrawGizmos()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, radius);
        Gizmos.DrawLine(transform.position, transform.position + transform.right * 0.5f);
    }
}