# 실습용 Codex 프롬프트

## 1. 읽기 전용 분석
현재 `PlayerShooter2D`, `Projectile2D`, `EnemyHealth2D`를 수정하지 말고 읽기 전용으로 분석해 주세요. 공격 입력 → Instantiate → Rigidbody2D 이동 → Trigger → TakeDamage → Destroy의 호출 흐름과 null/레이어/중복 히트 위험을 설명해 주세요.

## 2. 오류 재현
Unity 6.3에서 J를 눌러도 발사체가 생성되지 않습니다. Inspector 연결, Fire Input Action 활성화, FirePoint, prefab을 순서대로 점검할 체크리스트와 최소 로그만 제안해 주세요. 임의의 코드는 수정하지 마세요.

## 3. 최소 수정 요청
아래 콘솔 로그와 재현 단계를 분석하고 가장 가능성이 높은 원인 2개를 제시한 다음, 영향 범위가 작은 수정안을 Diff로 작성해 주세요. 기존 이동·애니메이션 코드는 변경하지 마세요.

## 4. 회귀 테스트
이전 구현과 비교해 공격 간격, 좌우 발사, 자기 자신 충돌 방지, 적 체력 0 하한, 빠른 연속 충돌, 씬 종료시 오류가 없는지 테스트 표로 제시하세요. 통과 근거가 없는 항목은 '미검증'이라고 표시해 주세요.

## 5. 확장 설계 (선택)
현재 Instantiate/Destroy 기반 Projectile2D를 ObjectPool 기반으로 바꾸기 전에 재사용에 필요한 리셋 항목(속도, 데미지, owner, 타이머, spent)을 설계해 주세요. 이번 단계에서는 소스 파일을 수정하지 마세요.
