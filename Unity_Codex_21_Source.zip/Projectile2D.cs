using UnityEngine;

[RequireComponent(typeof(Rigidbody2D), typeof(Collider2D))]
public class Projectile2D : MonoBehaviour
{
    [SerializeField, Min(0.1f)] private float lifetime = 2f;

    private Rigidbody2D body;
    private Transform ownerTransform;
    private int damage;
    private bool spent;

    private void Awake()
    {
        body = GetComponent<Rigidbody2D>();
        body.gravityScale = 0f;
    }

    public void Launch(Vector2 direction, float speed, int amount, Transform owner)
    {
        spent = false;
        ownerTransform = owner;
        damage = Mathf.Max(1, amount);
        body.linearVelocity = direction.normalized * Mathf.Max(0.1f, speed);
        Destroy(gameObject, lifetime);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (spent || other.isTrigger) return;
        if (ownerTransform != null && other.transform.IsChildOf(ownerTransform)) return;
        spent = true; // prevents two hits before Destroy executes

        EnemyHealth2D enemy = other.GetComponentInParent<EnemyHealth2D>();
        if (enemy != null) enemy.TakeDamage(damage);
        Destroy(gameObject);
    }
}