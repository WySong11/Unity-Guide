# Unity × Codex | 59일차 — 아이템 및 인벤토리

Unity 6.3 · 3D URP · 120분 독립 실습 예제입니다. 58일차 스킬 예제와 함께 사용할 수도 있으나 통합은 별도 작업입니다.

## 설치 및 실행

1. Unity 6.3 URP 프로젝트를 엽니다. 새 Input System을 사용할 경우 Input System 패키지를 설치하고 프로젝트 입력 설정을 확인합니다. 패키지가 없어도 실습 HUD의 버튼은 사용 가능합니다.
2. `Runtime/`의 C# 파일 10개를 `Assets/Day59/Scripts/`에, `Editor/`의 파일 2개를 `Assets/Day59/Editor/`에 복사합니다. **Editor 파일은 반드시 Editor 폴더에** 두십시오.
3. Console 컴파일 오류가 없는지 확인합니다.
4. Unity 메뉴 `Tools > Unity Codex > Day59 > Create Inventory Lab`을 선택합니다.
5. 자동으로 생성된 `Assets/Day59_Inventory_Lab/Scenes/Day59_Inventory_Lab.unity` 씬을 엽니다.
6. Play 버튼을 눌러 오른쪽/왼쪽 세 개 아이템 구체에 접근하거나 화면 왼쪽 Debug HUD 버튼을 사용합니다.
7. `Tools > Unity Codex > Day59 > Validate Inventory Lab`로 에셋 ID, 씬의 필수 컴포넌트, Pickup Collider를 점검합니다.

실행 메뉴는 기존 `Day59_Inventory_Lab` 폴더가 존재하면 `_2`, `_3` 등 새 폴더에 만들므로 기존 파일을 덮어쓰지 않습니다.

## 키 조작 및 실습 UI

- WASD: 테스트 플레이어 이동 (New Input System이 프로젝트에 존재할 때)
- `1`: Potion 9개 추가 / `2`: Gem 10개 추가 / `3`: Key 2개 추가
- `P`: 가장 먼저 발견되는 Potion 1개 사용 / `L`: 로드 / `Ctrl+S`: 저장
- 왼쪽 **Debug HUD**: Add, Use, Damage, Full HP, Drop, Clear, Save, Load 버튼

Debug HUD는 원리를 확인하기 위한 `OnGUI` 샘플입니다. 상용 UI는 별도의 Canvas + GridLayoutGroup + Image + Button + TMP 컴포넌트로 교체하십시오.

## 수업 데이터

| 에셋 | itemId | MaxStack | 기능 |
|---|---|---:|---|
| SmallPotion | potion_small | 5 | HP 30 회복 |
| BlueGem | gem_blue | 20 | 재료 |
| IronKey | key_iron | 1 | 비중첩 퀘스트 아이템 |

- 인벤토리는 **12칸**입니다.
- ItemData는 공유 설정이며 `InventorySlot.Item + Quantity`는 플레이어별 실행 상태입니다.
- `Add(item, n)`의 반환값은 **실제로 들어간 수량**입니다. 월드 아이템은 이 개수만 감소시켜야 합니다.
- 수량 감소에 성공하면 `Inventory.Changed` 이벤트가 발생하여 HUD가 갱신됩니다.
- 포션 사용은 HP가 최대일 때 실패하며 인벤토리 수량이 줄지 않습니다.
- JSON은 `Application.persistentDataPath/inventory_day59.json`에 저장됩니다. 아이템 에셋의 Unity 참조가 아니라 **ID·슬롯 인덱스·수량**을 직렬화합니다.
- Save/Load는 단일 플레이어용 로컬 교육 예제이며, 암호화·멀티플레이 권한·동시 수정 경쟁 조건은 별도 주제입니다.

## 연결 구조

```
Day59ItemData.asset (Potion/Gem/Key)
           |                      
Day59ItemCatalog ----> Day59InventorySave ----> JSON
           |                      ^
Day59WorldPickup ----> Day59Inventory ----> Day59InventoryHUD
                                  ^
Day59ItemUseController ----> Day59PlayerVitals
```

## 주의사항

- `Day59InventorySlot`을 다른 코드에서 직접 수정하지 마십시오. `Day59Inventory.Add/RemoveAt` 경로만 사용해야 합니다.
- ItemData의 `itemId`를 플레이 도중 변경하면 기존 저장 파일과 매칭이 깨질 수 있습니다.
- 중복 ID는 에셋 자체에서 유효하지 않으므로 검사 메뉴로 확인하십시오.
- 기존 Day58 데이터·프리팹·씬을 복사하거나 삭제하지 않습니다.
- `Editor` 전용 파일을 런타임 어셈블리에 포함하지 마십시오.
- 제작 환경에서는 Unity Editor 컴파일/Play Mode를 실제로 실행하지 않았습니다. 본 실습에서 해당 검증을 실시해야 합니다.

## 과제

`Docs/Day59_Test_Checklist.csv`의 T01~T12를 실시하고, HUD 캡처와 Save JSON 내용, Codex 코드 리뷰 결과를 제출합니다.
