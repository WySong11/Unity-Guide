using System;
using UnityEngine;

public sealed class Day59PlayerVitals : MonoBehaviour
{
    [Min(1)] [SerializeField] private int maxHp = 100;
    [SerializeField] private int currentHp = 60;
    public int MaxHp => maxHp;
    public int CurrentHp => currentHp;
    public event Action Changed;

    private void Awake() => currentHp = Mathf.Clamp(currentHp, 0, maxHp);
    public bool TryHeal(int amount)
    {
        if (amount <= 0 || currentHp <= 0 || currentHp >= maxHp) return false;
        currentHp = Mathf.Min(maxHp, currentHp + amount);
        Changed?.Invoke();
        return true;
    }
    public void Damage(int amount)
    {
        if (amount <= 0) return;
        currentHp = Mathf.Max(0, currentHp - amount);
        Changed?.Invoke();
    }
    public void RestoreFull()
    {
        currentHp = maxHp;
        Changed?.Invoke();
    }
}
