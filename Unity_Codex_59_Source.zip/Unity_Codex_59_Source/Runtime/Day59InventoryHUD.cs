using System.Text;
using UnityEngine;

/// <summary>Simple debug HUD for the exercise. Replace with Canvas/GridLayoutGroup for production UI.</summary>
public sealed class Day59InventoryHUD : MonoBehaviour
{
    [SerializeField] private Day59Inventory inventory;
    [SerializeField] private Day59PlayerVitals vitals;
    [SerializeField] private Day59ItemUseController useController;
    [SerializeField] private Day59InventorySave saveSystem;
    [SerializeField] private Day59ItemCatalog catalog;
    private string cached = string.Empty;
    private string status = "아이템을 획득해 보세요.";
    private GUIStyle cellStyle;

    private void OnEnable()
    {
        if (inventory != null) inventory.Changed += Refresh;
        if (vitals != null) vitals.Changed += Refresh;
        Refresh();
    }
    private void OnDisable()
    {
        if (inventory != null) inventory.Changed -= Refresh;
        if (vitals != null) vitals.Changed -= Refresh;
    }
    private void Refresh()
    {
        if (inventory == null) return;
        var sb = new StringBuilder();
        for (int i = 0; i < inventory.Capacity; i++)
        {
            var slot = inventory.GetSlot(i);
            string label = slot == null || slot.IsEmpty ? "Empty" : slot.Item.DisplayName + " × " + slot.Quantity;
            sb.Append(i.ToString("00")).Append("  ").Append(label).Append('\n');
        }
        cached = sb.ToString();
    }
    private void OnGUI()
    {
        if (inventory == null) return;
        if (cellStyle == null) cellStyle = new GUIStyle(GUI.skin.label) { fontSize = 15, wordWrap = false };
        GUILayout.BeginArea(new Rect(14, 14, 430, 665), GUI.skin.box);
        GUILayout.Label("DAY 59  |  ITEM INVENTORY", GUI.skin.box);
        GUILayout.Label(vitals != null ? "HP: " + vitals.CurrentHp + " / " + vitals.MaxHp : "HP: -");
        GUILayout.Label(cached, cellStyle, GUILayout.MinHeight(325));
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("+9 Potion")) Add(0, 9);
        if (GUILayout.Button("+10 Gem")) Add(1, 10);
        if (GUILayout.Button("+2 Key")) Add(2, 2);
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Use first Potion")) status = UseFirstPotion() ? "Potion consumed." : "Potion not usable.";
        if (GUILayout.Button("HP -40") && vitals != null) vitals.Damage(40);
        if (GUILayout.Button("Full HP") && vitals != null) vitals.RestoreFull();
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Drop slot 0")) status = inventory.RemoveAt(0, 1) ? "Removed." : "Cannot remove.";
        if (GUILayout.Button("Clear")) { inventory.Clear(); status = "Cleared."; }
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("Save") && saveSystem != null) status = saveSystem.Save() ? "Saved." : "Save failed.";
        if (GUILayout.Button("Load") && saveSystem != null) status = saveSystem.Load() ? "Loaded." : "Load failed.";
        GUILayout.EndHorizontal();
        GUILayout.Label(status);
        GUILayout.Label("WASD move · pickup spheres · 1/2/3 add · P use · S/L save/load");
        GUILayout.EndArea();
    }
    private void Add(int itemIndex, int qty)
    {
        if (catalog == null || catalog.Items == null || itemIndex >= catalog.Items.Count) return;
        var item = catalog.Items[itemIndex];
        int accepted = inventory.Add(item, qty);
        status = "Added " + accepted + "/" + qty + " " + (item != null ? item.DisplayName : "item");
    }
    public void AddPotion() => Add(0, 9);
    public void AddGem() => Add(1, 10);
    public void AddKey() => Add(2, 2);
    public bool UseFirstPotion()
    {
        if (useController == null) return false;
        for (int i = 0; i < inventory.Capacity; i++)
        {
            var slot = inventory.GetSlot(i);
            if (slot != null && !slot.IsEmpty && slot.Item.Kind == Day59ItemKind.Consumable)
                return useController.TryUse(i);
        }
        return false;
    }
}
