using UnityEngine;

public enum Day59ItemKind { Consumable, Material, KeyItem }

/// <summary>Shared, authoring-time data. Never store owned quantities here.</summary>
[CreateAssetMenu(fileName = "Day59_Item", menuName = "Day59/Item Data")]
public sealed class Day59ItemData : ScriptableObject
{
    [SerializeField] private string itemId;
    [SerializeField] private string displayName;
    [SerializeField] private Day59ItemKind kind;
    [Min(1)] [SerializeField] private int maxStack = 1;
    [Min(0)] [SerializeField] private int healAmount;
    [SerializeField] private Sprite icon;

    public string ItemId => itemId;
    public string DisplayName => string.IsNullOrWhiteSpace(displayName) ? name : displayName;
    public Day59ItemKind Kind => kind;
    public int MaxStack => Mathf.Max(1, maxStack);
    public int HealAmount => Mathf.Max(0, healAmount);
    public Sprite Icon => icon;

    private void OnValidate()
    {
        maxStack = Mathf.Max(1, maxStack);
        healAmount = Mathf.Max(0, healAmount);
    }
}
