using UnityEngine;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

[RequireComponent(typeof(CharacterController))]
public sealed class Day59DemoInput : MonoBehaviour
{
    [Min(0.1f)] [SerializeField] private float speed = 4f;
    [SerializeField] private Day59InventoryHUD hud;
    [SerializeField] private Day59InventorySave saveSystem;
    private CharacterController cc;
    private void Awake() => cc = GetComponent<CharacterController>();

    private void Update()
    {
#if ENABLE_INPUT_SYSTEM
        if (Keyboard.current == null) return;
        var k = Keyboard.current;
        Vector3 move = Vector3.zero;
        if (k.wKey.isPressed) move.z += 1;
        if (k.sKey.isPressed) move.z -= 1;
        if (k.dKey.isPressed) move.x += 1;
        if (k.aKey.isPressed) move.x -= 1;
        cc.Move(move.normalized * speed * Time.deltaTime);
        if (hud != null)
        {
            if (k.digit1Key.wasPressedThisFrame) hud.AddPotion();
            if (k.digit2Key.wasPressedThisFrame) hud.AddGem();
            if (k.digit3Key.wasPressedThisFrame) hud.AddKey();
            if (k.pKey.wasPressedThisFrame) hud.UseFirstPotion();
        }
        if (saveSystem != null)
        {
            if (k.sKey.wasPressedThisFrame && k.leftCtrlKey.isPressed) saveSystem.Save();
            if (k.lKey.wasPressedThisFrame) saveSystem.Load();
        }
#endif
    }
}
