using UnityEngine;

[RequireComponent(typeof(Collider))]
public sealed class Day59WorldPickup : MonoBehaviour
{
    [SerializeField] private Day59ItemData item;
    [Min(1)] [SerializeField] private int quantity = 1;
    public Day59ItemData Item => item;
    public int Quantity => quantity;

    private void OnTriggerEnter(Collider other)
    {
        if (!isActiveAndEnabled || item == null || quantity <= 0) return;
        var inventory = other.GetComponentInParent<Day59Inventory>();
        if (inventory == null) return;
        int accepted = inventory.Add(item, quantity);
        quantity -= accepted;
        if (quantity <= 0) gameObject.SetActive(false);
    }
}
