using System;
using UnityEngine;

[Serializable]
public sealed class Day59InventorySlot
{
    [SerializeField] private Day59ItemData item;
    [SerializeField] private int quantity;
    public Day59ItemData Item => item;
    public int Quantity => quantity;
    public bool IsEmpty => item == null || quantity <= 0;

    // Do not call this from UI: all inventory mutations belong in Day59Inventory.
    internal void Set(Day59ItemData data, int amount)
    {
        item = amount > 0 && data != null ? data : null;
        quantity = item != null ? amount : 0;
    }
}
