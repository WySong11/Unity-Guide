using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

[Serializable]
public sealed class Day59SaveSlot
{
    public int index;
    public string itemId;
    public int quantity;
}
[Serializable]
public sealed class Day59SaveFile
{
    public int version = 1;
    public Day59SaveSlot[] slots;
}

/// <summary>Stores stable item IDs and numbers; Unity object references are not serialized.</summary>
public sealed class Day59InventorySave : MonoBehaviour
{
    [SerializeField] private Day59Inventory inventory;
    [SerializeField] private Day59ItemCatalog catalog;
    private const string FileName = "inventory_day59.json";
    public string FilePath => Path.Combine(Application.persistentDataPath, FileName);

    public bool Save()
    {
        if (inventory == null) return false;
        var entries = new List<Day59SaveSlot>();
        for (int i = 0; i < inventory.Capacity; i++)
        {
            var slot = inventory.GetSlot(i);
            if (slot == null || slot.IsEmpty) continue;
            entries.Add(new Day59SaveSlot { index = i, itemId = slot.Item.ItemId, quantity = slot.Quantity });
        }
        try
        {
            Directory.CreateDirectory(Application.persistentDataPath);
            var dto = new Day59SaveFile { slots = entries.ToArray() };
            File.WriteAllText(FilePath, JsonUtility.ToJson(dto, true));
            Debug.Log("[Day59] Saved: " + FilePath);
            return true;
        }
        catch (Exception e) { Debug.LogError("[Day59] Save failed: " + e.Message); return false; }
    }

    public bool Load()
    {
        if (inventory == null || catalog == null || !File.Exists(FilePath)) return false;
        try
        {
            var data = JsonUtility.FromJson<Day59SaveFile>(File.ReadAllText(FilePath));
            if (data == null || data.version != 1 || data.slots == null) return false;
            var next = new Day59InventorySlot[inventory.Capacity];
            var used = new HashSet<int>();
            for (int i = 0; i < next.Length; i++) next[i] = new Day59InventorySlot();
            foreach (var row in data.slots)
            {
                if (row == null || row.index < 0 || row.index >= next.Length || !used.Add(row.index)) continue;
                var item = catalog.Find(row.itemId);
                if (item == null || row.quantity <= 0 || row.quantity > item.MaxStack) continue;
                next[row.index].Set(item, row.quantity);
            }
            inventory.ReplaceSlots(next);
            Debug.Log("[Day59] Loaded: " + FilePath);
            return true;
        }
        catch (Exception e) { Debug.LogError("[Day59] Load failed: " + e.Message); return false; }
    }
}
