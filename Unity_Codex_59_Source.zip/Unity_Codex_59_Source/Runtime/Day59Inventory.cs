using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>Owns slot mutation. Add returns the accepted quantity, not a bool.</summary>
public sealed class Day59Inventory : MonoBehaviour
{
    [Min(1)] [SerializeField] private int capacity = 12;
    [SerializeField] private List<Day59InventorySlot> slots = new List<Day59InventorySlot>();
    public event Action Changed;
    public int Capacity => slots.Count;

    private void Awake() => EnsureSlots();
    private void EnsureSlots()
    {
        capacity = Mathf.Clamp(capacity, 1, 64);
        if (slots == null) slots = new List<Day59InventorySlot>();
        while (slots.Count < capacity) slots.Add(new Day59InventorySlot());
        if (slots.Count > capacity) slots.RemoveRange(capacity, slots.Count - capacity);
        for (int i = 0; i < slots.Count; i++)
            if (slots[i] == null) slots[i] = new Day59InventorySlot();
    }

    public Day59InventorySlot GetSlot(int index)
    {
        EnsureSlots();
        return index >= 0 && index < slots.Count ? slots[index] : null;
    }

    public int Add(Day59ItemData item, int count)
    {
        if (item == null || count <= 0) return 0;
        EnsureSlots();
        int remaining = count;
        foreach (var slot in slots)
        {
            if (remaining == 0) break;
            if (slot.IsEmpty || slot.Item != item) continue;
            int room = item.MaxStack - slot.Quantity;
            int amount = Mathf.Min(remaining, Mathf.Max(0, room));
            if (amount <= 0) continue;
            slot.Set(item, slot.Quantity + amount);
            remaining -= amount;
        }
        foreach (var slot in slots)
        {
            if (remaining == 0) break;
            if (!slot.IsEmpty) continue;
            int amount = Mathf.Min(remaining, item.MaxStack);
            slot.Set(item, amount);
            remaining -= amount;
        }
        int accepted = count - remaining;
        if (accepted > 0) Changed?.Invoke();
        return accepted;
    }

    public bool RemoveAt(int index, int count)
    {
        var slot = GetSlot(index);
        if (slot == null || slot.IsEmpty || count <= 0 || slot.Quantity < count)
            return false;
        slot.Set(slot.Item, slot.Quantity - count);
        Changed?.Invoke();
        return true;
    }

    public void Clear()
    {
        EnsureSlots();
        foreach (var slot in slots) slot.Set(null, 0);
        Changed?.Invoke();
    }

    // Save adapter constructs and validates every slot before replacing state once.
    internal void ReplaceSlots(Day59InventorySlot[] next)
    {
        EnsureSlots();
        if (next == null || next.Length != slots.Count)
            throw new ArgumentException("Snapshot length must equal inventory capacity.");
        for (int i = 0; i < slots.Count; i++)
        {
            var entry = next[i];
            if (entry == null || entry.IsEmpty) slots[i].Set(null, 0);
            else slots[i].Set(entry.Item, entry.Quantity);
        }
        Changed?.Invoke();
    }
}
