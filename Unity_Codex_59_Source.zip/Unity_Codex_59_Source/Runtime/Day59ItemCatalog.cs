using System.Collections.Generic;
using UnityEngine;

public sealed class Day59ItemCatalog : MonoBehaviour
{
    [SerializeField] private Day59ItemData[] items;
    public IReadOnlyList<Day59ItemData> Items => items;

    public Day59ItemData Find(string itemId)
    {
        if (string.IsNullOrWhiteSpace(itemId) || items == null) return null;
        foreach (var item in items)
            if (item != null && item.ItemId == itemId) return item;
        return null;
    }
}
