using UnityEngine;

public sealed class Day59ItemUseController : MonoBehaviour
{
    [SerializeField] private Day59Inventory inventory;
    [SerializeField] private Day59PlayerVitals vitals;

    private void Awake()
    {
        if (inventory == null) inventory = GetComponent<Day59Inventory>();
        if (vitals == null) vitals = GetComponent<Day59PlayerVitals>();
    }
    public bool TryUse(int slotIndex)
    {
        if (inventory == null || vitals == null) return false;
        var slot = inventory.GetSlot(slotIndex);
        if (slot == null || slot.IsEmpty) return false;
        var item = slot.Item;
        if (item.Kind != Day59ItemKind.Consumable) return false;
        // Single-threaded demo: first apply a valid heal, then consume one item.
        if (!vitals.TryHeal(item.HealAmount)) return false;
        return inventory.RemoveAt(slotIndex, 1);
    }
}
