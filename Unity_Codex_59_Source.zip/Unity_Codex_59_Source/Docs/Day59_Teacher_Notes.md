# 강사용 진행 가이드 — 59일차

## 시간 배분

- 00–25분: ItemData와 Slot Runtime 구분, SO 중복 데이터의 위험
- 25–55분: Add(기존 스택 → 빈 슬롯), RemoveAt, MaxStack
- 55–100분: Pickup Trigger, Heal 사용, HUD 이벤트, JSON Save/Load
- 100–120분: 실패 조건 검증, Codex 리뷰, 동료 시연

## 시연 권장 순서

1. Empty 인벤토리에서 `+9 Potion`: 5+4
2. `+2 Potion`이 필요하면 HUD 버튼은 9개 단위이므로 Code/API 호출 `inventory.Add(potion, 2)`를 별도 사용하도록 안내
3. Full HP로 만든 후 Use → 소모 0
4. HP를 40 감소시킨 후 Use → HP 증가 / Potion -1
5. Save → Clear → Load → 동일 슬롯 재등장
6. 단축키와 Pickup Trigger로 재현

## 자주 생기는 혼동

- MaxStack과 Capacity는 전혀 다릅니다.
- World Pickup이 inventory.Add를 호출한 뒤 자신의 quantity를 **accepted**만큼 감소시켜야 합니다.
- `ScriptableObject` 에셋은 설정 데이터이며 배포 빌드 저장소가 아닙니다.
- `OnGUI`는 학습용 Debug UI입니다. Canvas 인벤토리 UI 교체는 다음 단계로 진행하십시오.
- Save는 ID와 수량을 저장하고, Load 때 Catalog가 ID를 실제 SO로 매핑합니다.

## 실제 검증 미실시 사항

제공 자료는 코드·PPT 형태로 제작했으며 Unity Editor 컴파일과 Play Mode 실행은 교육 환경에서 수행해야 합니다.
