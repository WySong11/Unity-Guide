# 59일차 학생 실습 워크시트

**목표:** SO 아이템 정의와 슬롯 상태를 분리한 12칸 Inventory 제작 및 검증

## 1단계 (00~25분) 데이터 정의

- [ ] ItemData 3개 생성 (potion_small, gem_blue, key_iron)
- [ ] ItemId, Kind, MaxStack, HealAmount 필드 확인
- [ ] ItemData에 CurrentQuantity 필드가 없는지 확인

## 2단계 (25~55분) 수량 모델

- [ ] Potion 9개 → Slot0 x5, Slot1 x4 확인
- [ ] 추가 Potion 2개 → x5 / x5 / x1 확인
- [ ] 비중첩 Key 2개 → 서로 다른 2슬롯 확인
- [ ] 용량 부족 시 Add가 수용 개수만 반환하는지 확인

## 3단계 (55~100분) 사용·UI·저장

- [ ] 플레이어 HP=60에서 Potion 사용 → HP=90, Potion -1
- [ ] HP=100에서 Potion 사용 → 실패, Potion 보존
- [ ] Pickup 구체에 접촉해 수량이 누락·중복되지 않는지 확인
- [ ] Save → Clear → Load로 슬롯 데이터 재구성
- [ ] JSON의 `itemId`를 Catalog가 조회하는지 확인

## 4단계 (100~120분) Codex 검증

- [ ] T01~T12 실제 Play Mode 결과 확인
- [ ] 에러 로그·스크린샷·변경 사항(diff) 기록
- [ ] 개선점 1개 이상 제시

## 제출

씬 캡처 2장 이상, 12칸 인벤토리 결과 캡처, JSON 파일(개인정보 없음), 테스트 체크리스트, Codex 보고서.
