# VS Code Codex 검증 프롬프트

## 1. 설계 리뷰

```
Unity 6.3 프로젝트의 Day59 아이템 인벤토리 코드를 검토해줘.
ItemData는 설정값만 갖고 수량은 InventorySlot Runtime에서만 보관하는지 확인해.
ItemId 중복, MaxStack 이상 수량, 음수 count 입력이 발생할 수 있는 경로를 찾아줘.
코드를 바꾸기 전 먼저 재현 조건과 실제 영향 범위를 제시하고, 필요한 최소 변경만 해줘.
```

## 2. 동작 검증

```
Day59Inventory.Add/RemoveAt와 Day59ItemUseController.TryUse를 검증해줘.
T01~T12 중 자동화 가능한 EditMode/PlayMode Test를 제안하고 코드를 작성해줘.
특히 9개 Potion(5+4), 추가 2개(5+5+1), FullHP 사용 실패, Pickup 부분 수용을 검사해줘.
수업 프로젝트 기존 파일과 현재 작업 디렉터리를 바꾸지 말고 결과 diff와 증거를 알려줘.
```

## 3. 저장과 UI 검증

```
Day59InventorySave와 Day59InventoryHUD를 검토해줘.
저장 JSON의 itemId/quantity/index 조작, 누락/중복 ItemId, 모르는 ID, 잘못된 슬롯 인덱스를 테스트해줘.
UI 이벤트가 OnEnable/OnDisable에서 한 번만 구독되는지 확인해줘.
Unity를 실제 실행했다면 Console 로그와 테스트 결과를 증거로 보고하고, 실행하지 못했다면 미검증이라고 분명히 써줘.
```
