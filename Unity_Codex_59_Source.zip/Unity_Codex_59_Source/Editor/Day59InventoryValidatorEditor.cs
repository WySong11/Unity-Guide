#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public static class Day59InventoryValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day59/Validate Inventory Lab")]
    public static void Validate()
    {
        int errors = 0, warnings = 0;
        var ids = new HashSet<string>();
        string[] guids = AssetDatabase.FindAssets("t:Day59ItemData");
        foreach (string guid in guids)
        {
            var item = AssetDatabase.LoadAssetAtPath<Day59ItemData>(AssetDatabase.GUIDToAssetPath(guid));
            if (item == null) continue;
            if (string.IsNullOrWhiteSpace(item.ItemId) || !ids.Add(item.ItemId))
            { Debug.LogError("[Day59] Empty/duplicate ItemId: " + item.name); errors++; }
            if (item.Kind == Day59ItemKind.Consumable && item.HealAmount <= 0)
            { Debug.LogWarning("[Day59] Consumable has no healing amount: " + item.name); warnings++; }
        }
        var inventory = Object.FindFirstObjectByType<Day59Inventory>();
        var catalog = Object.FindFirstObjectByType<Day59ItemCatalog>();
        var save = Object.FindFirstObjectByType<Day59InventorySave>();
        var hud = Object.FindFirstObjectByType<Day59InventoryHUD>();
        if (inventory == null) { Debug.LogError("[Day59] Missing Day59Inventory in open scene."); errors++; }
        if (catalog == null) { Debug.LogError("[Day59] Missing Day59ItemCatalog in open scene."); errors++; }
        if (save == null) { Debug.LogError("[Day59] Missing Day59InventorySave in open scene."); errors++; }
        if (hud == null) { Debug.LogWarning("[Day59] HUD not found."); warnings++; }
        foreach (var pickup in Object.FindObjectsByType<Day59WorldPickup>(FindObjectsSortMode.None))
        {
            if (pickup.Item == null || pickup.Quantity < 1)
            { Debug.LogError("[Day59] Invalid pickup: " + pickup.name); errors++; }
            var col = pickup.GetComponent<Collider>();
            if (col == null || !col.isTrigger)
            { Debug.LogError("[Day59] Pickup requires a Trigger Collider: " + pickup.name); errors++; }
        }
        Debug.Log($"[Day59] Validator finished: errors={errors}, warnings={warnings}, item assets={guids.Length}. Unity Play Mode checks remain manual.");
        EditorUtility.DisplayDialog("Day59 Validator", $"Errors: {errors}\nWarnings: {warnings}\nCheck Console for details.", "OK");
    }
}
#endif
