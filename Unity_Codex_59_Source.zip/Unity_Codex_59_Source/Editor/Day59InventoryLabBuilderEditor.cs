#if UNITY_EDITOR
using System;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class Day59InventoryLabBuilderEditor
{
    private const string Root = "Assets/Day59_Inventory_Lab";

    [MenuItem("Tools/Unity Codex/Day59/Create Inventory Lab")]
    public static void Build()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        string basePath = Root;
        for (int i = 2; AssetDatabase.IsValidFolder(basePath); i++)
            basePath = Root + "_" + i;
        AssetDatabase.CreateFolder("Assets", basePath.Substring("Assets/".Length));
        AssetDatabase.CreateFolder(basePath, "Data");
        AssetDatabase.CreateFolder(basePath, "Prefabs");
        AssetDatabase.CreateFolder(basePath, "Scenes");

        Day59ItemData potion = MakeItem(basePath, "SmallPotion", "potion_small", "Small Potion", Day59ItemKind.Consumable, 5, 30);
        Day59ItemData gem = MakeItem(basePath, "BlueGem", "gem_blue", "Blue Gem", Day59ItemKind.Material, 20, 0);
        Day59ItemData key = MakeItem(basePath, "IronKey", "key_iron", "Iron Key", Day59ItemKind.KeyItem, 1, 0);
        Day59ItemData[] items = { potion, gem, key };

        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        SetupEnvironment();
        var systems = new GameObject("InventorySystems");
        var catalog = systems.AddComponent<Day59ItemCatalog>();
        var cso = new SerializedObject(catalog);
        var itemProp = cso.FindProperty("items");
        itemProp.arraySize = items.Length;
        for (int i = 0; i < items.Length; i++) itemProp.GetArrayElementAtIndex(i).objectReferenceValue = items[i];
        cso.ApplyModifiedPropertiesWithoutUndo();

        var player = new GameObject("Player_InventoryLab");
        player.tag = "Player";
        player.transform.position = Vector3.zero;
        var cc = player.AddComponent<CharacterController>();
        cc.center = new Vector3(0, 1, 0); cc.height = 2; cc.radius = 0.35f;
        var visual = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        visual.name = "Visual"; visual.transform.SetParent(player.transform, false);
        visual.transform.localPosition = new Vector3(0, 1, 0);
        UnityEngine.Object.DestroyImmediate(visual.GetComponent<Collider>());
        var inventory = player.AddComponent<Day59Inventory>();
        var vitals = player.AddComponent<Day59PlayerVitals>();
        var use = player.AddComponent<Day59ItemUseController>();
        SetRef(use, "inventory", inventory); SetRef(use, "vitals", vitals);
        var save = player.AddComponent<Day59InventorySave>();
        SetRef(save, "inventory", inventory); SetRef(save, "catalog", catalog);
        var hud = player.AddComponent<Day59InventoryHUD>();
        SetRef(hud, "inventory", inventory); SetRef(hud, "vitals", vitals);
        SetRef(hud, "useController", use); SetRef(hud, "saveSystem", save); SetRef(hud, "catalog", catalog);
        var input = player.AddComponent<Day59DemoInput>();
        SetRef(input, "hud", hud); SetRef(input, "saveSystem", save);

        CreatePickup(basePath, "PotionPickup_x9", items[0], 9, new Vector3(2, 0.55f, 2), new Color(0.9f, 0.26f, 0.25f));
        CreatePickup(basePath, "GemPickup_x10", items[1], 10, new Vector3(-2, 0.55f, 2), new Color(0.2f, 0.5f, 1f));
        CreatePickup(basePath, "KeyPickup_x2", items[2], 2, new Vector3(0, 0.55f, 4), new Color(1f, 0.8f, 0.18f));

        string scenePath = basePath + "/Scenes/Day59_Inventory_Lab.unity";
        EditorSceneManager.MarkSceneDirty(scene);
        EditorSceneManager.SaveScene(scene, scenePath);
        AssetDatabase.SaveAssets(); AssetDatabase.Refresh();
        EditorUtility.DisplayDialog("Day59 Inventory Lab", "Created:\n" + scenePath + "\n\nPlay > walk over pickup spheres, or use the demo HUD.", "OK");
        Debug.Log("[Day59] Scene created: " + scenePath);
    }

    private static Day59ItemData MakeItem(string root, string fileName, string id, string label,
        Day59ItemKind kind, int stack, int heal)
    {
        Day59ItemData data = ScriptableObject.CreateInstance<Day59ItemData>();
        string path = root + "/Data/" + fileName + ".asset";
        AssetDatabase.CreateAsset(data, path);
        var so = new SerializedObject(data);
        so.FindProperty("itemId").stringValue = id;
        so.FindProperty("displayName").stringValue = label;
        so.FindProperty("kind").enumValueIndex = (int)kind;
        so.FindProperty("maxStack").intValue = stack;
        so.FindProperty("healAmount").intValue = heal;
        so.ApplyModifiedPropertiesWithoutUndo();
        EditorUtility.SetDirty(data);
        return data;
    }

    private static void SetRef(Component component, string property, UnityEngine.Object value)
    {
        var so = new SerializedObject(component);
        so.FindProperty(property).objectReferenceValue = value;
        so.ApplyModifiedPropertiesWithoutUndo();
    }
    private static void SetupEnvironment()
    {
        var floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
        floor.name = "Floor"; floor.transform.localScale = new Vector3(2.5f, 1, 2.5f);
        var camObject = new GameObject("Main Camera"); camObject.tag = "MainCamera";
        var cam = camObject.AddComponent<Camera>();
        camObject.AddComponent<AudioListener>();
        cam.transform.position = new Vector3(0, 13, -13);
        cam.transform.LookAt(new Vector3(0, 0, 1));
        var lightObj = new GameObject("Directional Light");
        var light = lightObj.AddComponent<Light>(); light.type = LightType.Directional;
        light.transform.rotation = Quaternion.Euler(45, -25, 0);
    }
    private static void CreatePickup(string root, string label, Day59ItemData data, int quantity, Vector3 pos, Color color)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        go.name = label; go.transform.position = pos;
        go.transform.localScale = Vector3.one * 0.9f;
        var collider = go.GetComponent<SphereCollider>(); collider.isTrigger = true;
        var rb = go.AddComponent<Rigidbody>(); rb.isKinematic = true; rb.useGravity = false;
        var pickup = go.AddComponent<Day59WorldPickup>();
        SetRef(pickup, "item", data);
        var so = new SerializedObject(pickup);
        so.FindProperty("quantity").intValue = quantity;
        so.ApplyModifiedPropertiesWithoutUndo();
        var renderer = go.GetComponent<Renderer>();
        if (renderer != null)
        {
            var shader = Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Standard");
            if (shader != null)
            {
                var mat = new Material(shader);
                if (mat.HasProperty("_BaseColor")) mat.SetColor("_BaseColor", color);
                else if (mat.HasProperty("_Color")) mat.SetColor("_Color", color);
                renderer.sharedMaterial = mat;
                AssetDatabase.CreateAsset(mat, root + "/Prefabs/" + label + "_Mat.mat");
            }
        }
        PrefabUtility.SaveAsPrefabAssetAndConnect(go, root + "/Prefabs/" + label + ".prefab", InteractionMode.AutomatedAction);
    }
}
#endif
