# Codex 실습 프롬프트

## 1. 사전 분석
```text
Unity 6.3 프로젝트에서 Enemy AI의 Navigation 코드를 분석해줘.
Day50EnemyPerception, Day50PatrolRoute, Day51EnemyAttack, Day51EnemyHealth와
Day51EnemyBrain의 참조 관계를 먼저 조사하고, 기존 동작을 변경하면 안 되는 부분을 정리해줘.
어떤 Brain도 임의로 삭제하지 말고 변경 계획만 작성해줘.
```

## 2. 개선 구현
```text
기존 Patrol/Chase/Attack/Return/Dead의 상태와 체력 이벤트 계약은 유지하면서
NavMeshAgent 추적 품질을 개선해줘.
필수:
- SetDestination 호출을 RepathInterval과 목표 이동 Threshold로 제한
- agent.enabled, isOnNavMesh, pathPending, pathStatus, hasPath 점검
- NavMesh.SamplePosition 사용, Partial/Invalid 경로 처리
- Stuck 감지와 재시도 지연, 무한 재계산 금지
- NavMeshObstacle Carving을 O 키로 ON/OFF하는 테스트 씬
- 기존 Day51EnemyBrain과 중복 실행 불가
변경 파일, Inspector 연결, 예상 부작용, Rollback 방법을 먼저 제시해줘.
```

## 3. 오류 재현
```text
다음 증상과 로그를 확인하고 근본 원인을 조사해줘:
[여기에 Scene / NavMeshSurface / Agent 값 / Console 로그 / 재현 단계]
코드 수정 전에 원인 후보와 해당 원인을 확인할 최소 실험을 2개 이상 제안해줘.
```

## 4. 검증 및 보고
```text
코드 컴파일, 씬 구조 검사, Play Mode 경로 테스트를 서로 구분해 수행해줘.
가능한 경우 16개 테스트 케이스를 실제로 실행하고 Pass/Fail/Not-run으로 보고해줘.
수정된 diff와 이전 기능(Attack, Return, Dead) 회귀 결과를 포함해줘.
실행 불가능했던 항목은 '검증하지 못함'으로 표시해줘.
```
