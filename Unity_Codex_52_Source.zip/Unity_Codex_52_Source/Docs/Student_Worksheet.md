# 52일차 학생 워크시트 — NavMesh 추적과 AI 개선

## 실습 1: 경로 갱신 관찰 (20분)
1. Scene을 열고 NavMeshSurface Bake 상태를 확인하세요.
2. F1 HUD에서 Agent의 pathPending / pathStatus / remainingDistance를 기록하세요.
3. Player를 이동시키면서 `SetDestination requests` 값이 증가하는 순간을 확인하세요.
4. Repath Interval을 0.1 → 0.3 → 0.7초로 바꿔 추적 반응성 차이를 기록하세요.

## 실습 2: 동적 장애물 (15분)
1. 문 오브젝트에 NavMeshObstacle와 Collider가 있는지 확인하세요.
2. `O` 키로 문을 닫고 열어 Enemy의 이동 경로를 비교하세요.
3. Carving ON/OFF가 경로 계획에 어떤 차이를 만드는지 설명하세요.

## 실습 3: Stuck 및 Return (20분)
1. 지나갈 수 없는 위치로 목표를 유도한 다음 HUD의 LastIssue를 기록하세요.
2. pathStatus가 Partial 또는 Invalid일 때 프로그램이 어떻게 반응하는지 확인하세요.
3. Enemy가 Player를 놓쳤을 때 Return → Patrol이 이어지는지 기록하세요.

## 실습 4: Codex 검증 (20분)
1. 먼저 오류를 재현하고 Console + HUD 스크린샷을 저장하세요.
2. Codex에 원인 가설 2개와 최소 수정안을 요청하세요.
3. 수정 전후 RequestCount/RecoveryCount/상태 전환을 비교하세요.
4. Day51 Attack / Dead 동작이 깨지지 않았는지 회귀 테스트하세요.

## 제출
- 실행 Scene과 수정 스크립트
- 검증 스크린샷 6장 이상(경로·HUD·Console 포함)
- 채운 `Test_Checklist.csv`
- `git diff` 및 Codex 변경 보고서 1부
