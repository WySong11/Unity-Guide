# 강사용 해설 및 판정 요령

- **SetDestination 빈도:** 매 프레임 요청하지 않음. 정지된 목표는 기존 경로를 유지. 이동한 목표는 Interval과 Threshold가 충족된 후 갱신.
- **pathPending:** 경로 계산 중으로 판단. 이때 Partial/Complete 판정이나 도착 판정을 수행하지 않음.
- **PathPartial:** 목적지까지 전체 경로가 없음. 계속 전진하다 벽 앞에서 멈추면 길찾기·목표 좌표·Agent Radius·Bake를 확인.
- **SamplePosition:** NavMesh 가까운 위치를 찾는 기능이지 경로 도달 보증 기능이 아님.
- **Carving:** NavMesh에 구멍을 생성해 전역 경로가 우회를 고려하게 할 수 있음. Carving OFF는 국소 회피가 중심.
- **Stuck:** 목표 희망 이동(desiredVelocity)과 실제 속도가 지속적으로 다르면 재시도를 예약. 정체 복구는 막힌 통로를 물리적으로 만들지 않음.
- **중복 Brain:** 기존 Day51EnemyBrain과 새 Day52EnemyBrain을 같은 Enemy에 넣지 않음.
- **Dead:** HP=0 시 공격 예약 취소, NavMeshAgent Stop, 상태 변경 중단. AI는 사망 후 다시 움직이면 안 됨.
- **평가 예시(100점):** Repath 25, Path 25, Carving 20, FSM 회귀 20, Codex 검증 10.

실제로 Unity Editor에서 컴파일/실행하지 않았다면 그 사실을 기록하고 과대 주장하지 않습니다.
