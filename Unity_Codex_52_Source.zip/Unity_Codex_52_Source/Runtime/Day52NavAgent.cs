using UnityEngine;
using UnityEngine.AI;

/// <summary>
/// NavMeshAgent 명령과 경로 상태 판정을 담당하는 공통 내비게이션 계층.
/// 목표 갱신은 시간 + 목표 위치 변화량으로 제한합니다.
/// </summary>
[RequireComponent(typeof(NavMeshAgent))]
public sealed class Day52NavAgent : MonoBehaviour
{
    [Header("Speed")]
    [SerializeField, Min(0.1f)] private float patrolSpeed = 2f;
    [SerializeField, Min(0.1f)] private float chaseSpeed = 4.5f;
    [Header("Path Requests")]
    [SerializeField, Min(0.05f)] private float repathInterval = 0.30f;
    [SerializeField, Min(0.05f)] private float targetMoveThreshold = 0.55f;
    [SerializeField, Min(0.05f)] private float navMeshSampleRadius = 1.5f;
    [SerializeField, Min(0.01f)] private float arrivalTolerance = 0.20f;
    [Header("Recovery")]
    [SerializeField, Min(0.25f)] private float stuckTimeout = 2.25f;
    [SerializeField, Min(0.1f)] private float retryDelay = 0.65f;

    private NavMeshAgent agent;
    private float nextRequestAt;
    private float lastRequestAt;
    private float stuckTimer;
    private Vector3 lastGoal;
    private bool requested;
    private bool forceNext;

    public NavMeshAgent Agent => agent ? agent : (agent = GetComponent<NavMeshAgent>());
    public bool Ready => Agent && Agent.enabled && Agent.isOnNavMesh;
    public int RequestCount { get; private set; }
    public int RecoveryCount { get; private set; }
    public string LastIssue { get; private set; } = "None";
    public Vector3 LastGoal => lastGoal;
    public bool PathPending => Ready && Agent.pathPending;
    public NavMeshPathStatus PathStatus => Ready ? Agent.pathStatus : NavMeshPathStatus.PathInvalid;
    public float RemainingDistance => Ready ? Agent.remainingDistance : float.PositiveInfinity;
    public float RepathInterval => repathInterval;

    private void Awake() => agent = GetComponent<NavMeshAgent>();

    public void SetPatrolMode()
    {
        if (!Ready) return;
        Agent.speed = patrolSpeed;
        Agent.stoppingDistance = 0.25f;
        Agent.autoBraking = false;
        Agent.isStopped = false;
    }

    public void SetChaseMode(float stopDistance)
    {
        if (!Ready) return;
        Agent.speed = chaseSpeed;
        Agent.stoppingDistance = Mathf.Max(0.15f, stopDistance);
        Agent.autoBraking = true;
        Agent.isStopped = false;
    }

    /// <summary>
    /// false = 새 요청이 실패함. true = 기존 경로 유지 또는 새 요청 성공.
    /// true가 '목적지에 도착했다'를 의미하지는 않습니다.
    /// </summary>
    public bool TryUpdateGoal(Vector3 desired, bool force = false)
    {
        if (!Ready) { LastIssue = "Agent is not on NavMesh"; return false; }
        if (Agent.isStopped) { LastIssue = "Agent is stopped"; return false; }
        if (Time.time < nextRequestAt) return requested; // 경로 재계산 쿨다운

        bool movedEnough = !requested || (desired - lastGoal).sqrMagnitude >=
                           targetMoveThreshold * targetMoveThreshold;
        bool pathBad = PathFailed();
        if (!force && !forceNext && requested && !movedEnough && !pathBad)
            return true;

        if (!NavMesh.SamplePosition(desired, out NavMeshHit hit,
                                    navMeshSampleRadius, Agent.areaMask))
        {
            LastIssue = "NavMesh.SamplePosition failed";
            nextRequestAt = Time.time + retryDelay;
            return false;
        }

        lastGoal = desired;
        lastRequestAt = Time.time;
        nextRequestAt = Time.time + repathInterval;
        forceNext = false;
        requested = Agent.SetDestination(hit.position);
        RequestCount++;
        LastIssue = requested ? "None" : "SetDestination returned false";
        return requested;
    }

    public bool HasArrived()
    {
        if (!Ready || Agent.pathPending) return false;
        if (Agent.pathStatus != NavMeshPathStatus.PathComplete) return false;
        if (!Agent.hasPath) return false;
        if (float.IsInfinity(Agent.remainingDistance)) return false;
        float threshold = Agent.stoppingDistance + arrivalTolerance;
        return Agent.remainingDistance <= threshold && Agent.velocity.sqrMagnitude < 0.09f;
    }

    public bool PathFailed()
    {
        if (!Ready || Agent.pathPending || !requested) return false;
        if (Agent.pathStatus != NavMeshPathStatus.PathComplete) return true;
        // 계산 요청 직후와 경로 도착 직후를 제외하고 경로가 없는 경우
        return !Agent.hasPath && Time.time - lastRequestAt > 0.4f &&
               Vector3.Distance(transform.position, lastGoal) >
               Agent.stoppingDistance + arrivalTolerance;
    }

    public void Tick(float deltaTime)
    {
        if (!Ready || Agent.isStopped || Agent.pathPending || !Agent.hasPath ||
            Agent.pathStatus != NavMeshPathStatus.PathComplete ||
            float.IsInfinity(Agent.remainingDistance) ||
            Agent.remainingDistance <= Agent.stoppingDistance + arrivalTolerance)
        { stuckTimer = 0f; return; }

        if (Agent.desiredVelocity.sqrMagnitude > 0.04f && Agent.velocity.sqrMagnitude < 0.01f)
            stuckTimer += deltaTime;
        else stuckTimer = 0f;

        if (stuckTimer < stuckTimeout) return;
        stuckTimer = 0f;
        RecoveryCount++;
        LastIssue = "Stuck: reset & delayed repath";
        Agent.ResetPath();
        forceNext = true;
        nextRequestAt = Time.time + retryDelay;
    }

    public void Stop(bool clearPath = true)
    {
        if (!Ready) return;
        Agent.isStopped = true;
        if (clearPath) Agent.ResetPath();
        stuckTimer = 0f;
    }
    public void ResetGoal()
    {
        requested = false;
        forceNext = true;
        nextRequestAt = 0f;
        stuckTimer = 0f;
    }
}
