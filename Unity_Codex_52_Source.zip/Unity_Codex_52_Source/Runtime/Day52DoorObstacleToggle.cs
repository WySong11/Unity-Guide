using UnityEngine;
using UnityEngine.AI;
using UnityEngine.InputSystem;

/// <summary>O 키로 문을 열고 닫으면서 동적 Carving을 관찰합니다.</summary>
[RequireComponent(typeof(NavMeshObstacle))]
public sealed class Day52DoorObstacleToggle : MonoBehaviour
{
    [SerializeField] private Collider blockingCollider;
    [SerializeField] private Renderer visual;
    [SerializeField] private bool startsClosed = true;
    private NavMeshObstacle obstacle;
    private bool closed;
    private void Awake()
    {
        obstacle = GetComponent<NavMeshObstacle>();
        if (!blockingCollider) blockingCollider = GetComponent<Collider>();
        if (!visual) visual = GetComponent<Renderer>();
    }
    private void Start() => SetClosed(startsClosed);
    private void Update()
    {
        if (Keyboard.current != null && Keyboard.current.oKey.wasPressedThisFrame)
            SetClosed(!closed);
    }
    public void SetClosed(bool value)
    {
        closed = value;
        if (obstacle)
        {
            obstacle.carving = true;
            obstacle.carveOnlyStationary = true;
            obstacle.enabled = closed;
        }
        if (blockingCollider) blockingCollider.enabled = closed;
        if (visual) visual.enabled = closed;
        Debug.Log($"[Day52] Door closed: {closed}", this);
    }
}
