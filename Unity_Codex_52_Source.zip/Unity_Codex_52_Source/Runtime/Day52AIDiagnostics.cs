using UnityEngine;
using UnityEngine.AI;
using UnityEngine.InputSystem;

/// <summary>F1: HUD / Scene View: NavMesh 경로와 목적지 Gizmos.</summary>
[RequireComponent(typeof(Day52EnemyBrain), typeof(Day52NavAgent))]
public sealed class Day52AIDiagnostics : MonoBehaviour
{
    [SerializeField] private bool visible = true;
    [SerializeField] private bool drawPath = true;
    [SerializeField] private Vector2 hudPosition = new Vector2(16, 16);
    private Day52EnemyBrain brain;
    private Day52NavAgent nav;

    private void Awake()
    {
        brain = GetComponent<Day52EnemyBrain>();
        nav = GetComponent<Day52NavAgent>();
    }
    private void Update()
    {
        if (Keyboard.current != null && Keyboard.current.f1Key.wasPressedThisFrame)
            visible = !visible;
    }
    private void OnGUI()
    {
        if (!visible || brain == null || nav == null) return;
        NavMeshAgent agent = nav.Agent;
        GUILayout.BeginArea(new Rect(hudPosition.x, hudPosition.y, 365, 250), GUI.skin.box);
        GUILayout.Label("DAY 52   ENEMY NAVMESH DIAGNOSTICS");
        GUILayout.Label($"State: {brain.State} | LostTimer: {brain.LostTimer:F2}");
        GUILayout.Label($"Agent Ready: {nav.Ready} | Stopped: {(nav.Ready && agent.isStopped)}");
        GUILayout.Label($"pathPending: {nav.PathPending} | pathStatus: {nav.PathStatus}");
        GUILayout.Label($"hasPath: {agent.hasPath} | remaining: {nav.RemainingDistance:F2}");
        GUILayout.Label($"desiredSpeed: {agent.desiredVelocity.magnitude:F2} | actual: {agent.velocity.magnitude:F2}");
        GUILayout.Label($"SetDestination requests: {nav.RequestCount} | recovery: {nav.RecoveryCount}");
        GUILayout.Label($"Last issue: {nav.LastIssue}");
        GUILayout.Label("WASD: player  |  F1: HUD  |  O: door obstacle");
        GUILayout.EndArea();
    }
    private void OnDrawGizmosSelected()
    {
        if (!drawPath) return;
        NavMeshAgent agent = GetComponent<NavMeshAgent>();
        if (agent == null || !agent.enabled || !agent.isOnNavMesh) return;
        Vector3[] corners = agent.path.corners;
        Gizmos.color = Color.cyan;
        for (int i = 1; i < corners.Length; i++)
            Gizmos.DrawLine(corners[i - 1] + Vector3.up * .15f,
                            corners[i] + Vector3.up * .15f);
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(agent.destination, .25f);
    }
}
