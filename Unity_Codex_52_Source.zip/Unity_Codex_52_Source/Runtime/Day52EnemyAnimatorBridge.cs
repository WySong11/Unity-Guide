using UnityEngine;

/// <summary>선택: 외부 Animator Controller 파라미터 Speed/Dead를 연결합니다.</summary>
[RequireComponent(typeof(Day52EnemyBrain), typeof(Day52NavAgent))]
public sealed class Day52EnemyAnimatorBridge : MonoBehaviour
{
    [SerializeField] private Animator animator;
    [SerializeField] private string speedParameter = "Speed";
    [SerializeField] private string deadParameter = "Dead";
    private Day52EnemyBrain brain;
    private Day52NavAgent navigation;

    private void Awake()
    {
        brain = GetComponent<Day52EnemyBrain>();
        navigation = GetComponent<Day52NavAgent>();
    }
    private void Update()
    {
        if (!animator || !navigation.Ready) return;
        animator.SetFloat(speedParameter, navigation.Agent.velocity.magnitude, .1f, Time.deltaTime);
        animator.SetBool(deadParameter, brain.State == Day51EnemyState.Dead);
    }
}
