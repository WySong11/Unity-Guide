using System;
using UnityEngine;

/// <summary>
/// Day51EnemyBrain 대신 단독 장착하는 개선 버전.
/// Day50 탐지·순찰 + Day51 Attack·Health + Day52 NavAgent를 조합합니다.
/// </summary>
[RequireComponent(typeof(Day52NavAgent), typeof(Day50EnemyPerception), typeof(Day50PatrolRoute))]
[RequireComponent(typeof(Day51EnemyAttack), typeof(Day51EnemyHealth))]
public sealed class Day52EnemyBrain : MonoBehaviour
{
    [SerializeField] private Day52NavAgent navigation;
    [SerializeField] private Day50EnemyPerception perception;
    [SerializeField] private Day50PatrolRoute patrolRoute;
    [SerializeField] private Day51EnemyAttack attack;
    [SerializeField] private Day51EnemyHealth health;
    [Header("Transitions")]
    [SerializeField, Min(0.1f)] private float lostTargetDelay = 1.5f;
    [SerializeField, Min(0.0f)] private float attackExitPadding = 0.6f;
    [SerializeField, Min(1f)] private float returnTimeout = 8f;

    public Day51EnemyState State { get; private set; } = Day51EnemyState.Patrol;
    public event Action<Day51EnemyState> StateChanged;
    public float LostTimer => lostTimer;
    public Day52NavAgent Navigation => navigation;
    public Day50EnemyPerception Perception => perception;
    public Day51EnemyHealth Health => health;

    private float lostTimer;
    private float patrolWait;
    private float returnTimer;
    private float returnRetryTimer;
    private bool waiting;
    private Vector3 lastSeenPosition;
    private Vector3 returnPosition;

    private void Awake()
    {
        if (!navigation) navigation = GetComponent<Day52NavAgent>();
        if (!perception) perception = GetComponent<Day50EnemyPerception>();
        if (!patrolRoute) patrolRoute = GetComponent<Day50PatrolRoute>();
        if (!attack) attack = GetComponent<Day51EnemyAttack>();
        if (!health) health = GetComponent<Day51EnemyHealth>();
    }
    private void OnEnable()
    {
        if (health) health.Died += EnterDead;
    }
    private void OnDisable()
    {
        if (health) health.Died -= EnterDead;
        if (attack) attack.CancelAttack();
        if (navigation && navigation.Ready) navigation.Stop();
    }
    private void Start()
    {
        if (health && health.IsDead) { EnterDead(); return; }
        BeginPatrol();
    }
    private void Update()
    {
        if (State == Day51EnemyState.Dead || !navigation || !navigation.Ready) return;
        navigation.Tick(Time.deltaTime);
        if ((State == Day51EnemyState.Patrol || State == Day51EnemyState.Return) &&
            perception.CanAcquire())
        { BeginChase(true); return; }
        switch (State)
        {
            case Day51EnemyState.Patrol: UpdatePatrol(); break;
            case Day51EnemyState.Chase: UpdateChase(); break;
            case Day51EnemyState.Attack: UpdateAttack(); break;
            case Day51EnemyState.Return: UpdateReturn(); break;
        }
    }
    private void ChangeState(Day51EnemyState state)
    {
        if (State == Day51EnemyState.Dead || State == state) return;
        State = state;
        StateChanged?.Invoke(state);
    }
    private void BeginPatrol()
    {
        if (!patrolRoute || !patrolRoute.HasPoints)
        { Debug.LogWarning("[Day52] Waypoints missing", this); return; }
        waiting = false;
        patrolWait = 0f;
        navigation.SetPatrolMode();
        navigation.ResetGoal();
        ChangeState(Day51EnemyState.Patrol);
        navigation.TryUpdateGoal(patrolRoute.CurrentPoint, true);
    }
    private void UpdatePatrol()
    {
        if (!patrolRoute || !patrolRoute.HasPoints) return;
        if (waiting)
        {
            patrolWait -= Time.deltaTime;
            if (patrolWait <= 0f)
            {
                patrolRoute.Advance();
                waiting = false;
                navigation.SetPatrolMode();
                navigation.ResetGoal();
                navigation.TryUpdateGoal(patrolRoute.CurrentPoint, true);
            }
            return;
        }
        if (navigation.HasArrived() ||
            Vector3.Distance(transform.position, patrolRoute.CurrentPoint) <= 0.45f)
        {
            waiting = true;
            patrolWait = patrolRoute.WaitAtPoint;
            navigation.Stop();
            return;
        }
        navigation.TryUpdateGoal(patrolRoute.CurrentPoint);
        if (navigation.PathFailed())
        {
            patrolRoute.Advance();
            navigation.ResetGoal();
        }
    }
    private void BeginChase(bool resetLost)
    {
        if (perception.Target == null) return;
        if (resetLost) lostTimer = 0f;
        if (perception.CanKeepSight()) lastSeenPosition = perception.Target.position;
        navigation.SetChaseMode(attack.AttackRange);
        navigation.ResetGoal();
        ChangeState(Day51EnemyState.Chase);
    }
    private bool UpdateSightAndLoss()
    {
        Transform target = perception.Target;
        if (!target || !target.gameObject.activeInHierarchy)
        { BeginReturn(); return false; }
        Day51PlayerHealth hp = target.GetComponentInParent<Day51PlayerHealth>();
        if (hp && hp.IsDead) { BeginReturn(); return false; }
        if (perception.CanKeepSight())
        {
            lostTimer = 0f;
            lastSeenPosition = target.position;
            return true;
        }
        lostTimer += Time.deltaTime;
        if (lostTimer >= lostTargetDelay) BeginReturn();
        return false;
    }
    private void UpdateChase()
    {
        bool visible = UpdateSightAndLoss();
        if (State != Day51EnemyState.Chase) return;
        if (visible && perception.DistanceToTarget <= attack.AttackRange)
        { BeginAttack(); return; }
        navigation.SetChaseMode(attack.AttackRange);
        navigation.TryUpdateGoal(lastSeenPosition);
    }
    private void BeginAttack()
    {
        navigation.Stop();
        ChangeState(Day51EnemyState.Attack);
    }
    private void UpdateAttack()
    {
        bool visible = UpdateSightAndLoss();
        if (State != Day51EnemyState.Attack) return;
        if (!visible)
        {
            attack.CancelAttack();
            BeginChase(false); // 마지막으로 목격한 위치를 수색; lostTimer는 유지
            return;
        }
        if (perception.DistanceToTarget > attack.AttackRange + attackExitPadding)
        {
            attack.CancelAttack();
            BeginChase(true);
            return;
        }
        Transform target = perception.Target;
        Vector3 forward = target.position - transform.position;
        forward.y = 0f;
        if (forward.sqrMagnitude > 0.001f)
            transform.rotation = Quaternion.RotateTowards(transform.rotation,
                Quaternion.LookRotation(forward), 360f * Time.deltaTime);
        attack.TryAttack(target);
    }
    private void BeginReturn()
    {
        if (State == Day51EnemyState.Return || State == Day51EnemyState.Dead) return;
        attack.CancelAttack();
        navigation.SetPatrolMode();
        navigation.ResetGoal();
        if (patrolRoute && patrolRoute.HasPoints)
        {
            patrolRoute.SelectClosest(transform.position);
            returnPosition = patrolRoute.CurrentPoint;
        }
        else returnPosition = transform.position;
        returnTimer = 0f;
        returnRetryTimer = 0f;
        ChangeState(Day51EnemyState.Return);
        navigation.TryUpdateGoal(returnPosition, true);
    }
    private void UpdateReturn()
    {
        returnTimer += Time.deltaTime;
        returnRetryTimer -= Time.deltaTime;
        if (navigation.HasArrived() || Vector3.Distance(transform.position, returnPosition) < 0.45f)
        { BeginPatrol(); return; }
        if (navigation.PathFailed() && returnRetryTimer <= 0f)
        {
            if (patrolRoute && patrolRoute.HasPoints)
            {
                patrolRoute.Advance();
                returnPosition = patrolRoute.CurrentPoint;
            }
            navigation.ResetGoal();
            returnRetryTimer = 0.8f;
        }
        navigation.TryUpdateGoal(returnPosition);
        if (returnTimer >= returnTimeout)
        {
            Debug.LogWarning("[Day52] Return timed out; reset Patrol route", this);
            BeginPatrol();
        }
    }
    public void EnterDead()
    {
        if (State == Day51EnemyState.Dead) return;
        attack.CancelAttack();
        navigation.Stop();
        State = Day51EnemyState.Dead;
        StateChanged?.Invoke(State);
        Debug.Log("[Day52] Dead: AI, path requests, combat stopped", this);
    }
}
