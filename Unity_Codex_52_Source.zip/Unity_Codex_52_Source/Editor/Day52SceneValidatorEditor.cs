#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using UnityEngine.AI;
using Unity.AI.Navigation;

public static class Day52SceneValidatorEditor
{
    [MenuItem("Tools/Unity Codex/Day52/Validate Active Scene")]
    public static void Validate()
    {
        int problems = 0;
        foreach (Day52EnemyBrain enemy in Object.FindObjectsByType<Day52EnemyBrain>(FindObjectsSortMode.None))
        {
            GameObject g = enemy.gameObject;
            foreach (MonoBehaviour component in g.GetComponents<MonoBehaviour>())
            {
                if (component != null && (component.GetType().Name == "Day51EnemyBrain" ||
                                          component.GetType().Name == "Day50EnemyBrain"))
                { Debug.LogError("[Day52] 이전 Brain과 Day52Brain 동시 부착 금지", g); problems++; }
            }
            if (!g.TryGetComponent(out NavMeshAgent agent))
            { Debug.LogError("[Day52] NavMeshAgent 없음", g); problems++; continue; }
            if (!agent.isOnNavMesh)
            { Debug.LogWarning("[Day52] Agent가 NavMesh 위에 있는지 Play Mode에서 확인하세요", g); }
            if (!g.TryGetComponent(out Day52NavAgent _) ||
                !g.TryGetComponent(out Day50EnemyPerception _) ||
                !g.TryGetComponent(out Day50PatrolRoute _) ||
                !g.TryGetComponent(out Day51EnemyAttack _) ||
                !g.TryGetComponent(out Day51EnemyHealth _))
            { Debug.LogError("[Day52] 핵심 AI 컴포넌트 누락", g); problems++; }
        }
        if (Object.FindObjectsByType<NavMeshSurface>(FindObjectsSortMode.None).Length == 0)
        { Debug.LogWarning("[Day52] NavMeshSurface 없음: AI Navigation 설치 및 Bake 확인"); problems++; }
        foreach (NavMeshObstacle obstacle in Object.FindObjectsByType<NavMeshObstacle>(FindObjectsSortMode.None))
        {
            if (obstacle.GetComponent<NavMeshAgent>())
            { Debug.LogWarning("[Day52] Agent와 Obstacle을 동일 객체에 부착하지 마세요", obstacle); problems++; }
        }
        if (problems == 0) Debug.Log("[Day52] Scene structural validation PASS; Play Mode tests still required.");
        else Debug.LogWarning($"[Day52] Structural issues: {problems}");
    }
}
#endif
