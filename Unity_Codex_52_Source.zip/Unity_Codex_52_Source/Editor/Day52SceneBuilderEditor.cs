#if UNITY_EDITOR
using System;
using Unity.AI.Navigation;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.SceneManagement;

/// <summary>기존 Scene을 덮어쓰지 않는 독립 실습 생성기.</summary>
public static class Day52SceneBuilderEditor
{
    private const string Root = "Assets/UnityCodexDay52";

    [MenuItem("Tools/Unity Codex/Day52/Create NavMesh AI Lab")]
    public static void CreateLab()
    {
        if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
        if (!AssetDatabase.IsValidFolder(Root)) AssetDatabase.CreateFolder("Assets", "UnityCodexDay52");
        if (!AssetDatabase.IsValidFolder(Root + "/Scenes")) AssetDatabase.CreateFolder(Root, "Scenes");
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        GameObject root = new GameObject("Day52_NavMesh_AI_Lab");
        GameObject geometry = new GameObject("NavigationGeometry");
        geometry.transform.SetParent(root.transform);
        Block("Ground", new Vector3(0, -.25f, 0), new Vector3(30, .5f, 26), geometry.transform);
        // 좌/우 벽 사이에 통로와 우회로를 만들어 경로 변경을 비교합니다.
        Block("Wall_L", new Vector3(-4, 1, -1), new Vector3(1, 2, 11), geometry.transform);
        Block("Wall_R", new Vector3(4, 1, 1), new Vector3(1, 2, 11), geometry.transform);
        Block("Crate_A", new Vector3(-9, .75f, 3), new Vector3(2, 1.5f, 2), geometry.transform);
        Block("Crate_B", new Vector3(9, .75f, -3), new Vector3(2, 1.5f, 2), geometry.transform);

        NavMeshSurface surface = geometry.AddComponent<NavMeshSurface>();
        surface.collectObjects = CollectObjects.Children;
        surface.useGeometry = NavMeshCollectGeometry.PhysicsColliders;
        // 현재 씬을 먼저 저장해야 NavMeshData 에셋 경로가 안정적으로 생성됩니다.
        string path = AssetDatabase.GenerateUniqueAssetPath(Root + "/Scenes/Day52_" +
                      DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".unity");
        EditorSceneManager.SaveScene(scene, path);
        surface.BuildNavMesh();

        GameObject pointsRoot = new GameObject("PatrolWaypoints");
        pointsRoot.transform.SetParent(root.transform);
        Vector3[] pos = { new Vector3(-9, 0, -9), new Vector3(-9, 0, 9),
                          new Vector3(9, 0, 9), new Vector3(9, 0, -9) };
        Transform[] points = new Transform[pos.Length];
        for (int i = 0; i < pos.Length; i++)
        {
            GameObject p = new GameObject($"WP_{i:00}");
            p.transform.SetParent(pointsRoot.transform);
            p.transform.position = pos[i];
            points[i] = p.transform;
        }

        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Player_Test";
        player.transform.SetParent(root.transform);
        player.transform.position = new Vector3(0, 1, 8);
        UnityEngine.Object.DestroyImmediate(player.GetComponent<CapsuleCollider>());
        player.AddComponent<CharacterController>();
        player.AddComponent<Day50PlayerMover>();
        player.AddComponent<Day51PlayerHealth>();

        GameObject enemy = new GameObject("Enemy_Day52");
        enemy.transform.SetParent(root.transform);
        enemy.transform.position = pos[0];
        GameObject visual = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        visual.name = "Visual";
        visual.transform.SetParent(enemy.transform, false);
        visual.transform.localPosition = Vector3.up;
        UnityEngine.Object.DestroyImmediate(visual.GetComponent<CapsuleCollider>());
        NavMeshAgent agent = enemy.AddComponent<NavMeshAgent>();
        agent.radius = .45f;
        agent.height = 2f;
        agent.speed = 2f;
        agent.angularSpeed = 540f;
        agent.avoidancePriority = 45;
        enemy.AddComponent<Day52NavAgent>();
        Day50EnemyPerception perception = enemy.AddComponent<Day50EnemyPerception>();
        perception.Configure(player.transform);
        Day50PatrolRoute route = enemy.AddComponent<Day50PatrolRoute>();
        route.Configure(points);
        enemy.AddComponent<Day51EnemyAttack>();
        enemy.AddComponent<Day51EnemyHealth>();
        enemy.AddComponent<Day52EnemyBrain>();
        enemy.AddComponent<Day52AIDiagnostics>();

        GameObject door = Block("Toggle_Door_Press_O", new Vector3(0, 1, 0),
                                 new Vector3(3.0f, 2f, .8f), root.transform);
        NavMeshObstacle obstacle = door.AddComponent<NavMeshObstacle>();
        obstacle.shape = NavMeshObstacleShape.Box;
        obstacle.size = new Vector3(1, 1, 1); // 스케일 적용을 고려한 로컬 크기
        obstacle.carving = true;
        obstacle.carveOnlyStationary = true;
        door.AddComponent<Day52DoorObstacleToggle>();

        GameObject camera = new GameObject("Main Camera");
        camera.tag = "MainCamera";
        camera.AddComponent<Camera>();
        camera.AddComponent<AudioListener>();
        camera.AddComponent<Day50FollowCamera>().Configure(player.transform);
        camera.transform.position = new Vector3(0, 13, -13);
        GameObject light = new GameObject("Directional Light");
        light.AddComponent<Light>().type = LightType.Directional;
        light.transform.rotation = Quaternion.Euler(50, -25, 0);

        EditorSceneManager.SaveScene(scene, path);
        Selection.activeGameObject = enemy;
        Debug.Log($"[Day52] Created {path} | W/A/S/D Player, O toggles door, F1 HUD", enemy);
    }

    private static GameObject Block(string name, Vector3 p, Vector3 scale, Transform parent)
    {
        GameObject g = GameObject.CreatePrimitive(PrimitiveType.Cube);
        g.name = name;
        g.transform.SetParent(parent);
        g.transform.position = p;
        g.transform.localScale = scale;
        return g;
    }
}
#endif
