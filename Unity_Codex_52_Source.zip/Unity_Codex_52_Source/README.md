# Unity Codex 52일차 — NavMesh 추적과 AI 개선

- 대상: **Unity 6.3 / Universal 3D(URP)**
- 목표: 50~51일차 FSM(Patrol/Chase/Attack/Return/Dead)을 유지하면서 이동 경로를 안정화합니다.
- 설치 패키지: **AI Navigation (com.unity.ai.navigation)** + **Input System (com.unity.inputsystem)**
- 중요: Unity 에디터/컴파일 실측이 아닌 교육용 예제입니다. 반드시 실제 프로젝트에서 Play Mode를 검증하세요.

## 1. 신규 프로젝트에서 따라 하기

1. Package Manager에 `AI Navigation`, `Input System`을 설치합니다. Active Input Handling이 Input System을 포함하도록 설정합니다.
2. `Runtime`, `Editor`, `Dependencies_Day50_Day51`의 **C# 파일**을 원하는 `Assets/Day52/` 아래의 적절한 Runtime / Editor 폴더에 복사합니다. `Editor` 파일은 **반드시 이름이 Editor인 하위 폴더**에 배치합니다.
3. 컴파일 오류가 없는지 Console을 확인합니다.
4. Unity 메뉴 **Tools > Unity Codex > Day52 > Create NavMesh AI Lab**을 실행합니다.
5. 새 Scene이 `Assets/UnityCodexDay52/Scenes`에 저장됩니다. 자동 Bake 성공 여부와 Enemy의 `NavMeshAgent.isOnNavMesh`를 확인합니다.
6. Play Mode: `WASD` Player 이동, `O` 문 여닫기, `F1` AI HUD.
7. **Tools > Unity Codex > Day52 > Validate Active Scene**로 정적 구성을 검사합니다.

## 2. 기존 50~51일차 프로젝트에 적용

기존 프로젝트의 `Day50EnemyPerception`, `Day50PatrolRoute`, `Day50PlayerMover`, `Day50FollowCamera`, `Day51EnemyAttack`, `Day51EnemyHealth`, `Day51PlayerHealth`, `IDay51Damageable`, `Day51EnemyState`가 이미 있으면 `Dependencies_Day50_Day51` 코드를 **다시 복사하지 마세요**. 동일 이름 클래스가 중복 선언되어 컴파일 오류가 발생합니다.

- Enemy에서 **기존 `Day51EnemyBrain`(및 `Day50EnemyBrain`)을 제거**합니다.
- Enemy의 기존 **`Day50EnemyNavigation`도 제거**하거나 사용하지 않습니다. 대신 `Day52NavAgent`를 추가합니다.
- `Day52EnemyBrain`을 부착합니다. `RequireComponent`에 의해 NavAgent, Perception, PatrolRoute, Attack, Health가 필요합니다.
- 선택적으로 `Day52AIDiagnostics`와 `Day52EnemyAnimatorBridge`를 추가합니다.
- Animator를 연결할 경우 `Speed`(Float), `Dead`(Bool) 파라미터가 있어야 합니다.
- AI Navigation 패키지에 포함된 `NavMeshSurface`를 사용하고 Bake를 진행합니다.

**금지:** 50/51/52 Brain을 동일 Enemy에 동시에 부착하면 상태별 경로 제어가 충돌합니다. 또한 NavMeshAgent와 NavMeshObstacle을 동일 GameObject에 함께 넣지 마세요.

## 3. 설계 책임

| 컴포넌트 | 역할 |
|---|---|
| Day52EnemyBrain | 전이: Patrol / Chase / Attack / Return / Dead, 마지막 목격 지점 |
| Day52NavAgent | NavMeshAgent 설정, Repath 주기 제한, SamplePosition, 경로 실패·정체 복구 |
| Day50EnemyPerception | 거리·시야각·LOS 및 Target 검색 |
| Day50PatrolRoute | Patrol Waypoint와 복귀 후보 |
| Day51EnemyAttack | 공격 쿨다운, Windup, 데미지 |
| Day51EnemyHealth | HP 및 Died 이벤트 |
| Day52AIDiagnostics | F1 HUD / Gizmos 경로 표시 |
| Day52DoorObstacleToggle | O 키 동적 문, NavMeshObstacle carving |

## 4. 시작값(최적값 아님)

- Repath Interval: **0.30s**
- Target Move Threshold: **0.55m**
- NavMesh Sample Radius: **1.5m**
- Stuck Timeout: **2.25s**
- Retry Delay: **0.65s**
- Lost Target Delay: **1.5s**

많은 Enemy를 동시 실행하면 Agent 수, 경로 계산 요청 수, 장애물 수에 따라 값을 조절하세요. 목표가 NavMesh 위에 있어도 도달 경로가 없을 수 있으며 SamplePosition만으로 도달 가능성을 보증하지 않습니다.

## 5. 권장 검증 순서

1. 메뉴에서 Lab Scene 생성 후 Console 오류 확인
2. Enemy가 Waypoint를 순찰하는지 확인
3. Player 접근 → Chase / Attack 확인
4. Player를 가려 Return 복귀 확인
5. `O`로 Carving 문 토글 → Scene Gizmo 경로 변경 확인
6. F1 HUD에서 pathPending / PathStatus / hasPath / Repath count 확인
7. 비정상 목적지 / 통로 폭 / 장애물 밀도를 바꿔 경로 실패 재현
8. 적 HP 0 → Dead 이후 모든 경로·공격 중단 확인
9. Profiler를 이용해 변경 전후 `SetDestination` 빈도·성능 비교

## 6. Codex 작업 지시

`Docs/Codex_Prompts.md`의 프롬프트를 사용합니다. **실행하지 않은 Play Mode·Editor 검증을 완료라고 보고하면 안 됩니다.** 변경 범위와 검증 결과, `git diff`, 남은 위험 항목을 함께 요청합니다.

## 공식 문서

- AI Navigation: https://docs.unity3d.com/6000.0/Documentation/Manual/com.unity.ai.navigation.html
- NavMeshAgent.SetDestination: https://docs.unity3d.com/ScriptReference/AI.NavMeshAgent.SetDestination.html
- NavMeshObstacle: https://docs.unity3d.com/ScriptReference/AI.NavMeshObstacle.html
